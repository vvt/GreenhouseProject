﻿namespace GreenHouseConfig
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.imglToolbarImages = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.miFile = new System.Windows.Forms.ToolStripMenuItem();
            this.miExit = new System.Windows.Forms.ToolStripMenuItem();
            this.miConfiguration = new System.Windows.Forms.ToolStripMenuItem();
            this.miPlayPause = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.miDelta = new System.Windows.Forms.ToolStripMenuItem();
            this.miReservationSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miUniversalSensors = new System.Windows.Forms.ToolStripMenuItem();
            this.miTimers = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.miDateTime = new System.Windows.Forms.ToolStripMenuItem();
            this.miRestart = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.miFirmwareInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.miSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miMonitorScreenSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miPinsUsed = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbToolBar = new System.Windows.Forms.ToolStrip();
            this.tbbConnectBtn = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsiCOMConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.miRescanPorts = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbPlayPause = new System.Windows.Forms.ToolStripButton();
            this.tbRestartButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSetControllerTime = new System.Windows.Forms.ToolStripButton();
            this.tbDelta = new System.Windows.Forms.ToolStripButton();
            this.tbReservationSettings = new System.Windows.Forms.ToolStripButton();
            this.tbTimers = new System.Windows.Forms.ToolStripButton();
            this.tbUniversalSensors = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tbMonitorScreenSettings = new System.Windows.Forms.ToolStripButton();
            this.tbPinsUsed = new System.Windows.Forms.ToolStripButton();
            this.tbFirmwareInfo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tbbAbout = new System.Windows.Forms.ToolStripButton();
            this.splitCont = new System.Windows.Forms.SplitContainer();
            this.tabCMain = new System.Windows.Forms.TabControl();
            this.tcStatPage = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblByte = new System.Windows.Forms.Label();
            this.lblFreeRam = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblUptime = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lblSetControllerTime = new System.Windows.Forms.LinkLabel();
            this.lblControllerTime = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblCelsiusController = new System.Windows.Forms.Label();
            this.lblTempController = new System.Windows.Forms.Label();
            this.thermController = new System.Windows.Forms.PictureBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.lblCelsius1 = new System.Windows.Forms.Label();
            this.lblTempInside = new System.Windows.Forms.Label();
            this.therm1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.lblCelsius2 = new System.Windows.Forms.Label();
            this.lblTempOutside = new System.Windows.Forms.Label();
            this.therm2 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tbWindowPosition = new System.Windows.Forms.TrackBar();
            this.lblCurrentWindowState = new System.Windows.Forms.Label();
            this.pbWindowState = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.tbSetWorkMode = new System.Windows.Forms.TrackBar();
            this.lblWindowWorkMode = new System.Windows.Forms.Label();
            this.pbWindowWorkMode = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.dgvWindowsChannelsList = new System.Windows.Forms.DataGridView();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.tpTemperatureTab = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel14 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.lvTempData = new System.Windows.Forms.ListView();
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel87 = new System.Windows.Forms.Panel();
            this.label85 = new System.Windows.Forms.Label();
            this.panel88 = new System.Windows.Forms.Panel();
            this.lblWriteTempSettings = new System.Windows.Forms.LinkLabel();
            this.nudInterval = new System.Windows.Forms.NumericUpDown();
            this.cbCreateTemperatureRules = new System.Windows.Forms.CheckBox();
            this.nudTClose = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nudTOpen = new System.Windows.Forms.NumericUpDown();
            this.cbTempSettings = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tpWateringTab = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel15 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel103 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.gbWateringSettings = new System.Windows.Forms.GroupBox();
            this.nudStartWateringTimeMinutes = new System.Windows.Forms.NumericUpDown();
            this.nudStartWateringTimeHours = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.nudWateringTime = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.gbWeekDays = new System.Windows.Forms.GroupBox();
            this.clbWeekDays = new System.Windows.Forms.CheckedListBox();
            this.cbWateringControl = new System.Windows.Forms.ComboBox();
            this.chbTurnOnPump = new System.Windows.Forms.CheckBox();
            this.dgvWateringChannels = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSaveWateringOptions = new System.Windows.Forms.LinkLabel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label87 = new System.Windows.Forms.Label();
            this.panel97 = new System.Windows.Forms.Panel();
            this.plWaterChannelsList = new System.Windows.Forms.Panel();
            this.panel99 = new System.Windows.Forms.Panel();
            this.label88 = new System.Windows.Forms.Label();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.lblWateringState = new System.Windows.Forms.Label();
            this.tbWatering = new System.Windows.Forms.TrackBar();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tbWateringMode = new System.Windows.Forms.TrackBar();
            this.lblWateringMode = new System.Windows.Forms.Label();
            this.panel96 = new System.Windows.Forms.Panel();
            this.label86 = new System.Windows.Forms.Label();
            this.tpLuminosity = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel13 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.lvLuminosity = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel78 = new System.Windows.Forms.Panel();
            this.label82 = new System.Windows.Forms.Label();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.lblSaveLuxSettings = new System.Windows.Forms.LinkLabel();
            this.cbWorkWithoutLightSensor = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.nudMinLux = new System.Windows.Forms.NumericUpDown();
            this.nudLuxHourFrom = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.nudLuxHourTo = new System.Windows.Forms.NumericUpDown();
            this.cbEnableLuminosityManage = new System.Windows.Forms.CheckBox();
            this.panel82 = new System.Windows.Forms.Panel();
            this.label83 = new System.Windows.Forms.Label();
            this.panel83 = new System.Windows.Forms.Panel();
            this.panel84 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.tbLux = new System.Windows.Forms.TrackBar();
            this.lblLuxMode = new System.Windows.Forms.Label();
            this.lblLuxState = new System.Windows.Forms.Label();
            this.tbLuxMode = new System.Windows.Forms.TrackBar();
            this.label24 = new System.Windows.Forms.Label();
            this.panel85 = new System.Windows.Forms.Panel();
            this.label84 = new System.Windows.Forms.Label();
            this.tpHumidity = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.lvHumiditySensorsData = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel22 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.tpSMSTab = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel12 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.label80 = new System.Windows.Forms.Label();
            this.cbGSMProvider = new System.Windows.Forms.ComboBox();
            this.tbPhoneNumber = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.pbNumberHelp = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.label79 = new System.Windows.Forms.Label();
            this.btnSmsList = new System.Windows.Forms.Button();
            this.btnAddSMS = new System.Windows.Forms.Button();
            this.btnSavePhoneNumber = new System.Windows.Forms.Button();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel75 = new System.Windows.Forms.Panel();
            this.label81 = new System.Windows.Forms.Label();
            this.tpWiFi = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel11 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.tbRouterPassword = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cbConnectToTheRouter = new System.Windows.Forms.CheckBox();
            this.panel65 = new System.Windows.Forms.Panel();
            this.label76 = new System.Windows.Forms.Label();
            this.tbRouterID = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel66 = new System.Windows.Forms.Panel();
            this.label78 = new System.Windows.Forms.Label();
            this.tbStationPassword = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel67 = new System.Windows.Forms.Panel();
            this.label75 = new System.Windows.Forms.Label();
            this.tbStationID = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.label77 = new System.Windows.Forms.Label();
            this.btnSaveWiFiSettings = new System.Windows.Forms.Button();
            this.btnQueryIP = new System.Windows.Forms.Button();
            this.tpRules = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel10 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.lblRuleStr = new System.Windows.Forms.Label();
            this.lvRulesList = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel60 = new System.Windows.Forms.Panel();
            this.label73 = new System.Windows.Forms.Label();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.btnDeleteRule = new System.Windows.Forms.Button();
            this.btnSaveRules = new System.Windows.Forms.Button();
            this.btnAddRule = new System.Windows.Forms.Button();
            this.btnLoadRules = new System.Windows.Forms.Button();
            this.lblComputeRulesmemory = new System.Windows.Forms.LinkLabel();
            this.btnEditRule = new System.Windows.Forms.Button();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.tbLogsDirectory = new System.Windows.Forms.TextBox();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.imglTabImages = new System.Windows.Forms.ImageList(this.components);
            this.label27 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.rbMonth = new System.Windows.Forms.RadioButton();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.rbWeek = new System.Windows.Forms.RadioButton();
            this.rbDay = new System.Windows.Forms.RadioButton();
            this.panel36 = new System.Windows.Forms.Panel();
            this.lblLoadLogs = new System.Windows.Forms.LinkLabel();
            this.lblCurrentLogLine = new System.Windows.Forms.Label();
            this.lblCurrentLogFileName = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.label56 = new System.Windows.Forms.Label();
            this.pbLogsProgress = new System.Windows.Forms.ProgressBar();
            this.label28 = new System.Windows.Forms.Label();
            this.tpWaterFlow = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.label66 = new System.Windows.Forms.Label();
            this.nudFlowCalibration1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblFlowInstant1 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblFlowIncremental1 = new System.Windows.Forms.Label();
            this.panel51 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel52 = new System.Windows.Forms.Panel();
            this.label65 = new System.Windows.Forms.Label();
            this.nudFlowCalibration2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lblFlowInstant2 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblFlowIncremental2 = new System.Windows.Forms.Label();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.label67 = new System.Windows.Forms.Label();
            this.btnResetWaterflowData = new System.Windows.Forms.Button();
            this.btnSaveFlowSettings = new System.Windows.Forms.Button();
            this.tpMultipleCommands = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.lvCompositeCommandsList = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel56 = new System.Windows.Forms.Panel();
            this.label72 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.label68 = new System.Windows.Forms.Label();
            this.btnClearCCCommands = new System.Windows.Forms.Button();
            this.btnUploadCompositeCommands = new System.Windows.Forms.Button();
            this.btnDeleteCompositeCommand = new System.Windows.Forms.Button();
            this.btnEditCompositeCommand = new System.Windows.Forms.Button();
            this.btnAddCompositeCommand = new System.Windows.Forms.Button();
            this.tpDeltas = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.lvDeltasList = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel20 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.tpSoilMoisture = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lvSoilMoistureSensorsData = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel24 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.tpPH = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.lvPH = new System.Windows.Forms.ListView();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel39 = new System.Windows.Forms.Panel();
            this.label57 = new System.Windows.Forms.Label();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.lblPHMinusStatus = new System.Windows.Forms.Label();
            this.lblPHPlusStatus = new System.Windows.Forms.Label();
            this.lblPHMixPumpStatus = new System.Windows.Forms.Label();
            this.lblPHWaterPumpStatus = new System.Windows.Forms.Label();
            this.panel47 = new System.Windows.Forms.Panel();
            this.label60 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.nudPHVoltage10 = new System.Windows.Forms.NumericUpDown();
            this.nudPHVoltage7 = new System.Windows.Forms.NumericUpDown();
            this.nudPHVoltage4 = new System.Windows.Forms.NumericUpDown();
            this.panel41 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.nudPHCalibrationTemperature = new System.Windows.Forms.NumericUpDown();
            this.label42 = new System.Windows.Forms.Label();
            this.nudPHTempSensorIndex = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.nudPHCalibration = new System.Windows.Forms.NumericUpDown();
            this.panel43 = new System.Windows.Forms.Panel();
            this.label58 = new System.Windows.Forms.Label();
            this.panel44 = new System.Windows.Forms.Panel();
            this.label61 = new System.Windows.Forms.Label();
            this.nudPHReagentPumpTime = new System.Windows.Forms.NumericUpDown();
            this.label62 = new System.Windows.Forms.Label();
            this.nudPHHisteresis = new System.Windows.Forms.NumericUpDown();
            this.label63 = new System.Windows.Forms.Label();
            this.nudTargetPH = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.nudPHMixPumpTime = new System.Windows.Forms.NumericUpDown();
            this.lblSavePHSettings = new System.Windows.Forms.LinkLabel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label59 = new System.Windows.Forms.Label();
            this.tpIOT = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.lblSaveIoTSettings = new System.Windows.Forms.LinkLabel();
            this.tbThingSpeakChannelKey = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.nudIoTInterval = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.cbThingSpeakEnabled = new System.Windows.Forms.CheckBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.lbIOTAllSensors = new System.Windows.Forms.ListBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.lbIOTSelectedSensors = new System.Windows.Forms.ListBox();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lvLog = new System.Windows.Forms.ListView();
            this.logColumn1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.logColumn2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tmrUptime = new System.Windows.Forms.Timer(this.components);
            this.tmrFreeRam = new System.Windows.Forms.Timer(this.components);
            this.tmProcessCommandsTimer = new System.Windows.Forms.Timer(this.components);
            this.tmrTicks = new System.Windows.Forms.Timer(this.components);
            this.tmWaitDataTimer = new System.Windows.Forms.Timer(this.components);
            this.tmGetAllTempData = new System.Windows.Forms.Timer(this.components);
            this.ttPhoneNumberHint = new System.Windows.Forms.ToolTip(this.components);
            this.ttDefault = new System.Windows.Forms.ToolTip(this.components);
            this.selectFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.ttTempRulesHint = new System.Windows.Forms.ToolTip(this.components);
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.menuStrip1.SuspendLayout();
            this.tbToolBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitCont)).BeginInit();
            this.splitCont.Panel1.SuspendLayout();
            this.splitCont.Panel2.SuspendLayout();
            this.splitCont.SuspendLayout();
            this.tabCMain.SuspendLayout();
            this.tcStatPage.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermController)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.therm1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.therm2)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbWindowPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowState)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetWorkMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowWorkMode)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWindowsChannelsList)).BeginInit();
            this.panel18.SuspendLayout();
            this.tpTemperatureTab.SuspendLayout();
            this.flowLayoutPanel14.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel88.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTClose)).BeginInit();
            this.panel89.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTOpen)).BeginInit();
            this.tpWateringTab.SuspendLayout();
            this.flowLayoutPanel15.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel93.SuspendLayout();
            this.panel103.SuspendLayout();
            this.gbWateringSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTimeMinutes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTimeHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWateringTime)).BeginInit();
            this.gbWeekDays.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWateringChannels)).BeginInit();
            this.panel92.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel99.SuspendLayout();
            this.panel94.SuspendLayout();
            this.panel95.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbWatering)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWateringMode)).BeginInit();
            this.panel96.SuspendLayout();
            this.tpLuminosity.SuspendLayout();
            this.flowLayoutPanel13.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel81.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinLux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourTo)).BeginInit();
            this.panel82.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel84.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbLux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbLuxMode)).BeginInit();
            this.panel85.SuspendLayout();
            this.tpHumidity.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tpSMSTab.SuspendLayout();
            this.flowLayoutPanel12.SuspendLayout();
            this.panel70.SuspendLayout();
            this.panel71.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNumberHelp)).BeginInit();
            this.panel72.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel74.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel75.SuspendLayout();
            this.tpWiFi.SuspendLayout();
            this.flowLayoutPanel11.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel69.SuspendLayout();
            this.tpRules.SuspendLayout();
            this.flowLayoutPanel10.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel63.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.tpWaterFlow.SuspendLayout();
            this.flowLayoutPanel8.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.tpMultipleCommands.SuspendLayout();
            this.flowLayoutPanel9.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel58.SuspendLayout();
            this.tpDeltas.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tpSoilMoisture.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tpPH.SuspendLayout();
            this.flowLayoutPanel7.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel40.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage4)).BeginInit();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibrationTemperature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHTempSensorIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibration)).BeginInit();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHReagentPumpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHHisteresis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTargetPH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHMixPumpTime)).BeginInit();
            this.panel45.SuspendLayout();
            this.tpIOT.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIoTInterval)).BeginInit();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 708);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusBar";
            // 
            // imglToolbarImages
            // 
            this.imglToolbarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglToolbarImages.ImageStream")));
            this.imglToolbarImages.TransparentColor = System.Drawing.Color.Transparent;
            this.imglToolbarImages.Images.SetKeyName(0, "connect_no.png");
            this.imglToolbarImages.Images.SetKeyName(1, "connect_established.png");
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFile,
            this.miConfiguration,
            this.miSettings,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // miFile
            // 
            this.miFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miExit});
            this.miFile.Name = "miFile";
            this.miFile.Size = new System.Drawing.Size(48, 20);
            this.miFile.Text = "Файл";
            // 
            // miExit
            // 
            this.miExit.Name = "miExit";
            this.miExit.Size = new System.Drawing.Size(108, 22);
            this.miExit.Text = "Выход";
            this.miExit.Click += new System.EventHandler(this.miExit_Click);
            // 
            // miConfiguration
            // 
            this.miConfiguration.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miPlayPause,
            this.toolStripMenuItem4,
            this.miDelta,
            this.miReservationSettings,
            this.miUniversalSensors,
            this.miTimers,
            this.toolStripMenuItem3,
            this.miDateTime,
            this.miRestart,
            this.toolStripMenuItem5,
            this.miFirmwareInfo});
            this.miConfiguration.Name = "miConfiguration";
            this.miConfiguration.Size = new System.Drawing.Size(85, 20);
            this.miConfiguration.Text = "Управление";
            // 
            // miPlayPause
            // 
            this.miPlayPause.Enabled = false;
            this.miPlayPause.Name = "miPlayPause";
            this.miPlayPause.Size = new System.Drawing.Size(282, 22);
            this.miPlayPause.Text = "Стоп";
            this.miPlayPause.Click += new System.EventHandler(this.tbPlayPause_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(279, 6);
            // 
            // miDelta
            // 
            this.miDelta.Enabled = false;
            this.miDelta.Name = "miDelta";
            this.miDelta.Size = new System.Drawing.Size(282, 22);
            this.miDelta.Text = "Список виртуальных датчиков дельт";
            this.miDelta.Click += new System.EventHandler(this.tbDelta_Click);
            // 
            // miReservationSettings
            // 
            this.miReservationSettings.Enabled = false;
            this.miReservationSettings.Name = "miReservationSettings";
            this.miReservationSettings.Size = new System.Drawing.Size(282, 22);
            this.miReservationSettings.Text = "Настройки резервирования датчиков";
            this.miReservationSettings.Visible = false;
            this.miReservationSettings.Click += new System.EventHandler(this.miReservationSettings_Click);
            // 
            // miUniversalSensors
            // 
            this.miUniversalSensors.Enabled = false;
            this.miUniversalSensors.Name = "miUniversalSensors";
            this.miUniversalSensors.Size = new System.Drawing.Size(282, 22);
            this.miUniversalSensors.Text = "Регистрация универсальных модулей";
            this.miUniversalSensors.Click += new System.EventHandler(this.miUniversalSensors_Click);
            // 
            // miTimers
            // 
            this.miTimers.Enabled = false;
            this.miTimers.Name = "miTimers";
            this.miTimers.Size = new System.Drawing.Size(282, 22);
            this.miTimers.Text = "Периодические таймеры";
            this.miTimers.Visible = false;
            this.miTimers.Click += new System.EventHandler(this.miTimers_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(279, 6);
            // 
            // miDateTime
            // 
            this.miDateTime.Enabled = false;
            this.miDateTime.Name = "miDateTime";
            this.miDateTime.Size = new System.Drawing.Size(282, 22);
            this.miDateTime.Text = "Установить дату/время контроллера";
            this.miDateTime.Click += new System.EventHandler(this.btnSetControllerTime_Click);
            // 
            // miRestart
            // 
            this.miRestart.Enabled = false;
            this.miRestart.Name = "miRestart";
            this.miRestart.Size = new System.Drawing.Size(282, 22);
            this.miRestart.Text = "Перезагрузить контроллер";
            this.miRestart.Click += new System.EventHandler(this.tbRestartButton_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(279, 6);
            // 
            // miFirmwareInfo
            // 
            this.miFirmwareInfo.Enabled = false;
            this.miFirmwareInfo.Name = "miFirmwareInfo";
            this.miFirmwareInfo.Size = new System.Drawing.Size(282, 22);
            this.miFirmwareInfo.Text = "Информация о прошивке";
            this.miFirmwareInfo.Click += new System.EventHandler(this.miFirmwareInfo_Click);
            // 
            // miSettings
            // 
            this.miSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miMonitorScreenSettings,
            this.miPinsUsed});
            this.miSettings.Name = "miSettings";
            this.miSettings.Size = new System.Drawing.Size(79, 20);
            this.miSettings.Text = "Настройки";
            // 
            // miMonitorScreenSettings
            // 
            this.miMonitorScreenSettings.Name = "miMonitorScreenSettings";
            this.miMonitorScreenSettings.Size = new System.Drawing.Size(254, 22);
            this.miMonitorScreenSettings.Text = "Настройки экрана \"Монитор\"";
            this.miMonitorScreenSettings.Click += new System.EventHandler(this.miMonitorScreenSettings_Click);
            // 
            // miPinsUsed
            // 
            this.miPinsUsed.Enabled = false;
            this.miPinsUsed.Name = "miPinsUsed";
            this.miPinsUsed.Size = new System.Drawing.Size(254, 22);
            this.miPinsUsed.Text = "Информация по занятым пинам";
            this.miPinsUsed.Click += new System.EventHandler(this.miPinsUsed_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.helpToolStripMenuItem.Text = "Помощь";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.aboutToolStripMenuItem.Text = "О программе";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // tbToolBar
            // 
            this.tbToolBar.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.tbToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbbConnectBtn,
            this.tbPlayPause,
            this.tbRestartButton,
            this.toolStripSeparator2,
            this.btnSetControllerTime,
            this.tbDelta,
            this.tbReservationSettings,
            this.tbTimers,
            this.tbUniversalSensors,
            this.toolStripSeparator3,
            this.tbMonitorScreenSettings,
            this.tbPinsUsed,
            this.tbFirmwareInfo,
            this.toolStripSeparator1,
            this.tbbAbout});
            this.tbToolBar.Location = new System.Drawing.Point(0, 24);
            this.tbToolBar.Name = "tbToolBar";
            this.tbToolBar.Size = new System.Drawing.Size(1008, 70);
            this.tbToolBar.TabIndex = 2;
            this.tbToolBar.Paint += new System.Windows.Forms.PaintEventHandler(this.tbToolBar_Paint);
            // 
            // tbbConnectBtn
            // 
            this.tbbConnectBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsiCOMConnection});
            this.tbbConnectBtn.Image = ((System.Drawing.Image)(resources.GetObject("tbbConnectBtn.Image")));
            this.tbbConnectBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbbConnectBtn.Name = "tbbConnectBtn";
            this.tbbConnectBtn.Size = new System.Drawing.Size(79, 67);
            this.tbbConnectBtn.Text = "Соединить";
            this.tbbConnectBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbbConnectBtn.ToolTipText = "Установить соединение с выбранным портом";
            // 
            // tsiCOMConnection
            // 
            this.tsiCOMConnection.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miRescanPorts,
            this.toolStripMenuItem2});
            this.tsiCOMConnection.Name = "tsiCOMConnection";
            this.tsiCOMConnection.Size = new System.Drawing.Size(226, 22);
            this.tsiCOMConnection.Text = "Соединение по COM-порту";
            // 
            // miRescanPorts
            // 
            this.miRescanPorts.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.miRescanPorts.Name = "miRescanPorts";
            this.miRescanPorts.Size = new System.Drawing.Size(176, 22);
            this.miRescanPorts.Tag = "1";
            this.miRescanPorts.Text = "Перечитать порты";
            this.miRescanPorts.Click += new System.EventHandler(this.miRescanPorts_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(173, 6);
            this.toolStripMenuItem2.Tag = "1";
            // 
            // tbPlayPause
            // 
            this.tbPlayPause.Enabled = false;
            this.tbPlayPause.Image = ((System.Drawing.Image)(resources.GetObject("tbPlayPause.Image")));
            this.tbPlayPause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbPlayPause.Name = "tbPlayPause";
            this.tbPlayPause.Size = new System.Drawing.Size(52, 67);
            this.tbPlayPause.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbPlayPause.Click += new System.EventHandler(this.tbPlayPause_Click);
            // 
            // tbRestartButton
            // 
            this.tbRestartButton.Enabled = false;
            this.tbRestartButton.Image = global::GreenHouseConfig.Properties.Resources.system_restart;
            this.tbRestartButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tbRestartButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbRestartButton.Name = "tbRestartButton";
            this.tbRestartButton.Size = new System.Drawing.Size(53, 67);
            this.tbRestartButton.Text = "Рестарт";
            this.tbRestartButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbRestartButton.ToolTipText = "Перезагрузить контроллер";
            this.tbRestartButton.Click += new System.EventHandler(this.tbRestartButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 70);
            // 
            // btnSetControllerTime
            // 
            this.btnSetControllerTime.Enabled = false;
            this.btnSetControllerTime.Image = ((System.Drawing.Image)(resources.GetObject("btnSetControllerTime.Image")));
            this.btnSetControllerTime.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSetControllerTime.Name = "btnSetControllerTime";
            this.btnSetControllerTime.Size = new System.Drawing.Size(75, 67);
            this.btnSetControllerTime.Text = "Дата/время";
            this.btnSetControllerTime.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSetControllerTime.ToolTipText = "Установить текущее время в контроллере";
            this.btnSetControllerTime.Click += new System.EventHandler(this.btnSetControllerTime_Click);
            // 
            // tbDelta
            // 
            this.tbDelta.Enabled = false;
            this.tbDelta.Image = ((System.Drawing.Image)(resources.GetObject("tbDelta.Image")));
            this.tbDelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbDelta.Name = "tbDelta";
            this.tbDelta.Size = new System.Drawing.Size(70, 67);
            this.tbDelta.Text = "   Дельты   ";
            this.tbDelta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbDelta.ToolTipText = "Список виртуальных датчиков дельт";
            this.tbDelta.Visible = false;
            this.tbDelta.Click += new System.EventHandler(this.tbDelta_Click);
            // 
            // tbReservationSettings
            // 
            this.tbReservationSettings.Enabled = false;
            this.tbReservationSettings.Image = ((System.Drawing.Image)(resources.GetObject("tbReservationSettings.Image")));
            this.tbReservationSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbReservationSettings.Name = "tbReservationSettings";
            this.tbReservationSettings.Size = new System.Drawing.Size(101, 67);
            this.tbReservationSettings.Text = "Резервирование";
            this.tbReservationSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbReservationSettings.ToolTipText = "Резервирование датчиков";
            this.tbReservationSettings.Visible = false;
            this.tbReservationSettings.Click += new System.EventHandler(this.miReservationSettings_Click);
            // 
            // tbTimers
            // 
            this.tbTimers.Enabled = false;
            this.tbTimers.Image = ((System.Drawing.Image)(resources.GetObject("tbTimers.Image")));
            this.tbTimers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbTimers.Name = "tbTimers";
            this.tbTimers.Size = new System.Drawing.Size(62, 67);
            this.tbTimers.Text = "Таймеры";
            this.tbTimers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbTimers.ToolTipText = "Настройки периодических таймеров";
            this.tbTimers.Visible = false;
            this.tbTimers.Click += new System.EventHandler(this.miTimers_Click);
            // 
            // tbUniversalSensors
            // 
            this.tbUniversalSensors.Enabled = false;
            this.tbUniversalSensors.Image = ((System.Drawing.Image)(resources.GetObject("tbUniversalSensors.Image")));
            this.tbUniversalSensors.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbUniversalSensors.Name = "tbUniversalSensors";
            this.tbUniversalSensors.Size = new System.Drawing.Size(67, 67);
            this.tbUniversalSensors.Text = "  Модули  ";
            this.tbUniversalSensors.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbUniversalSensors.ToolTipText = "Регистрация универсальных модулей";
            this.tbUniversalSensors.Click += new System.EventHandler(this.miUniversalSensors_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 70);
            // 
            // tbMonitorScreenSettings
            // 
            this.tbMonitorScreenSettings.Image = ((System.Drawing.Image)(resources.GetObject("tbMonitorScreenSettings.Image")));
            this.tbMonitorScreenSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbMonitorScreenSettings.Name = "tbMonitorScreenSettings";
            this.tbMonitorScreenSettings.Size = new System.Drawing.Size(108, 67);
            this.tbMonitorScreenSettings.Text = "Экран \"Монитор\"";
            this.tbMonitorScreenSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbMonitorScreenSettings.ToolTipText = "Настройки экрана \"Монитор\"";
            this.tbMonitorScreenSettings.Click += new System.EventHandler(this.miMonitorScreenSettings_Click);
            // 
            // tbPinsUsed
            // 
            this.tbPinsUsed.Enabled = false;
            this.tbPinsUsed.Image = ((System.Drawing.Image)(resources.GetObject("tbPinsUsed.Image")));
            this.tbPinsUsed.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbPinsUsed.Name = "tbPinsUsed";
            this.tbPinsUsed.Size = new System.Drawing.Size(90, 67);
            this.tbPinsUsed.Text = "Занятые пины";
            this.tbPinsUsed.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbPinsUsed.ToolTipText = "Информация по занятым пинам";
            this.tbPinsUsed.Click += new System.EventHandler(this.miPinsUsed_Click);
            // 
            // tbFirmwareInfo
            // 
            this.tbFirmwareInfo.Enabled = false;
            this.tbFirmwareInfo.Image = ((System.Drawing.Image)(resources.GetObject("tbFirmwareInfo.Image")));
            this.tbFirmwareInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbFirmwareInfo.Name = "tbFirmwareInfo";
            this.tbFirmwareInfo.Size = new System.Drawing.Size(80, 67);
            this.tbFirmwareInfo.Text = "О прошивке";
            this.tbFirmwareInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbFirmwareInfo.ToolTipText = "Показать информацию о прошивке";
            this.tbFirmwareInfo.Click += new System.EventHandler(this.miFirmwareInfo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 70);
            // 
            // tbbAbout
            // 
            this.tbbAbout.Image = global::GreenHouseConfig.Properties.Resources.information;
            this.tbbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbbAbout.Name = "tbbAbout";
            this.tbbAbout.Size = new System.Drawing.Size(86, 67);
            this.tbbAbout.Text = "О программе";
            this.tbbAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbbAbout.ToolTipText = "Показать окно информации о программе";
            this.tbbAbout.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // splitCont
            // 
            this.splitCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitCont.Location = new System.Drawing.Point(0, 94);
            this.splitCont.Name = "splitCont";
            this.splitCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitCont.Panel1
            // 
            this.splitCont.Panel1.Controls.Add(this.tabCMain);
            this.splitCont.Panel1MinSize = 100;
            // 
            // splitCont.Panel2
            // 
            this.splitCont.Panel2.Controls.Add(this.tabControl1);
            this.splitCont.Panel2MinSize = 100;
            this.splitCont.Size = new System.Drawing.Size(1008, 614);
            this.splitCont.SplitterDistance = 463;
            this.splitCont.TabIndex = 3;
            // 
            // tabCMain
            // 
            this.tabCMain.Controls.Add(this.tcStatPage);
            this.tabCMain.Controls.Add(this.tpTemperatureTab);
            this.tabCMain.Controls.Add(this.tpWateringTab);
            this.tabCMain.Controls.Add(this.tpLuminosity);
            this.tabCMain.Controls.Add(this.tpHumidity);
            this.tabCMain.Controls.Add(this.tpSMSTab);
            this.tabCMain.Controls.Add(this.tpWiFi);
            this.tabCMain.Controls.Add(this.tpRules);
            this.tabCMain.Controls.Add(this.tpLog);
            this.tabCMain.Controls.Add(this.tpWaterFlow);
            this.tabCMain.Controls.Add(this.tpMultipleCommands);
            this.tabCMain.Controls.Add(this.tpDeltas);
            this.tabCMain.Controls.Add(this.tpSoilMoisture);
            this.tabCMain.Controls.Add(this.tpPH);
            this.tabCMain.Controls.Add(this.tpIOT);
            this.tabCMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCMain.HotTrack = true;
            this.tabCMain.ImageList = this.imglTabImages;
            this.tabCMain.ItemSize = new System.Drawing.Size(78, 32);
            this.tabCMain.Location = new System.Drawing.Point(0, 0);
            this.tabCMain.Margin = new System.Windows.Forms.Padding(10);
            this.tabCMain.Name = "tabCMain";
            this.tabCMain.SelectedIndex = 0;
            this.tabCMain.Size = new System.Drawing.Size(1008, 463);
            this.tabCMain.TabIndex = 0;
            // 
            // tcStatPage
            // 
            this.tcStatPage.BackColor = System.Drawing.Color.White;
            this.tcStatPage.Controls.Add(this.flowLayoutPanel1);
            this.tcStatPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tcStatPage.ImageIndex = 0;
            this.tcStatPage.Location = new System.Drawing.Point(4, 36);
            this.tcStatPage.Margin = new System.Windows.Forms.Padding(10);
            this.tcStatPage.Name = "tcStatPage";
            this.tcStatPage.Padding = new System.Windows.Forms.Padding(3);
            this.tcStatPage.Size = new System.Drawing.Size(1000, 423);
            this.tcStatPage.TabIndex = 0;
            this.tcStatPage.Text = "Монитор";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.panel2);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.panel13);
            this.flowLayoutPanel1.Controls.Add(this.panel15);
            this.flowLayoutPanel1.Controls.Add(this.panel5);
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Controls.Add(this.panel9);
            this.flowLayoutPanel1.Controls.Add(this.panel11);
            this.flowLayoutPanel1.Controls.Add(this.panel17);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel1.TabIndex = 24;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblByte);
            this.panel2.Controls.Add(this.lblFreeRam);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(13, 20);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 118);
            this.panel2.TabIndex = 1;
            // 
            // lblByte
            // 
            this.lblByte.AutoSize = true;
            this.lblByte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblByte.ForeColor = System.Drawing.Color.Black;
            this.lblByte.Location = new System.Drawing.Point(125, 55);
            this.lblByte.Name = "lblByte";
            this.lblByte.Size = new System.Drawing.Size(49, 20);
            this.lblByte.TabIndex = 13;
            this.lblByte.Text = "байт";
            this.lblByte.Visible = false;
            // 
            // lblFreeRam
            // 
            this.lblFreeRam.AutoSize = true;
            this.lblFreeRam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFreeRam.ForeColor = System.Drawing.Color.White;
            this.lblFreeRam.Location = new System.Drawing.Point(64, 55);
            this.lblFreeRam.Name = "lblFreeRam";
            this.lblFreeRam.Size = new System.Drawing.Size(126, 20);
            this.lblFreeRam.TabIndex = 12;
            this.lblFreeRam.Text = "<нет данных>";
            this.lblFreeRam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(8, 41);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(48, 48);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel3.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel3.Controls.Add(this.label50);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(3);
            this.panel3.Size = new System.Drawing.Size(198, 26);
            this.panel3.TabIndex = 0;
            // 
            // label50
            // 
            this.label50.Dock = System.Windows.Forms.DockStyle.Top;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label50.ForeColor = System.Drawing.Color.Beige;
            this.label50.Location = new System.Drawing.Point(3, 3);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(192, 20);
            this.label50.TabIndex = 1;
            this.label50.Text = "Память";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblUptime);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Location = new System.Drawing.Point(226, 20);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 118);
            this.panel1.TabIndex = 0;
            // 
            // lblUptime
            // 
            this.lblUptime.AutoSize = true;
            this.lblUptime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUptime.ForeColor = System.Drawing.Color.White;
            this.lblUptime.Location = new System.Drawing.Point(58, 55);
            this.lblUptime.Name = "lblUptime";
            this.lblUptime.Size = new System.Drawing.Size(126, 20);
            this.lblUptime.TabIndex = 10;
            this.lblUptime.Text = "<нет данных>";
            this.lblUptime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(8, 41);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3);
            this.panel4.Size = new System.Drawing.Size(198, 26);
            this.panel4.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Beige;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Время работы";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.SteelBlue;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.lblSetControllerTime);
            this.panel13.Controls.Add(this.lblControllerTime);
            this.panel13.Controls.Add(this.pictureBox6);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Location = new System.Drawing.Point(439, 20);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(200, 118);
            this.panel13.TabIndex = 6;
            // 
            // lblSetControllerTime
            // 
            this.lblSetControllerTime.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblSetControllerTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSetControllerTime.ForeColor = System.Drawing.Color.White;
            this.lblSetControllerTime.LinkColor = System.Drawing.Color.White;
            this.lblSetControllerTime.Location = new System.Drawing.Point(0, 93);
            this.lblSetControllerTime.Name = "lblSetControllerTime";
            this.lblSetControllerTime.Padding = new System.Windows.Forms.Padding(5);
            this.lblSetControllerTime.Size = new System.Drawing.Size(198, 23);
            this.lblSetControllerTime.TabIndex = 25;
            this.lblSetControllerTime.TabStop = true;
            this.lblSetControllerTime.Text = "Установить";
            this.lblSetControllerTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblSetControllerTime, "Установить дату/время в контроллере");
            this.lblSetControllerTime.VisitedLinkColor = System.Drawing.Color.White;
            this.lblSetControllerTime.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSetControllerTime_LinkClicked);
            // 
            // lblControllerTime
            // 
            this.lblControllerTime.AutoSize = true;
            this.lblControllerTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblControllerTime.ForeColor = System.Drawing.Color.White;
            this.lblControllerTime.Location = new System.Drawing.Point(62, 55);
            this.lblControllerTime.Name = "lblControllerTime";
            this.lblControllerTime.Size = new System.Drawing.Size(126, 20);
            this.lblControllerTime.TabIndex = 10;
            this.lblControllerTime.Text = "<нет данных>";
            this.lblControllerTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.InitialImage = null;
            this.pictureBox6.Location = new System.Drawing.Point(8, 41);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(48, 48);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 9;
            this.pictureBox6.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.AutoSize = true;
            this.panel14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel14.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel14.Controls.Add(this.label4);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Padding = new System.Windows.Forms.Padding(3);
            this.panel14.Size = new System.Drawing.Size(198, 26);
            this.panel14.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Beige;
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Время прибора";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.SteelBlue;
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.lblCelsiusController);
            this.panel15.Controls.Add(this.lblTempController);
            this.panel15.Controls.Add(this.thermController);
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Location = new System.Drawing.Point(652, 20);
            this.panel15.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(200, 118);
            this.panel15.TabIndex = 7;
            // 
            // lblCelsiusController
            // 
            this.lblCelsiusController.AutoSize = true;
            this.lblCelsiusController.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCelsiusController.ForeColor = System.Drawing.Color.Black;
            this.lblCelsiusController.Location = new System.Drawing.Point(126, 55);
            this.lblCelsiusController.Name = "lblCelsiusController";
            this.lblCelsiusController.Size = new System.Drawing.Size(27, 20);
            this.lblCelsiusController.TabIndex = 14;
            this.lblCelsiusController.Text = "°C";
            this.lblCelsiusController.Visible = false;
            // 
            // lblTempController
            // 
            this.lblTempController.AutoSize = true;
            this.lblTempController.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTempController.ForeColor = System.Drawing.Color.White;
            this.lblTempController.Location = new System.Drawing.Point(58, 55);
            this.lblTempController.Name = "lblTempController";
            this.lblTempController.Size = new System.Drawing.Size(126, 20);
            this.lblTempController.TabIndex = 11;
            this.lblTempController.Text = "<нет данных>";
            this.lblTempController.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // thermController
            // 
            this.thermController.Image = global::GreenHouseConfig.Properties.Resources.bluetherm;
            this.thermController.InitialImage = null;
            this.thermController.Location = new System.Drawing.Point(-1, 32);
            this.thermController.Name = "thermController";
            this.thermController.Size = new System.Drawing.Size(64, 64);
            this.thermController.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.thermController.TabIndex = 5;
            this.thermController.TabStop = false;
            // 
            // panel16
            // 
            this.panel16.AutoSize = true;
            this.panel16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel16.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel16.Controls.Add(this.label6);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Padding = new System.Windows.Forms.Padding(3);
            this.panel16.Size = new System.Drawing.Size(198, 26);
            this.panel16.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Beige;
            this.label6.Location = new System.Drawing.Point(3, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Т прибора";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.linkLabel1);
            this.panel5.Controls.Add(this.lblCelsius1);
            this.panel5.Controls.Add(this.lblTempInside);
            this.panel5.Controls.Add(this.therm1);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(13, 151);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 118);
            this.panel5.TabIndex = 2;
            // 
            // linkLabel1
            // 
            this.linkLabel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkLabel1.ForeColor = System.Drawing.Color.White;
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(0, 93);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Padding = new System.Windows.Forms.Padding(5);
            this.linkLabel1.Size = new System.Drawing.Size(198, 23);
            this.linkLabel1.TabIndex = 24;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Привязать датчик";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.linkLabel1, "Привязать датчик");
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.White;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DoShowMonitorSettings);
            // 
            // lblCelsius1
            // 
            this.lblCelsius1.AutoSize = true;
            this.lblCelsius1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCelsius1.ForeColor = System.Drawing.Color.Black;
            this.lblCelsius1.Location = new System.Drawing.Point(126, 55);
            this.lblCelsius1.Name = "lblCelsius1";
            this.lblCelsius1.Size = new System.Drawing.Size(27, 20);
            this.lblCelsius1.TabIndex = 14;
            this.lblCelsius1.Text = "°C";
            this.lblCelsius1.Visible = false;
            // 
            // lblTempInside
            // 
            this.lblTempInside.AutoSize = true;
            this.lblTempInside.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTempInside.ForeColor = System.Drawing.Color.White;
            this.lblTempInside.Location = new System.Drawing.Point(58, 55);
            this.lblTempInside.Name = "lblTempInside";
            this.lblTempInside.Size = new System.Drawing.Size(126, 20);
            this.lblTempInside.TabIndex = 11;
            this.lblTempInside.Text = "<нет данных>";
            this.lblTempInside.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // therm1
            // 
            this.therm1.Image = global::GreenHouseConfig.Properties.Resources.bluetherm;
            this.therm1.InitialImage = null;
            this.therm1.Location = new System.Drawing.Point(-1, 32);
            this.therm1.Name = "therm1";
            this.therm1.Size = new System.Drawing.Size(64, 64);
            this.therm1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.therm1.TabIndex = 5;
            this.therm1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel6.Controls.Add(this.label49);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(198, 26);
            this.panel6.TabIndex = 0;
            // 
            // label49
            // 
            this.label49.Dock = System.Windows.Forms.DockStyle.Top;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label49.ForeColor = System.Drawing.Color.Beige;
            this.label49.Location = new System.Drawing.Point(3, 3);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(192, 20);
            this.label49.TabIndex = 1;
            this.label49.Text = "Т внутри";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SteelBlue;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.linkLabel2);
            this.panel7.Controls.Add(this.lblCelsius2);
            this.panel7.Controls.Add(this.lblTempOutside);
            this.panel7.Controls.Add(this.therm2);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(226, 151);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(200, 118);
            this.panel7.TabIndex = 3;
            // 
            // linkLabel2
            // 
            this.linkLabel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkLabel2.ForeColor = System.Drawing.Color.White;
            this.linkLabel2.LinkColor = System.Drawing.Color.White;
            this.linkLabel2.Location = new System.Drawing.Point(0, 93);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Padding = new System.Windows.Forms.Padding(5);
            this.linkLabel2.Size = new System.Drawing.Size(198, 23);
            this.linkLabel2.TabIndex = 24;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Привязать датчик";
            this.linkLabel2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.linkLabel2, "Привязать датчик");
            this.linkLabel2.VisitedLinkColor = System.Drawing.Color.White;
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DoShowMonitorSettings);
            // 
            // lblCelsius2
            // 
            this.lblCelsius2.AutoSize = true;
            this.lblCelsius2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCelsius2.ForeColor = System.Drawing.Color.Black;
            this.lblCelsius2.Location = new System.Drawing.Point(125, 55);
            this.lblCelsius2.Name = "lblCelsius2";
            this.lblCelsius2.Size = new System.Drawing.Size(27, 20);
            this.lblCelsius2.TabIndex = 15;
            this.lblCelsius2.Text = "°C";
            this.lblCelsius2.Visible = false;
            // 
            // lblTempOutside
            // 
            this.lblTempOutside.AutoSize = true;
            this.lblTempOutside.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTempOutside.ForeColor = System.Drawing.Color.White;
            this.lblTempOutside.Location = new System.Drawing.Point(64, 55);
            this.lblTempOutside.Name = "lblTempOutside";
            this.lblTempOutside.Size = new System.Drawing.Size(126, 20);
            this.lblTempOutside.TabIndex = 12;
            this.lblTempOutside.Text = "<нет данных>";
            this.lblTempOutside.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // therm2
            // 
            this.therm2.Image = global::GreenHouseConfig.Properties.Resources.bluetherm;
            this.therm2.InitialImage = null;
            this.therm2.Location = new System.Drawing.Point(-6, 32);
            this.therm2.Name = "therm2";
            this.therm2.Size = new System.Drawing.Size(64, 64);
            this.therm2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.therm2.TabIndex = 6;
            this.therm2.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.AutoSize = true;
            this.panel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel8.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel8.Controls.Add(this.label3);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Padding = new System.Windows.Forms.Padding(3);
            this.panel8.Size = new System.Drawing.Size(198, 26);
            this.panel8.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Beige;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Т снаружи";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.SteelBlue;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.tbWindowPosition);
            this.panel9.Controls.Add(this.lblCurrentWindowState);
            this.panel9.Controls.Add(this.pbWindowState);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Location = new System.Drawing.Point(439, 151);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(251, 118);
            this.panel9.TabIndex = 4;
            // 
            // tbWindowPosition
            // 
            this.tbWindowPosition.BackColor = System.Drawing.Color.SteelBlue;
            this.tbWindowPosition.Enabled = false;
            this.tbWindowPosition.LargeChange = 1;
            this.tbWindowPosition.Location = new System.Drawing.Point(190, 32);
            this.tbWindowPosition.Maximum = 1;
            this.tbWindowPosition.Name = "tbWindowPosition";
            this.tbWindowPosition.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbWindowPosition.Size = new System.Drawing.Size(45, 58);
            this.tbWindowPosition.TabIndex = 22;
            this.tbWindowPosition.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWindowPosition.Scroll += new System.EventHandler(this.tbWindowPosition_Scroll);
            // 
            // lblCurrentWindowState
            // 
            this.lblCurrentWindowState.AutoSize = true;
            this.lblCurrentWindowState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCurrentWindowState.ForeColor = System.Drawing.Color.White;
            this.lblCurrentWindowState.Location = new System.Drawing.Point(58, 55);
            this.lblCurrentWindowState.Name = "lblCurrentWindowState";
            this.lblCurrentWindowState.Size = new System.Drawing.Size(126, 20);
            this.lblCurrentWindowState.TabIndex = 18;
            this.lblCurrentWindowState.Text = "<нет данных>";
            this.lblCurrentWindowState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbWindowState
            // 
            this.pbWindowState.Image = ((System.Drawing.Image)(resources.GetObject("pbWindowState.Image")));
            this.pbWindowState.InitialImage = null;
            this.pbWindowState.Location = new System.Drawing.Point(8, 42);
            this.pbWindowState.Name = "pbWindowState";
            this.pbWindowState.Size = new System.Drawing.Size(48, 48);
            this.pbWindowState.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWindowState.TabIndex = 16;
            this.pbWindowState.TabStop = false;
            // 
            // panel10
            // 
            this.panel10.AutoSize = true;
            this.panel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel10.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel10.Controls.Add(this.label52);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(3);
            this.panel10.Size = new System.Drawing.Size(249, 26);
            this.panel10.TabIndex = 0;
            // 
            // label52
            // 
            this.label52.Dock = System.Windows.Forms.DockStyle.Top;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label52.ForeColor = System.Drawing.Color.Beige;
            this.label52.Location = new System.Drawing.Point(3, 3);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(243, 20);
            this.label52.TabIndex = 1;
            this.label52.Text = "Окна";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.SteelBlue;
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.tbSetWorkMode);
            this.panel11.Controls.Add(this.lblWindowWorkMode);
            this.panel11.Controls.Add(this.pbWindowWorkMode);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Location = new System.Drawing.Point(703, 151);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(244, 118);
            this.panel11.TabIndex = 5;
            // 
            // tbSetWorkMode
            // 
            this.tbSetWorkMode.BackColor = System.Drawing.Color.SteelBlue;
            this.tbSetWorkMode.Enabled = false;
            this.tbSetWorkMode.LargeChange = 1;
            this.tbSetWorkMode.Location = new System.Drawing.Point(190, 31);
            this.tbSetWorkMode.Maximum = 1;
            this.tbSetWorkMode.Name = "tbSetWorkMode";
            this.tbSetWorkMode.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbSetWorkMode.Size = new System.Drawing.Size(45, 58);
            this.tbSetWorkMode.TabIndex = 23;
            this.tbSetWorkMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbSetWorkMode.Scroll += new System.EventHandler(this.tbSetWorkMode_Scroll);
            // 
            // lblWindowWorkMode
            // 
            this.lblWindowWorkMode.AutoSize = true;
            this.lblWindowWorkMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWindowWorkMode.ForeColor = System.Drawing.Color.White;
            this.lblWindowWorkMode.Location = new System.Drawing.Point(58, 55);
            this.lblWindowWorkMode.Name = "lblWindowWorkMode";
            this.lblWindowWorkMode.Size = new System.Drawing.Size(126, 20);
            this.lblWindowWorkMode.TabIndex = 21;
            this.lblWindowWorkMode.Text = "<нет данных>";
            this.lblWindowWorkMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbWindowWorkMode
            // 
            this.pbWindowWorkMode.Image = ((System.Drawing.Image)(resources.GetObject("pbWindowWorkMode.Image")));
            this.pbWindowWorkMode.InitialImage = null;
            this.pbWindowWorkMode.Location = new System.Drawing.Point(8, 42);
            this.pbWindowWorkMode.Name = "pbWindowWorkMode";
            this.pbWindowWorkMode.Size = new System.Drawing.Size(48, 48);
            this.pbWindowWorkMode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWindowWorkMode.TabIndex = 19;
            this.pbWindowWorkMode.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.AutoSize = true;
            this.panel12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel12.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel12.Controls.Add(this.label51);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(3);
            this.panel12.Size = new System.Drawing.Size(242, 26);
            this.panel12.TabIndex = 0;
            // 
            // label51
            // 
            this.label51.Dock = System.Windows.Forms.DockStyle.Top;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label51.ForeColor = System.Drawing.Color.Beige;
            this.label51.Location = new System.Drawing.Point(3, 3);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(236, 20);
            this.label51.TabIndex = 1;
            this.label51.Text = "Режим окон";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.SteelBlue;
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.dgvWindowsChannelsList);
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Location = new System.Drawing.Point(13, 282);
            this.panel17.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(280, 118);
            this.panel17.TabIndex = 8;
            // 
            // dgvWindowsChannelsList
            // 
            this.dgvWindowsChannelsList.AllowUserToAddRows = false;
            this.dgvWindowsChannelsList.AllowUserToDeleteRows = false;
            this.dgvWindowsChannelsList.AllowUserToResizeRows = false;
            this.dgvWindowsChannelsList.BackgroundColor = System.Drawing.Color.White;
            this.dgvWindowsChannelsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvWindowsChannelsList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvWindowsChannelsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWindowsChannelsList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column5,
            this.Column6});
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvWindowsChannelsList.DefaultCellStyle = dataGridViewCellStyle37;
            this.dgvWindowsChannelsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvWindowsChannelsList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvWindowsChannelsList.GridColor = System.Drawing.Color.LightGray;
            this.dgvWindowsChannelsList.Location = new System.Drawing.Point(0, 26);
            this.dgvWindowsChannelsList.MultiSelect = false;
            this.dgvWindowsChannelsList.Name = "dgvWindowsChannelsList";
            this.dgvWindowsChannelsList.ReadOnly = true;
            this.dgvWindowsChannelsList.RowHeadersVisible = false;
            this.dgvWindowsChannelsList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvWindowsChannelsList.RowTemplate.ReadOnly = true;
            this.dgvWindowsChannelsList.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvWindowsChannelsList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWindowsChannelsList.ShowEditingIcon = false;
            this.dgvWindowsChannelsList.Size = new System.Drawing.Size(278, 90);
            this.dgvWindowsChannelsList.TabIndex = 2;
            this.dgvWindowsChannelsList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvWindowsChannelsList_CellContentClick);
            // 
            // panel18
            // 
            this.panel18.AutoSize = true;
            this.panel18.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel18.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel18.Controls.Add(this.label5);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Padding = new System.Windows.Forms.Padding(3);
            this.panel18.Size = new System.Drawing.Size(278, 26);
            this.panel18.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Beige;
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(272, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Состояние окон";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpTemperatureTab
            // 
            this.tpTemperatureTab.BackColor = System.Drawing.Color.White;
            this.tpTemperatureTab.Controls.Add(this.flowLayoutPanel14);
            this.tpTemperatureTab.ImageIndex = 1;
            this.tpTemperatureTab.Location = new System.Drawing.Point(4, 36);
            this.tpTemperatureTab.Name = "tpTemperatureTab";
            this.tpTemperatureTab.Padding = new System.Windows.Forms.Padding(3);
            this.tpTemperatureTab.Size = new System.Drawing.Size(1000, 423);
            this.tpTemperatureTab.TabIndex = 1;
            this.tpTemperatureTab.Text = "Температура";
            // 
            // flowLayoutPanel14
            // 
            this.flowLayoutPanel14.AutoScroll = true;
            this.flowLayoutPanel14.Controls.Add(this.panel86);
            this.flowLayoutPanel14.Controls.Add(this.panel88);
            this.flowLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel14.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel14.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel14.Name = "flowLayoutPanel14";
            this.flowLayoutPanel14.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel14.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel14.TabIndex = 12;
            // 
            // panel86
            // 
            this.panel86.BackColor = System.Drawing.Color.SteelBlue;
            this.panel86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel86.Controls.Add(this.panel90);
            this.panel86.Controls.Add(this.panel87);
            this.panel86.Location = new System.Drawing.Point(13, 20);
            this.panel86.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(287, 216);
            this.panel86.TabIndex = 1;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.lvTempData);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel90.Location = new System.Drawing.Point(0, 26);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(285, 188);
            this.panel90.TabIndex = 1;
            // 
            // lvTempData
            // 
            this.lvTempData.BackColor = System.Drawing.Color.White;
            this.lvTempData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvTempData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader19,
            this.columnHeader20});
            this.lvTempData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvTempData.ForeColor = System.Drawing.Color.Black;
            this.lvTempData.FullRowSelect = true;
            this.lvTempData.GridLines = true;
            this.lvTempData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvTempData.Location = new System.Drawing.Point(0, 0);
            this.lvTempData.MultiSelect = false;
            this.lvTempData.Name = "lvTempData";
            this.lvTempData.Size = new System.Drawing.Size(285, 188);
            this.lvTempData.TabIndex = 1;
            this.lvTempData.UseCompatibleStateImageBehavior = false;
            this.lvTempData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "#";
            this.columnHeader19.Width = 50;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Показания";
            this.columnHeader20.Width = 200;
            // 
            // panel87
            // 
            this.panel87.AutoSize = true;
            this.panel87.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel87.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel87.Controls.Add(this.label85);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel87.Location = new System.Drawing.Point(0, 0);
            this.panel87.Name = "panel87";
            this.panel87.Padding = new System.Windows.Forms.Padding(3);
            this.panel87.Size = new System.Drawing.Size(285, 26);
            this.panel87.TabIndex = 0;
            // 
            // label85
            // 
            this.label85.Dock = System.Windows.Forms.DockStyle.Top;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label85.ForeColor = System.Drawing.Color.Beige;
            this.label85.Location = new System.Drawing.Point(3, 3);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(279, 20);
            this.label85.TabIndex = 1;
            this.label85.Text = "Датчики";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.SteelBlue;
            this.panel88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel88.Controls.Add(this.lblWriteTempSettings);
            this.panel88.Controls.Add(this.nudInterval);
            this.panel88.Controls.Add(this.cbCreateTemperatureRules);
            this.panel88.Controls.Add(this.nudTClose);
            this.panel88.Controls.Add(this.label10);
            this.panel88.Controls.Add(this.panel89);
            this.panel88.Controls.Add(this.label8);
            this.panel88.Controls.Add(this.nudTOpen);
            this.panel88.Controls.Add(this.cbTempSettings);
            this.panel88.Controls.Add(this.label9);
            this.panel88.Controls.Add(this.label7);
            this.panel88.Location = new System.Drawing.Point(313, 20);
            this.panel88.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(344, 216);
            this.panel88.TabIndex = 2;
            // 
            // lblWriteTempSettings
            // 
            this.lblWriteTempSettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblWriteTempSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWriteTempSettings.ForeColor = System.Drawing.Color.White;
            this.lblWriteTempSettings.LinkColor = System.Drawing.Color.White;
            this.lblWriteTempSettings.Location = new System.Drawing.Point(0, 191);
            this.lblWriteTempSettings.Name = "lblWriteTempSettings";
            this.lblWriteTempSettings.Padding = new System.Windows.Forms.Padding(5);
            this.lblWriteTempSettings.Size = new System.Drawing.Size(342, 23);
            this.lblWriteTempSettings.TabIndex = 26;
            this.lblWriteTempSettings.TabStop = true;
            this.lblWriteTempSettings.Text = "Сохранить настройки";
            this.lblWriteTempSettings.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblWriteTempSettings, "Сохранить настройки в контроллер");
            this.lblWriteTempSettings.VisitedLinkColor = System.Drawing.Color.White;
            this.lblWriteTempSettings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblWriteTempSettings_LinkClicked);
            // 
            // nudInterval
            // 
            this.nudInterval.BackColor = System.Drawing.Color.White;
            this.nudInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudInterval.ForeColor = System.Drawing.Color.Black;
            this.nudInterval.Location = new System.Drawing.Point(266, 142);
            this.nudInterval.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudInterval.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudInterval.Name = "nudInterval";
            this.nudInterval.Size = new System.Drawing.Size(55, 20);
            this.nudInterval.TabIndex = 8;
            this.nudInterval.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // cbCreateTemperatureRules
            // 
            this.cbCreateTemperatureRules.AutoSize = true;
            this.cbCreateTemperatureRules.Checked = true;
            this.cbCreateTemperatureRules.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCreateTemperatureRules.ForeColor = System.Drawing.Color.White;
            this.cbCreateTemperatureRules.Location = new System.Drawing.Point(25, 168);
            this.cbCreateTemperatureRules.Name = "cbCreateTemperatureRules";
            this.cbCreateTemperatureRules.Size = new System.Drawing.Size(296, 17);
            this.cbCreateTemperatureRules.TabIndex = 11;
            this.cbCreateTemperatureRules.Text = "Создать служебные правила управления фрамугами";
            this.ttTempRulesHint.SetToolTip(this.cbCreateTemperatureRules, resources.GetString("cbCreateTemperatureRules.ToolTip"));
            this.ttDefault.SetToolTip(this.cbCreateTemperatureRules, "Создать служебные правила управления фрамугами по температуре");
            this.cbCreateTemperatureRules.UseVisualStyleBackColor = true;
            this.cbCreateTemperatureRules.CheckedChanged += new System.EventHandler(this.cbCreateTemperatureRules_CheckedChanged);
            // 
            // nudTClose
            // 
            this.nudTClose.BackColor = System.Drawing.Color.White;
            this.nudTClose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudTClose.ForeColor = System.Drawing.Color.Black;
            this.nudTClose.Location = new System.Drawing.Point(266, 115);
            this.nudTClose.Name = "nudTClose";
            this.nudTClose.Size = new System.Drawing.Size(55, 20);
            this.nudTClose.TabIndex = 9;
            this.nudTClose.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(22, 144);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(165, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Время до полного открытия, с:";
            // 
            // panel89
            // 
            this.panel89.AutoSize = true;
            this.panel89.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel89.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel89.Controls.Add(this.label20);
            this.panel89.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel89.Location = new System.Drawing.Point(0, 0);
            this.panel89.Name = "panel89";
            this.panel89.Padding = new System.Windows.Forms.Padding(3);
            this.panel89.Size = new System.Drawing.Size(342, 26);
            this.panel89.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Top;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.Color.Beige;
            this.label20.Location = new System.Drawing.Point(3, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(336, 20);
            this.label20.TabIndex = 1;
            this.label20.Text = "Настройки";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(22, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Т закрытия фрамуг:";
            // 
            // nudTOpen
            // 
            this.nudTOpen.BackColor = System.Drawing.Color.White;
            this.nudTOpen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudTOpen.ForeColor = System.Drawing.Color.Black;
            this.nudTOpen.Location = new System.Drawing.Point(266, 89);
            this.nudTOpen.Name = "nudTOpen";
            this.nudTOpen.Size = new System.Drawing.Size(55, 20);
            this.nudTOpen.TabIndex = 7;
            this.nudTOpen.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cbTempSettings
            // 
            this.cbTempSettings.BackColor = System.Drawing.Color.White;
            this.cbTempSettings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTempSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbTempSettings.ForeColor = System.Drawing.Color.Black;
            this.cbTempSettings.FormattingEnabled = true;
            this.cbTempSettings.Location = new System.Drawing.Point(22, 59);
            this.cbTempSettings.Name = "cbTempSettings";
            this.cbTempSettings.Size = new System.Drawing.Size(299, 21);
            this.cbTempSettings.TabIndex = 1;
            this.cbTempSettings.SelectedIndexChanged += new System.EventHandler(this.cbTempSettings_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(22, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Т открытия фрамуг:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(22, 41);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label7.Size = new System.Drawing.Size(232, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "Предустановленные настройки температур:";
            // 
            // tpWateringTab
            // 
            this.tpWateringTab.BackColor = System.Drawing.Color.White;
            this.tpWateringTab.Controls.Add(this.flowLayoutPanel15);
            this.tpWateringTab.ImageIndex = 4;
            this.tpWateringTab.Location = new System.Drawing.Point(4, 36);
            this.tpWateringTab.Name = "tpWateringTab";
            this.tpWateringTab.Padding = new System.Windows.Forms.Padding(3);
            this.tpWateringTab.Size = new System.Drawing.Size(1000, 423);
            this.tpWateringTab.TabIndex = 3;
            this.tpWateringTab.Text = "Полив";
            // 
            // flowLayoutPanel15
            // 
            this.flowLayoutPanel15.AutoScroll = true;
            this.flowLayoutPanel15.Controls.Add(this.panel91);
            this.flowLayoutPanel15.Controls.Add(this.panel97);
            this.flowLayoutPanel15.Controls.Add(this.panel94);
            this.flowLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel15.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel15.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel15.Name = "flowLayoutPanel15";
            this.flowLayoutPanel15.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel15.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel15.TabIndex = 31;
            // 
            // panel91
            // 
            this.panel91.BackColor = System.Drawing.Color.SteelBlue;
            this.panel91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel91.Controls.Add(this.panel93);
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Location = new System.Drawing.Point(13, 20);
            this.panel91.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(504, 325);
            this.panel91.TabIndex = 1;
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.panel103);
            this.panel93.Controls.Add(this.lblSaveWateringOptions);
            this.panel93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel93.Location = new System.Drawing.Point(0, 26);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(502, 297);
            this.panel93.TabIndex = 1;
            // 
            // panel103
            // 
            this.panel103.Controls.Add(this.label12);
            this.panel103.Controls.Add(this.gbWateringSettings);
            this.panel103.Controls.Add(this.gbWeekDays);
            this.panel103.Controls.Add(this.cbWateringControl);
            this.panel103.Controls.Add(this.chbTurnOnPump);
            this.panel103.Controls.Add(this.dgvWateringChannels);
            this.panel103.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel103.Location = new System.Drawing.Point(0, 0);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(502, 274);
            this.panel103.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(14, 14);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label12.Size = new System.Drawing.Size(203, 18);
            this.label12.TabIndex = 0;
            this.label12.Text = "Автоматическое управление поливом:";
            // 
            // gbWateringSettings
            // 
            this.gbWateringSettings.Controls.Add(this.nudStartWateringTimeMinutes);
            this.gbWateringSettings.Controls.Add(this.nudStartWateringTimeHours);
            this.gbWateringSettings.Controls.Add(this.label16);
            this.gbWateringSettings.Controls.Add(this.nudWateringTime);
            this.gbWateringSettings.Controls.Add(this.label13);
            this.gbWateringSettings.ForeColor = System.Drawing.Color.White;
            this.gbWateringSettings.Location = new System.Drawing.Point(185, 62);
            this.gbWateringSettings.Name = "gbWateringSettings";
            this.gbWateringSettings.Size = new System.Drawing.Size(302, 176);
            this.gbWateringSettings.TabIndex = 3;
            this.gbWateringSettings.TabStop = false;
            this.gbWateringSettings.Text = "Настройки полива";
            this.gbWateringSettings.Visible = false;
            // 
            // nudStartWateringTimeMinutes
            // 
            this.nudStartWateringTimeMinutes.BackColor = System.Drawing.Color.White;
            this.nudStartWateringTimeMinutes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudStartWateringTimeMinutes.ForeColor = System.Drawing.Color.Black;
            this.nudStartWateringTimeMinutes.Location = new System.Drawing.Point(221, 29);
            this.nudStartWateringTimeMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nudStartWateringTimeMinutes.Name = "nudStartWateringTimeMinutes";
            this.nudStartWateringTimeMinutes.Size = new System.Drawing.Size(55, 20);
            this.nudStartWateringTimeMinutes.TabIndex = 12;
            // 
            // nudStartWateringTimeHours
            // 
            this.nudStartWateringTimeHours.BackColor = System.Drawing.Color.White;
            this.nudStartWateringTimeHours.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudStartWateringTimeHours.ForeColor = System.Drawing.Color.Black;
            this.nudStartWateringTimeHours.Location = new System.Drawing.Point(160, 29);
            this.nudStartWateringTimeHours.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.nudStartWateringTimeHours.Name = "nudStartWateringTimeHours";
            this.nudStartWateringTimeHours.Size = new System.Drawing.Size(55, 20);
            this.nudStartWateringTimeHours.TabIndex = 11;
            this.nudStartWateringTimeHours.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 10;
            this.label16.Text = "Начало с, чч:мм:";
            // 
            // nudWateringTime
            // 
            this.nudWateringTime.BackColor = System.Drawing.Color.White;
            this.nudWateringTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudWateringTime.ForeColor = System.Drawing.Color.Black;
            this.nudWateringTime.Location = new System.Drawing.Point(221, 67);
            this.nudWateringTime.Maximum = new decimal(new int[] {
            1380,
            0,
            0,
            0});
            this.nudWateringTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudWateringTime.Name = "nudWateringTime";
            this.nudWateringTime.Size = new System.Drawing.Size(55, 20);
            this.nudWateringTime.TabIndex = 9;
            this.nudWateringTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nudWateringTime.ValueChanged += new System.EventHandler(this.nudWateringTime_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(140, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Продолжительность, мин:";
            // 
            // gbWeekDays
            // 
            this.gbWeekDays.Controls.Add(this.clbWeekDays);
            this.gbWeekDays.ForeColor = System.Drawing.Color.White;
            this.gbWeekDays.Location = new System.Drawing.Point(17, 62);
            this.gbWeekDays.Name = "gbWeekDays";
            this.gbWeekDays.Padding = new System.Windows.Forms.Padding(8);
            this.gbWeekDays.Size = new System.Drawing.Size(149, 176);
            this.gbWeekDays.TabIndex = 2;
            this.gbWeekDays.TabStop = false;
            this.gbWeekDays.Text = "Дни недели";
            this.gbWeekDays.Visible = false;
            // 
            // clbWeekDays
            // 
            this.clbWeekDays.BackColor = System.Drawing.Color.SteelBlue;
            this.clbWeekDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbWeekDays.CheckOnClick = true;
            this.clbWeekDays.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clbWeekDays.ForeColor = System.Drawing.Color.White;
            this.clbWeekDays.FormattingEnabled = true;
            this.clbWeekDays.IntegralHeight = false;
            this.clbWeekDays.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.clbWeekDays.Location = new System.Drawing.Point(8, 21);
            this.clbWeekDays.Name = "clbWeekDays";
            this.clbWeekDays.Size = new System.Drawing.Size(133, 147);
            this.clbWeekDays.TabIndex = 0;
            this.clbWeekDays.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbWeekDays_ItemCheck);
            // 
            // cbWateringControl
            // 
            this.cbWateringControl.BackColor = System.Drawing.Color.White;
            this.cbWateringControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWateringControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbWateringControl.ForeColor = System.Drawing.Color.Black;
            this.cbWateringControl.FormattingEnabled = true;
            this.cbWateringControl.Location = new System.Drawing.Point(17, 35);
            this.cbWateringControl.Name = "cbWateringControl";
            this.cbWateringControl.Size = new System.Drawing.Size(470, 21);
            this.cbWateringControl.TabIndex = 1;
            this.cbWateringControl.SelectedIndexChanged += new System.EventHandler(this.cbWateringControl_SelectedIndexChanged);
            // 
            // chbTurnOnPump
            // 
            this.chbTurnOnPump.AutoSize = true;
            this.chbTurnOnPump.ForeColor = System.Drawing.Color.White;
            this.chbTurnOnPump.Location = new System.Drawing.Point(17, 244);
            this.chbTurnOnPump.Name = "chbTurnOnPump";
            this.chbTurnOnPump.Size = new System.Drawing.Size(292, 17);
            this.chbTurnOnPump.TabIndex = 28;
            this.chbTurnOnPump.Text = "Включать реле насоса при поливе на любом канале";
            this.chbTurnOnPump.UseVisualStyleBackColor = true;
            this.chbTurnOnPump.CheckedChanged += new System.EventHandler(this.chbTurnOnPump_CheckedChanged);
            // 
            // dgvWateringChannels
            // 
            this.dgvWateringChannels.AllowUserToAddRows = false;
            this.dgvWateringChannels.AllowUserToDeleteRows = false;
            this.dgvWateringChannels.AllowUserToResizeRows = false;
            this.dgvWateringChannels.BackgroundColor = System.Drawing.Color.White;
            this.dgvWateringChannels.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvWateringChannels.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dgvWateringChannels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWateringChannels.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column4});
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvWateringChannels.DefaultCellStyle = dataGridViewCellStyle41;
            this.dgvWateringChannels.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvWateringChannels.GridColor = System.Drawing.Color.LightGray;
            this.dgvWateringChannels.Location = new System.Drawing.Point(17, 62);
            this.dgvWateringChannels.MultiSelect = false;
            this.dgvWateringChannels.Name = "dgvWateringChannels";
            this.dgvWateringChannels.RowHeadersVisible = false;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvWateringChannels.RowsDefaultCellStyle = dataGridViewCellStyle42;
            this.dgvWateringChannels.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWateringChannels.Size = new System.Drawing.Size(470, 176);
            this.dgvWateringChannels.TabIndex = 29;
            this.dgvWateringChannels.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvWateringChannels_CellBeginEdit);
            this.dgvWateringChannels.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvWateringChannels_CellEndEdit);
            this.dgvWateringChannels.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvWateringChannels_CellFormatting);
            this.dgvWateringChannels.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvWateringChannels_DataError);
            this.dgvWateringChannels.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvWateringChannels_EditingControlShowing);
            // 
            // Column1
            // 
            dataGridViewCellStyle38.NullValue = null;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle38;
            this.Column1.HeaderText = "Канал";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 50;
            // 
            // Column3
            // 
            dataGridViewCellStyle39.Format = "N0";
            dataGridViewCellStyle39.NullValue = "0";
            this.Column3.DefaultCellStyle = dataGridViewCellStyle39;
            this.Column3.HeaderText = "Начало, чч:мм";
            this.Column3.MaxInputLength = 5;
            this.Column3.Name = "Column3";
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column4
            // 
            dataGridViewCellStyle40.Format = "N2";
            dataGridViewCellStyle40.NullValue = null;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle40;
            this.Column4.HeaderText = "Продолжительность";
            this.Column4.MaxInputLength = 3;
            this.Column4.Name = "Column4";
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 140;
            // 
            // lblSaveWateringOptions
            // 
            this.lblSaveWateringOptions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblSaveWateringOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSaveWateringOptions.ForeColor = System.Drawing.Color.White;
            this.lblSaveWateringOptions.LinkColor = System.Drawing.Color.White;
            this.lblSaveWateringOptions.Location = new System.Drawing.Point(0, 274);
            this.lblSaveWateringOptions.Name = "lblSaveWateringOptions";
            this.lblSaveWateringOptions.Padding = new System.Windows.Forms.Padding(5);
            this.lblSaveWateringOptions.Size = new System.Drawing.Size(502, 23);
            this.lblSaveWateringOptions.TabIndex = 26;
            this.lblSaveWateringOptions.TabStop = true;
            this.lblSaveWateringOptions.Text = "Сохранить настройки";
            this.lblSaveWateringOptions.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblSaveWateringOptions, "Сохранить настройки в контроллер");
            this.lblSaveWateringOptions.VisitedLinkColor = System.Drawing.Color.White;
            this.lblSaveWateringOptions.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSaveWateringOptions_LinkClicked);
            // 
            // panel92
            // 
            this.panel92.AutoSize = true;
            this.panel92.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel92.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel92.Controls.Add(this.label87);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel92.Location = new System.Drawing.Point(0, 0);
            this.panel92.Name = "panel92";
            this.panel92.Padding = new System.Windows.Forms.Padding(3);
            this.panel92.Size = new System.Drawing.Size(502, 26);
            this.panel92.TabIndex = 0;
            // 
            // label87
            // 
            this.label87.Dock = System.Windows.Forms.DockStyle.Top;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label87.ForeColor = System.Drawing.Color.Beige;
            this.label87.Location = new System.Drawing.Point(3, 3);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(496, 20);
            this.label87.TabIndex = 1;
            this.label87.Text = "Настройки";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel97
            // 
            this.panel97.BackColor = System.Drawing.Color.SteelBlue;
            this.panel97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel97.Controls.Add(this.plWaterChannelsList);
            this.panel97.Controls.Add(this.panel99);
            this.panel97.Location = new System.Drawing.Point(530, 20);
            this.panel97.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(200, 324);
            this.panel97.TabIndex = 3;
            // 
            // plWaterChannelsList
            // 
            this.plWaterChannelsList.AutoScroll = true;
            this.plWaterChannelsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.plWaterChannelsList.Location = new System.Drawing.Point(0, 26);
            this.plWaterChannelsList.Name = "plWaterChannelsList";
            this.plWaterChannelsList.Size = new System.Drawing.Size(198, 296);
            this.plWaterChannelsList.TabIndex = 1;
            // 
            // panel99
            // 
            this.panel99.AutoSize = true;
            this.panel99.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel99.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel99.Controls.Add(this.label88);
            this.panel99.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel99.Location = new System.Drawing.Point(0, 0);
            this.panel99.Name = "panel99";
            this.panel99.Padding = new System.Windows.Forms.Padding(3);
            this.panel99.Size = new System.Drawing.Size(198, 26);
            this.panel99.TabIndex = 0;
            // 
            // label88
            // 
            this.label88.Dock = System.Windows.Forms.DockStyle.Top;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label88.ForeColor = System.Drawing.Color.Beige;
            this.label88.Location = new System.Drawing.Point(3, 3);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(192, 20);
            this.label88.TabIndex = 1;
            this.label88.Text = "Каналы";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.SteelBlue;
            this.panel94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel94.Controls.Add(this.panel95);
            this.panel94.Controls.Add(this.panel96);
            this.panel94.Location = new System.Drawing.Point(743, 20);
            this.panel94.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(200, 178);
            this.panel94.TabIndex = 2;
            // 
            // panel95
            // 
            this.panel95.Controls.Add(this.lblWateringState);
            this.panel95.Controls.Add(this.tbWatering);
            this.panel95.Controls.Add(this.label14);
            this.panel95.Controls.Add(this.label15);
            this.panel95.Controls.Add(this.tbWateringMode);
            this.panel95.Controls.Add(this.lblWateringMode);
            this.panel95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel95.Location = new System.Drawing.Point(0, 26);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(198, 150);
            this.panel95.TabIndex = 1;
            // 
            // lblWateringState
            // 
            this.lblWateringState.AutoSize = true;
            this.lblWateringState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWateringState.ForeColor = System.Drawing.Color.White;
            this.lblWateringState.Location = new System.Drawing.Point(30, 39);
            this.lblWateringState.Name = "lblWateringState";
            this.lblWateringState.Size = new System.Drawing.Size(39, 20);
            this.lblWateringState.TabIndex = 23;
            this.lblWateringState.Text = "<?>";
            this.lblWateringState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbWatering
            // 
            this.tbWatering.BackColor = System.Drawing.Color.SteelBlue;
            this.tbWatering.LargeChange = 1;
            this.tbWatering.Location = new System.Drawing.Point(144, 9);
            this.tbWatering.Maximum = 1;
            this.tbWatering.Name = "tbWatering";
            this.tbWatering.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbWatering.Size = new System.Drawing.Size(45, 58);
            this.tbWatering.TabIndex = 22;
            this.tbWatering.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWatering.Scroll += new System.EventHandler(this.tbWatering_Scroll);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(10, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 20);
            this.label14.TabIndex = 24;
            this.label14.Text = "Полив:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 82);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 20);
            this.label15.TabIndex = 27;
            this.label15.Text = "Режим:";
            // 
            // tbWateringMode
            // 
            this.tbWateringMode.BackColor = System.Drawing.Color.SteelBlue;
            this.tbWateringMode.LargeChange = 1;
            this.tbWateringMode.Location = new System.Drawing.Point(144, 73);
            this.tbWateringMode.Maximum = 1;
            this.tbWateringMode.Name = "tbWateringMode";
            this.tbWateringMode.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbWateringMode.Size = new System.Drawing.Size(45, 58);
            this.tbWateringMode.TabIndex = 25;
            this.tbWateringMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWateringMode.Scroll += new System.EventHandler(this.tbWateringMode_Scroll);
            // 
            // lblWateringMode
            // 
            this.lblWateringMode.AutoSize = true;
            this.lblWateringMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWateringMode.ForeColor = System.Drawing.Color.White;
            this.lblWateringMode.Location = new System.Drawing.Point(30, 102);
            this.lblWateringMode.Name = "lblWateringMode";
            this.lblWateringMode.Size = new System.Drawing.Size(39, 20);
            this.lblWateringMode.TabIndex = 26;
            this.lblWateringMode.Text = "<?>";
            this.lblWateringMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel96
            // 
            this.panel96.AutoSize = true;
            this.panel96.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel96.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel96.Controls.Add(this.label86);
            this.panel96.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel96.Location = new System.Drawing.Point(0, 0);
            this.panel96.Name = "panel96";
            this.panel96.Padding = new System.Windows.Forms.Padding(3);
            this.panel96.Size = new System.Drawing.Size(198, 26);
            this.panel96.TabIndex = 0;
            // 
            // label86
            // 
            this.label86.Dock = System.Windows.Forms.DockStyle.Top;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label86.ForeColor = System.Drawing.Color.Beige;
            this.label86.Location = new System.Drawing.Point(3, 3);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(192, 20);
            this.label86.TabIndex = 1;
            this.label86.Text = "Управление";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpLuminosity
            // 
            this.tpLuminosity.BackColor = System.Drawing.Color.White;
            this.tpLuminosity.Controls.Add(this.flowLayoutPanel13);
            this.tpLuminosity.ImageIndex = 5;
            this.tpLuminosity.Location = new System.Drawing.Point(4, 36);
            this.tpLuminosity.Name = "tpLuminosity";
            this.tpLuminosity.Padding = new System.Windows.Forms.Padding(3);
            this.tpLuminosity.Size = new System.Drawing.Size(1000, 423);
            this.tpLuminosity.TabIndex = 4;
            this.tpLuminosity.Text = "Досветка";
            // 
            // flowLayoutPanel13
            // 
            this.flowLayoutPanel13.AutoScroll = true;
            this.flowLayoutPanel13.Controls.Add(this.panel77);
            this.flowLayoutPanel13.Controls.Add(this.panel80);
            this.flowLayoutPanel13.Controls.Add(this.panel83);
            this.flowLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel13.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel13.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel13.Name = "flowLayoutPanel13";
            this.flowLayoutPanel13.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel13.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel13.TabIndex = 35;
            // 
            // panel77
            // 
            this.panel77.BackColor = System.Drawing.Color.SteelBlue;
            this.panel77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel77.Controls.Add(this.panel79);
            this.panel77.Controls.Add(this.panel78);
            this.panel77.Location = new System.Drawing.Point(13, 20);
            this.panel77.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(157, 199);
            this.panel77.TabIndex = 4;
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.lvLuminosity);
            this.panel79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel79.Location = new System.Drawing.Point(0, 26);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(155, 171);
            this.panel79.TabIndex = 1;
            // 
            // lvLuminosity
            // 
            this.lvLuminosity.BackColor = System.Drawing.Color.White;
            this.lvLuminosity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvLuminosity.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader15});
            this.lvLuminosity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvLuminosity.ForeColor = System.Drawing.Color.Black;
            this.lvLuminosity.FullRowSelect = true;
            this.lvLuminosity.GridLines = true;
            this.lvLuminosity.HideSelection = false;
            this.lvLuminosity.Location = new System.Drawing.Point(0, 0);
            this.lvLuminosity.MultiSelect = false;
            this.lvLuminosity.Name = "lvLuminosity";
            this.lvLuminosity.ShowItemToolTips = true;
            this.lvLuminosity.Size = new System.Drawing.Size(155, 171);
            this.lvLuminosity.TabIndex = 35;
            this.lvLuminosity.UseCompatibleStateImageBehavior = false;
            this.lvLuminosity.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "#";
            this.columnHeader13.Width = 30;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Люкс";
            this.columnHeader15.Width = 90;
            // 
            // panel78
            // 
            this.panel78.AutoSize = true;
            this.panel78.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel78.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel78.Controls.Add(this.label82);
            this.panel78.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel78.Location = new System.Drawing.Point(0, 0);
            this.panel78.Name = "panel78";
            this.panel78.Padding = new System.Windows.Forms.Padding(3);
            this.panel78.Size = new System.Drawing.Size(155, 26);
            this.panel78.TabIndex = 0;
            // 
            // label82
            // 
            this.label82.Dock = System.Windows.Forms.DockStyle.Top;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label82.ForeColor = System.Drawing.Color.Beige;
            this.label82.Location = new System.Drawing.Point(3, 3);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(149, 20);
            this.label82.TabIndex = 1;
            this.label82.Text = "Датчики освещённости";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel80
            // 
            this.panel80.BackColor = System.Drawing.Color.SteelBlue;
            this.panel80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel80.Controls.Add(this.panel81);
            this.panel80.Controls.Add(this.panel82);
            this.panel80.Location = new System.Drawing.Point(183, 20);
            this.panel80.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(366, 199);
            this.panel80.TabIndex = 5;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.lblSaveLuxSettings);
            this.panel81.Controls.Add(this.cbWorkWithoutLightSensor);
            this.panel81.Controls.Add(this.label21);
            this.panel81.Controls.Add(this.label17);
            this.panel81.Controls.Add(this.nudMinLux);
            this.panel81.Controls.Add(this.nudLuxHourFrom);
            this.panel81.Controls.Add(this.label18);
            this.panel81.Controls.Add(this.nudLuxHourTo);
            this.panel81.Controls.Add(this.cbEnableLuminosityManage);
            this.panel81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel81.Location = new System.Drawing.Point(0, 26);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(364, 171);
            this.panel81.TabIndex = 1;
            // 
            // lblSaveLuxSettings
            // 
            this.lblSaveLuxSettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblSaveLuxSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSaveLuxSettings.ForeColor = System.Drawing.Color.White;
            this.lblSaveLuxSettings.LinkColor = System.Drawing.Color.White;
            this.lblSaveLuxSettings.Location = new System.Drawing.Point(0, 148);
            this.lblSaveLuxSettings.Name = "lblSaveLuxSettings";
            this.lblSaveLuxSettings.Padding = new System.Windows.Forms.Padding(5);
            this.lblSaveLuxSettings.Size = new System.Drawing.Size(364, 23);
            this.lblSaveLuxSettings.TabIndex = 26;
            this.lblSaveLuxSettings.TabStop = true;
            this.lblSaveLuxSettings.Text = "Сохранить настройки";
            this.lblSaveLuxSettings.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblSaveLuxSettings, "Сохранить настройки в контроллер");
            this.lblSaveLuxSettings.VisitedLinkColor = System.Drawing.Color.White;
            this.lblSaveLuxSettings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSaveLuxSettings_LinkClicked);
            // 
            // cbWorkWithoutLightSensor
            // 
            this.cbWorkWithoutLightSensor.AutoSize = true;
            this.cbWorkWithoutLightSensor.ForeColor = System.Drawing.Color.White;
            this.cbWorkWithoutLightSensor.Location = new System.Drawing.Point(14, 94);
            this.cbWorkWithoutLightSensor.Name = "cbWorkWithoutLightSensor";
            this.cbWorkWithoutLightSensor.Size = new System.Drawing.Size(269, 17);
            this.cbWorkWithoutLightSensor.TabIndex = 10;
            this.cbWorkWithoutLightSensor.Text = "Работа без показаний с датчика освещенности";
            this.cbWorkWithoutLightSensor.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(11, 60);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(190, 13);
            this.label21.TabIndex = 6;
            this.label21.Text = "Мин. освещенность для включения:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(11, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(156, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Часы управления досветкой:";
            // 
            // nudMinLux
            // 
            this.nudMinLux.BackColor = System.Drawing.Color.White;
            this.nudMinLux.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudMinLux.ForeColor = System.Drawing.Color.Black;
            this.nudMinLux.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nudMinLux.Location = new System.Drawing.Point(230, 58);
            this.nudMinLux.Maximum = new decimal(new int[] {
            65500,
            0,
            0,
            0});
            this.nudMinLux.Name = "nudMinLux";
            this.nudMinLux.Size = new System.Drawing.Size(112, 20);
            this.nudMinLux.TabIndex = 7;
            // 
            // nudLuxHourFrom
            // 
            this.nudLuxHourFrom.BackColor = System.Drawing.Color.White;
            this.nudLuxHourFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudLuxHourFrom.ForeColor = System.Drawing.Color.Black;
            this.nudLuxHourFrom.Location = new System.Drawing.Point(230, 22);
            this.nudLuxHourFrom.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudLuxHourFrom.Name = "nudLuxHourFrom";
            this.nudLuxHourFrom.Size = new System.Drawing.Size(45, 20);
            this.nudLuxHourFrom.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(281, 24);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "-";
            // 
            // nudLuxHourTo
            // 
            this.nudLuxHourTo.BackColor = System.Drawing.Color.White;
            this.nudLuxHourTo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudLuxHourTo.ForeColor = System.Drawing.Color.Black;
            this.nudLuxHourTo.Location = new System.Drawing.Point(297, 22);
            this.nudLuxHourTo.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudLuxHourTo.Name = "nudLuxHourTo";
            this.nudLuxHourTo.Size = new System.Drawing.Size(45, 20);
            this.nudLuxHourTo.TabIndex = 4;
            // 
            // cbEnableLuminosityManage
            // 
            this.cbEnableLuminosityManage.AutoSize = true;
            this.cbEnableLuminosityManage.ForeColor = System.Drawing.Color.White;
            this.cbEnableLuminosityManage.Location = new System.Drawing.Point(14, 117);
            this.cbEnableLuminosityManage.Name = "cbEnableLuminosityManage";
            this.cbEnableLuminosityManage.Size = new System.Drawing.Size(193, 17);
            this.cbEnableLuminosityManage.TabIndex = 10;
            this.cbEnableLuminosityManage.Text = "Включить управление досветкой";
            this.cbEnableLuminosityManage.UseVisualStyleBackColor = true;
            this.cbEnableLuminosityManage.CheckedChanged += new System.EventHandler(this.cbEnableLuminosityManage_CheckedChanged);
            // 
            // panel82
            // 
            this.panel82.AutoSize = true;
            this.panel82.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel82.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel82.Controls.Add(this.label83);
            this.panel82.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel82.Location = new System.Drawing.Point(0, 0);
            this.panel82.Name = "panel82";
            this.panel82.Padding = new System.Windows.Forms.Padding(3);
            this.panel82.Size = new System.Drawing.Size(364, 26);
            this.panel82.TabIndex = 0;
            // 
            // label83
            // 
            this.label83.Dock = System.Windows.Forms.DockStyle.Top;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label83.ForeColor = System.Drawing.Color.Beige;
            this.label83.Location = new System.Drawing.Point(3, 3);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(358, 20);
            this.label83.TabIndex = 1;
            this.label83.Text = "Настройки";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.Color.SteelBlue;
            this.panel83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel83.Controls.Add(this.panel84);
            this.panel83.Controls.Add(this.panel85);
            this.panel83.Location = new System.Drawing.Point(562, 20);
            this.panel83.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(254, 199);
            this.panel83.TabIndex = 6;
            // 
            // panel84
            // 
            this.panel84.Controls.Add(this.label22);
            this.panel84.Controls.Add(this.tbLux);
            this.panel84.Controls.Add(this.lblLuxMode);
            this.panel84.Controls.Add(this.lblLuxState);
            this.panel84.Controls.Add(this.tbLuxMode);
            this.panel84.Controls.Add(this.label24);
            this.panel84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel84.Location = new System.Drawing.Point(0, 26);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(252, 171);
            this.panel84.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(27, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 33;
            this.label22.Text = "Режим:";
            // 
            // tbLux
            // 
            this.tbLux.BackColor = System.Drawing.Color.SteelBlue;
            this.tbLux.LargeChange = 1;
            this.tbLux.Location = new System.Drawing.Point(189, 20);
            this.tbLux.Maximum = 1;
            this.tbLux.Name = "tbLux";
            this.tbLux.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbLux.Size = new System.Drawing.Size(45, 58);
            this.tbLux.TabIndex = 28;
            this.tbLux.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbLux.Scroll += new System.EventHandler(this.tbLux_Scroll);
            // 
            // lblLuxMode
            // 
            this.lblLuxMode.AutoSize = true;
            this.lblLuxMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLuxMode.ForeColor = System.Drawing.Color.White;
            this.lblLuxMode.Location = new System.Drawing.Point(48, 132);
            this.lblLuxMode.Name = "lblLuxMode";
            this.lblLuxMode.Size = new System.Drawing.Size(39, 20);
            this.lblLuxMode.TabIndex = 32;
            this.lblLuxMode.Text = "<?>";
            this.lblLuxMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLuxState
            // 
            this.lblLuxState.AutoSize = true;
            this.lblLuxState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLuxState.ForeColor = System.Drawing.Color.White;
            this.lblLuxState.Location = new System.Drawing.Point(48, 53);
            this.lblLuxState.Name = "lblLuxState";
            this.lblLuxState.Size = new System.Drawing.Size(39, 20);
            this.lblLuxState.TabIndex = 29;
            this.lblLuxState.Text = "<?>";
            this.lblLuxState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbLuxMode
            // 
            this.tbLuxMode.BackColor = System.Drawing.Color.SteelBlue;
            this.tbLuxMode.LargeChange = 1;
            this.tbLuxMode.Location = new System.Drawing.Point(189, 94);
            this.tbLuxMode.Maximum = 1;
            this.tbLuxMode.Name = "tbLuxMode";
            this.tbLuxMode.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbLuxMode.Size = new System.Drawing.Size(45, 58);
            this.tbLuxMode.TabIndex = 31;
            this.tbLuxMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbLuxMode.Scroll += new System.EventHandler(this.tbLuxMode_Scroll);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(27, 25);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 20);
            this.label24.TabIndex = 30;
            this.label24.Text = "Досветка:";
            // 
            // panel85
            // 
            this.panel85.AutoSize = true;
            this.panel85.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel85.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel85.Controls.Add(this.label84);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel85.Location = new System.Drawing.Point(0, 0);
            this.panel85.Name = "panel85";
            this.panel85.Padding = new System.Windows.Forms.Padding(3);
            this.panel85.Size = new System.Drawing.Size(252, 26);
            this.panel85.TabIndex = 0;
            // 
            // label84
            // 
            this.label84.Dock = System.Windows.Forms.DockStyle.Top;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label84.ForeColor = System.Drawing.Color.Beige;
            this.label84.Location = new System.Drawing.Point(3, 3);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(246, 20);
            this.label84.TabIndex = 1;
            this.label84.Text = "Управление";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpHumidity
            // 
            this.tpHumidity.BackColor = System.Drawing.Color.White;
            this.tpHumidity.Controls.Add(this.flowLayoutPanel3);
            this.tpHumidity.ImageIndex = 7;
            this.tpHumidity.Location = new System.Drawing.Point(4, 36);
            this.tpHumidity.Margin = new System.Windows.Forms.Padding(10);
            this.tpHumidity.Name = "tpHumidity";
            this.tpHumidity.Padding = new System.Windows.Forms.Padding(3);
            this.tpHumidity.Size = new System.Drawing.Size(1000, 423);
            this.tpHumidity.TabIndex = 6;
            this.tpHumidity.Text = "Влажность";
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.AutoScroll = true;
            this.flowLayoutPanel3.Controls.Add(this.panel21);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel3.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel3.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.SteelBlue;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.lvHumiditySensorsData);
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Location = new System.Drawing.Point(13, 20);
            this.panel21.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(335, 382);
            this.panel21.TabIndex = 3;
            // 
            // lvHumiditySensorsData
            // 
            this.lvHumiditySensorsData.BackColor = System.Drawing.Color.White;
            this.lvHumiditySensorsData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvHumiditySensorsData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvHumiditySensorsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvHumiditySensorsData.ForeColor = System.Drawing.Color.Black;
            this.lvHumiditySensorsData.FullRowSelect = true;
            this.lvHumiditySensorsData.GridLines = true;
            this.lvHumiditySensorsData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvHumiditySensorsData.LabelWrap = false;
            this.lvHumiditySensorsData.Location = new System.Drawing.Point(0, 26);
            this.lvHumiditySensorsData.MultiSelect = false;
            this.lvHumiditySensorsData.Name = "lvHumiditySensorsData";
            this.lvHumiditySensorsData.Size = new System.Drawing.Size(333, 354);
            this.lvHumiditySensorsData.TabIndex = 1;
            this.lvHumiditySensorsData.UseCompatibleStateImageBehavior = false;
            this.lvHumiditySensorsData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Влажность";
            this.columnHeader2.Width = 110;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Температура";
            this.columnHeader3.Width = 120;
            // 
            // panel22
            // 
            this.panel22.AutoSize = true;
            this.panel22.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel22.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel22.Controls.Add(this.label2);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Padding = new System.Windows.Forms.Padding(3);
            this.panel22.Size = new System.Drawing.Size(333, 26);
            this.panel22.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Beige;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(327, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Датчики влажности";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpSMSTab
            // 
            this.tpSMSTab.BackColor = System.Drawing.Color.White;
            this.tpSMSTab.Controls.Add(this.flowLayoutPanel12);
            this.tpSMSTab.Cursor = System.Windows.Forms.Cursors.Default;
            this.tpSMSTab.ImageIndex = 3;
            this.tpSMSTab.Location = new System.Drawing.Point(4, 36);
            this.tpSMSTab.Name = "tpSMSTab";
            this.tpSMSTab.Padding = new System.Windows.Forms.Padding(3);
            this.tpSMSTab.Size = new System.Drawing.Size(1000, 423);
            this.tpSMSTab.TabIndex = 2;
            this.tpSMSTab.Text = "СМС";
            // 
            // flowLayoutPanel12
            // 
            this.flowLayoutPanel12.AutoScroll = true;
            this.flowLayoutPanel12.Controls.Add(this.panel70);
            this.flowLayoutPanel12.Controls.Add(this.panel72);
            this.flowLayoutPanel12.Controls.Add(this.panel74);
            this.flowLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel12.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel12.Name = "flowLayoutPanel12";
            this.flowLayoutPanel12.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel12.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel12.TabIndex = 15;
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.Color.SteelBlue;
            this.panel70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel70.Controls.Add(this.panel71);
            this.panel70.Controls.Add(this.cbGSMProvider);
            this.panel70.Controls.Add(this.tbPhoneNumber);
            this.panel70.Controls.Add(this.label48);
            this.panel70.Controls.Add(this.pbNumberHelp);
            this.panel70.Controls.Add(this.label11);
            this.panel70.Location = new System.Drawing.Point(13, 20);
            this.panel70.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(270, 187);
            this.panel70.TabIndex = 2;
            // 
            // panel71
            // 
            this.panel71.AutoSize = true;
            this.panel71.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel71.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel71.Controls.Add(this.label80);
            this.panel71.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel71.Location = new System.Drawing.Point(0, 0);
            this.panel71.Name = "panel71";
            this.panel71.Padding = new System.Windows.Forms.Padding(3);
            this.panel71.Size = new System.Drawing.Size(268, 26);
            this.panel71.TabIndex = 0;
            // 
            // label80
            // 
            this.label80.Dock = System.Windows.Forms.DockStyle.Top;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label80.ForeColor = System.Drawing.Color.Beige;
            this.label80.Location = new System.Drawing.Point(3, 3);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(262, 20);
            this.label80.TabIndex = 1;
            this.label80.Text = "Настройки";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbGSMProvider
            // 
            this.cbGSMProvider.BackColor = System.Drawing.Color.White;
            this.cbGSMProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGSMProvider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbGSMProvider.ForeColor = System.Drawing.Color.Black;
            this.cbGSMProvider.FormattingEnabled = true;
            this.cbGSMProvider.Items.AddRange(new object[] {
            "МТС (Россия)",
            "Билайн (Россия)",
            "Мегафон (Россия)",
            "Теле2 (Россия)",
            "Йота (Россия)",
            "МТС (Беларусь)",
            "Velcom (Беларусь)",
            "Privet (Беларусь)",
            "Life (Беларусь)"});
            this.cbGSMProvider.Location = new System.Drawing.Point(24, 131);
            this.cbGSMProvider.Name = "cbGSMProvider";
            this.cbGSMProvider.Size = new System.Drawing.Size(223, 21);
            this.cbGSMProvider.TabIndex = 14;
            // 
            // tbPhoneNumber
            // 
            this.tbPhoneNumber.BackColor = System.Drawing.Color.White;
            this.tbPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPhoneNumber.ForeColor = System.Drawing.Color.Black;
            this.tbPhoneNumber.Location = new System.Drawing.Point(24, 65);
            this.tbPhoneNumber.Name = "tbPhoneNumber";
            this.tbPhoneNumber.Size = new System.Drawing.Size(200, 20);
            this.tbPhoneNumber.TabIndex = 1;
            this.tbPhoneNumber.WordWrap = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(21, 115);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(183, 13);
            this.label48.TabIndex = 13;
            this.label48.Text = "Оператор SIM-карты контроллера:";
            // 
            // pbNumberHelp
            // 
            this.pbNumberHelp.Cursor = System.Windows.Forms.Cursors.Help;
            this.pbNumberHelp.Image = global::GreenHouseConfig.Properties.Resources.help;
            this.pbNumberHelp.Location = new System.Drawing.Point(231, 67);
            this.pbNumberHelp.Name = "pbNumberHelp";
            this.pbNumberHelp.Size = new System.Drawing.Size(16, 16);
            this.pbNumberHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbNumberHelp.TabIndex = 10;
            this.pbNumberHelp.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(21, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(226, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Входящий номер, в формате +79XXxxxxxxx:";
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.SteelBlue;
            this.panel72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel72.Controls.Add(this.panel73);
            this.panel72.Controls.Add(this.btnSmsList);
            this.panel72.Controls.Add(this.btnAddSMS);
            this.panel72.Controls.Add(this.btnSavePhoneNumber);
            this.panel72.Location = new System.Drawing.Point(296, 20);
            this.panel72.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(280, 187);
            this.panel72.TabIndex = 3;
            // 
            // panel73
            // 
            this.panel73.AutoSize = true;
            this.panel73.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel73.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel73.Controls.Add(this.label79);
            this.panel73.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel73.Location = new System.Drawing.Point(0, 0);
            this.panel73.Name = "panel73";
            this.panel73.Padding = new System.Windows.Forms.Padding(3);
            this.panel73.Size = new System.Drawing.Size(278, 26);
            this.panel73.TabIndex = 0;
            // 
            // label79
            // 
            this.label79.Dock = System.Windows.Forms.DockStyle.Top;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label79.ForeColor = System.Drawing.Color.Beige;
            this.label79.Location = new System.Drawing.Point(3, 3);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(272, 20);
            this.label79.TabIndex = 1;
            this.label79.Text = "Действия";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSmsList
            // 
            this.btnSmsList.BackColor = System.Drawing.Color.LightSalmon;
            this.btnSmsList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSmsList.ForeColor = System.Drawing.Color.Black;
            this.btnSmsList.Image = global::GreenHouseConfig.Properties.Resources.list1;
            this.btnSmsList.Location = new System.Drawing.Point(12, 43);
            this.btnSmsList.Name = "btnSmsList";
            this.btnSmsList.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnSmsList.Size = new System.Drawing.Size(254, 38);
            this.btnSmsList.TabIndex = 12;
            this.btnSmsList.Text = "Список СМС (локальный)";
            this.btnSmsList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSmsList, "Показать список ранее добавленных СМС");
            this.btnSmsList.UseVisualStyleBackColor = false;
            this.btnSmsList.Click += new System.EventHandler(this.btnSmsList_Click);
            // 
            // btnAddSMS
            // 
            this.btnAddSMS.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddSMS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSMS.ForeColor = System.Drawing.Color.Black;
            this.btnAddSMS.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddSMS.Location = new System.Drawing.Point(12, 87);
            this.btnAddSMS.Name = "btnAddSMS";
            this.btnAddSMS.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnAddSMS.Size = new System.Drawing.Size(254, 38);
            this.btnAddSMS.TabIndex = 11;
            this.btnAddSMS.Text = "Добавить СМС в контроллер";
            this.btnAddSMS.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddSMS, "Добавить СМС в контроллер");
            this.btnAddSMS.UseVisualStyleBackColor = false;
            this.btnAddSMS.Click += new System.EventHandler(this.btnAddSMS_Click);
            // 
            // btnSavePhoneNumber
            // 
            this.btnSavePhoneNumber.BackColor = System.Drawing.Color.LightSalmon;
            this.btnSavePhoneNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSavePhoneNumber.ForeColor = System.Drawing.Color.Black;
            this.btnSavePhoneNumber.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSavePhoneNumber.Location = new System.Drawing.Point(12, 131);
            this.btnSavePhoneNumber.Name = "btnSavePhoneNumber";
            this.btnSavePhoneNumber.Padding = new System.Windows.Forms.Padding(50, 0, 0, 0);
            this.btnSavePhoneNumber.Size = new System.Drawing.Size(254, 38);
            this.btnSavePhoneNumber.TabIndex = 8;
            this.btnSavePhoneNumber.Text = "Сохранить данные";
            this.btnSavePhoneNumber.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSavePhoneNumber, "Записать настройки в контроллер");
            this.btnSavePhoneNumber.UseVisualStyleBackColor = false;
            this.btnSavePhoneNumber.Click += new System.EventHandler(this.btnSavePhoneNumber_Click);
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.SteelBlue;
            this.panel74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel74.Controls.Add(this.panel76);
            this.panel74.Controls.Add(this.panel75);
            this.panel74.Location = new System.Drawing.Point(589, 20);
            this.panel74.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(335, 187);
            this.panel74.TabIndex = 4;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.richTextBox1);
            this.panel76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel76.Location = new System.Drawing.Point(0, 26);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(333, 159);
            this.panel76.TabIndex = 1;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(333, 159);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "\n";
            // 
            // panel75
            // 
            this.panel75.AutoSize = true;
            this.panel75.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel75.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel75.Controls.Add(this.label81);
            this.panel75.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel75.Location = new System.Drawing.Point(0, 0);
            this.panel75.Name = "panel75";
            this.panel75.Padding = new System.Windows.Forms.Padding(3);
            this.panel75.Size = new System.Drawing.Size(333, 26);
            this.panel75.TabIndex = 0;
            // 
            // label81
            // 
            this.label81.Dock = System.Windows.Forms.DockStyle.Top;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label81.ForeColor = System.Drawing.Color.Beige;
            this.label81.Location = new System.Drawing.Point(3, 3);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(327, 20);
            this.label81.TabIndex = 1;
            this.label81.Text = "Справка";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpWiFi
            // 
            this.tpWiFi.BackColor = System.Drawing.Color.White;
            this.tpWiFi.Controls.Add(this.flowLayoutPanel11);
            this.tpWiFi.ImageIndex = 6;
            this.tpWiFi.Location = new System.Drawing.Point(4, 36);
            this.tpWiFi.Name = "tpWiFi";
            this.tpWiFi.Padding = new System.Windows.Forms.Padding(3);
            this.tpWiFi.Size = new System.Drawing.Size(1000, 423);
            this.tpWiFi.TabIndex = 5;
            this.tpWiFi.Text = "Wi-Fi";
            // 
            // flowLayoutPanel11
            // 
            this.flowLayoutPanel11.AutoScroll = true;
            this.flowLayoutPanel11.Controls.Add(this.panel64);
            this.flowLayoutPanel11.Controls.Add(this.panel66);
            this.flowLayoutPanel11.Controls.Add(this.panel68);
            this.flowLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel11.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel11.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel11.Name = "flowLayoutPanel11";
            this.flowLayoutPanel11.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel11.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel11.TabIndex = 18;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.Color.SteelBlue;
            this.panel64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel64.Controls.Add(this.tbRouterPassword);
            this.panel64.Controls.Add(this.label23);
            this.panel64.Controls.Add(this.cbConnectToTheRouter);
            this.panel64.Controls.Add(this.panel65);
            this.panel64.Controls.Add(this.tbRouterID);
            this.panel64.Controls.Add(this.label19);
            this.panel64.Location = new System.Drawing.Point(13, 20);
            this.panel64.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(257, 140);
            this.panel64.TabIndex = 1;
            // 
            // tbRouterPassword
            // 
            this.tbRouterPassword.BackColor = System.Drawing.Color.White;
            this.tbRouterPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRouterPassword.ForeColor = System.Drawing.Color.Black;
            this.tbRouterPassword.Location = new System.Drawing.Point(121, 66);
            this.tbRouterPassword.Name = "tbRouterPassword";
            this.tbRouterPassword.Size = new System.Drawing.Size(115, 20);
            this.tbRouterPassword.TabIndex = 14;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(18, 69);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 13);
            this.label23.TabIndex = 13;
            this.label23.Text = "Пароль:";
            // 
            // cbConnectToTheRouter
            // 
            this.cbConnectToTheRouter.AutoSize = true;
            this.cbConnectToTheRouter.ForeColor = System.Drawing.Color.White;
            this.cbConnectToTheRouter.Location = new System.Drawing.Point(21, 103);
            this.cbConnectToTheRouter.Name = "cbConnectToTheRouter";
            this.cbConnectToTheRouter.Size = new System.Drawing.Size(152, 17);
            this.cbConnectToTheRouter.TabIndex = 16;
            this.cbConnectToTheRouter.Text = "Соединяться с роутером";
            this.cbConnectToTheRouter.UseVisualStyleBackColor = true;
            // 
            // panel65
            // 
            this.panel65.AutoSize = true;
            this.panel65.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel65.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel65.Controls.Add(this.label76);
            this.panel65.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel65.Location = new System.Drawing.Point(0, 0);
            this.panel65.Name = "panel65";
            this.panel65.Padding = new System.Windows.Forms.Padding(3);
            this.panel65.Size = new System.Drawing.Size(255, 26);
            this.panel65.TabIndex = 0;
            // 
            // label76
            // 
            this.label76.Dock = System.Windows.Forms.DockStyle.Top;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label76.ForeColor = System.Drawing.Color.Beige;
            this.label76.Location = new System.Drawing.Point(3, 3);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(249, 20);
            this.label76.TabIndex = 1;
            this.label76.Text = "Роутер";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbRouterID
            // 
            this.tbRouterID.BackColor = System.Drawing.Color.White;
            this.tbRouterID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRouterID.ForeColor = System.Drawing.Color.Black;
            this.tbRouterID.Location = new System.Drawing.Point(121, 40);
            this.tbRouterID.Name = "tbRouterID";
            this.tbRouterID.Size = new System.Drawing.Size(115, 20);
            this.tbRouterID.TabIndex = 12;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(18, 43);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Имя сети:";
            // 
            // panel66
            // 
            this.panel66.BackColor = System.Drawing.Color.SteelBlue;
            this.panel66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel66.Controls.Add(this.label78);
            this.panel66.Controls.Add(this.tbStationPassword);
            this.panel66.Controls.Add(this.label25);
            this.panel66.Controls.Add(this.panel67);
            this.panel66.Controls.Add(this.tbStationID);
            this.panel66.Controls.Add(this.label26);
            this.panel66.Location = new System.Drawing.Point(283, 20);
            this.panel66.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(257, 140);
            this.panel66.TabIndex = 2;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.ForeColor = System.Drawing.Color.White;
            this.label78.Location = new System.Drawing.Point(18, 104);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(207, 13);
            this.label78.TabIndex = 15;
            this.label78.Text = "* Длина пароля - минимум 8 символов!";
            // 
            // tbStationPassword
            // 
            this.tbStationPassword.BackColor = System.Drawing.Color.White;
            this.tbStationPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbStationPassword.ForeColor = System.Drawing.Color.Black;
            this.tbStationPassword.Location = new System.Drawing.Point(121, 66);
            this.tbStationPassword.Name = "tbStationPassword";
            this.tbStationPassword.Size = new System.Drawing.Size(115, 20);
            this.tbStationPassword.TabIndex = 14;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(18, 69);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 13);
            this.label25.TabIndex = 13;
            this.label25.Text = "Пароль*:";
            // 
            // panel67
            // 
            this.panel67.AutoSize = true;
            this.panel67.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel67.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel67.Controls.Add(this.label75);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel67.Location = new System.Drawing.Point(0, 0);
            this.panel67.Name = "panel67";
            this.panel67.Padding = new System.Windows.Forms.Padding(3);
            this.panel67.Size = new System.Drawing.Size(255, 26);
            this.panel67.TabIndex = 0;
            // 
            // label75
            // 
            this.label75.Dock = System.Windows.Forms.DockStyle.Top;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label75.ForeColor = System.Drawing.Color.Beige;
            this.label75.Location = new System.Drawing.Point(3, 3);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(249, 20);
            this.label75.TabIndex = 1;
            this.label75.Text = "Точка доступа";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbStationID
            // 
            this.tbStationID.BackColor = System.Drawing.Color.White;
            this.tbStationID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbStationID.ForeColor = System.Drawing.Color.Black;
            this.tbStationID.Location = new System.Drawing.Point(121, 40);
            this.tbStationID.Name = "tbStationID";
            this.tbStationID.Size = new System.Drawing.Size(115, 20);
            this.tbStationID.TabIndex = 12;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(18, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 13);
            this.label26.TabIndex = 5;
            this.label26.Text = "Название:";
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.Color.SteelBlue;
            this.panel68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel68.Controls.Add(this.panel69);
            this.panel68.Controls.Add(this.btnSaveWiFiSettings);
            this.panel68.Controls.Add(this.btnQueryIP);
            this.panel68.Location = new System.Drawing.Point(553, 20);
            this.panel68.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(257, 140);
            this.panel68.TabIndex = 3;
            // 
            // panel69
            // 
            this.panel69.AutoSize = true;
            this.panel69.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel69.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel69.Controls.Add(this.label77);
            this.panel69.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel69.Location = new System.Drawing.Point(0, 0);
            this.panel69.Name = "panel69";
            this.panel69.Padding = new System.Windows.Forms.Padding(3);
            this.panel69.Size = new System.Drawing.Size(255, 26);
            this.panel69.TabIndex = 0;
            // 
            // label77
            // 
            this.label77.Dock = System.Windows.Forms.DockStyle.Top;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label77.ForeColor = System.Drawing.Color.Beige;
            this.label77.Location = new System.Drawing.Point(3, 3);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(249, 20);
            this.label77.TabIndex = 1;
            this.label77.Text = "Действия";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaveWiFiSettings
            // 
            this.btnSaveWiFiSettings.BackColor = System.Drawing.Color.LightGreen;
            this.btnSaveWiFiSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveWiFiSettings.ForeColor = System.Drawing.Color.Black;
            this.btnSaveWiFiSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveWiFiSettings.Location = new System.Drawing.Point(20, 82);
            this.btnSaveWiFiSettings.Name = "btnSaveWiFiSettings";
            this.btnSaveWiFiSettings.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnSaveWiFiSettings.Size = new System.Drawing.Size(215, 38);
            this.btnSaveWiFiSettings.TabIndex = 12;
            this.btnSaveWiFiSettings.Text = "Записать настройки";
            this.btnSaveWiFiSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveWiFiSettings, "Записать настройки в контроллер");
            this.btnSaveWiFiSettings.UseVisualStyleBackColor = false;
            this.btnSaveWiFiSettings.Click += new System.EventHandler(this.btnSaveWiFiSettings_Click);
            // 
            // btnQueryIP
            // 
            this.btnQueryIP.BackColor = System.Drawing.Color.LightSalmon;
            this.btnQueryIP.Enabled = false;
            this.btnQueryIP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQueryIP.ForeColor = System.Drawing.Color.Black;
            this.btnQueryIP.Image = global::GreenHouseConfig.Properties.Resources.wifismall;
            this.btnQueryIP.Location = new System.Drawing.Point(20, 40);
            this.btnQueryIP.Name = "btnQueryIP";
            this.btnQueryIP.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnQueryIP.Size = new System.Drawing.Size(215, 38);
            this.btnQueryIP.TabIndex = 17;
            this.btnQueryIP.Text = "Просмотр IP-адресов";
            this.btnQueryIP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnQueryIP, "Получить IP-адреса");
            this.btnQueryIP.UseVisualStyleBackColor = false;
            this.btnQueryIP.Click += new System.EventHandler(this.btnQueryIP_Click);
            // 
            // tpRules
            // 
            this.tpRules.BackColor = System.Drawing.Color.White;
            this.tpRules.Controls.Add(this.flowLayoutPanel10);
            this.tpRules.ImageIndex = 8;
            this.tpRules.Location = new System.Drawing.Point(4, 36);
            this.tpRules.Name = "tpRules";
            this.tpRules.Padding = new System.Windows.Forms.Padding(3);
            this.tpRules.Size = new System.Drawing.Size(1000, 423);
            this.tpRules.TabIndex = 7;
            this.tpRules.Text = "Правила";
            // 
            // flowLayoutPanel10
            // 
            this.flowLayoutPanel10.AutoScroll = true;
            this.flowLayoutPanel10.Controls.Add(this.panel59);
            this.flowLayoutPanel10.Controls.Add(this.panel62);
            this.flowLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel10.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel10.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel10.Name = "flowLayoutPanel10";
            this.flowLayoutPanel10.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel10.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel10.TabIndex = 19;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.SteelBlue;
            this.panel59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel59.Controls.Add(this.panel61);
            this.panel59.Controls.Add(this.panel60);
            this.panel59.Location = new System.Drawing.Point(13, 20);
            this.panel59.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(468, 321);
            this.panel59.TabIndex = 2;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.lblRuleStr);
            this.panel61.Controls.Add(this.lvRulesList);
            this.panel61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel61.Location = new System.Drawing.Point(0, 26);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(466, 293);
            this.panel61.TabIndex = 1;
            // 
            // lblRuleStr
            // 
            this.lblRuleStr.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblRuleStr.ForeColor = System.Drawing.Color.White;
            this.lblRuleStr.Location = new System.Drawing.Point(0, 272);
            this.lblRuleStr.Name = "lblRuleStr";
            this.lblRuleStr.Padding = new System.Windows.Forms.Padding(4);
            this.lblRuleStr.Size = new System.Drawing.Size(466, 21);
            this.lblRuleStr.TabIndex = 1;
            this.lblRuleStr.Text = "Строка с командой выбранного правила";
            this.lblRuleStr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lvRulesList
            // 
            this.lvRulesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvRulesList.CheckBoxes = true;
            this.lvRulesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader4});
            this.lvRulesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvRulesList.FullRowSelect = true;
            this.lvRulesList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvRulesList.HideSelection = false;
            this.lvRulesList.Location = new System.Drawing.Point(0, 0);
            this.lvRulesList.MultiSelect = false;
            this.lvRulesList.Name = "lvRulesList";
            this.lvRulesList.ShowItemToolTips = true;
            this.lvRulesList.Size = new System.Drawing.Size(466, 293);
            this.lvRulesList.TabIndex = 0;
            this.lvRulesList.UseCompatibleStateImageBehavior = false;
            this.lvRulesList.View = System.Windows.Forms.View.Details;
            this.lvRulesList.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.lvRulesList_ItemChecked);
            this.lvRulesList.SelectedIndexChanged += new System.EventHandler(this.lvRulesList_SelectedIndexChanged);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "За чем следим";
            this.columnHeader5.Width = 220;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Что делаем";
            this.columnHeader6.Width = 140;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Служебное?";
            this.columnHeader4.Width = 80;
            // 
            // panel60
            // 
            this.panel60.AutoSize = true;
            this.panel60.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel60.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel60.Controls.Add(this.label73);
            this.panel60.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel60.Location = new System.Drawing.Point(0, 0);
            this.panel60.Name = "panel60";
            this.panel60.Padding = new System.Windows.Forms.Padding(3);
            this.panel60.Size = new System.Drawing.Size(466, 26);
            this.panel60.TabIndex = 0;
            // 
            // label73
            // 
            this.label73.Dock = System.Windows.Forms.DockStyle.Top;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label73.ForeColor = System.Drawing.Color.Beige;
            this.label73.Location = new System.Drawing.Point(3, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(460, 20);
            this.label73.TabIndex = 1;
            this.label73.Text = "Список правил";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.SteelBlue;
            this.panel62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel62.Controls.Add(this.panel63);
            this.panel62.Controls.Add(this.btnDeleteRule);
            this.panel62.Controls.Add(this.btnSaveRules);
            this.panel62.Controls.Add(this.btnAddRule);
            this.panel62.Controls.Add(this.btnLoadRules);
            this.panel62.Controls.Add(this.lblComputeRulesmemory);
            this.panel62.Controls.Add(this.btnEditRule);
            this.panel62.Location = new System.Drawing.Point(494, 20);
            this.panel62.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(318, 321);
            this.panel62.TabIndex = 3;
            // 
            // panel63
            // 
            this.panel63.AutoSize = true;
            this.panel63.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel63.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel63.Controls.Add(this.label74);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel63.Location = new System.Drawing.Point(0, 0);
            this.panel63.Name = "panel63";
            this.panel63.Padding = new System.Windows.Forms.Padding(3);
            this.panel63.Size = new System.Drawing.Size(316, 26);
            this.panel63.TabIndex = 0;
            // 
            // label74
            // 
            this.label74.Dock = System.Windows.Forms.DockStyle.Top;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label74.ForeColor = System.Drawing.Color.Beige;
            this.label74.Location = new System.Drawing.Point(3, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(310, 20);
            this.label74.TabIndex = 1;
            this.label74.Text = "Действия";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDeleteRule
            // 
            this.btnDeleteRule.BackColor = System.Drawing.Color.LightSalmon;
            this.btnDeleteRule.Enabled = false;
            this.btnDeleteRule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteRule.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteRule.Location = new System.Drawing.Point(29, 128);
            this.btnDeleteRule.Name = "btnDeleteRule";
            this.btnDeleteRule.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnDeleteRule.Size = new System.Drawing.Size(258, 38);
            this.btnDeleteRule.TabIndex = 18;
            this.btnDeleteRule.Text = "Удалить выбранное правило";
            this.btnDeleteRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnDeleteRule, "Удалить выбранное правило");
            this.btnDeleteRule.UseVisualStyleBackColor = false;
            this.btnDeleteRule.Click += new System.EventHandler(this.btnDeleteRule_Click);
            // 
            // btnSaveRules
            // 
            this.btnSaveRules.BackColor = System.Drawing.Color.LightSalmon;
            this.btnSaveRules.Enabled = false;
            this.btnSaveRules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveRules.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveRules.Location = new System.Drawing.Point(29, 257);
            this.btnSaveRules.Name = "btnSaveRules";
            this.btnSaveRules.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnSaveRules.Size = new System.Drawing.Size(258, 38);
            this.btnSaveRules.TabIndex = 13;
            this.btnSaveRules.Text = "Сохранить в контроллер";
            this.btnSaveRules.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveRules, "Сохранить правила в контроллер");
            this.btnSaveRules.UseVisualStyleBackColor = false;
            this.btnSaveRules.Click += new System.EventHandler(this.btnSaveRules_Click);
            // 
            // btnAddRule
            // 
            this.btnAddRule.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddRule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddRule.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddRule.Location = new System.Drawing.Point(29, 40);
            this.btnAddRule.Name = "btnAddRule";
            this.btnAddRule.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnAddRule.Size = new System.Drawing.Size(258, 38);
            this.btnAddRule.TabIndex = 17;
            this.btnAddRule.Text = "Добавить новое правило";
            this.btnAddRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddRule, "Добавить новое правило");
            this.btnAddRule.UseVisualStyleBackColor = false;
            this.btnAddRule.Click += new System.EventHandler(this.btnAddRule_Click);
            // 
            // btnLoadRules
            // 
            this.btnLoadRules.BackColor = System.Drawing.Color.LightSalmon;
            this.btnLoadRules.Enabled = false;
            this.btnLoadRules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadRules.Image = global::GreenHouseConfig.Properties.Resources.load_rules;
            this.btnLoadRules.Location = new System.Drawing.Point(29, 213);
            this.btnLoadRules.Name = "btnLoadRules";
            this.btnLoadRules.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnLoadRules.Size = new System.Drawing.Size(258, 38);
            this.btnLoadRules.TabIndex = 8;
            this.btnLoadRules.Text = "Загрузить из контроллера";
            this.btnLoadRules.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnLoadRules, "Загрузить правила из контроллера");
            this.btnLoadRules.UseVisualStyleBackColor = false;
            this.btnLoadRules.Click += new System.EventHandler(this.btnLoadRules_Click);
            // 
            // lblComputeRulesmemory
            // 
            this.lblComputeRulesmemory.LinkColor = System.Drawing.Color.White;
            this.lblComputeRulesmemory.Location = new System.Drawing.Point(110, 169);
            this.lblComputeRulesmemory.Name = "lblComputeRulesmemory";
            this.lblComputeRulesmemory.Size = new System.Drawing.Size(177, 13);
            this.lblComputeRulesmemory.TabIndex = 16;
            this.lblComputeRulesmemory.TabStop = true;
            this.lblComputeRulesmemory.Text = "Расход памяти";
            this.lblComputeRulesmemory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ttDefault.SetToolTip(this.lblComputeRulesmemory, "Информация по расходу правилами памяти в контроллере");
            this.lblComputeRulesmemory.VisitedLinkColor = System.Drawing.Color.White;
            this.lblComputeRulesmemory.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblComputeRulesmemory_LinkClicked);
            // 
            // btnEditRule
            // 
            this.btnEditRule.BackColor = System.Drawing.Color.LightSalmon;
            this.btnEditRule.Enabled = false;
            this.btnEditRule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditRule.Image = global::GreenHouseConfig.Properties.Resources.edit_rule;
            this.btnEditRule.Location = new System.Drawing.Point(29, 84);
            this.btnEditRule.Name = "btnEditRule";
            this.btnEditRule.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnEditRule.Size = new System.Drawing.Size(258, 38);
            this.btnEditRule.TabIndex = 15;
            this.btnEditRule.Text = "Изменить выбранное правило";
            this.btnEditRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnEditRule, "Изменить выбранное правило");
            this.btnEditRule.UseVisualStyleBackColor = false;
            this.btnEditRule.Click += new System.EventHandler(this.btnEditRule_Click);
            // 
            // tpLog
            // 
            this.tpLog.BackColor = System.Drawing.Color.White;
            this.tpLog.Controls.Add(this.flowLayoutPanel6);
            this.tpLog.ImageIndex = 2;
            this.tpLog.Location = new System.Drawing.Point(4, 36);
            this.tpLog.Margin = new System.Windows.Forms.Padding(10);
            this.tpLog.Name = "tpLog";
            this.tpLog.Padding = new System.Windows.Forms.Padding(3);
            this.tpLog.Size = new System.Drawing.Size(1000, 423);
            this.tpLog.TabIndex = 8;
            this.tpLog.Text = "Логи";
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.AutoScroll = true;
            this.flowLayoutPanel6.Controls.Add(this.panel32);
            this.flowLayoutPanel6.Controls.Add(this.panel34);
            this.flowLayoutPanel6.Controls.Add(this.panel36);
            this.flowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel6.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel6.TabIndex = 15;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.SteelBlue;
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.panel33);
            this.panel32.Controls.Add(this.tbLogsDirectory);
            this.panel32.Controls.Add(this.btnSelectFolder);
            this.panel32.Controls.Add(this.label27);
            this.panel32.Location = new System.Drawing.Point(13, 20);
            this.panel32.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(292, 118);
            this.panel32.TabIndex = 1;
            // 
            // panel33
            // 
            this.panel33.AutoSize = true;
            this.panel33.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel33.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel33.Controls.Add(this.label47);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Padding = new System.Windows.Forms.Padding(3);
            this.panel33.Size = new System.Drawing.Size(290, 26);
            this.panel33.TabIndex = 0;
            // 
            // label47
            // 
            this.label47.Dock = System.Windows.Forms.DockStyle.Top;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label47.ForeColor = System.Drawing.Color.Beige;
            this.label47.Location = new System.Drawing.Point(3, 3);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(284, 20);
            this.label47.TabIndex = 1;
            this.label47.Text = "Папка для логов";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbLogsDirectory
            // 
            this.tbLogsDirectory.BackColor = System.Drawing.Color.White;
            this.tbLogsDirectory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbLogsDirectory.ForeColor = System.Drawing.Color.Black;
            this.tbLogsDirectory.Location = new System.Drawing.Point(8, 60);
            this.tbLogsDirectory.Name = "tbLogsDirectory";
            this.tbLogsDirectory.ReadOnly = true;
            this.tbLogsDirectory.Size = new System.Drawing.Size(245, 20);
            this.tbLogsDirectory.TabIndex = 1;
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.ImageIndex = 9;
            this.btnSelectFolder.ImageList = this.imglTabImages;
            this.btnSelectFolder.Location = new System.Drawing.Point(255, 58);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(25, 25);
            this.btnSelectFolder.TabIndex = 2;
            this.ttDefault.SetToolTip(this.btnSelectFolder, "Выбрать папку для логов");
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.btnSelectFolder_Click);
            // 
            // imglTabImages
            // 
            this.imglTabImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglTabImages.ImageStream")));
            this.imglTabImages.TransparentColor = System.Drawing.Color.Transparent;
            this.imglTabImages.Images.SetKeyName(0, "kchart16.png");
            this.imglTabImages.Images.SetKeyName(1, "9006-prescription_pad.png");
            this.imglTabImages.Images.SetKeyName(2, "list.png");
            this.imglTabImages.Images.SetKeyName(3, "ipod_unmount.png");
            this.imglTabImages.Images.SetKeyName(4, "water.png");
            this.imglTabImages.Images.SetKeyName(5, "help_hint.png");
            this.imglTabImages.Images.SetKeyName(6, "wifismall.png");
            this.imglTabImages.Images.SetKeyName(7, "raindrop.png");
            this.imglTabImages.Images.SetKeyName(8, "flag_green.png");
            this.imglTabImages.Images.SetKeyName(9, "0003-folder.png");
            this.imglTabImages.Images.SetKeyName(10, "fill.png");
            this.imglTabImages.Images.SetKeyName(11, "multiple_commands.png");
            this.imglTabImages.Images.SetKeyName(12, "delta_small.png");
            this.imglTabImages.Images.SetKeyName(13, "soil_moisture.png");
            this.imglTabImages.Images.SetKeyName(14, "preferences_desktop_icons.png");
            this.imglTabImages.Images.SetKeyName(15, "network.png");
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(5, 44);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(141, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Текущая папка для логов:";
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.SteelBlue;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.rbMonth);
            this.panel34.Controls.Add(this.panel35);
            this.panel34.Controls.Add(this.rbWeek);
            this.panel34.Controls.Add(this.rbDay);
            this.panel34.Location = new System.Drawing.Point(318, 20);
            this.panel34.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(200, 118);
            this.panel34.TabIndex = 2;
            // 
            // rbMonth
            // 
            this.rbMonth.AutoSize = true;
            this.rbMonth.ForeColor = System.Drawing.Color.White;
            this.rbMonth.Location = new System.Drawing.Point(19, 81);
            this.rbMonth.Name = "rbMonth";
            this.rbMonth.Size = new System.Drawing.Size(58, 17);
            this.rbMonth.TabIndex = 14;
            this.rbMonth.Text = "Месяц";
            this.rbMonth.UseVisualStyleBackColor = true;
            // 
            // panel35
            // 
            this.panel35.AutoSize = true;
            this.panel35.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel35.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel35.Controls.Add(this.label55);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel35.Location = new System.Drawing.Point(0, 0);
            this.panel35.Name = "panel35";
            this.panel35.Padding = new System.Windows.Forms.Padding(3);
            this.panel35.Size = new System.Drawing.Size(198, 26);
            this.panel35.TabIndex = 0;
            // 
            // label55
            // 
            this.label55.Dock = System.Windows.Forms.DockStyle.Top;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label55.ForeColor = System.Drawing.Color.Beige;
            this.label55.Location = new System.Drawing.Point(3, 3);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(192, 20);
            this.label55.TabIndex = 1;
            this.label55.Text = "Интервал";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbWeek
            // 
            this.rbWeek.AutoSize = true;
            this.rbWeek.ForeColor = System.Drawing.Color.White;
            this.rbWeek.Location = new System.Drawing.Point(19, 60);
            this.rbWeek.Name = "rbWeek";
            this.rbWeek.Size = new System.Drawing.Size(63, 17);
            this.rbWeek.TabIndex = 13;
            this.rbWeek.Text = "Неделя";
            this.rbWeek.UseVisualStyleBackColor = true;
            // 
            // rbDay
            // 
            this.rbDay.AutoSize = true;
            this.rbDay.Checked = true;
            this.rbDay.ForeColor = System.Drawing.Color.White;
            this.rbDay.Location = new System.Drawing.Point(19, 37);
            this.rbDay.Name = "rbDay";
            this.rbDay.Size = new System.Drawing.Size(52, 17);
            this.rbDay.TabIndex = 12;
            this.rbDay.TabStop = true;
            this.rbDay.Text = "День";
            this.rbDay.UseVisualStyleBackColor = true;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.SteelBlue;
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.lblLoadLogs);
            this.panel36.Controls.Add(this.lblCurrentLogLine);
            this.panel36.Controls.Add(this.lblCurrentLogFileName);
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Controls.Add(this.pbLogsProgress);
            this.panel36.Controls.Add(this.label28);
            this.panel36.Location = new System.Drawing.Point(531, 20);
            this.panel36.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(371, 150);
            this.panel36.TabIndex = 3;
            // 
            // lblLoadLogs
            // 
            this.lblLoadLogs.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblLoadLogs.Enabled = false;
            this.lblLoadLogs.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLoadLogs.ForeColor = System.Drawing.Color.White;
            this.lblLoadLogs.LinkColor = System.Drawing.Color.White;
            this.lblLoadLogs.Location = new System.Drawing.Point(0, 125);
            this.lblLoadLogs.Name = "lblLoadLogs";
            this.lblLoadLogs.Padding = new System.Windows.Forms.Padding(5);
            this.lblLoadLogs.Size = new System.Drawing.Size(369, 23);
            this.lblLoadLogs.TabIndex = 26;
            this.lblLoadLogs.TabStop = true;
            this.lblLoadLogs.Text = "Выгрузить логи";
            this.lblLoadLogs.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblLoadLogs, "Выгрузить логи из контроллера");
            this.lblLoadLogs.VisitedLinkColor = System.Drawing.Color.White;
            this.lblLoadLogs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblLoadLogs_LinkClicked);
            // 
            // lblCurrentLogLine
            // 
            this.lblCurrentLogLine.AutoSize = true;
            this.lblCurrentLogLine.ForeColor = System.Drawing.Color.White;
            this.lblCurrentLogLine.Location = new System.Drawing.Point(7, 104);
            this.lblCurrentLogLine.Name = "lblCurrentLogLine";
            this.lblCurrentLogLine.Size = new System.Drawing.Size(34, 13);
            this.lblCurrentLogLine.TabIndex = 14;
            this.lblCurrentLogLine.Text = "         ";
            // 
            // lblCurrentLogFileName
            // 
            this.lblCurrentLogFileName.AutoSize = true;
            this.lblCurrentLogFileName.ForeColor = System.Drawing.Color.White;
            this.lblCurrentLogFileName.Location = new System.Drawing.Point(7, 83);
            this.lblCurrentLogFileName.Name = "lblCurrentLogFileName";
            this.lblCurrentLogFileName.Size = new System.Drawing.Size(34, 13);
            this.lblCurrentLogFileName.TabIndex = 13;
            this.lblCurrentLogFileName.Text = "         ";
            // 
            // panel37
            // 
            this.panel37.AutoSize = true;
            this.panel37.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel37.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel37.Controls.Add(this.label56);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel37.Location = new System.Drawing.Point(0, 0);
            this.panel37.Name = "panel37";
            this.panel37.Padding = new System.Windows.Forms.Padding(3);
            this.panel37.Size = new System.Drawing.Size(369, 26);
            this.panel37.TabIndex = 0;
            // 
            // label56
            // 
            this.label56.Dock = System.Windows.Forms.DockStyle.Top;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label56.ForeColor = System.Drawing.Color.Beige;
            this.label56.Location = new System.Drawing.Point(3, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(363, 20);
            this.label56.TabIndex = 1;
            this.label56.Text = "Выгрузка";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbLogsProgress
            // 
            this.pbLogsProgress.ForeColor = System.Drawing.Color.LightSalmon;
            this.pbLogsProgress.Location = new System.Drawing.Point(10, 54);
            this.pbLogsProgress.Name = "pbLogsProgress";
            this.pbLogsProgress.Size = new System.Drawing.Size(353, 23);
            this.pbLogsProgress.Step = 1;
            this.pbLogsProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbLogsProgress.TabIndex = 12;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(7, 37);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 11;
            this.label28.Text = "Прогресс:";
            // 
            // tpWaterFlow
            // 
            this.tpWaterFlow.BackColor = System.Drawing.Color.White;
            this.tpWaterFlow.Controls.Add(this.flowLayoutPanel8);
            this.tpWaterFlow.ImageIndex = 10;
            this.tpWaterFlow.Location = new System.Drawing.Point(4, 36);
            this.tpWaterFlow.Name = "tpWaterFlow";
            this.tpWaterFlow.Padding = new System.Windows.Forms.Padding(3);
            this.tpWaterFlow.Size = new System.Drawing.Size(1000, 423);
            this.tpWaterFlow.TabIndex = 9;
            this.tpWaterFlow.Text = "Расход";
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.AutoScroll = true;
            this.flowLayoutPanel8.Controls.Add(this.panel49);
            this.flowLayoutPanel8.Controls.Add(this.panel51);
            this.flowLayoutPanel8.Controls.Add(this.panel53);
            this.flowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel8.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel8.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel8.TabIndex = 16;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.SteelBlue;
            this.panel49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel49.Controls.Add(this.label37);
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Controls.Add(this.nudFlowCalibration1);
            this.panel49.Controls.Add(this.pictureBox2);
            this.panel49.Controls.Add(this.lblFlowInstant1);
            this.panel49.Controls.Add(this.label31);
            this.panel49.Controls.Add(this.label30);
            this.panel49.Controls.Add(this.lblFlowIncremental1);
            this.panel49.Location = new System.Drawing.Point(13, 20);
            this.panel49.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(328, 195);
            this.panel49.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(62, 162);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(167, 23);
            this.label37.TabIndex = 10;
            this.label37.Text = "Фактор калибровки:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel50
            // 
            this.panel50.AutoSize = true;
            this.panel50.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel50.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel50.Controls.Add(this.label66);
            this.panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Padding = new System.Windows.Forms.Padding(3);
            this.panel50.Size = new System.Drawing.Size(326, 26);
            this.panel50.TabIndex = 0;
            // 
            // label66
            // 
            this.label66.Dock = System.Windows.Forms.DockStyle.Top;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label66.ForeColor = System.Drawing.Color.Beige;
            this.label66.Location = new System.Drawing.Point(3, 3);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(320, 20);
            this.label66.TabIndex = 1;
            this.label66.Text = "Первый расходомер";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudFlowCalibration1
            // 
            this.nudFlowCalibration1.BackColor = System.Drawing.Color.White;
            this.nudFlowCalibration1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudFlowCalibration1.ForeColor = System.Drawing.Color.Black;
            this.nudFlowCalibration1.Location = new System.Drawing.Point(241, 160);
            this.nudFlowCalibration1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFlowCalibration1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlowCalibration1.Name = "nudFlowCalibration1";
            this.nudFlowCalibration1.Size = new System.Drawing.Size(61, 20);
            this.nudFlowCalibration1.TabIndex = 9;
            this.nudFlowCalibration1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(222, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(96, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // lblFlowInstant1
            // 
            this.lblFlowInstant1.AutoSize = true;
            this.lblFlowInstant1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowInstant1.ForeColor = System.Drawing.Color.White;
            this.lblFlowInstant1.Location = new System.Drawing.Point(16, 59);
            this.lblFlowInstant1.Name = "lblFlowInstant1";
            this.lblFlowInstant1.Size = new System.Drawing.Size(126, 20);
            this.lblFlowInstant1.TabIndex = 2;
            this.lblFlowInstant1.Text = "<нет данных>";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(17, 95);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(83, 13);
            this.label31.TabIndex = 5;
            this.label31.Text = "Общий расход:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(17, 41);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(112, 13);
            this.label30.TabIndex = 3;
            this.label30.Text = "Мгновенный расход:";
            // 
            // lblFlowIncremental1
            // 
            this.lblFlowIncremental1.AutoSize = true;
            this.lblFlowIncremental1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowIncremental1.ForeColor = System.Drawing.Color.White;
            this.lblFlowIncremental1.Location = new System.Drawing.Point(16, 113);
            this.lblFlowIncremental1.Name = "lblFlowIncremental1";
            this.lblFlowIncremental1.Size = new System.Drawing.Size(126, 20);
            this.lblFlowIncremental1.TabIndex = 4;
            this.lblFlowIncremental1.Text = "<нет данных>";
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.SteelBlue;
            this.panel51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel51.Controls.Add(this.label36);
            this.panel51.Controls.Add(this.panel52);
            this.panel51.Controls.Add(this.nudFlowCalibration2);
            this.panel51.Controls.Add(this.pictureBox5);
            this.panel51.Controls.Add(this.lblFlowInstant2);
            this.panel51.Controls.Add(this.label29);
            this.panel51.Controls.Add(this.label33);
            this.panel51.Controls.Add(this.lblFlowIncremental2);
            this.panel51.Location = new System.Drawing.Point(354, 20);
            this.panel51.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(328, 195);
            this.panel51.TabIndex = 2;
            // 
            // label36
            // 
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(62, 162);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(167, 23);
            this.label36.TabIndex = 9;
            this.label36.Text = "Фактор калибровки:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel52
            // 
            this.panel52.AutoSize = true;
            this.panel52.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel52.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel52.Controls.Add(this.label65);
            this.panel52.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel52.Location = new System.Drawing.Point(0, 0);
            this.panel52.Name = "panel52";
            this.panel52.Padding = new System.Windows.Forms.Padding(3);
            this.panel52.Size = new System.Drawing.Size(326, 26);
            this.panel52.TabIndex = 0;
            // 
            // label65
            // 
            this.label65.Dock = System.Windows.Forms.DockStyle.Top;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label65.ForeColor = System.Drawing.Color.Beige;
            this.label65.Location = new System.Drawing.Point(3, 3);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(320, 20);
            this.label65.TabIndex = 1;
            this.label65.Text = "Второй расходомер";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudFlowCalibration2
            // 
            this.nudFlowCalibration2.BackColor = System.Drawing.Color.White;
            this.nudFlowCalibration2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudFlowCalibration2.ForeColor = System.Drawing.Color.Black;
            this.nudFlowCalibration2.Location = new System.Drawing.Point(241, 160);
            this.nudFlowCalibration2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFlowCalibration2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlowCalibration2.Name = "nudFlowCalibration2";
            this.nudFlowCalibration2.Size = new System.Drawing.Size(61, 20);
            this.nudFlowCalibration2.TabIndex = 8;
            this.nudFlowCalibration2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(222, 32);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(96, 96);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // lblFlowInstant2
            // 
            this.lblFlowInstant2.AutoSize = true;
            this.lblFlowInstant2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowInstant2.ForeColor = System.Drawing.Color.White;
            this.lblFlowInstant2.Location = new System.Drawing.Point(17, 59);
            this.lblFlowInstant2.Name = "lblFlowInstant2";
            this.lblFlowInstant2.Size = new System.Drawing.Size(126, 20);
            this.lblFlowInstant2.TabIndex = 2;
            this.lblFlowInstant2.Text = "<нет данных>";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(16, 95);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 13);
            this.label29.TabIndex = 5;
            this.label29.Text = "Общий расход:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(18, 41);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(112, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Мгновенный расход:";
            // 
            // lblFlowIncremental2
            // 
            this.lblFlowIncremental2.AutoSize = true;
            this.lblFlowIncremental2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowIncremental2.ForeColor = System.Drawing.Color.White;
            this.lblFlowIncremental2.Location = new System.Drawing.Point(17, 113);
            this.lblFlowIncremental2.Name = "lblFlowIncremental2";
            this.lblFlowIncremental2.Size = new System.Drawing.Size(126, 20);
            this.lblFlowIncremental2.TabIndex = 4;
            this.lblFlowIncremental2.Text = "<нет данных>";
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.SteelBlue;
            this.panel53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel53.Controls.Add(this.panel54);
            this.panel53.Controls.Add(this.btnResetWaterflowData);
            this.panel53.Controls.Add(this.btnSaveFlowSettings);
            this.panel53.Location = new System.Drawing.Point(695, 20);
            this.panel53.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(188, 195);
            this.panel53.TabIndex = 3;
            // 
            // panel54
            // 
            this.panel54.AutoSize = true;
            this.panel54.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel54.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel54.Controls.Add(this.label67);
            this.panel54.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel54.Location = new System.Drawing.Point(0, 0);
            this.panel54.Name = "panel54";
            this.panel54.Padding = new System.Windows.Forms.Padding(3);
            this.panel54.Size = new System.Drawing.Size(186, 26);
            this.panel54.TabIndex = 0;
            // 
            // label67
            // 
            this.label67.Dock = System.Windows.Forms.DockStyle.Top;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label67.ForeColor = System.Drawing.Color.Beige;
            this.label67.Location = new System.Drawing.Point(3, 3);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(180, 20);
            this.label67.TabIndex = 1;
            this.label67.Text = "Настройки";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnResetWaterflowData
            // 
            this.btnResetWaterflowData.BackColor = System.Drawing.Color.LightSalmon;
            this.btnResetWaterflowData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResetWaterflowData.ForeColor = System.Drawing.Color.Black;
            this.btnResetWaterflowData.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnResetWaterflowData.Location = new System.Drawing.Point(23, 55);
            this.btnResetWaterflowData.Name = "btnResetWaterflowData";
            this.btnResetWaterflowData.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnResetWaterflowData.Size = new System.Drawing.Size(140, 38);
            this.btnResetWaterflowData.TabIndex = 15;
            this.btnResetWaterflowData.Text = "Сбросить";
            this.btnResetWaterflowData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnResetWaterflowData, "Сбросить общий расход в 0");
            this.btnResetWaterflowData.UseVisualStyleBackColor = false;
            this.btnResetWaterflowData.Click += new System.EventHandler(this.btnResetWaterflowData_Click);
            // 
            // btnSaveFlowSettings
            // 
            this.btnSaveFlowSettings.BackColor = System.Drawing.Color.LightGreen;
            this.btnSaveFlowSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveFlowSettings.ForeColor = System.Drawing.Color.Black;
            this.btnSaveFlowSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveFlowSettings.Location = new System.Drawing.Point(23, 99);
            this.btnSaveFlowSettings.Name = "btnSaveFlowSettings";
            this.btnSaveFlowSettings.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnSaveFlowSettings.Size = new System.Drawing.Size(140, 38);
            this.btnSaveFlowSettings.TabIndex = 14;
            this.btnSaveFlowSettings.Text = "Сохранить";
            this.btnSaveFlowSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveFlowSettings, "Сохранить факторы калибровки в контроллер");
            this.btnSaveFlowSettings.UseVisualStyleBackColor = false;
            this.btnSaveFlowSettings.Click += new System.EventHandler(this.btnSaveFlowSettings_Click);
            // 
            // tpMultipleCommands
            // 
            this.tpMultipleCommands.BackColor = System.Drawing.Color.White;
            this.tpMultipleCommands.Controls.Add(this.flowLayoutPanel9);
            this.tpMultipleCommands.ImageIndex = 11;
            this.tpMultipleCommands.Location = new System.Drawing.Point(4, 36);
            this.tpMultipleCommands.Name = "tpMultipleCommands";
            this.tpMultipleCommands.Padding = new System.Windows.Forms.Padding(3);
            this.tpMultipleCommands.Size = new System.Drawing.Size(1000, 423);
            this.tpMultipleCommands.TabIndex = 10;
            this.tpMultipleCommands.Text = "Составные команды";
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.AutoScroll = true;
            this.flowLayoutPanel9.Controls.Add(this.panel55);
            this.flowLayoutPanel9.Controls.Add(this.panel57);
            this.flowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel9.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel9.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel9.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel9.TabIndex = 26;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.SteelBlue;
            this.panel55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel55.Controls.Add(this.lvCompositeCommandsList);
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Location = new System.Drawing.Point(13, 20);
            this.panel55.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(468, 321);
            this.panel55.TabIndex = 1;
            // 
            // lvCompositeCommandsList
            // 
            this.lvCompositeCommandsList.BackColor = System.Drawing.Color.White;
            this.lvCompositeCommandsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvCompositeCommandsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8});
            this.lvCompositeCommandsList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvCompositeCommandsList.ForeColor = System.Drawing.Color.Black;
            this.lvCompositeCommandsList.FullRowSelect = true;
            this.lvCompositeCommandsList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvCompositeCommandsList.HideSelection = false;
            this.lvCompositeCommandsList.Location = new System.Drawing.Point(0, 26);
            this.lvCompositeCommandsList.MultiSelect = false;
            this.lvCompositeCommandsList.Name = "lvCompositeCommandsList";
            this.lvCompositeCommandsList.ShowItemToolTips = true;
            this.lvCompositeCommandsList.Size = new System.Drawing.Size(466, 293);
            this.lvCompositeCommandsList.TabIndex = 0;
            this.lvCompositeCommandsList.UseCompatibleStateImageBehavior = false;
            this.lvCompositeCommandsList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "#";
            this.columnHeader7.Width = 70;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Имя";
            this.columnHeader8.Width = 350;
            // 
            // panel56
            // 
            this.panel56.AutoSize = true;
            this.panel56.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel56.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel56.Controls.Add(this.label72);
            this.panel56.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel56.Location = new System.Drawing.Point(0, 0);
            this.panel56.Name = "panel56";
            this.panel56.Padding = new System.Windows.Forms.Padding(3);
            this.panel56.Size = new System.Drawing.Size(466, 26);
            this.panel56.TabIndex = 0;
            // 
            // label72
            // 
            this.label72.Dock = System.Windows.Forms.DockStyle.Top;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label72.ForeColor = System.Drawing.Color.Beige;
            this.label72.Location = new System.Drawing.Point(3, 3);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(460, 20);
            this.label72.TabIndex = 1;
            this.label72.Text = "Список составных команд";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.SteelBlue;
            this.panel57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel57.Controls.Add(this.panel58);
            this.panel57.Controls.Add(this.btnClearCCCommands);
            this.panel57.Controls.Add(this.btnUploadCompositeCommands);
            this.panel57.Controls.Add(this.btnDeleteCompositeCommand);
            this.panel57.Controls.Add(this.btnEditCompositeCommand);
            this.panel57.Controls.Add(this.btnAddCompositeCommand);
            this.panel57.Location = new System.Drawing.Point(494, 20);
            this.panel57.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(318, 321);
            this.panel57.TabIndex = 2;
            // 
            // panel58
            // 
            this.panel58.AutoSize = true;
            this.panel58.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel58.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel58.Controls.Add(this.label68);
            this.panel58.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel58.Location = new System.Drawing.Point(0, 0);
            this.panel58.Name = "panel58";
            this.panel58.Padding = new System.Windows.Forms.Padding(3);
            this.panel58.Size = new System.Drawing.Size(316, 26);
            this.panel58.TabIndex = 0;
            // 
            // label68
            // 
            this.label68.Dock = System.Windows.Forms.DockStyle.Top;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label68.ForeColor = System.Drawing.Color.Beige;
            this.label68.Location = new System.Drawing.Point(3, 3);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(310, 20);
            this.label68.TabIndex = 1;
            this.label68.Text = "Действия";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClearCCCommands
            // 
            this.btnClearCCCommands.BackColor = System.Drawing.Color.LightSalmon;
            this.btnClearCCCommands.Enabled = false;
            this.btnClearCCCommands.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearCCCommands.ForeColor = System.Drawing.Color.Black;
            this.btnClearCCCommands.Image = global::GreenHouseConfig.Properties.Resources.eraser;
            this.btnClearCCCommands.Location = new System.Drawing.Point(29, 213);
            this.btnClearCCCommands.Name = "btnClearCCCommands";
            this.btnClearCCCommands.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnClearCCCommands.Size = new System.Drawing.Size(258, 38);
            this.btnClearCCCommands.TabIndex = 25;
            this.btnClearCCCommands.Text = "Очистить в контроллере";
            this.btnClearCCCommands.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnClearCCCommands, "Очистить список составных команд в контроллере");
            this.btnClearCCCommands.UseVisualStyleBackColor = false;
            this.btnClearCCCommands.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUploadCompositeCommands
            // 
            this.btnUploadCompositeCommands.BackColor = System.Drawing.Color.LightGreen;
            this.btnUploadCompositeCommands.Enabled = false;
            this.btnUploadCompositeCommands.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUploadCompositeCommands.ForeColor = System.Drawing.Color.Black;
            this.btnUploadCompositeCommands.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnUploadCompositeCommands.Location = new System.Drawing.Point(29, 257);
            this.btnUploadCompositeCommands.Name = "btnUploadCompositeCommands";
            this.btnUploadCompositeCommands.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnUploadCompositeCommands.Size = new System.Drawing.Size(258, 38);
            this.btnUploadCompositeCommands.TabIndex = 20;
            this.btnUploadCompositeCommands.Text = "Сохранить в контроллер";
            this.btnUploadCompositeCommands.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnUploadCompositeCommands, "Сохранить составные команды в контроллер");
            this.btnUploadCompositeCommands.UseVisualStyleBackColor = false;
            this.btnUploadCompositeCommands.Click += new System.EventHandler(this.btnUploadCompositeCommands_Click);
            // 
            // btnDeleteCompositeCommand
            // 
            this.btnDeleteCompositeCommand.BackColor = System.Drawing.Color.LightSalmon;
            this.btnDeleteCompositeCommand.Enabled = false;
            this.btnDeleteCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteCompositeCommand.Location = new System.Drawing.Point(29, 128);
            this.btnDeleteCompositeCommand.Name = "btnDeleteCompositeCommand";
            this.btnDeleteCompositeCommand.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnDeleteCompositeCommand.Size = new System.Drawing.Size(258, 38);
            this.btnDeleteCompositeCommand.TabIndex = 24;
            this.btnDeleteCompositeCommand.Text = "Удалить выделенный список";
            this.btnDeleteCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnDeleteCompositeCommand, "Удалить выбранный список");
            this.btnDeleteCompositeCommand.UseVisualStyleBackColor = false;
            this.btnDeleteCompositeCommand.Click += new System.EventHandler(this.btnDeleteCompositeCommand_Click);
            // 
            // btnEditCompositeCommand
            // 
            this.btnEditCompositeCommand.BackColor = System.Drawing.Color.LightSalmon;
            this.btnEditCompositeCommand.Enabled = false;
            this.btnEditCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnEditCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.edit_rule;
            this.btnEditCompositeCommand.Location = new System.Drawing.Point(29, 84);
            this.btnEditCompositeCommand.Name = "btnEditCompositeCommand";
            this.btnEditCompositeCommand.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnEditCompositeCommand.Size = new System.Drawing.Size(258, 38);
            this.btnEditCompositeCommand.TabIndex = 22;
            this.btnEditCompositeCommand.Text = "Изменить выделенный список";
            this.btnEditCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnEditCompositeCommand, "Изменить выбранный список");
            this.btnEditCompositeCommand.UseVisualStyleBackColor = false;
            this.btnEditCompositeCommand.Click += new System.EventHandler(this.btnEditCompositeCommand_Click);
            // 
            // btnAddCompositeCommand
            // 
            this.btnAddCompositeCommand.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnAddCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddCompositeCommand.Location = new System.Drawing.Point(29, 40);
            this.btnAddCompositeCommand.Name = "btnAddCompositeCommand";
            this.btnAddCompositeCommand.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            this.btnAddCompositeCommand.Size = new System.Drawing.Size(258, 38);
            this.btnAddCompositeCommand.TabIndex = 23;
            this.btnAddCompositeCommand.Text = "Добавить новый список";
            this.btnAddCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddCompositeCommand, "Добавить новый список");
            this.btnAddCompositeCommand.UseVisualStyleBackColor = false;
            this.btnAddCompositeCommand.Click += new System.EventHandler(this.btnAddCompositeCommand_Click);
            // 
            // tpDeltas
            // 
            this.tpDeltas.BackColor = System.Drawing.Color.White;
            this.tpDeltas.Controls.Add(this.flowLayoutPanel2);
            this.tpDeltas.ImageIndex = 12;
            this.tpDeltas.Location = new System.Drawing.Point(4, 36);
            this.tpDeltas.Margin = new System.Windows.Forms.Padding(10);
            this.tpDeltas.Name = "tpDeltas";
            this.tpDeltas.Padding = new System.Windows.Forms.Padding(3);
            this.tpDeltas.Size = new System.Drawing.Size(1000, 423);
            this.tpDeltas.TabIndex = 11;
            this.tpDeltas.Text = "Дельты";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.AutoScroll = true;
            this.flowLayoutPanel2.Controls.Add(this.panel19);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel2.TabIndex = 2;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.SteelBlue;
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.lvDeltasList);
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Location = new System.Drawing.Point(13, 20);
            this.panel19.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(335, 382);
            this.panel19.TabIndex = 2;
            // 
            // lvDeltasList
            // 
            this.lvDeltasList.BackColor = System.Drawing.Color.White;
            this.lvDeltasList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvDeltasList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.lvDeltasList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvDeltasList.ForeColor = System.Drawing.Color.Black;
            this.lvDeltasList.FullRowSelect = true;
            this.lvDeltasList.GridLines = true;
            this.lvDeltasList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvDeltasList.LabelWrap = false;
            this.lvDeltasList.Location = new System.Drawing.Point(0, 26);
            this.lvDeltasList.MultiSelect = false;
            this.lvDeltasList.Name = "lvDeltasList";
            this.lvDeltasList.Size = new System.Drawing.Size(333, 354);
            this.lvDeltasList.TabIndex = 1;
            this.lvDeltasList.UseCompatibleStateImageBehavior = false;
            this.lvDeltasList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "#";
            this.columnHeader9.Width = 40;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Тип";
            this.columnHeader10.Width = 140;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Показание";
            this.columnHeader11.Width = 120;
            // 
            // panel20
            // 
            this.panel20.AutoSize = true;
            this.panel20.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel20.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel20.Controls.Add(this.label53);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Padding = new System.Windows.Forms.Padding(3);
            this.panel20.Size = new System.Drawing.Size(333, 26);
            this.panel20.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.Dock = System.Windows.Forms.DockStyle.Top;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label53.ForeColor = System.Drawing.Color.Beige;
            this.label53.Location = new System.Drawing.Point(3, 3);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(327, 20);
            this.label53.TabIndex = 1;
            this.label53.Text = "Список дельт";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpSoilMoisture
            // 
            this.tpSoilMoisture.BackColor = System.Drawing.Color.White;
            this.tpSoilMoisture.Controls.Add(this.flowLayoutPanel4);
            this.tpSoilMoisture.ImageIndex = 13;
            this.tpSoilMoisture.Location = new System.Drawing.Point(4, 36);
            this.tpSoilMoisture.Margin = new System.Windows.Forms.Padding(10);
            this.tpSoilMoisture.Name = "tpSoilMoisture";
            this.tpSoilMoisture.Padding = new System.Windows.Forms.Padding(3);
            this.tpSoilMoisture.Size = new System.Drawing.Size(1000, 423);
            this.tpSoilMoisture.TabIndex = 12;
            this.tpSoilMoisture.Text = "Влажность почвы";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.AutoScroll = true;
            this.flowLayoutPanel4.Controls.Add(this.panel23);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel4.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel4.TabIndex = 4;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.SteelBlue;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.lvSoilMoistureSensorsData);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Location = new System.Drawing.Point(13, 20);
            this.panel23.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(335, 382);
            this.panel23.TabIndex = 3;
            // 
            // lvSoilMoistureSensorsData
            // 
            this.lvSoilMoistureSensorsData.BackColor = System.Drawing.Color.White;
            this.lvSoilMoistureSensorsData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvSoilMoistureSensorsData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader14});
            this.lvSoilMoistureSensorsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSoilMoistureSensorsData.ForeColor = System.Drawing.Color.Black;
            this.lvSoilMoistureSensorsData.FullRowSelect = true;
            this.lvSoilMoistureSensorsData.GridLines = true;
            this.lvSoilMoistureSensorsData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvSoilMoistureSensorsData.LabelWrap = false;
            this.lvSoilMoistureSensorsData.Location = new System.Drawing.Point(0, 26);
            this.lvSoilMoistureSensorsData.MultiSelect = false;
            this.lvSoilMoistureSensorsData.Name = "lvSoilMoistureSensorsData";
            this.lvSoilMoistureSensorsData.Size = new System.Drawing.Size(333, 354);
            this.lvSoilMoistureSensorsData.TabIndex = 1;
            this.lvSoilMoistureSensorsData.UseCompatibleStateImageBehavior = false;
            this.lvSoilMoistureSensorsData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "#";
            this.columnHeader12.Width = 40;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Влажность почвы";
            this.columnHeader14.Width = 250;
            // 
            // panel24
            // 
            this.panel24.AutoSize = true;
            this.panel24.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel24.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel24.Controls.Add(this.label32);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Padding = new System.Windows.Forms.Padding(3);
            this.panel24.Size = new System.Drawing.Size(333, 26);
            this.panel24.TabIndex = 0;
            // 
            // label32
            // 
            this.label32.Dock = System.Windows.Forms.DockStyle.Top;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.ForeColor = System.Drawing.Color.Beige;
            this.label32.Location = new System.Drawing.Point(3, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(327, 20);
            this.label32.TabIndex = 1;
            this.label32.Text = "Влажность почвы";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpPH
            // 
            this.tpPH.BackColor = System.Drawing.Color.White;
            this.tpPH.Controls.Add(this.flowLayoutPanel7);
            this.tpPH.ImageIndex = 14;
            this.tpPH.Location = new System.Drawing.Point(4, 36);
            this.tpPH.Margin = new System.Windows.Forms.Padding(10);
            this.tpPH.Name = "tpPH";
            this.tpPH.Padding = new System.Windows.Forms.Padding(3);
            this.tpPH.Size = new System.Drawing.Size(1000, 423);
            this.tpPH.TabIndex = 13;
            this.tpPH.Text = "PH";
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.AutoScroll = true;
            this.flowLayoutPanel7.Controls.Add(this.panel38);
            this.flowLayoutPanel7.Controls.Add(this.panel46);
            this.flowLayoutPanel7.Controls.Add(this.panel40);
            this.flowLayoutPanel7.Controls.Add(this.panel42);
            this.flowLayoutPanel7.Controls.Add(this.panel44);
            this.flowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel7.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel7.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel7.TabIndex = 49;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.SteelBlue;
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.lvPH);
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Location = new System.Drawing.Point(13, 20);
            this.panel38.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(232, 144);
            this.panel38.TabIndex = 1;
            // 
            // lvPH
            // 
            this.lvPH.BackColor = System.Drawing.Color.White;
            this.lvPH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvPH.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18});
            this.lvPH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvPH.ForeColor = System.Drawing.Color.Black;
            this.lvPH.FullRowSelect = true;
            this.lvPH.GridLines = true;
            this.lvPH.HideSelection = false;
            this.lvPH.Location = new System.Drawing.Point(0, 26);
            this.lvPH.MultiSelect = false;
            this.lvPH.Name = "lvPH";
            this.lvPH.ShowItemToolTips = true;
            this.lvPH.Size = new System.Drawing.Size(230, 116);
            this.lvPH.TabIndex = 36;
            this.lvPH.UseCompatibleStateImageBehavior = false;
            this.lvPH.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "#";
            this.columnHeader16.Width = 30;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Показания";
            this.columnHeader17.Width = 90;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Вольтаж";
            this.columnHeader18.Width = 90;
            // 
            // panel39
            // 
            this.panel39.AutoSize = true;
            this.panel39.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel39.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel39.Controls.Add(this.label57);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Padding = new System.Windows.Forms.Padding(3);
            this.panel39.Size = new System.Drawing.Size(230, 26);
            this.panel39.TabIndex = 0;
            // 
            // label57
            // 
            this.label57.Dock = System.Windows.Forms.DockStyle.Top;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label57.ForeColor = System.Drawing.Color.Beige;
            this.label57.Location = new System.Drawing.Point(3, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(224, 20);
            this.label57.TabIndex = 1;
            this.label57.Text = "Датчики";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.SteelBlue;
            this.panel46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel46.Controls.Add(this.panel48);
            this.panel46.Controls.Add(this.panel47);
            this.panel46.Location = new System.Drawing.Point(258, 20);
            this.panel46.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(221, 144);
            this.panel46.TabIndex = 5;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.label71);
            this.panel48.Controls.Add(this.label70);
            this.panel48.Controls.Add(this.label69);
            this.panel48.Controls.Add(this.lblPHMinusStatus);
            this.panel48.Controls.Add(this.lblPHPlusStatus);
            this.panel48.Controls.Add(this.lblPHMixPumpStatus);
            this.panel48.Controls.Add(this.lblPHWaterPumpStatus);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel48.Location = new System.Drawing.Point(0, 26);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(219, 116);
            this.panel48.TabIndex = 1;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(17, 88);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(53, 13);
            this.label71.TabIndex = 6;
            this.label71.Text = "Легенда:";
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.Color.Green;
            this.label70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label70.ForeColor = System.Drawing.Color.White;
            this.label70.Location = new System.Drawing.Point(150, 83);
            this.label70.Name = "label70";
            this.label70.Padding = new System.Windows.Forms.Padding(5);
            this.label70.Size = new System.Drawing.Size(51, 25);
            this.label70.TabIndex = 5;
            this.label70.Text = "ВКЛ";
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.LightGray;
            this.label69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(87, 83);
            this.label69.Name = "label69";
            this.label69.Padding = new System.Windows.Forms.Padding(5);
            this.label69.Size = new System.Drawing.Size(57, 25);
            this.label69.TabIndex = 4;
            this.label69.Text = "ВЫКЛ";
            // 
            // lblPHMinusStatus
            // 
            this.lblPHMinusStatus.BackColor = System.Drawing.Color.LightGray;
            this.lblPHMinusStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPHMinusStatus.ForeColor = System.Drawing.Color.Black;
            this.lblPHMinusStatus.Location = new System.Drawing.Point(152, 42);
            this.lblPHMinusStatus.Name = "lblPHMinusStatus";
            this.lblPHMinusStatus.Padding = new System.Windows.Forms.Padding(5);
            this.lblPHMinusStatus.Size = new System.Drawing.Size(49, 25);
            this.lblPHMinusStatus.TabIndex = 3;
            this.lblPHMinusStatus.Text = "PH-";
            this.ttDefault.SetToolTip(this.lblPHMinusStatus, "Клапан понижения pH");
            // 
            // lblPHPlusStatus
            // 
            this.lblPHPlusStatus.BackColor = System.Drawing.Color.LightGray;
            this.lblPHPlusStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPHPlusStatus.ForeColor = System.Drawing.Color.Black;
            this.lblPHPlusStatus.Location = new System.Drawing.Point(152, 11);
            this.lblPHPlusStatus.Name = "lblPHPlusStatus";
            this.lblPHPlusStatus.Padding = new System.Windows.Forms.Padding(5);
            this.lblPHPlusStatus.Size = new System.Drawing.Size(49, 25);
            this.lblPHPlusStatus.TabIndex = 2;
            this.lblPHPlusStatus.Text = "PH+";
            this.ttDefault.SetToolTip(this.lblPHPlusStatus, "Клапан повышения pH");
            // 
            // lblPHMixPumpStatus
            // 
            this.lblPHMixPumpStatus.BackColor = System.Drawing.Color.LightGray;
            this.lblPHMixPumpStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPHMixPumpStatus.ForeColor = System.Drawing.Color.Black;
            this.lblPHMixPumpStatus.Location = new System.Drawing.Point(20, 44);
            this.lblPHMixPumpStatus.Name = "lblPHMixPumpStatus";
            this.lblPHMixPumpStatus.Padding = new System.Windows.Forms.Padding(5);
            this.lblPHMixPumpStatus.Size = new System.Drawing.Size(117, 25);
            this.lblPHMixPumpStatus.TabIndex = 1;
            this.lblPHMixPumpStatus.Text = "Перемешивание";
            this.ttDefault.SetToolTip(this.lblPHMixPumpStatus, "Насос перемешивания");
            // 
            // lblPHWaterPumpStatus
            // 
            this.lblPHWaterPumpStatus.BackColor = System.Drawing.Color.LightGray;
            this.lblPHWaterPumpStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPHWaterPumpStatus.ForeColor = System.Drawing.Color.Black;
            this.lblPHWaterPumpStatus.Location = new System.Drawing.Point(20, 11);
            this.lblPHWaterPumpStatus.Name = "lblPHWaterPumpStatus";
            this.lblPHWaterPumpStatus.Padding = new System.Windows.Forms.Padding(5);
            this.lblPHWaterPumpStatus.Size = new System.Drawing.Size(117, 25);
            this.lblPHWaterPumpStatus.TabIndex = 0;
            this.lblPHWaterPumpStatus.Text = "Подача воды";
            this.ttDefault.SetToolTip(this.lblPHWaterPumpStatus, "Клапан подачи воды");
            // 
            // panel47
            // 
            this.panel47.AutoSize = true;
            this.panel47.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel47.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel47.Controls.Add(this.label60);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(0, 0);
            this.panel47.Name = "panel47";
            this.panel47.Padding = new System.Windows.Forms.Padding(3);
            this.panel47.Size = new System.Drawing.Size(219, 26);
            this.panel47.TabIndex = 0;
            // 
            // label60
            // 
            this.label60.Dock = System.Windows.Forms.DockStyle.Top;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label60.ForeColor = System.Drawing.Color.Beige;
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(213, 20);
            this.label60.TabIndex = 1;
            this.label60.Text = "Статус";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.SteelBlue;
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.label40);
            this.panel40.Controls.Add(this.label39);
            this.panel40.Controls.Add(this.label38);
            this.panel40.Controls.Add(this.nudPHVoltage10);
            this.panel40.Controls.Add(this.nudPHVoltage7);
            this.panel40.Controls.Add(this.nudPHVoltage4);
            this.panel40.Controls.Add(this.panel41);
            this.panel40.Location = new System.Drawing.Point(492, 20);
            this.panel40.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(217, 144);
            this.panel40.TabIndex = 2;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(13, 96);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(106, 13);
            this.label40.TabIndex = 53;
            this.label40.Text = "10 pH, милливольт:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(13, 70);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(100, 13);
            this.label39.TabIndex = 52;
            this.label39.Text = "7 pH, милливольт:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(13, 44);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(100, 13);
            this.label38.TabIndex = 51;
            this.label38.Text = "4 pH, милливольт:";
            // 
            // nudPHVoltage10
            // 
            this.nudPHVoltage10.BackColor = System.Drawing.Color.White;
            this.nudPHVoltage10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHVoltage10.ForeColor = System.Drawing.Color.Black;
            this.nudPHVoltage10.Location = new System.Drawing.Point(140, 94);
            this.nudPHVoltage10.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage10.Name = "nudPHVoltage10";
            this.nudPHVoltage10.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage10.TabIndex = 50;
            // 
            // nudPHVoltage7
            // 
            this.nudPHVoltage7.BackColor = System.Drawing.Color.White;
            this.nudPHVoltage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHVoltage7.ForeColor = System.Drawing.Color.Black;
            this.nudPHVoltage7.Location = new System.Drawing.Point(140, 68);
            this.nudPHVoltage7.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage7.Name = "nudPHVoltage7";
            this.nudPHVoltage7.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage7.TabIndex = 49;
            // 
            // nudPHVoltage4
            // 
            this.nudPHVoltage4.BackColor = System.Drawing.Color.White;
            this.nudPHVoltage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHVoltage4.ForeColor = System.Drawing.Color.Black;
            this.nudPHVoltage4.Location = new System.Drawing.Point(140, 42);
            this.nudPHVoltage4.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage4.Name = "nudPHVoltage4";
            this.nudPHVoltage4.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage4.TabIndex = 48;
            // 
            // panel41
            // 
            this.panel41.AutoSize = true;
            this.panel41.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel41.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel41.Controls.Add(this.label45);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel41.Location = new System.Drawing.Point(0, 0);
            this.panel41.Name = "panel41";
            this.panel41.Padding = new System.Windows.Forms.Padding(3);
            this.panel41.Size = new System.Drawing.Size(215, 26);
            this.panel41.TabIndex = 0;
            // 
            // label45
            // 
            this.label45.Dock = System.Windows.Forms.DockStyle.Top;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label45.ForeColor = System.Drawing.Color.Beige;
            this.label45.Location = new System.Drawing.Point(3, 3);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(209, 20);
            this.label45.TabIndex = 1;
            this.label45.Text = "Калибровочные р-ры";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.SteelBlue;
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.label44);
            this.panel42.Controls.Add(this.nudPHCalibrationTemperature);
            this.panel42.Controls.Add(this.label42);
            this.panel42.Controls.Add(this.nudPHTempSensorIndex);
            this.panel42.Controls.Add(this.label41);
            this.panel42.Controls.Add(this.nudPHCalibration);
            this.panel42.Controls.Add(this.panel43);
            this.panel42.Location = new System.Drawing.Point(722, 20);
            this.panel42.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(217, 144);
            this.panel42.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(13, 94);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(103, 13);
            this.label44.TabIndex = 48;
            this.label44.Text = "Темп. калибровки:";
            // 
            // nudPHCalibrationTemperature
            // 
            this.nudPHCalibrationTemperature.BackColor = System.Drawing.Color.White;
            this.nudPHCalibrationTemperature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHCalibrationTemperature.DecimalPlaces = 2;
            this.nudPHCalibrationTemperature.ForeColor = System.Drawing.Color.Black;
            this.nudPHCalibrationTemperature.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudPHCalibrationTemperature.Location = new System.Drawing.Point(140, 92);
            this.nudPHCalibrationTemperature.Name = "nudPHCalibrationTemperature";
            this.nudPHCalibrationTemperature.Size = new System.Drawing.Size(61, 20);
            this.nudPHCalibrationTemperature.TabIndex = 47;
            this.ttDefault.SetToolTip(this.nudPHCalibrationTemperature, "Температура эталонного калибровочного раствора");
            this.nudPHCalibrationTemperature.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(13, 70);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(117, 13);
            this.label42.TabIndex = 46;
            this.label42.Text = "Датчик температуры:";
            // 
            // nudPHTempSensorIndex
            // 
            this.nudPHTempSensorIndex.BackColor = System.Drawing.Color.White;
            this.nudPHTempSensorIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHTempSensorIndex.ForeColor = System.Drawing.Color.Black;
            this.nudPHTempSensorIndex.Location = new System.Drawing.Point(140, 68);
            this.nudPHTempSensorIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nudPHTempSensorIndex.Name = "nudPHTempSensorIndex";
            this.nudPHTempSensorIndex.Size = new System.Drawing.Size(61, 20);
            this.nudPHTempSensorIndex.TabIndex = 45;
            this.ttDefault.SetToolTip(this.nudPHTempSensorIndex, "Индекс датчика температуры в модуле температур , \r\nс которого будут браться показ" +
        "ания текущей \r\nтемпературы раствора.");
            this.nudPHTempSensorIndex.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(13, 46);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(109, 13);
            this.label41.TabIndex = 44;
            this.label41.Text = "Поправочное число:";
            // 
            // nudPHCalibration
            // 
            this.nudPHCalibration.BackColor = System.Drawing.Color.White;
            this.nudPHCalibration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHCalibration.ForeColor = System.Drawing.Color.Black;
            this.nudPHCalibration.Location = new System.Drawing.Point(140, 44);
            this.nudPHCalibration.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudPHCalibration.Name = "nudPHCalibration";
            this.nudPHCalibration.Size = new System.Drawing.Size(61, 20);
            this.nudPHCalibration.TabIndex = 43;
            this.ttDefault.SetToolTip(this.nudPHCalibration, "Поправочный коэффициент (в сотых долях)");
            // 
            // panel43
            // 
            this.panel43.AutoSize = true;
            this.panel43.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel43.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel43.Controls.Add(this.label58);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(0, 0);
            this.panel43.Name = "panel43";
            this.panel43.Padding = new System.Windows.Forms.Padding(3);
            this.panel43.Size = new System.Drawing.Size(215, 26);
            this.panel43.TabIndex = 0;
            // 
            // label58
            // 
            this.label58.Dock = System.Windows.Forms.DockStyle.Top;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label58.ForeColor = System.Drawing.Color.Beige;
            this.label58.Location = new System.Drawing.Point(3, 3);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(209, 20);
            this.label58.TabIndex = 1;
            this.label58.Text = "Термокомпенсация";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.SteelBlue;
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.label61);
            this.panel44.Controls.Add(this.nudPHReagentPumpTime);
            this.panel44.Controls.Add(this.label62);
            this.panel44.Controls.Add(this.nudPHHisteresis);
            this.panel44.Controls.Add(this.label63);
            this.panel44.Controls.Add(this.nudTargetPH);
            this.panel44.Controls.Add(this.label64);
            this.panel44.Controls.Add(this.nudPHMixPumpTime);
            this.panel44.Controls.Add(this.lblSavePHSettings);
            this.panel44.Controls.Add(this.panel45);
            this.panel44.Location = new System.Drawing.Point(13, 177);
            this.panel44.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(393, 190);
            this.panel44.TabIndex = 4;
            // 
            // label61
            // 
            this.label61.ForeColor = System.Drawing.Color.White;
            this.label61.Location = new System.Drawing.Point(26, 119);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(241, 32);
            this.label61.TabIndex = 56;
            this.label61.Text = "Время работы насоса подачи реагента, для изменения pH на 0.1, с:";
            // 
            // nudPHReagentPumpTime
            // 
            this.nudPHReagentPumpTime.BackColor = System.Drawing.Color.White;
            this.nudPHReagentPumpTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHReagentPumpTime.ForeColor = System.Drawing.Color.Black;
            this.nudPHReagentPumpTime.Location = new System.Drawing.Point(298, 117);
            this.nudPHReagentPumpTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudPHReagentPumpTime.Name = "nudPHReagentPumpTime";
            this.nudPHReagentPumpTime.Size = new System.Drawing.Size(61, 20);
            this.nudPHReagentPumpTime.TabIndex = 55;
            this.nudPHReagentPumpTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.ForeColor = System.Drawing.Color.White;
            this.label62.Location = new System.Drawing.Point(26, 67);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(69, 13);
            this.label62.TabIndex = 54;
            this.label62.Text = "Гистерезис:";
            // 
            // nudPHHisteresis
            // 
            this.nudPHHisteresis.BackColor = System.Drawing.Color.White;
            this.nudPHHisteresis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHHisteresis.DecimalPlaces = 2;
            this.nudPHHisteresis.ForeColor = System.Drawing.Color.Black;
            this.nudPHHisteresis.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.nudPHHisteresis.Location = new System.Drawing.Point(298, 65);
            this.nudPHHisteresis.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudPHHisteresis.Name = "nudPHHisteresis";
            this.nudPHHisteresis.Size = new System.Drawing.Size(61, 20);
            this.nudPHHisteresis.TabIndex = 53;
            this.nudPHHisteresis.Value = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.White;
            this.label63.Location = new System.Drawing.Point(26, 41);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(167, 13);
            this.label63.TabIndex = 52;
            this.label63.Text = "Поддерживаемое значение pH:";
            // 
            // nudTargetPH
            // 
            this.nudTargetPH.BackColor = System.Drawing.Color.White;
            this.nudTargetPH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudTargetPH.DecimalPlaces = 2;
            this.nudTargetPH.ForeColor = System.Drawing.Color.Black;
            this.nudTargetPH.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudTargetPH.Location = new System.Drawing.Point(298, 39);
            this.nudTargetPH.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudTargetPH.Name = "nudTargetPH";
            this.nudTargetPH.Size = new System.Drawing.Size(61, 20);
            this.nudTargetPH.TabIndex = 51;
            this.nudTargetPH.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(26, 93);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(219, 13);
            this.label64.TabIndex = 50;
            this.label64.Text = "Время работы насоса перемешивания, с:";
            // 
            // nudPHMixPumpTime
            // 
            this.nudPHMixPumpTime.BackColor = System.Drawing.Color.White;
            this.nudPHMixPumpTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPHMixPumpTime.ForeColor = System.Drawing.Color.Black;
            this.nudPHMixPumpTime.Location = new System.Drawing.Point(298, 91);
            this.nudPHMixPumpTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudPHMixPumpTime.Name = "nudPHMixPumpTime";
            this.nudPHMixPumpTime.Size = new System.Drawing.Size(61, 20);
            this.nudPHMixPumpTime.TabIndex = 49;
            this.nudPHMixPumpTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // lblSavePHSettings
            // 
            this.lblSavePHSettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblSavePHSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSavePHSettings.ForeColor = System.Drawing.Color.White;
            this.lblSavePHSettings.LinkColor = System.Drawing.Color.White;
            this.lblSavePHSettings.Location = new System.Drawing.Point(0, 165);
            this.lblSavePHSettings.Name = "lblSavePHSettings";
            this.lblSavePHSettings.Padding = new System.Windows.Forms.Padding(5);
            this.lblSavePHSettings.Size = new System.Drawing.Size(391, 23);
            this.lblSavePHSettings.TabIndex = 26;
            this.lblSavePHSettings.TabStop = true;
            this.lblSavePHSettings.Text = "Сохранить настройки";
            this.lblSavePHSettings.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblSavePHSettings, "Сохранить настройки в контроллер");
            this.lblSavePHSettings.VisitedLinkColor = System.Drawing.Color.White;
            this.lblSavePHSettings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSavePHSettings_LinkClicked);
            // 
            // panel45
            // 
            this.panel45.AutoSize = true;
            this.panel45.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel45.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel45.Controls.Add(this.label59);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Padding = new System.Windows.Forms.Padding(3);
            this.panel45.Size = new System.Drawing.Size(391, 26);
            this.panel45.TabIndex = 0;
            // 
            // label59
            // 
            this.label59.Dock = System.Windows.Forms.DockStyle.Top;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label59.ForeColor = System.Drawing.Color.Beige;
            this.label59.Location = new System.Drawing.Point(3, 3);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(385, 20);
            this.label59.TabIndex = 1;
            this.label59.Text = "Контроль";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpIOT
            // 
            this.tpIOT.BackColor = System.Drawing.Color.White;
            this.tpIOT.Controls.Add(this.flowLayoutPanel5);
            this.tpIOT.ImageIndex = 15;
            this.tpIOT.Location = new System.Drawing.Point(4, 36);
            this.tpIOT.Name = "tpIOT";
            this.tpIOT.Padding = new System.Windows.Forms.Padding(3);
            this.tpIOT.Size = new System.Drawing.Size(1000, 423);
            this.tpIOT.TabIndex = 14;
            this.tpIOT.Text = "IoT";
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.AutoScroll = true;
            this.flowLayoutPanel5.Controls.Add(this.panel25);
            this.flowLayoutPanel5.Controls.Add(this.panel27);
            this.flowLayoutPanel5.Controls.Add(this.panel29);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel5.Size = new System.Drawing.Size(994, 417);
            this.flowLayoutPanel5.TabIndex = 25;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.SteelBlue;
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.lblSaveIoTSettings);
            this.panel25.Controls.Add(this.tbThingSpeakChannelKey);
            this.panel25.Controls.Add(this.label46);
            this.panel25.Controls.Add(this.nudIoTInterval);
            this.panel25.Controls.Add(this.label43);
            this.panel25.Controls.Add(this.cbThingSpeakEnabled);
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Location = new System.Drawing.Point(13, 20);
            this.panel25.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(257, 183);
            this.panel25.TabIndex = 4;
            // 
            // lblSaveIoTSettings
            // 
            this.lblSaveIoTSettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblSaveIoTSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSaveIoTSettings.ForeColor = System.Drawing.Color.White;
            this.lblSaveIoTSettings.LinkColor = System.Drawing.Color.White;
            this.lblSaveIoTSettings.Location = new System.Drawing.Point(0, 158);
            this.lblSaveIoTSettings.Name = "lblSaveIoTSettings";
            this.lblSaveIoTSettings.Padding = new System.Windows.Forms.Padding(5);
            this.lblSaveIoTSettings.Size = new System.Drawing.Size(255, 23);
            this.lblSaveIoTSettings.TabIndex = 25;
            this.lblSaveIoTSettings.TabStop = true;
            this.lblSaveIoTSettings.Text = "Сохранить настройки";
            this.lblSaveIoTSettings.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ttDefault.SetToolTip(this.lblSaveIoTSettings, "Сохранить настройки IoT в контроллер");
            this.lblSaveIoTSettings.VisitedLinkColor = System.Drawing.Color.White;
            this.lblSaveIoTSettings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSaveIoTSettings_LinkClicked);
            // 
            // tbThingSpeakChannelKey
            // 
            this.tbThingSpeakChannelKey.BackColor = System.Drawing.Color.White;
            this.tbThingSpeakChannelKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbThingSpeakChannelKey.ForeColor = System.Drawing.Color.Black;
            this.tbThingSpeakChannelKey.Location = new System.Drawing.Point(7, 77);
            this.tbThingSpeakChannelKey.MaxLength = 19;
            this.tbThingSpeakChannelKey.Name = "tbThingSpeakChannelKey";
            this.tbThingSpeakChannelKey.Size = new System.Drawing.Size(234, 20);
            this.tbThingSpeakChannelKey.TabIndex = 8;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(4, 61);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(136, 13);
            this.label46.TabIndex = 7;
            this.label46.Text = "Ключ канала ThingSpeak:";
            // 
            // nudIoTInterval
            // 
            this.nudIoTInterval.BackColor = System.Drawing.Color.White;
            this.nudIoTInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudIoTInterval.ForeColor = System.Drawing.Color.Black;
            this.nudIoTInterval.Location = new System.Drawing.Point(168, 114);
            this.nudIoTInterval.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudIoTInterval.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudIoTInterval.Name = "nudIoTInterval";
            this.nudIoTInterval.Size = new System.Drawing.Size(73, 20);
            this.nudIoTInterval.TabIndex = 4;
            this.nudIoTInterval.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(4, 116);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(71, 13);
            this.label43.TabIndex = 3;
            this.label43.Text = "Интервал, с:";
            // 
            // cbThingSpeakEnabled
            // 
            this.cbThingSpeakEnabled.AutoSize = true;
            this.cbThingSpeakEnabled.ForeColor = System.Drawing.Color.White;
            this.cbThingSpeakEnabled.Location = new System.Drawing.Point(7, 32);
            this.cbThingSpeakEnabled.Name = "cbThingSpeakEnabled";
            this.cbThingSpeakEnabled.Size = new System.Drawing.Size(199, 17);
            this.cbThingSpeakEnabled.TabIndex = 1;
            this.cbThingSpeakEnabled.Text = "Отсылать данные на ThingSpeak?";
            this.cbThingSpeakEnabled.UseVisualStyleBackColor = true;
            // 
            // panel26
            // 
            this.panel26.AutoSize = true;
            this.panel26.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel26.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel26.Controls.Add(this.label34);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Padding = new System.Windows.Forms.Padding(3);
            this.panel26.Size = new System.Drawing.Size(255, 26);
            this.panel26.TabIndex = 0;
            // 
            // label34
            // 
            this.label34.Dock = System.Windows.Forms.DockStyle.Top;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.ForeColor = System.Drawing.Color.Beige;
            this.label34.Location = new System.Drawing.Point(3, 3);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(249, 20);
            this.label34.TabIndex = 1;
            this.label34.Text = "Настройки";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.SteelBlue;
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.panel31);
            this.panel27.Controls.Add(this.panel28);
            this.panel27.Location = new System.Drawing.Point(283, 20);
            this.panel27.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(290, 183);
            this.panel27.TabIndex = 5;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.lbIOTAllSensors);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(0, 26);
            this.panel31.Margin = new System.Windows.Forms.Padding(0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(288, 155);
            this.panel31.TabIndex = 1;
            // 
            // lbIOTAllSensors
            // 
            this.lbIOTAllSensors.BackColor = System.Drawing.Color.White;
            this.lbIOTAllSensors.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbIOTAllSensors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbIOTAllSensors.ForeColor = System.Drawing.Color.Black;
            this.lbIOTAllSensors.FormattingEnabled = true;
            this.lbIOTAllSensors.IntegralHeight = false;
            this.lbIOTAllSensors.Location = new System.Drawing.Point(0, 0);
            this.lbIOTAllSensors.Name = "lbIOTAllSensors";
            this.lbIOTAllSensors.Size = new System.Drawing.Size(288, 155);
            this.lbIOTAllSensors.TabIndex = 25;
            this.lbIOTAllSensors.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragDrop);
            this.lbIOTAllSensors.DragOver += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragOver);
            this.lbIOTAllSensors.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbIOTSelectedSensors_MouseDown);
            // 
            // panel28
            // 
            this.panel28.AutoSize = true;
            this.panel28.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel28.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel28.Controls.Add(this.label54);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Padding = new System.Windows.Forms.Padding(3);
            this.panel28.Size = new System.Drawing.Size(288, 26);
            this.panel28.TabIndex = 0;
            // 
            // label54
            // 
            this.label54.Dock = System.Windows.Forms.DockStyle.Top;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label54.ForeColor = System.Drawing.Color.Beige;
            this.label54.Location = new System.Drawing.Point(3, 3);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(282, 20);
            this.label54.TabIndex = 1;
            this.label54.Text = "Доступные датчики";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.SteelBlue;
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.lbIOTSelectedSensors);
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Location = new System.Drawing.Point(586, 20);
            this.panel29.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(290, 183);
            this.panel29.TabIndex = 6;
            // 
            // lbIOTSelectedSensors
            // 
            this.lbIOTSelectedSensors.BackColor = System.Drawing.Color.White;
            this.lbIOTSelectedSensors.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbIOTSelectedSensors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbIOTSelectedSensors.ForeColor = System.Drawing.Color.Black;
            this.lbIOTSelectedSensors.FormattingEnabled = true;
            this.lbIOTSelectedSensors.IntegralHeight = false;
            this.lbIOTSelectedSensors.Location = new System.Drawing.Point(0, 26);
            this.lbIOTSelectedSensors.Name = "lbIOTSelectedSensors";
            this.lbIOTSelectedSensors.Size = new System.Drawing.Size(288, 155);
            this.lbIOTSelectedSensors.TabIndex = 25;
            this.lbIOTSelectedSensors.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragDrop);
            this.lbIOTSelectedSensors.DragOver += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragOver);
            this.lbIOTSelectedSensors.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbIOTSelectedSensors_MouseDown);
            // 
            // panel30
            // 
            this.panel30.AutoSize = true;
            this.panel30.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel30.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel30.Controls.Add(this.label35);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Padding = new System.Windows.Forms.Padding(3);
            this.panel30.Size = new System.Drawing.Size(288, 26);
            this.panel30.TabIndex = 0;
            // 
            // label35
            // 
            this.label35.Dock = System.Windows.Forms.DockStyle.Top;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.ForeColor = System.Drawing.Color.Beige;
            this.label35.Location = new System.Drawing.Point(3, 3);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(282, 20);
            this.label35.TabIndex = 1;
            this.label35.Text = "Выбранные датчики";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ImageList = this.imglTabImages;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1008, 147);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lvLog);
            this.tabPage1.ImageIndex = 2;
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1000, 120);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Лог";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lvLog
            // 
            this.lvLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.logColumn1,
            this.logColumn2});
            this.lvLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvLog.FullRowSelect = true;
            this.lvLog.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvLog.LabelWrap = false;
            this.lvLog.Location = new System.Drawing.Point(3, 3);
            this.lvLog.MultiSelect = false;
            this.lvLog.Name = "lvLog";
            this.lvLog.ShowGroups = false;
            this.lvLog.Size = new System.Drawing.Size(994, 114);
            this.lvLog.SmallImageList = this.imglTabImages;
            this.lvLog.TabIndex = 0;
            this.lvLog.UseCompatibleStateImageBehavior = false;
            this.lvLog.View = System.Windows.Forms.View.Details;
            // 
            // logColumn1
            // 
            this.logColumn1.Text = "";
            // 
            // logColumn2
            // 
            this.logColumn2.Text = "";
            // 
            // tmrUptime
            // 
            this.tmrUptime.Enabled = true;
            this.tmrUptime.Interval = 1001;
            this.tmrUptime.Tick += new System.EventHandler(this.tmrUptime_Tick);
            // 
            // tmrFreeRam
            // 
            this.tmrFreeRam.Enabled = true;
            this.tmrFreeRam.Interval = 3007;
            this.tmrFreeRam.Tick += new System.EventHandler(this.tmrFreeRam_Tick);
            // 
            // tmProcessCommandsTimer
            // 
            this.tmProcessCommandsTimer.Enabled = true;
            this.tmProcessCommandsTimer.Interval = 103;
            this.tmProcessCommandsTimer.Tick += new System.EventHandler(this.tmProcessCommandsTimer_Tick);
            // 
            // tmrTicks
            // 
            this.tmrTicks.Interval = 1000;
            this.tmrTicks.Tick += new System.EventHandler(this.tmrTicks_Tick);
            // 
            // tmWaitDataTimer
            // 
            this.tmWaitDataTimer.Tick += new System.EventHandler(this.tmWaitDataTimer_Tick);
            // 
            // tmGetAllTempData
            // 
            this.tmGetAllTempData.Interval = 2000;
            this.tmGetAllTempData.Tick += new System.EventHandler(this.tmGetAllTempData_Tick);
            // 
            // ttPhoneNumberHint
            // 
            this.ttPhoneNumberHint.AutoPopDelay = 8000;
            this.ttPhoneNumberHint.InitialDelay = 500;
            this.ttPhoneNumberHint.IsBalloon = true;
            this.ttPhoneNumberHint.ReshowDelay = 100;
            this.ttPhoneNumberHint.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ttTempRulesHint
            // 
            this.ttTempRulesHint.AutoPopDelay = 8000;
            this.ttTempRulesHint.InitialDelay = 500;
            this.ttTempRulesHint.IsBalloon = true;
            this.ttTempRulesHint.ReshowDelay = 100;
            this.ttTempRulesHint.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.ttTempRulesHint.ToolTipTitle = "Служебные правила";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "#";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 50;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Состояние";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column5.Width = 120;
            // 
            // Column6
            // 
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.LightSalmon;
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.White;
            this.Column6.DefaultCellStyle = dataGridViewCellStyle36;
            this.Column6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column6.HeaderText = "Управление";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 80;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1008, 730);
            this.Controls.Add(this.splitCont);
            this.Controls.Add(this.tbToolBar);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(640, 480);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Конфигуратор контроллера теплицы Arduino Mega, v.";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tbToolBar.ResumeLayout(false);
            this.tbToolBar.PerformLayout();
            this.splitCont.Panel1.ResumeLayout(false);
            this.splitCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitCont)).EndInit();
            this.splitCont.ResumeLayout(false);
            this.tabCMain.ResumeLayout(false);
            this.tcStatPage.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.thermController)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.therm1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.therm2)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbWindowPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowState)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetWorkMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowWorkMode)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWindowsChannelsList)).EndInit();
            this.panel18.ResumeLayout(false);
            this.tpTemperatureTab.ResumeLayout(false);
            this.flowLayoutPanel14.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel86.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTClose)).EndInit();
            this.panel89.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudTOpen)).EndInit();
            this.tpWateringTab.ResumeLayout(false);
            this.flowLayoutPanel15.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel93.ResumeLayout(false);
            this.panel103.ResumeLayout(false);
            this.panel103.PerformLayout();
            this.gbWateringSettings.ResumeLayout(false);
            this.gbWateringSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTimeMinutes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTimeHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWateringTime)).EndInit();
            this.gbWeekDays.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvWateringChannels)).EndInit();
            this.panel92.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel97.PerformLayout();
            this.panel99.ResumeLayout(false);
            this.panel94.ResumeLayout(false);
            this.panel94.PerformLayout();
            this.panel95.ResumeLayout(false);
            this.panel95.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbWatering)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWateringMode)).EndInit();
            this.panel96.ResumeLayout(false);
            this.tpLuminosity.ResumeLayout(false);
            this.flowLayoutPanel13.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.panel79.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel80.PerformLayout();
            this.panel81.ResumeLayout(false);
            this.panel81.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinLux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourTo)).EndInit();
            this.panel82.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbLux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbLuxMode)).EndInit();
            this.panel85.ResumeLayout(false);
            this.tpHumidity.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.tpSMSTab.ResumeLayout(false);
            this.flowLayoutPanel12.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.panel71.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbNumberHelp)).EndInit();
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.panel73.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.panel74.PerformLayout();
            this.panel76.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.tpWiFi.ResumeLayout(false);
            this.flowLayoutPanel11.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel65.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel66.PerformLayout();
            this.panel67.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel68.PerformLayout();
            this.panel69.ResumeLayout(false);
            this.tpRules.ResumeLayout(false);
            this.flowLayoutPanel10.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.panel61.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.tpLog.ResumeLayout(false);
            this.flowLayoutPanel6.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.tpWaterFlow.ResumeLayout(false);
            this.flowLayoutPanel8.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel50.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.panel52.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel54.ResumeLayout(false);
            this.tpMultipleCommands.ResumeLayout(false);
            this.flowLayoutPanel9.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel58.ResumeLayout(false);
            this.tpDeltas.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.tpSoilMoisture.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.tpPH.ResumeLayout(false);
            this.flowLayoutPanel7.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage4)).EndInit();
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibrationTemperature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHTempSensorIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibration)).EndInit();
            this.panel43.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHReagentPumpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHHisteresis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTargetPH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHMixPumpTime)).EndInit();
            this.panel45.ResumeLayout(false);
            this.tpIOT.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIoTInterval)).EndInit();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ImageList imglToolbarImages;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem miFile;
        private System.Windows.Forms.ToolStripMenuItem miExit;
        private System.Windows.Forms.ToolStrip tbToolBar;
        private System.Windows.Forms.SplitContainer splitCont;
        private System.Windows.Forms.TabControl tabCMain;
        private System.Windows.Forms.TabPage tcStatPage;
        private System.Windows.Forms.TabPage tpTemperatureTab;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Timer tmrUptime;
        private System.Windows.Forms.Timer tmrFreeRam;
        private System.Windows.Forms.Timer tmProcessCommandsTimer;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton tbbConnectBtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tbbAbout;
        private System.Windows.Forms.ImageList imglTabImages;
        private System.Windows.Forms.Timer tmrTicks;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbTempSettings;
        private System.Windows.Forms.NumericUpDown nudTClose;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nudTOpen;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudInterval;
        private System.Windows.Forms.TabPage tpSMSTab;
        private System.Windows.Forms.TextBox tbPhoneNumber;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnSavePhoneNumber;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pbNumberHelp;
        private System.Windows.Forms.ListView lvLog;
        private System.Windows.Forms.ColumnHeader logColumn1;
        private System.Windows.Forms.ColumnHeader logColumn2;
        private System.Windows.Forms.TabPage tpWateringTab;
        private System.Windows.Forms.ComboBox cbWateringControl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox gbWeekDays;
        private System.Windows.Forms.CheckedListBox clbWeekDays;
        private System.Windows.Forms.GroupBox gbWateringSettings;
        private System.Windows.Forms.NumericUpDown nudWateringTime;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tpLuminosity;
        private System.Windows.Forms.TrackBar tbWatering;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblWateringState;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblWateringMode;
        private System.Windows.Forms.TrackBar tbWateringMode;
        private System.Windows.Forms.NumericUpDown nudStartWateringTimeHours;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ToolStripButton tbPlayPause;
        private System.Windows.Forms.CheckBox chbTurnOnPump;
        private System.Windows.Forms.DataGridView dgvWateringChannels;
        private System.Windows.Forms.TabPage tpWiFi;
        private System.Windows.Forms.TabPage tpHumidity;
        private System.Windows.Forms.Timer tmWaitDataTimer;
        private System.Windows.Forms.NumericUpDown nudMinLux;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nudLuxHourTo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown nudLuxHourFrom;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox cbEnableLuminosityManage;
        private System.Windows.Forms.Timer tmGetAllTempData;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblLuxMode;
        private System.Windows.Forms.TrackBar tbLuxMode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblLuxState;
        private System.Windows.Forms.TrackBar tbLux;
        private System.Windows.Forms.ToolStripButton btnSetControllerTime;
        private System.Windows.Forms.CheckBox cbConnectToTheRouter;
        private System.Windows.Forms.Button btnSaveWiFiSettings;
        private System.Windows.Forms.TextBox tbStationPassword;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbStationID;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbRouterPassword;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbRouterID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnQueryIP;
        private System.Windows.Forms.CheckBox cbWorkWithoutLightSensor;
        private System.Windows.Forms.TabPage tpRules;
        private System.Windows.Forms.Button btnLoadRules;
        private System.Windows.Forms.Button btnSaveRules;
        private System.Windows.Forms.Button btnEditRule;
        private System.Windows.Forms.LinkLabel lblComputeRulesmemory;
        private System.Windows.Forms.Button btnAddRule;
        private System.Windows.Forms.Button btnDeleteRule;
        private System.Windows.Forms.ToolTip ttPhoneNumberHint;
        private System.Windows.Forms.ToolTip ttDefault;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.TextBox tbLogsDirectory;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.FolderBrowserDialog selectFolder;
        private System.Windows.Forms.RadioButton rbMonth;
        private System.Windows.Forms.RadioButton rbWeek;
        private System.Windows.Forms.RadioButton rbDay;
        private System.Windows.Forms.ProgressBar pbLogsProgress;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblCurrentLogFileName;
        private System.Windows.Forms.Label lblCurrentLogLine;
        private System.Windows.Forms.ToolStripButton tbDelta;
        private System.Windows.Forms.CheckBox cbCreateTemperatureRules;
        private System.Windows.Forms.ToolTip ttTempRulesHint;
        private System.Windows.Forms.TabPage tpWaterFlow;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblFlowIncremental2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblFlowInstant2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblFlowIncremental1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblFlowInstant1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripButton tbRestartButton;
        private System.Windows.Forms.ToolStripMenuItem tsiCOMConnection;
        private System.Windows.Forms.ToolStripMenuItem miRescanPorts;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.TabPage tpMultipleCommands;
        private System.Windows.Forms.Button btnDeleteCompositeCommand;
        private System.Windows.Forms.Button btnAddCompositeCommand;
        private System.Windows.Forms.Button btnEditCompositeCommand;
        private System.Windows.Forms.ListView lvCompositeCommandsList;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button btnUploadCompositeCommands;
        private System.Windows.Forms.TabPage tpDeltas;
        private System.Windows.Forms.ToolStripMenuItem miConfiguration;
        private System.Windows.Forms.ToolStripMenuItem miDateTime;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem miPlayPause;
        private System.Windows.Forms.ToolStripMenuItem miRestart;
        private System.Windows.Forms.ToolStripMenuItem miDelta;
        private System.Windows.Forms.ToolStripMenuItem miUniversalSensors;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem miFirmwareInfo;
        private System.Windows.Forms.TabPage tpSoilMoisture;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown nudFlowCalibration2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown nudFlowCalibration1;
        private System.Windows.Forms.Button btnSaveFlowSettings;
        private System.Windows.Forms.Button btnAddSMS;
        private System.Windows.Forms.Button btnSmsList;
        private System.Windows.Forms.ToolStripMenuItem miReservationSettings;
        private System.Windows.Forms.ToolStripMenuItem miTimers;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem miSettings;
        private System.Windows.Forms.ToolStripMenuItem miMonitorScreenSettings;
        private System.Windows.Forms.Button btnClearCCCommands;
        private System.Windows.Forms.Button btnResetWaterflowData;
        private System.Windows.Forms.TabPage tpPH;
        private System.Windows.Forms.ToolStripMenuItem miPinsUsed;
        private System.Windows.Forms.TabPage tpIOT;
        private System.Windows.Forms.ComboBox cbGSMProvider;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.NumericUpDown nudStartWateringTimeMinutes;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUptime;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblByte;
        private System.Windows.Forms.Label lblFreeRam;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblCelsius1;
        private System.Windows.Forms.Label lblTempInside;
        private System.Windows.Forms.PictureBox therm1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblCelsius2;
        private System.Windows.Forms.Label lblTempOutside;
        private System.Windows.Forms.PictureBox therm2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TrackBar tbWindowPosition;
        private System.Windows.Forms.Label lblCurrentWindowState;
        private System.Windows.Forms.PictureBox pbWindowState;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TrackBar tbSetWorkMode;
        private System.Windows.Forms.Label lblWindowWorkMode;
        private System.Windows.Forms.PictureBox pbWindowWorkMode;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lblControllerTime;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lblCelsiusController;
        private System.Windows.Forms.Label lblTempController;
        private System.Windows.Forms.PictureBox thermController;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel lblSetControllerTime;
        private System.Windows.Forms.DataGridView dgvWindowsChannelsList;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.ListView lvDeltasList;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.ListView lvHumiditySensorsData;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.ListView lvSoilMoistureSensorsData;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.LinkLabel lblSaveIoTSettings;
        private System.Windows.Forms.TextBox tbThingSpeakChannelKey;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown nudIoTInterval;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.CheckBox cbThingSpeakEnabled;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ListBox lbIOTSelectedSensors;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.ListBox lbIOTAllSensors;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.LinkLabel lblLoadLogs;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.ListView lvPH;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.NumericUpDown nudPHVoltage10;
        private System.Windows.Forms.NumericUpDown nudPHVoltage7;
        private System.Windows.Forms.NumericUpDown nudPHVoltage4;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown nudPHCalibrationTemperature;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown nudPHTempSensorIndex;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.NumericUpDown nudPHCalibration;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.LinkLabel lblSavePHSettings;
        private System.Windows.Forms.Label label61;
        public System.Windows.Forms.NumericUpDown nudPHReagentPumpTime;
        private System.Windows.Forms.Label label62;
        public System.Windows.Forms.NumericUpDown nudPHHisteresis;
        private System.Windows.Forms.Label label63;
        public System.Windows.Forms.NumericUpDown nudTargetPH;
        private System.Windows.Forms.Label label64;
        public System.Windows.Forms.NumericUpDown nudPHMixPumpTime;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label lblPHMinusStatus;
        private System.Windows.Forms.Label lblPHPlusStatus;
        private System.Windows.Forms.Label lblPHMixPumpStatus;
        private System.Windows.Forms.Label lblPHWaterPumpStatus;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel10;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ListView lvRulesList;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Label lblRuleStr;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel11;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel12;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel13;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.ListView lvLuminosity;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.LinkLabel lblSaveLuxSettings;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel14;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.LinkLabel lblWriteTempSettings;
        private System.Windows.Forms.ListView lvTempData;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel15;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel plWaterChannelsList;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.LinkLabel lblSaveWateringOptions;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.ToolStripButton tbReservationSettings;
        private System.Windows.Forms.ToolStripButton tbFirmwareInfo;
        private System.Windows.Forms.ToolStripButton tbTimers;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tbPinsUsed;
        private System.Windows.Forms.ToolStripButton tbUniversalSensors;
        private System.Windows.Forms.ToolStripButton tbMonitorScreenSettings;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewButtonColumn Column6;
    }
}

