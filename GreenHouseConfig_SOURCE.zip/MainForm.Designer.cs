﻿namespace GreenHouseConfig
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "Подача воды"}, -1, System.Drawing.Color.Black, System.Drawing.Color.LightGray, null);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Перемешивание"}, -1, System.Drawing.Color.Black, System.Drawing.Color.LightGray, null);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "PH+"}, -1, System.Drawing.Color.Black, System.Drawing.Color.LightGray, null);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "PH-"}, -1, System.Drawing.Color.Black, System.Drawing.Color.LightGray, null);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.imglToolbarImages = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.miFile = new System.Windows.Forms.ToolStripMenuItem();
            this.miExit = new System.Windows.Forms.ToolStripMenuItem();
            this.miConfiguration = new System.Windows.Forms.ToolStripMenuItem();
            this.miPlayPause = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.miDelta = new System.Windows.Forms.ToolStripMenuItem();
            this.miReservationSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miUniversalSensors = new System.Windows.Forms.ToolStripMenuItem();
            this.miTimers = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.miDateTime = new System.Windows.Forms.ToolStripMenuItem();
            this.miRestart = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.miFirmwareInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.miSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miMonitorScreenSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.miPinsUsed = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbToolBar = new System.Windows.Forms.ToolStrip();
            this.tbbConnectBtn = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsiCOMConnection = new System.Windows.Forms.ToolStripMenuItem();
            this.miRescanPorts = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbPlayPause = new System.Windows.Forms.ToolStripButton();
            this.btnSetControllerTime = new System.Windows.Forms.ToolStripButton();
            this.tbDelta = new System.Windows.Forms.ToolStripButton();
            this.tbRestartButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tbbAbout = new System.Windows.Forms.ToolStripButton();
            this.splitCont = new System.Windows.Forms.SplitContainer();
            this.tabCMain = new System.Windows.Forms.TabControl();
            this.tcStatPage = new System.Windows.Forms.TabPage();
            this.lblWindowStates = new System.Windows.Forms.LinkLabel();
            this.tbSetWorkMode = new System.Windows.Forms.TrackBar();
            this.tbWindowPosition = new System.Windows.Forms.TrackBar();
            this.lblWindowWorkMode = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pbWindowWorkMode = new System.Windows.Forms.PictureBox();
            this.lblCurrentWindowState = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pbWindowState = new System.Windows.Forms.PictureBox();
            this.lblCelsius2 = new System.Windows.Forms.Label();
            this.lblCelsius1 = new System.Windows.Forms.Label();
            this.lblByte = new System.Windows.Forms.Label();
            this.lblTempOutside = new System.Windows.Forms.Label();
            this.lblTempInside = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.therm2 = new System.Windows.Forms.PictureBox();
            this.therm1 = new System.Windows.Forms.PictureBox();
            this.lblFreeRam = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUptime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tpTemperatureTab = new System.Windows.Forms.TabPage();
            this.cbCreateTemperatureRules = new System.Windows.Forms.CheckBox();
            this.btnTempSensorsData = new System.Windows.Forms.Button();
            this.imglTabImages = new System.Windows.Forms.ImageList(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nudInterval = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.btnWriteTempSettings = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nudTClose = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.nudTOpen = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.cbTempSettings = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tpWateringTab = new System.Windows.Forms.TabPage();
            this.dgvWateringChannels = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chbTurnOnPump = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblWateringMode = new System.Windows.Forms.Label();
            this.tbWateringMode = new System.Windows.Forms.TrackBar();
            this.label14 = new System.Windows.Forms.Label();
            this.lblWateringState = new System.Windows.Forms.Label();
            this.tbWatering = new System.Windows.Forms.TrackBar();
            this.btnSaveWateringOptions = new System.Windows.Forms.Button();
            this.gbWateringSettings = new System.Windows.Forms.GroupBox();
            this.nudStartWateringTime = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.nudWateringTime = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.gbWeekDays = new System.Windows.Forms.GroupBox();
            this.clbWeekDays = new System.Windows.Forms.CheckedListBox();
            this.cbWateringControl = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tpLuminosity = new System.Windows.Forms.TabPage();
            this.lvLuminosity = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label22 = new System.Windows.Forms.Label();
            this.lblLuxMode = new System.Windows.Forms.Label();
            this.tbLuxMode = new System.Windows.Forms.TrackBar();
            this.label24 = new System.Windows.Forms.Label();
            this.lblLuxState = new System.Windows.Forms.Label();
            this.tbLux = new System.Windows.Forms.TrackBar();
            this.cbEnableLuminosityManage = new System.Windows.Forms.CheckBox();
            this.btnSaveLuxSettings = new System.Windows.Forms.Button();
            this.gbLuminositySettings = new System.Windows.Forms.GroupBox();
            this.cbWorkWithoutLightSensor = new System.Windows.Forms.CheckBox();
            this.nudLuxGisteresis = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.nudMinLux = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.nudLuxHourTo = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.nudLuxHourFrom = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.tpHumidity = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lvHumiditySensorsData = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpSMSTab = new System.Windows.Forms.TabPage();
            this.cbGSMProvider = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.btnSmsList = new System.Windows.Forms.Button();
            this.btnAddSMS = new System.Windows.Forms.Button();
            this.pbNumberHelp = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnSavePhoneNumber = new System.Windows.Forms.Button();
            this.tbPhoneNumber = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tpWiFi = new System.Windows.Forms.TabPage();
            this.btnQueryIP = new System.Windows.Forms.Button();
            this.cbConnectToTheRouter = new System.Windows.Forms.CheckBox();
            this.btnSaveWiFiSettings = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbStationPassword = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tbStationID = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbRouterPassword = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbRouterID = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tpRules = new System.Windows.Forms.TabPage();
            this.btnDeleteRule = new System.Windows.Forms.Button();
            this.btnAddRule = new System.Windows.Forms.Button();
            this.lblComputeRulesmemory = new System.Windows.Forms.LinkLabel();
            this.btnEditRule = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblRuleStr = new System.Windows.Forms.Label();
            this.lvRulesList = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSaveRules = new System.Windows.Forms.Button();
            this.btnLoadRules = new System.Windows.Forms.Button();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.lblCurrentLogLine = new System.Windows.Forms.Label();
            this.lblCurrentLogFileName = new System.Windows.Forms.Label();
            this.pbLogsProgress = new System.Windows.Forms.ProgressBar();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbMonth = new System.Windows.Forms.RadioButton();
            this.rbWeek = new System.Windows.Forms.RadioButton();
            this.rbDay = new System.Windows.Forms.RadioButton();
            this.btnLoadLogs = new System.Windows.Forms.Button();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.tbLogsDirectory = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tpWaterFlow = new System.Windows.Forms.TabPage();
            this.btnResetWaterflowData = new System.Windows.Forms.Button();
            this.btnSaveFlowSettings = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.nudFlowCalibration2 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label29 = new System.Windows.Forms.Label();
            this.lblFlowIncremental2 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblFlowInstant2 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.nudFlowCalibration1 = new System.Windows.Forms.NumericUpDown();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label31 = new System.Windows.Forms.Label();
            this.lblFlowIncremental1 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblFlowInstant1 = new System.Windows.Forms.Label();
            this.tpMultipleCommands = new System.Windows.Forms.TabPage();
            this.btnClearCCCommands = new System.Windows.Forms.Button();
            this.btnDeleteCompositeCommand = new System.Windows.Forms.Button();
            this.btnAddCompositeCommand = new System.Windows.Forms.Button();
            this.btnEditCompositeCommand = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lvCompositeCommandsList = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnUploadCompositeCommands = new System.Windows.Forms.Button();
            this.tpDeltas = new System.Windows.Forms.TabPage();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lvDeltasList = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpSoilMoisture = new System.Windows.Forms.TabPage();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.lvSoilMoistureSensorsData = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpPH = new System.Windows.Forms.TabPage();
            this.lvPHStatus = new System.Windows.Forms.ListView();
            this.btnPHControl = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label44 = new System.Windows.Forms.Label();
            this.nudPHCalibrationTemperature = new System.Windows.Forms.NumericUpDown();
            this.label42 = new System.Windows.Forms.Label();
            this.nudPHTempSensorIndex = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.nudPHCalibration = new System.Windows.Forms.NumericUpDown();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.nudPHVoltage10 = new System.Windows.Forms.NumericUpDown();
            this.nudPHVoltage7 = new System.Windows.Forms.NumericUpDown();
            this.nudPHVoltage4 = new System.Windows.Forms.NumericUpDown();
            this.btnSavePHSettings = new System.Windows.Forms.Button();
            this.lvPH = new System.Windows.Forms.ListView();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tpIOT = new System.Windows.Forms.TabPage();
            this.lbIOTSelectedSensors = new System.Windows.Forms.ListBox();
            this.lbIOTAllSensors = new System.Windows.Forms.ListBox();
            this.label47 = new System.Windows.Forms.Label();
            this.btnSaveIoTSettings = new System.Windows.Forms.Button();
            this.tbThingSpeakChannelKey = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.nudIoTInterval = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.cbThingSpeakEnabled = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lvLog = new System.Windows.Forms.ListView();
            this.logColumn1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.logColumn2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tmrUptime = new System.Windows.Forms.Timer(this.components);
            this.tmrFreeRam = new System.Windows.Forms.Timer(this.components);
            this.tmProcessCommandsTimer = new System.Windows.Forms.Timer(this.components);
            this.tmrTicks = new System.Windows.Forms.Timer(this.components);
            this.tmWaitDataTimer = new System.Windows.Forms.Timer(this.components);
            this.tmGetAllTempData = new System.Windows.Forms.Timer(this.components);
            this.ttPhoneNumberHint = new System.Windows.Forms.ToolTip(this.components);
            this.ttDefault = new System.Windows.Forms.ToolTip(this.components);
            this.selectFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.ttTempRulesHint = new System.Windows.Forms.ToolTip(this.components);
            this.lblDriveWaterChannels = new System.Windows.Forms.LinkLabel();
            this.menuStrip1.SuspendLayout();
            this.tbToolBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitCont)).BeginInit();
            this.splitCont.Panel1.SuspendLayout();
            this.splitCont.Panel2.SuspendLayout();
            this.splitCont.SuspendLayout();
            this.tabCMain.SuspendLayout();
            this.tcStatPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetWorkMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWindowPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowWorkMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.therm2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.therm1)).BeginInit();
            this.tpTemperatureTab.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudInterval)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTOpen)).BeginInit();
            this.tpWateringTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWateringChannels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWateringMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWatering)).BeginInit();
            this.gbWateringSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWateringTime)).BeginInit();
            this.gbWeekDays.SuspendLayout();
            this.tpLuminosity.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbLuxMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbLux)).BeginInit();
            this.gbLuminositySettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxGisteresis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinLux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourFrom)).BeginInit();
            this.tpHumidity.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tpSMSTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNumberHelp)).BeginInit();
            this.tpWiFi.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tpRules.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tpWaterFlow.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tpMultipleCommands.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tpDeltas.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tpSoilMoisture.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tpPH.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibrationTemperature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHTempSensorIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibration)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage4)).BeginInit();
            this.tpIOT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIoTInterval)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 411);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(685, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusBar";
            // 
            // imglToolbarImages
            // 
            this.imglToolbarImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglToolbarImages.ImageStream")));
            this.imglToolbarImages.TransparentColor = System.Drawing.Color.Transparent;
            this.imglToolbarImages.Images.SetKeyName(0, "connect_no.png");
            this.imglToolbarImages.Images.SetKeyName(1, "connect_established.png");
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFile,
            this.miConfiguration,
            this.miSettings,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(685, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // miFile
            // 
            this.miFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miExit});
            this.miFile.Name = "miFile";
            this.miFile.Size = new System.Drawing.Size(48, 20);
            this.miFile.Text = "Файл";
            // 
            // miExit
            // 
            this.miExit.Name = "miExit";
            this.miExit.Size = new System.Drawing.Size(108, 22);
            this.miExit.Text = "Выход";
            this.miExit.Click += new System.EventHandler(this.miExit_Click);
            // 
            // miConfiguration
            // 
            this.miConfiguration.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miPlayPause,
            this.toolStripMenuItem4,
            this.miDelta,
            this.miReservationSettings,
            this.miUniversalSensors,
            this.miTimers,
            this.toolStripMenuItem3,
            this.miDateTime,
            this.miRestart,
            this.toolStripMenuItem5,
            this.miFirmwareInfo});
            this.miConfiguration.Name = "miConfiguration";
            this.miConfiguration.Size = new System.Drawing.Size(85, 20);
            this.miConfiguration.Text = "Управление";
            // 
            // miPlayPause
            // 
            this.miPlayPause.Enabled = false;
            this.miPlayPause.Name = "miPlayPause";
            this.miPlayPause.Size = new System.Drawing.Size(282, 22);
            this.miPlayPause.Text = "Стоп";
            this.miPlayPause.Click += new System.EventHandler(this.tbPlayPause_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(279, 6);
            // 
            // miDelta
            // 
            this.miDelta.Enabled = false;
            this.miDelta.Name = "miDelta";
            this.miDelta.Size = new System.Drawing.Size(282, 22);
            this.miDelta.Text = "Список виртуальных датчиков дельт";
            this.miDelta.Click += new System.EventHandler(this.tbDelta_Click);
            // 
            // miReservationSettings
            // 
            this.miReservationSettings.Enabled = false;
            this.miReservationSettings.Name = "miReservationSettings";
            this.miReservationSettings.Size = new System.Drawing.Size(282, 22);
            this.miReservationSettings.Text = "Настройки резервирования датчиков";
            this.miReservationSettings.Visible = false;
            this.miReservationSettings.Click += new System.EventHandler(this.miReservationSettings_Click);
            // 
            // miUniversalSensors
            // 
            this.miUniversalSensors.Enabled = false;
            this.miUniversalSensors.Name = "miUniversalSensors";
            this.miUniversalSensors.Size = new System.Drawing.Size(282, 22);
            this.miUniversalSensors.Text = "Регистрация универсальных модулей";
            this.miUniversalSensors.Click += new System.EventHandler(this.miUniversalSensors_Click);
            // 
            // miTimers
            // 
            this.miTimers.Enabled = false;
            this.miTimers.Name = "miTimers";
            this.miTimers.Size = new System.Drawing.Size(282, 22);
            this.miTimers.Text = "Периодические таймеры";
            this.miTimers.Visible = false;
            this.miTimers.Click += new System.EventHandler(this.miTimers_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(279, 6);
            // 
            // miDateTime
            // 
            this.miDateTime.Enabled = false;
            this.miDateTime.Name = "miDateTime";
            this.miDateTime.Size = new System.Drawing.Size(282, 22);
            this.miDateTime.Text = "Установить дату/время контроллера";
            this.miDateTime.Click += new System.EventHandler(this.btnSetControllerTime_Click);
            // 
            // miRestart
            // 
            this.miRestart.Enabled = false;
            this.miRestart.Name = "miRestart";
            this.miRestart.Size = new System.Drawing.Size(282, 22);
            this.miRestart.Text = "Перезагрузить контроллер";
            this.miRestart.Click += new System.EventHandler(this.tbRestartButton_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(279, 6);
            // 
            // miFirmwareInfo
            // 
            this.miFirmwareInfo.Enabled = false;
            this.miFirmwareInfo.Name = "miFirmwareInfo";
            this.miFirmwareInfo.Size = new System.Drawing.Size(282, 22);
            this.miFirmwareInfo.Text = "Информация о прошивке";
            this.miFirmwareInfo.Click += new System.EventHandler(this.miFirmwareInfo_Click);
            // 
            // miSettings
            // 
            this.miSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miMonitorScreenSettings,
            this.miPinsUsed});
            this.miSettings.Name = "miSettings";
            this.miSettings.Size = new System.Drawing.Size(79, 20);
            this.miSettings.Text = "Настройки";
            // 
            // miMonitorScreenSettings
            // 
            this.miMonitorScreenSettings.Name = "miMonitorScreenSettings";
            this.miMonitorScreenSettings.Size = new System.Drawing.Size(254, 22);
            this.miMonitorScreenSettings.Text = "Настройки экрана \"Монитор\"";
            this.miMonitorScreenSettings.Click += new System.EventHandler(this.miMonitorScreenSettings_Click);
            // 
            // miPinsUsed
            // 
            this.miPinsUsed.Enabled = false;
            this.miPinsUsed.Name = "miPinsUsed";
            this.miPinsUsed.Size = new System.Drawing.Size(254, 22);
            this.miPinsUsed.Text = "Информация по занятым пинам";
            this.miPinsUsed.Click += new System.EventHandler(this.miPinsUsed_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.helpToolStripMenuItem.Text = "Помощь";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.aboutToolStripMenuItem.Text = "О программе";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // tbToolBar
            // 
            this.tbToolBar.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.tbToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbbConnectBtn,
            this.tbPlayPause,
            this.btnSetControllerTime,
            this.tbDelta,
            this.tbRestartButton,
            this.toolStripSeparator1,
            this.tbbAbout});
            this.tbToolBar.Location = new System.Drawing.Point(0, 24);
            this.tbToolBar.Name = "tbToolBar";
            this.tbToolBar.Size = new System.Drawing.Size(685, 70);
            this.tbToolBar.TabIndex = 2;
            this.tbToolBar.Paint += new System.Windows.Forms.PaintEventHandler(this.tbToolBar_Paint);
            // 
            // tbbConnectBtn
            // 
            this.tbbConnectBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsiCOMConnection});
            this.tbbConnectBtn.Image = ((System.Drawing.Image)(resources.GetObject("tbbConnectBtn.Image")));
            this.tbbConnectBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbbConnectBtn.Name = "tbbConnectBtn";
            this.tbbConnectBtn.Size = new System.Drawing.Size(79, 67);
            this.tbbConnectBtn.Text = "Соединить";
            this.tbbConnectBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbbConnectBtn.ToolTipText = "Установить соединение с выбранным портом";
            // 
            // tsiCOMConnection
            // 
            this.tsiCOMConnection.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miRescanPorts,
            this.toolStripMenuItem2});
            this.tsiCOMConnection.Name = "tsiCOMConnection";
            this.tsiCOMConnection.Size = new System.Drawing.Size(226, 22);
            this.tsiCOMConnection.Text = "Соединение по COM-порту";
            // 
            // miRescanPorts
            // 
            this.miRescanPorts.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.miRescanPorts.Name = "miRescanPorts";
            this.miRescanPorts.Size = new System.Drawing.Size(176, 22);
            this.miRescanPorts.Tag = "1";
            this.miRescanPorts.Text = "Перечитать порты";
            this.miRescanPorts.Click += new System.EventHandler(this.miRescanPorts_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(173, 6);
            this.toolStripMenuItem2.Tag = "1";
            // 
            // tbPlayPause
            // 
            this.tbPlayPause.Enabled = false;
            this.tbPlayPause.Image = ((System.Drawing.Image)(resources.GetObject("tbPlayPause.Image")));
            this.tbPlayPause.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbPlayPause.Name = "tbPlayPause";
            this.tbPlayPause.Size = new System.Drawing.Size(52, 67);
            this.tbPlayPause.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbPlayPause.Click += new System.EventHandler(this.tbPlayPause_Click);
            // 
            // btnSetControllerTime
            // 
            this.btnSetControllerTime.Enabled = false;
            this.btnSetControllerTime.Image = ((System.Drawing.Image)(resources.GetObject("btnSetControllerTime.Image")));
            this.btnSetControllerTime.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSetControllerTime.Name = "btnSetControllerTime";
            this.btnSetControllerTime.Size = new System.Drawing.Size(75, 67);
            this.btnSetControllerTime.Text = "Дата/время";
            this.btnSetControllerTime.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSetControllerTime.ToolTipText = "Установить текущее время в контроллере";
            this.btnSetControllerTime.Click += new System.EventHandler(this.btnSetControllerTime_Click);
            // 
            // tbDelta
            // 
            this.tbDelta.Enabled = false;
            this.tbDelta.Image = ((System.Drawing.Image)(resources.GetObject("tbDelta.Image")));
            this.tbDelta.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbDelta.Name = "tbDelta";
            this.tbDelta.Size = new System.Drawing.Size(70, 67);
            this.tbDelta.Text = "   Дельты   ";
            this.tbDelta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbDelta.ToolTipText = "Список виртуальных датчиков дельт";
            this.tbDelta.Click += new System.EventHandler(this.tbDelta_Click);
            // 
            // tbRestartButton
            // 
            this.tbRestartButton.Enabled = false;
            this.tbRestartButton.Image = global::GreenHouseConfig.Properties.Resources.system_restart;
            this.tbRestartButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tbRestartButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbRestartButton.Name = "tbRestartButton";
            this.tbRestartButton.Size = new System.Drawing.Size(53, 67);
            this.tbRestartButton.Text = "Рестарт";
            this.tbRestartButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbRestartButton.ToolTipText = "Перезагрузить контроллер";
            this.tbRestartButton.Click += new System.EventHandler(this.tbRestartButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 70);
            // 
            // tbbAbout
            // 
            this.tbbAbout.Image = global::GreenHouseConfig.Properties.Resources.information;
            this.tbbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbbAbout.Name = "tbbAbout";
            this.tbbAbout.Size = new System.Drawing.Size(86, 67);
            this.tbbAbout.Text = "О программе";
            this.tbbAbout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tbbAbout.ToolTipText = "Показать окно информации о программе";
            this.tbbAbout.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // splitCont
            // 
            this.splitCont.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitCont.Location = new System.Drawing.Point(0, 94);
            this.splitCont.Name = "splitCont";
            this.splitCont.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitCont.Panel1
            // 
            this.splitCont.Panel1.Controls.Add(this.tabCMain);
            this.splitCont.Panel1MinSize = 100;
            // 
            // splitCont.Panel2
            // 
            this.splitCont.Panel2.Controls.Add(this.tabControl1);
            this.splitCont.Panel2MinSize = 100;
            this.splitCont.Size = new System.Drawing.Size(685, 317);
            this.splitCont.SplitterDistance = 202;
            this.splitCont.TabIndex = 3;
            // 
            // tabCMain
            // 
            this.tabCMain.Controls.Add(this.tcStatPage);
            this.tabCMain.Controls.Add(this.tpTemperatureTab);
            this.tabCMain.Controls.Add(this.tpWateringTab);
            this.tabCMain.Controls.Add(this.tpLuminosity);
            this.tabCMain.Controls.Add(this.tpHumidity);
            this.tabCMain.Controls.Add(this.tpSMSTab);
            this.tabCMain.Controls.Add(this.tpWiFi);
            this.tabCMain.Controls.Add(this.tpRules);
            this.tabCMain.Controls.Add(this.tpLog);
            this.tabCMain.Controls.Add(this.tpWaterFlow);
            this.tabCMain.Controls.Add(this.tpMultipleCommands);
            this.tabCMain.Controls.Add(this.tpDeltas);
            this.tabCMain.Controls.Add(this.tpSoilMoisture);
            this.tabCMain.Controls.Add(this.tpPH);
            this.tabCMain.Controls.Add(this.tpIOT);
            this.tabCMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCMain.HotTrack = true;
            this.tabCMain.ImageList = this.imglTabImages;
            this.tabCMain.Location = new System.Drawing.Point(0, 0);
            this.tabCMain.Name = "tabCMain";
            this.tabCMain.SelectedIndex = 0;
            this.tabCMain.Size = new System.Drawing.Size(685, 202);
            this.tabCMain.TabIndex = 0;
            // 
            // tcStatPage
            // 
            this.tcStatPage.Controls.Add(this.lblWindowStates);
            this.tcStatPage.Controls.Add(this.tbSetWorkMode);
            this.tcStatPage.Controls.Add(this.tbWindowPosition);
            this.tcStatPage.Controls.Add(this.lblWindowWorkMode);
            this.tcStatPage.Controls.Add(this.label6);
            this.tcStatPage.Controls.Add(this.pbWindowWorkMode);
            this.tcStatPage.Controls.Add(this.lblCurrentWindowState);
            this.tcStatPage.Controls.Add(this.label5);
            this.tcStatPage.Controls.Add(this.pbWindowState);
            this.tcStatPage.Controls.Add(this.lblCelsius2);
            this.tcStatPage.Controls.Add(this.lblCelsius1);
            this.tcStatPage.Controls.Add(this.lblByte);
            this.tcStatPage.Controls.Add(this.lblTempOutside);
            this.tcStatPage.Controls.Add(this.lblTempInside);
            this.tcStatPage.Controls.Add(this.pictureBox4);
            this.tcStatPage.Controls.Add(this.pictureBox3);
            this.tcStatPage.Controls.Add(this.label4);
            this.tcStatPage.Controls.Add(this.label3);
            this.tcStatPage.Controls.Add(this.therm2);
            this.tcStatPage.Controls.Add(this.therm1);
            this.tcStatPage.Controls.Add(this.lblFreeRam);
            this.tcStatPage.Controls.Add(this.label2);
            this.tcStatPage.Controls.Add(this.lblUptime);
            this.tcStatPage.Controls.Add(this.label1);
            this.tcStatPage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tcStatPage.ImageIndex = 0;
            this.tcStatPage.Location = new System.Drawing.Point(4, 23);
            this.tcStatPage.Name = "tcStatPage";
            this.tcStatPage.Padding = new System.Windows.Forms.Padding(3);
            this.tcStatPage.Size = new System.Drawing.Size(677, 175);
            this.tcStatPage.TabIndex = 0;
            this.tcStatPage.Text = "Монитор";
            this.tcStatPage.UseVisualStyleBackColor = true;
            // 
            // lblWindowStates
            // 
            this.lblWindowStates.AutoSize = true;
            this.lblWindowStates.Location = new System.Drawing.Point(438, 76);
            this.lblWindowStates.Name = "lblWindowStates";
            this.lblWindowStates.Size = new System.Drawing.Size(150, 13);
            this.lblWindowStates.TabIndex = 23;
            this.lblWindowStates.TabStop = true;
            this.lblWindowStates.Text = "Состояние окон по каналам";
            this.ttDefault.SetToolTip(this.lblWindowStates, "Посмотреть состояние окон по каналам");
            this.lblWindowStates.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblWindowStates_LinkClicked);
            // 
            // tbSetWorkMode
            // 
            this.tbSetWorkMode.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbSetWorkMode.Enabled = false;
            this.tbSetWorkMode.LargeChange = 1;
            this.tbSetWorkMode.Location = new System.Drawing.Point(624, 96);
            this.tbSetWorkMode.Maximum = 1;
            this.tbSetWorkMode.Name = "tbSetWorkMode";
            this.tbSetWorkMode.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbSetWorkMode.Size = new System.Drawing.Size(45, 58);
            this.tbSetWorkMode.TabIndex = 22;
            this.tbSetWorkMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbSetWorkMode.Scroll += new System.EventHandler(this.tbSetWorkMode_Scroll);
            // 
            // tbWindowPosition
            // 
            this.tbWindowPosition.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbWindowPosition.Enabled = false;
            this.tbWindowPosition.LargeChange = 1;
            this.tbWindowPosition.Location = new System.Drawing.Point(626, 17);
            this.tbWindowPosition.Maximum = 1;
            this.tbWindowPosition.Name = "tbWindowPosition";
            this.tbWindowPosition.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbWindowPosition.Size = new System.Drawing.Size(45, 58);
            this.tbWindowPosition.TabIndex = 21;
            this.tbWindowPosition.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWindowPosition.Scroll += new System.EventHandler(this.tbWindowPosition_Scroll);
            // 
            // lblWindowWorkMode
            // 
            this.lblWindowWorkMode.AutoSize = true;
            this.lblWindowWorkMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWindowWorkMode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblWindowWorkMode.Location = new System.Drawing.Point(495, 128);
            this.lblWindowWorkMode.Name = "lblWindowWorkMode";
            this.lblWindowWorkMode.Size = new System.Drawing.Size(126, 20);
            this.lblWindowWorkMode.TabIndex = 20;
            this.lblWindowWorkMode.Text = "<нет данных>";
            this.lblWindowWorkMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(495, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Режим окон:";
            // 
            // pbWindowWorkMode
            // 
            this.pbWindowWorkMode.Image = ((System.Drawing.Image)(resources.GetObject("pbWindowWorkMode.Image")));
            this.pbWindowWorkMode.InitialImage = null;
            this.pbWindowWorkMode.Location = new System.Drawing.Point(441, 100);
            this.pbWindowWorkMode.Name = "pbWindowWorkMode";
            this.pbWindowWorkMode.Size = new System.Drawing.Size(48, 48);
            this.pbWindowWorkMode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWindowWorkMode.TabIndex = 18;
            this.pbWindowWorkMode.TabStop = false;
            // 
            // lblCurrentWindowState
            // 
            this.lblCurrentWindowState.AutoSize = true;
            this.lblCurrentWindowState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCurrentWindowState.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCurrentWindowState.Location = new System.Drawing.Point(495, 47);
            this.lblCurrentWindowState.Name = "lblCurrentWindowState";
            this.lblCurrentWindowState.Size = new System.Drawing.Size(126, 20);
            this.lblCurrentWindowState.TabIndex = 17;
            this.lblCurrentWindowState.Text = "<нет данных>";
            this.lblCurrentWindowState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(495, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Окна:";
            // 
            // pbWindowState
            // 
            this.pbWindowState.Image = ((System.Drawing.Image)(resources.GetObject("pbWindowState.Image")));
            this.pbWindowState.InitialImage = null;
            this.pbWindowState.Location = new System.Drawing.Point(441, 19);
            this.pbWindowState.Name = "pbWindowState";
            this.pbWindowState.Size = new System.Drawing.Size(48, 48);
            this.pbWindowState.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbWindowState.TabIndex = 15;
            this.pbWindowState.TabStop = false;
            // 
            // lblCelsius2
            // 
            this.lblCelsius2.AutoSize = true;
            this.lblCelsius2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCelsius2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCelsius2.Location = new System.Drawing.Point(327, 128);
            this.lblCelsius2.Name = "lblCelsius2";
            this.lblCelsius2.Size = new System.Drawing.Size(27, 20);
            this.lblCelsius2.TabIndex = 14;
            this.lblCelsius2.Text = "°C";
            this.lblCelsius2.Visible = false;
            // 
            // lblCelsius1
            // 
            this.lblCelsius1.AutoSize = true;
            this.lblCelsius1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCelsius1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCelsius1.Location = new System.Drawing.Point(327, 47);
            this.lblCelsius1.Name = "lblCelsius1";
            this.lblCelsius1.Size = new System.Drawing.Size(27, 20);
            this.lblCelsius1.TabIndex = 13;
            this.lblCelsius1.Text = "°C";
            this.lblCelsius1.Visible = false;
            // 
            // lblByte
            // 
            this.lblByte.AutoSize = true;
            this.lblByte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblByte.Location = new System.Drawing.Point(99, 128);
            this.lblByte.Name = "lblByte";
            this.lblByte.Size = new System.Drawing.Size(49, 20);
            this.lblByte.TabIndex = 12;
            this.lblByte.Text = "байт";
            this.lblByte.Visible = false;
            // 
            // lblTempOutside
            // 
            this.lblTempOutside.AutoSize = true;
            this.lblTempOutside.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTempOutside.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTempOutside.Location = new System.Drawing.Point(293, 128);
            this.lblTempOutside.Name = "lblTempOutside";
            this.lblTempOutside.Size = new System.Drawing.Size(126, 20);
            this.lblTempOutside.TabIndex = 11;
            this.lblTempOutside.Text = "<нет данных>";
            this.lblTempOutside.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTempInside
            // 
            this.lblTempInside.AutoSize = true;
            this.lblTempInside.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTempInside.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblTempInside.Location = new System.Drawing.Point(293, 47);
            this.lblTempInside.Name = "lblTempInside";
            this.lblTempInside.Size = new System.Drawing.Size(126, 20);
            this.lblTempInside.TabIndex = 10;
            this.lblTempInside.Text = "<нет данных>";
            this.lblTempInside.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(19, 100);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(48, 48);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(19, 19);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(293, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Т снаружи:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(293, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Т внутри:";
            // 
            // therm2
            // 
            this.therm2.Image = global::GreenHouseConfig.Properties.Resources.bluetherm;
            this.therm2.InitialImage = null;
            this.therm2.Location = new System.Drawing.Point(232, 100);
            this.therm2.Name = "therm2";
            this.therm2.Size = new System.Drawing.Size(64, 64);
            this.therm2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.therm2.TabIndex = 5;
            this.therm2.TabStop = false;
            // 
            // therm1
            // 
            this.therm1.Image = global::GreenHouseConfig.Properties.Resources.bluetherm;
            this.therm1.InitialImage = null;
            this.therm1.Location = new System.Drawing.Point(232, 19);
            this.therm1.Name = "therm1";
            this.therm1.Size = new System.Drawing.Size(64, 64);
            this.therm1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.therm1.TabIndex = 4;
            this.therm1.TabStop = false;
            // 
            // lblFreeRam
            // 
            this.lblFreeRam.AutoSize = true;
            this.lblFreeRam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFreeRam.Location = new System.Drawing.Point(74, 128);
            this.lblFreeRam.Name = "lblFreeRam";
            this.lblFreeRam.Size = new System.Drawing.Size(126, 20);
            this.lblFreeRam.TabIndex = 3;
            this.lblFreeRam.Text = "<нет данных>";
            this.lblFreeRam.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(74, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Память:";
            // 
            // lblUptime
            // 
            this.lblUptime.AutoSize = true;
            this.lblUptime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUptime.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUptime.Location = new System.Drawing.Point(73, 47);
            this.lblUptime.Name = "lblUptime";
            this.lblUptime.Size = new System.Drawing.Size(126, 20);
            this.lblUptime.TabIndex = 1;
            this.lblUptime.Text = "<нет данных>";
            this.lblUptime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(73, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Время работы:";
            // 
            // tpTemperatureTab
            // 
            this.tpTemperatureTab.Controls.Add(this.cbCreateTemperatureRules);
            this.tpTemperatureTab.Controls.Add(this.btnTempSensorsData);
            this.tpTemperatureTab.Controls.Add(this.groupBox2);
            this.tpTemperatureTab.Controls.Add(this.btnWriteTempSettings);
            this.tpTemperatureTab.Controls.Add(this.groupBox1);
            this.tpTemperatureTab.Controls.Add(this.cbTempSettings);
            this.tpTemperatureTab.Controls.Add(this.label7);
            this.tpTemperatureTab.ImageIndex = 1;
            this.tpTemperatureTab.Location = new System.Drawing.Point(4, 23);
            this.tpTemperatureTab.Name = "tpTemperatureTab";
            this.tpTemperatureTab.Padding = new System.Windows.Forms.Padding(10);
            this.tpTemperatureTab.Size = new System.Drawing.Size(677, 175);
            this.tpTemperatureTab.TabIndex = 1;
            this.tpTemperatureTab.Text = "Температура";
            this.tpTemperatureTab.UseVisualStyleBackColor = true;
            // 
            // cbCreateTemperatureRules
            // 
            this.cbCreateTemperatureRules.AutoSize = true;
            this.cbCreateTemperatureRules.Checked = true;
            this.cbCreateTemperatureRules.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCreateTemperatureRules.Location = new System.Drawing.Point(13, 148);
            this.cbCreateTemperatureRules.Name = "cbCreateTemperatureRules";
            this.cbCreateTemperatureRules.Size = new System.Drawing.Size(359, 17);
            this.cbCreateTemperatureRules.TabIndex = 11;
            this.cbCreateTemperatureRules.Text = "Создать служебные правила управления окнами по температуре";
            this.ttTempRulesHint.SetToolTip(this.cbCreateTemperatureRules, resources.GetString("cbCreateTemperatureRules.ToolTip"));
            this.cbCreateTemperatureRules.UseVisualStyleBackColor = true;
            this.cbCreateTemperatureRules.CheckedChanged += new System.EventHandler(this.cbCreateTemperatureRules_CheckedChanged);
            // 
            // btnTempSensorsData
            // 
            this.btnTempSensorsData.ImageIndex = 1;
            this.btnTempSensorsData.ImageList = this.imglTabImages;
            this.btnTempSensorsData.Location = new System.Drawing.Point(529, 80);
            this.btnTempSensorsData.Name = "btnTempSensorsData";
            this.btnTempSensorsData.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.btnTempSensorsData.Size = new System.Drawing.Size(138, 38);
            this.btnTempSensorsData.TabIndex = 10;
            this.btnTempSensorsData.Text = "Данные датчиков";
            this.btnTempSensorsData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTempSensorsData.UseVisualStyleBackColor = true;
            this.btnTempSensorsData.Click += new System.EventHandler(this.btnTempSensorsData_Click);
            // 
            // imglTabImages
            // 
            this.imglTabImages.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglTabImages.ImageStream")));
            this.imglTabImages.TransparentColor = System.Drawing.Color.Transparent;
            this.imglTabImages.Images.SetKeyName(0, "kchart16.png");
            this.imglTabImages.Images.SetKeyName(1, "9006-prescription_pad.png");
            this.imglTabImages.Images.SetKeyName(2, "list.png");
            this.imglTabImages.Images.SetKeyName(3, "ipod_unmount.png");
            this.imglTabImages.Images.SetKeyName(4, "water.png");
            this.imglTabImages.Images.SetKeyName(5, "help_hint.png");
            this.imglTabImages.Images.SetKeyName(6, "wifismall.png");
            this.imglTabImages.Images.SetKeyName(7, "raindrop.png");
            this.imglTabImages.Images.SetKeyName(8, "flag_green.png");
            this.imglTabImages.Images.SetKeyName(9, "0003-folder.png");
            this.imglTabImages.Images.SetKeyName(10, "fill.png");
            this.imglTabImages.Images.SetKeyName(11, "multiple_commands.png");
            this.imglTabImages.Images.SetKeyName(12, "delta_small.png");
            this.imglTabImages.Images.SetKeyName(13, "soil_moisture.png");
            this.imglTabImages.Images.SetKeyName(14, "preferences_desktop_icons.png");
            this.imglTabImages.Images.SetKeyName(15, "network.png");
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nudInterval);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(237, 62);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(272, 80);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Настройка моторов";
            // 
            // nudInterval
            // 
            this.nudInterval.Location = new System.Drawing.Point(200, 25);
            this.nudInterval.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.nudInterval.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudInterval.Name = "nudInterval";
            this.nudInterval.Size = new System.Drawing.Size(55, 20);
            this.nudInterval.TabIndex = 8;
            this.nudInterval.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(165, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Время до полного открытия, с:";
            // 
            // btnWriteTempSettings
            // 
            this.btnWriteTempSettings.Enabled = false;
            this.btnWriteTempSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnWriteTempSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWriteTempSettings.Location = new System.Drawing.Point(529, 124);
            this.btnWriteTempSettings.Name = "btnWriteTempSettings";
            this.btnWriteTempSettings.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnWriteTempSettings.Size = new System.Drawing.Size(138, 38);
            this.btnWriteTempSettings.TabIndex = 7;
            this.btnWriteTempSettings.Text = "Записать настройки";
            this.btnWriteTempSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnWriteTempSettings, "Записать настройки в контроллер");
            this.btnWriteTempSettings.UseVisualStyleBackColor = true;
            this.btnWriteTempSettings.Click += new System.EventHandler(this.btnWriteTempSettings_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nudTClose);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.nudTOpen);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(13, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 80);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Текущие настройки температур";
            // 
            // nudTClose
            // 
            this.nudTClose.Location = new System.Drawing.Point(129, 51);
            this.nudTClose.Name = "nudTClose";
            this.nudTClose.Size = new System.Drawing.Size(55, 20);
            this.nudTClose.TabIndex = 9;
            this.nudTClose.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Т закрытия:";
            // 
            // nudTOpen
            // 
            this.nudTOpen.Location = new System.Drawing.Point(129, 25);
            this.nudTOpen.Name = "nudTOpen";
            this.nudTOpen.Size = new System.Drawing.Size(55, 20);
            this.nudTOpen.TabIndex = 7;
            this.nudTOpen.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Т открытия:";
            // 
            // cbTempSettings
            // 
            this.cbTempSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.cbTempSettings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTempSettings.FormattingEnabled = true;
            this.cbTempSettings.Location = new System.Drawing.Point(10, 28);
            this.cbTempSettings.Name = "cbTempSettings";
            this.cbTempSettings.Size = new System.Drawing.Size(657, 21);
            this.cbTempSettings.TabIndex = 1;
            this.cbTempSettings.SelectedIndexChanged += new System.EventHandler(this.cbTempSettings_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Location = new System.Drawing.Point(10, 10);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label7.Size = new System.Drawing.Size(232, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "Предустановленные настройки температур:";
            // 
            // tpWateringTab
            // 
            this.tpWateringTab.Controls.Add(this.lblDriveWaterChannels);
            this.tpWateringTab.Controls.Add(this.dgvWateringChannels);
            this.tpWateringTab.Controls.Add(this.chbTurnOnPump);
            this.tpWateringTab.Controls.Add(this.label15);
            this.tpWateringTab.Controls.Add(this.lblWateringMode);
            this.tpWateringTab.Controls.Add(this.tbWateringMode);
            this.tpWateringTab.Controls.Add(this.label14);
            this.tpWateringTab.Controls.Add(this.lblWateringState);
            this.tpWateringTab.Controls.Add(this.tbWatering);
            this.tpWateringTab.Controls.Add(this.btnSaveWateringOptions);
            this.tpWateringTab.Controls.Add(this.gbWateringSettings);
            this.tpWateringTab.Controls.Add(this.gbWeekDays);
            this.tpWateringTab.Controls.Add(this.cbWateringControl);
            this.tpWateringTab.Controls.Add(this.label12);
            this.tpWateringTab.ImageIndex = 4;
            this.tpWateringTab.Location = new System.Drawing.Point(4, 23);
            this.tpWateringTab.Name = "tpWateringTab";
            this.tpWateringTab.Padding = new System.Windows.Forms.Padding(10);
            this.tpWateringTab.Size = new System.Drawing.Size(677, 175);
            this.tpWateringTab.TabIndex = 3;
            this.tpWateringTab.Text = "Полив";
            this.tpWateringTab.UseVisualStyleBackColor = true;
            // 
            // dgvWateringChannels
            // 
            this.dgvWateringChannels.AllowUserToAddRows = false;
            this.dgvWateringChannels.AllowUserToDeleteRows = false;
            this.dgvWateringChannels.AllowUserToResizeRows = false;
            this.dgvWateringChannels.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvWateringChannels.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvWateringChannels.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dgvWateringChannels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWateringChannels.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column4});
            this.dgvWateringChannels.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvWateringChannels.Location = new System.Drawing.Point(10, 60);
            this.dgvWateringChannels.MultiSelect = false;
            this.dgvWateringChannels.Name = "dgvWateringChannels";
            this.dgvWateringChannels.RowHeadersVisible = false;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvWateringChannels.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvWateringChannels.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWateringChannels.Size = new System.Drawing.Size(489, 77);
            this.dgvWateringChannels.TabIndex = 29;
            this.dgvWateringChannels.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvWateringChannels_CellBeginEdit);
            this.dgvWateringChannels.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvWateringChannels_CellEndEdit);
            this.dgvWateringChannels.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvWateringChannels_CellFormatting);
            this.dgvWateringChannels.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvWateringChannels_DataError);
            this.dgvWateringChannels.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvWateringChannels_EditingControlShowing);
            // 
            // Column1
            // 
            dataGridViewCellStyle1.NullValue = null;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column1.HeaderText = "Канал";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 50;
            // 
            // Column3
            // 
            dataGridViewCellStyle2.Format = "N0";
            dataGridViewCellStyle2.NullValue = "0";
            this.Column3.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column3.HeaderText = "Начало";
            this.Column3.MaxInputLength = 2;
            this.Column3.Name = "Column3";
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column3.Width = 70;
            // 
            // Column4
            // 
            dataGridViewCellStyle3.Format = "N2";
            dataGridViewCellStyle3.NullValue = null;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column4.HeaderText = "Продолжительность";
            this.Column4.MaxInputLength = 3;
            this.Column4.Name = "Column4";
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 160;
            // 
            // chbTurnOnPump
            // 
            this.chbTurnOnPump.AutoSize = true;
            this.chbTurnOnPump.Location = new System.Drawing.Point(10, 145);
            this.chbTurnOnPump.Name = "chbTurnOnPump";
            this.chbTurnOnPump.Size = new System.Drawing.Size(292, 17);
            this.chbTurnOnPump.TabIndex = 28;
            this.chbTurnOnPump.Text = "Включать реле насоса при поливе на любом канале";
            this.chbTurnOnPump.UseVisualStyleBackColor = true;
            this.chbTurnOnPump.CheckedChanged += new System.EventHandler(this.chbTurnOnPump_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(516, 69);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 20);
            this.label15.TabIndex = 27;
            this.label15.Text = "Режим:";
            // 
            // lblWateringMode
            // 
            this.lblWateringMode.AutoSize = true;
            this.lblWateringMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWateringMode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblWateringMode.Location = new System.Drawing.Point(516, 89);
            this.lblWateringMode.Name = "lblWateringMode";
            this.lblWateringMode.Size = new System.Drawing.Size(39, 20);
            this.lblWateringMode.TabIndex = 26;
            this.lblWateringMode.Text = "<?>";
            this.lblWateringMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbWateringMode
            // 
            this.tbWateringMode.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbWateringMode.LargeChange = 1;
            this.tbWateringMode.Location = new System.Drawing.Point(609, 69);
            this.tbWateringMode.Maximum = 1;
            this.tbWateringMode.Name = "tbWateringMode";
            this.tbWateringMode.Size = new System.Drawing.Size(58, 45);
            this.tbWateringMode.TabIndex = 25;
            this.tbWateringMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWateringMode.Scroll += new System.EventHandler(this.tbWateringMode_Scroll);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(516, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 20);
            this.label14.TabIndex = 24;
            this.label14.Text = "Полив:";
            // 
            // lblWateringState
            // 
            this.lblWateringState.AutoSize = true;
            this.lblWateringState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWateringState.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblWateringState.Location = new System.Drawing.Point(516, 41);
            this.lblWateringState.Name = "lblWateringState";
            this.lblWateringState.Size = new System.Drawing.Size(39, 20);
            this.lblWateringState.TabIndex = 23;
            this.lblWateringState.Text = "<?>";
            this.lblWateringState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbWatering
            // 
            this.tbWatering.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbWatering.LargeChange = 1;
            this.tbWatering.Location = new System.Drawing.Point(609, 16);
            this.tbWatering.Maximum = 1;
            this.tbWatering.Name = "tbWatering";
            this.tbWatering.Size = new System.Drawing.Size(58, 45);
            this.tbWatering.TabIndex = 22;
            this.tbWatering.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbWatering.Scroll += new System.EventHandler(this.tbWatering_Scroll);
            // 
            // btnSaveWateringOptions
            // 
            this.btnSaveWateringOptions.Enabled = false;
            this.btnSaveWateringOptions.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveWateringOptions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveWateringOptions.Location = new System.Drawing.Point(529, 124);
            this.btnSaveWateringOptions.Name = "btnSaveWateringOptions";
            this.btnSaveWateringOptions.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnSaveWateringOptions.Size = new System.Drawing.Size(138, 38);
            this.btnSaveWateringOptions.TabIndex = 8;
            this.btnSaveWateringOptions.Text = "Записать настройки";
            this.btnSaveWateringOptions.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveWateringOptions, "Записать настройки в контроллер");
            this.btnSaveWateringOptions.UseVisualStyleBackColor = true;
            this.btnSaveWateringOptions.Click += new System.EventHandler(this.btnSaveWateringOptions_Click);
            // 
            // gbWateringSettings
            // 
            this.gbWateringSettings.Controls.Add(this.nudStartWateringTime);
            this.gbWateringSettings.Controls.Add(this.label16);
            this.gbWateringSettings.Controls.Add(this.nudWateringTime);
            this.gbWateringSettings.Controls.Add(this.label13);
            this.gbWateringSettings.Location = new System.Drawing.Point(237, 62);
            this.gbWateringSettings.Name = "gbWateringSettings";
            this.gbWateringSettings.Size = new System.Drawing.Size(262, 77);
            this.gbWateringSettings.TabIndex = 3;
            this.gbWateringSettings.TabStop = false;
            this.gbWateringSettings.Text = "Настройки полива";
            this.gbWateringSettings.Visible = false;
            // 
            // nudStartWateringTime
            // 
            this.nudStartWateringTime.Location = new System.Drawing.Point(188, 19);
            this.nudStartWateringTime.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.nudStartWateringTime.Name = "nudStartWateringTime";
            this.nudStartWateringTime.Size = new System.Drawing.Size(55, 20);
            this.nudStartWateringTime.TabIndex = 11;
            this.nudStartWateringTime.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nudStartWateringTime.ValueChanged += new System.EventHandler(this.nudStartWateringTime_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 10;
            this.label16.Text = "Начало с, часов:";
            // 
            // nudWateringTime
            // 
            this.nudWateringTime.Location = new System.Drawing.Point(188, 43);
            this.nudWateringTime.Maximum = new decimal(new int[] {
            1380,
            0,
            0,
            0});
            this.nudWateringTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudWateringTime.Name = "nudWateringTime";
            this.nudWateringTime.Size = new System.Drawing.Size(55, 20);
            this.nudWateringTime.TabIndex = 9;
            this.nudWateringTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nudWateringTime.ValueChanged += new System.EventHandler(this.nudWateringTime_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(140, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Продолжительность, мин:";
            // 
            // gbWeekDays
            // 
            this.gbWeekDays.Controls.Add(this.clbWeekDays);
            this.gbWeekDays.Location = new System.Drawing.Point(13, 62);
            this.gbWeekDays.Name = "gbWeekDays";
            this.gbWeekDays.Padding = new System.Windows.Forms.Padding(8);
            this.gbWeekDays.Size = new System.Drawing.Size(200, 77);
            this.gbWeekDays.TabIndex = 2;
            this.gbWeekDays.TabStop = false;
            this.gbWeekDays.Text = "Дни недели";
            this.gbWeekDays.Visible = false;
            // 
            // clbWeekDays
            // 
            this.clbWeekDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbWeekDays.CheckOnClick = true;
            this.clbWeekDays.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clbWeekDays.FormattingEnabled = true;
            this.clbWeekDays.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.clbWeekDays.Location = new System.Drawing.Point(8, 21);
            this.clbWeekDays.Name = "clbWeekDays";
            this.clbWeekDays.Size = new System.Drawing.Size(184, 48);
            this.clbWeekDays.TabIndex = 0;
            this.clbWeekDays.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbWeekDays_ItemCheck);
            // 
            // cbWateringControl
            // 
            this.cbWateringControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWateringControl.FormattingEnabled = true;
            this.cbWateringControl.Location = new System.Drawing.Point(10, 28);
            this.cbWateringControl.Name = "cbWateringControl";
            this.cbWateringControl.Size = new System.Drawing.Size(489, 21);
            this.cbWateringControl.TabIndex = 1;
            this.cbWateringControl.SelectedIndexChanged += new System.EventHandler(this.cbWateringControl_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Location = new System.Drawing.Point(10, 10);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label12.Size = new System.Drawing.Size(203, 18);
            this.label12.TabIndex = 0;
            this.label12.Text = "Автоматическое управление поливом:";
            // 
            // tpLuminosity
            // 
            this.tpLuminosity.Controls.Add(this.lvLuminosity);
            this.tpLuminosity.Controls.Add(this.label22);
            this.tpLuminosity.Controls.Add(this.lblLuxMode);
            this.tpLuminosity.Controls.Add(this.tbLuxMode);
            this.tpLuminosity.Controls.Add(this.label24);
            this.tpLuminosity.Controls.Add(this.lblLuxState);
            this.tpLuminosity.Controls.Add(this.tbLux);
            this.tpLuminosity.Controls.Add(this.cbEnableLuminosityManage);
            this.tpLuminosity.Controls.Add(this.btnSaveLuxSettings);
            this.tpLuminosity.Controls.Add(this.gbLuminositySettings);
            this.tpLuminosity.ImageIndex = 5;
            this.tpLuminosity.Location = new System.Drawing.Point(4, 23);
            this.tpLuminosity.Name = "tpLuminosity";
            this.tpLuminosity.Padding = new System.Windows.Forms.Padding(10);
            this.tpLuminosity.Size = new System.Drawing.Size(677, 175);
            this.tpLuminosity.TabIndex = 4;
            this.tpLuminosity.Text = "Досветка";
            this.tpLuminosity.UseVisualStyleBackColor = true;
            // 
            // lvLuminosity
            // 
            this.lvLuminosity.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader15});
            this.lvLuminosity.FullRowSelect = true;
            this.lvLuminosity.GridLines = true;
            this.lvLuminosity.HideSelection = false;
            this.lvLuminosity.Location = new System.Drawing.Point(370, 19);
            this.lvLuminosity.MultiSelect = false;
            this.lvLuminosity.Name = "lvLuminosity";
            this.lvLuminosity.ShowItemToolTips = true;
            this.lvLuminosity.Size = new System.Drawing.Size(140, 143);
            this.lvLuminosity.TabIndex = 34;
            this.lvLuminosity.UseCompatibleStateImageBehavior = false;
            this.lvLuminosity.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "#";
            this.columnHeader13.Width = 30;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Люкс";
            this.columnHeader15.Width = 90;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(516, 69);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 20);
            this.label22.TabIndex = 33;
            this.label22.Text = "Режим:";
            // 
            // lblLuxMode
            // 
            this.lblLuxMode.AutoSize = true;
            this.lblLuxMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLuxMode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLuxMode.Location = new System.Drawing.Point(516, 89);
            this.lblLuxMode.Name = "lblLuxMode";
            this.lblLuxMode.Size = new System.Drawing.Size(39, 20);
            this.lblLuxMode.TabIndex = 32;
            this.lblLuxMode.Text = "<?>";
            this.lblLuxMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbLuxMode
            // 
            this.tbLuxMode.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbLuxMode.LargeChange = 1;
            this.tbLuxMode.Location = new System.Drawing.Point(609, 69);
            this.tbLuxMode.Maximum = 1;
            this.tbLuxMode.Name = "tbLuxMode";
            this.tbLuxMode.Size = new System.Drawing.Size(58, 45);
            this.tbLuxMode.TabIndex = 31;
            this.tbLuxMode.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbLuxMode.Scroll += new System.EventHandler(this.tbLuxMode_Scroll);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(516, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 20);
            this.label24.TabIndex = 30;
            this.label24.Text = "Досветка:";
            // 
            // lblLuxState
            // 
            this.lblLuxState.AutoSize = true;
            this.lblLuxState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLuxState.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLuxState.Location = new System.Drawing.Point(516, 41);
            this.lblLuxState.Name = "lblLuxState";
            this.lblLuxState.Size = new System.Drawing.Size(39, 20);
            this.lblLuxState.TabIndex = 29;
            this.lblLuxState.Text = "<?>";
            this.lblLuxState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbLux
            // 
            this.tbLux.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tbLux.LargeChange = 1;
            this.tbLux.Location = new System.Drawing.Point(609, 16);
            this.tbLux.Maximum = 1;
            this.tbLux.Name = "tbLux";
            this.tbLux.Size = new System.Drawing.Size(58, 45);
            this.tbLux.TabIndex = 28;
            this.tbLux.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbLux.Scroll += new System.EventHandler(this.tbLux_Scroll);
            // 
            // cbEnableLuminosityManage
            // 
            this.cbEnableLuminosityManage.AutoSize = true;
            this.cbEnableLuminosityManage.Location = new System.Drawing.Point(13, 136);
            this.cbEnableLuminosityManage.Name = "cbEnableLuminosityManage";
            this.cbEnableLuminosityManage.Size = new System.Drawing.Size(193, 17);
            this.cbEnableLuminosityManage.TabIndex = 10;
            this.cbEnableLuminosityManage.Text = "Включить управление досветкой";
            this.cbEnableLuminosityManage.UseVisualStyleBackColor = true;
            this.cbEnableLuminosityManage.CheckedChanged += new System.EventHandler(this.cbEnableLuminosityManage_CheckedChanged);
            // 
            // btnSaveLuxSettings
            // 
            this.btnSaveLuxSettings.Enabled = false;
            this.btnSaveLuxSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveLuxSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveLuxSettings.Location = new System.Drawing.Point(529, 124);
            this.btnSaveLuxSettings.Name = "btnSaveLuxSettings";
            this.btnSaveLuxSettings.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.btnSaveLuxSettings.Size = new System.Drawing.Size(138, 38);
            this.btnSaveLuxSettings.TabIndex = 9;
            this.btnSaveLuxSettings.Text = "Записать настройки";
            this.btnSaveLuxSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveLuxSettings, "Записать настройки в контроллер");
            this.btnSaveLuxSettings.UseVisualStyleBackColor = true;
            this.btnSaveLuxSettings.Click += new System.EventHandler(this.btnSaveLuxSettings_Click);
            // 
            // gbLuminositySettings
            // 
            this.gbLuminositySettings.Controls.Add(this.cbWorkWithoutLightSensor);
            this.gbLuminositySettings.Controls.Add(this.nudLuxGisteresis);
            this.gbLuminositySettings.Controls.Add(this.label20);
            this.gbLuminositySettings.Controls.Add(this.nudMinLux);
            this.gbLuminositySettings.Controls.Add(this.label21);
            this.gbLuminositySettings.Controls.Add(this.nudLuxHourTo);
            this.gbLuminositySettings.Controls.Add(this.label18);
            this.gbLuminositySettings.Controls.Add(this.nudLuxHourFrom);
            this.gbLuminositySettings.Controls.Add(this.label17);
            this.gbLuminositySettings.Enabled = false;
            this.gbLuminositySettings.Location = new System.Drawing.Point(13, 13);
            this.gbLuminositySettings.Name = "gbLuminositySettings";
            this.gbLuminositySettings.Padding = new System.Windows.Forms.Padding(10);
            this.gbLuminositySettings.Size = new System.Drawing.Size(348, 117);
            this.gbLuminositySettings.TabIndex = 4;
            this.gbLuminositySettings.TabStop = false;
            this.gbLuminositySettings.Text = "Управление досветкой";
            // 
            // cbWorkWithoutLightSensor
            // 
            this.cbWorkWithoutLightSensor.AutoSize = true;
            this.cbWorkWithoutLightSensor.Location = new System.Drawing.Point(16, 79);
            this.cbWorkWithoutLightSensor.Name = "cbWorkWithoutLightSensor";
            this.cbWorkWithoutLightSensor.Size = new System.Drawing.Size(269, 17);
            this.cbWorkWithoutLightSensor.TabIndex = 10;
            this.cbWorkWithoutLightSensor.Text = "Работа без показаний с датчика освещенности";
            this.cbWorkWithoutLightSensor.UseVisualStyleBackColor = true;
            // 
            // nudLuxGisteresis
            // 
            this.nudLuxGisteresis.Enabled = false;
            this.nudLuxGisteresis.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nudLuxGisteresis.Location = new System.Drawing.Point(219, 81);
            this.nudLuxGisteresis.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.nudLuxGisteresis.Name = "nudLuxGisteresis";
            this.nudLuxGisteresis.Size = new System.Drawing.Size(112, 20);
            this.nudLuxGisteresis.TabIndex = 9;
            this.nudLuxGisteresis.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Enabled = false;
            this.label20.Location = new System.Drawing.Point(13, 85);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Гистерезис, люкс:";
            this.label20.Visible = false;
            // 
            // nudMinLux
            // 
            this.nudMinLux.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nudMinLux.Location = new System.Drawing.Point(219, 52);
            this.nudMinLux.Maximum = new decimal(new int[] {
            65500,
            0,
            0,
            0});
            this.nudMinLux.Name = "nudMinLux";
            this.nudMinLux.Size = new System.Drawing.Size(112, 20);
            this.nudMinLux.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 56);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(190, 13);
            this.label21.TabIndex = 6;
            this.label21.Text = "Мин. освещенность для включения:";
            // 
            // nudLuxHourTo
            // 
            this.nudLuxHourTo.Location = new System.Drawing.Point(286, 23);
            this.nudLuxHourTo.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudLuxHourTo.Name = "nudLuxHourTo";
            this.nudLuxHourTo.Size = new System.Drawing.Size(45, 20);
            this.nudLuxHourTo.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(270, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "-";
            // 
            // nudLuxHourFrom
            // 
            this.nudLuxHourFrom.Location = new System.Drawing.Point(219, 23);
            this.nudLuxHourFrom.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nudLuxHourFrom.Name = "nudLuxHourFrom";
            this.nudLuxHourFrom.Size = new System.Drawing.Size(45, 20);
            this.nudLuxHourFrom.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(156, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Часы управления досветкой:";
            // 
            // tpHumidity
            // 
            this.tpHumidity.Controls.Add(this.label34);
            this.tpHumidity.Controls.Add(this.groupBox3);
            this.tpHumidity.ImageIndex = 7;
            this.tpHumidity.Location = new System.Drawing.Point(4, 23);
            this.tpHumidity.Name = "tpHumidity";
            this.tpHumidity.Padding = new System.Windows.Forms.Padding(10);
            this.tpHumidity.Size = new System.Drawing.Size(677, 175);
            this.tpHumidity.TabIndex = 6;
            this.tpHumidity.Text = "Влажность";
            this.tpHumidity.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label34.Location = new System.Drawing.Point(367, 22);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(297, 140);
            this.label34.TabIndex = 3;
            this.label34.Text = "На этой вкладке отображаются показания с поддерживаемых прошивкой датчиков влажно" +
    "сти.\r\n\r\nПоддерживаемые типы датчиков: DHT11, DHT2x, Si7021.";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lvHumiditySensorsData);
            this.groupBox3.Location = new System.Drawing.Point(13, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox3.Size = new System.Drawing.Size(348, 149);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Показания датчиков влажности";
            // 
            // lvHumiditySensorsData
            // 
            this.lvHumiditySensorsData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvHumiditySensorsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvHumiditySensorsData.FullRowSelect = true;
            this.lvHumiditySensorsData.GridLines = true;
            this.lvHumiditySensorsData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvHumiditySensorsData.LabelWrap = false;
            this.lvHumiditySensorsData.Location = new System.Drawing.Point(10, 23);
            this.lvHumiditySensorsData.MultiSelect = false;
            this.lvHumiditySensorsData.Name = "lvHumiditySensorsData";
            this.lvHumiditySensorsData.Size = new System.Drawing.Size(328, 116);
            this.lvHumiditySensorsData.TabIndex = 0;
            this.lvHumiditySensorsData.UseCompatibleStateImageBehavior = false;
            this.lvHumiditySensorsData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Влажность";
            this.columnHeader2.Width = 110;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Температура";
            this.columnHeader3.Width = 120;
            // 
            // tpSMSTab
            // 
            this.tpSMSTab.Controls.Add(this.cbGSMProvider);
            this.tpSMSTab.Controls.Add(this.label48);
            this.tpSMSTab.Controls.Add(this.btnSmsList);
            this.tpSMSTab.Controls.Add(this.btnAddSMS);
            this.tpSMSTab.Controls.Add(this.pbNumberHelp);
            this.tpSMSTab.Controls.Add(this.richTextBox1);
            this.tpSMSTab.Controls.Add(this.btnSavePhoneNumber);
            this.tpSMSTab.Controls.Add(this.tbPhoneNumber);
            this.tpSMSTab.Controls.Add(this.label11);
            this.tpSMSTab.Cursor = System.Windows.Forms.Cursors.Default;
            this.tpSMSTab.ImageIndex = 3;
            this.tpSMSTab.Location = new System.Drawing.Point(4, 23);
            this.tpSMSTab.Name = "tpSMSTab";
            this.tpSMSTab.Padding = new System.Windows.Forms.Padding(10);
            this.tpSMSTab.Size = new System.Drawing.Size(677, 175);
            this.tpSMSTab.TabIndex = 2;
            this.tpSMSTab.Text = "СМС";
            this.tpSMSTab.UseVisualStyleBackColor = true;
            // 
            // cbGSMProvider
            // 
            this.cbGSMProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGSMProvider.FormattingEnabled = true;
            this.cbGSMProvider.Items.AddRange(new object[] {
            "МТС (Россия)",
            "Билайн (Россия)",
            "Мегафон (Россия)",
            "Теле2 (Россия)",
            "Йота (Россия)",
            "МТС (Беларусь)",
            "Velcom (Беларусь)",
            "Privet (Беларусь)",
            "Life (Беларусь)"});
            this.cbGSMProvider.Location = new System.Drawing.Point(277, 27);
            this.cbGSMProvider.Name = "cbGSMProvider";
            this.cbGSMProvider.Size = new System.Drawing.Size(158, 21);
            this.cbGSMProvider.TabIndex = 14;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(274, 10);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(59, 13);
            this.label48.TabIndex = 13;
            this.label48.Text = "Оператор:";
            // 
            // btnSmsList
            // 
            this.btnSmsList.Image = global::GreenHouseConfig.Properties.Resources.list1;
            this.btnSmsList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSmsList.Location = new System.Drawing.Point(529, 36);
            this.btnSmsList.Name = "btnSmsList";
            this.btnSmsList.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnSmsList.Size = new System.Drawing.Size(138, 38);
            this.btnSmsList.TabIndex = 12;
            this.btnSmsList.Text = "Список СМС";
            this.btnSmsList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSmsList, "Записать настройки в контроллер");
            this.btnSmsList.UseVisualStyleBackColor = true;
            this.btnSmsList.Click += new System.EventHandler(this.btnSmsList_Click);
            // 
            // btnAddSMS
            // 
            this.btnAddSMS.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddSMS.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddSMS.Location = new System.Drawing.Point(529, 80);
            this.btnAddSMS.Name = "btnAddSMS";
            this.btnAddSMS.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAddSMS.Size = new System.Drawing.Size(138, 38);
            this.btnAddSMS.TabIndex = 11;
            this.btnAddSMS.Text = "Добавить СМС";
            this.btnAddSMS.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddSMS, "Записать настройки в контроллер");
            this.btnAddSMS.UseVisualStyleBackColor = true;
            this.btnAddSMS.Click += new System.EventHandler(this.btnAddSMS_Click);
            // 
            // pbNumberHelp
            // 
            this.pbNumberHelp.Cursor = System.Windows.Forms.Cursors.Help;
            this.pbNumberHelp.Image = global::GreenHouseConfig.Properties.Resources.help;
            this.pbNumberHelp.Location = new System.Drawing.Point(216, 28);
            this.pbNumberHelp.Name = "pbNumberHelp";
            this.pbNumberHelp.Size = new System.Drawing.Size(16, 16);
            this.pbNumberHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbNumberHelp.TabIndex = 10;
            this.pbNumberHelp.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Location = new System.Drawing.Point(16, 66);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(458, 96);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "\n";
            // 
            // btnSavePhoneNumber
            // 
            this.btnSavePhoneNumber.Enabled = false;
            this.btnSavePhoneNumber.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSavePhoneNumber.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSavePhoneNumber.Location = new System.Drawing.Point(529, 124);
            this.btnSavePhoneNumber.Name = "btnSavePhoneNumber";
            this.btnSavePhoneNumber.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSavePhoneNumber.Size = new System.Drawing.Size(138, 38);
            this.btnSavePhoneNumber.TabIndex = 8;
            this.btnSavePhoneNumber.Text = "Сохранить данные";
            this.btnSavePhoneNumber.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSavePhoneNumber, "Записать настройки в контроллер");
            this.btnSavePhoneNumber.UseVisualStyleBackColor = true;
            this.btnSavePhoneNumber.Click += new System.EventHandler(this.btnSavePhoneNumber_Click);
            // 
            // tbPhoneNumber
            // 
            this.tbPhoneNumber.Location = new System.Drawing.Point(10, 28);
            this.tbPhoneNumber.Name = "tbPhoneNumber";
            this.tbPhoneNumber.Size = new System.Drawing.Size(200, 20);
            this.tbPhoneNumber.TabIndex = 1;
            this.tbPhoneNumber.WordWrap = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Location = new System.Drawing.Point(10, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(226, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Входящий номер, в формате +79XXxxxxxxx:";
            // 
            // tpWiFi
            // 
            this.tpWiFi.Controls.Add(this.btnQueryIP);
            this.tpWiFi.Controls.Add(this.cbConnectToTheRouter);
            this.tpWiFi.Controls.Add(this.btnSaveWiFiSettings);
            this.tpWiFi.Controls.Add(this.groupBox5);
            this.tpWiFi.Controls.Add(this.groupBox4);
            this.tpWiFi.Controls.Add(this.pictureBox1);
            this.tpWiFi.ImageIndex = 6;
            this.tpWiFi.Location = new System.Drawing.Point(4, 23);
            this.tpWiFi.Name = "tpWiFi";
            this.tpWiFi.Padding = new System.Windows.Forms.Padding(10);
            this.tpWiFi.Size = new System.Drawing.Size(677, 175);
            this.tpWiFi.TabIndex = 5;
            this.tpWiFi.Text = "Wi-Fi";
            this.tpWiFi.UseVisualStyleBackColor = true;
            // 
            // btnQueryIP
            // 
            this.btnQueryIP.Enabled = false;
            this.btnQueryIP.Image = global::GreenHouseConfig.Properties.Resources.wifismall;
            this.btnQueryIP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnQueryIP.Location = new System.Drawing.Point(369, 124);
            this.btnQueryIP.Name = "btnQueryIP";
            this.btnQueryIP.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.btnQueryIP.Size = new System.Drawing.Size(154, 38);
            this.btnQueryIP.TabIndex = 17;
            this.btnQueryIP.Text = "Просмотр IP-адресов";
            this.btnQueryIP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnQueryIP, "Получить IP-адреса");
            this.btnQueryIP.UseVisualStyleBackColor = true;
            this.btnQueryIP.Click += new System.EventHandler(this.btnQueryIP_Click);
            // 
            // cbConnectToTheRouter
            // 
            this.cbConnectToTheRouter.AutoSize = true;
            this.cbConnectToTheRouter.Location = new System.Drawing.Point(13, 116);
            this.cbConnectToTheRouter.Name = "cbConnectToTheRouter";
            this.cbConnectToTheRouter.Size = new System.Drawing.Size(152, 17);
            this.cbConnectToTheRouter.TabIndex = 16;
            this.cbConnectToTheRouter.Text = "Соединяться с роутером";
            this.cbConnectToTheRouter.UseVisualStyleBackColor = true;
            this.cbConnectToTheRouter.CheckedChanged += new System.EventHandler(this.cbConnectToTheRouter_CheckedChanged);
            // 
            // btnSaveWiFiSettings
            // 
            this.btnSaveWiFiSettings.Enabled = false;
            this.btnSaveWiFiSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveWiFiSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveWiFiSettings.Location = new System.Drawing.Point(529, 124);
            this.btnSaveWiFiSettings.Name = "btnSaveWiFiSettings";
            this.btnSaveWiFiSettings.Size = new System.Drawing.Size(138, 38);
            this.btnSaveWiFiSettings.TabIndex = 12;
            this.btnSaveWiFiSettings.Text = "Записать настройки";
            this.btnSaveWiFiSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveWiFiSettings, "Записать настройки в контроллер");
            this.btnSaveWiFiSettings.UseVisualStyleBackColor = true;
            this.btnSaveWiFiSettings.Click += new System.EventHandler(this.btnSaveWiFiSettings_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbStationPassword);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.tbStationID);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Location = new System.Drawing.Point(284, 13);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox5.Size = new System.Drawing.Size(244, 97);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Точка доступа";
            // 
            // tbStationPassword
            // 
            this.tbStationPassword.Location = new System.Drawing.Point(116, 46);
            this.tbStationPassword.Name = "tbStationPassword";
            this.tbStationPassword.Size = new System.Drawing.Size(115, 20);
            this.tbStationPassword.TabIndex = 14;
            this.tbStationPassword.TextChanged += new System.EventHandler(this.WiFiSettingsTextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 49);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 13);
            this.label25.TabIndex = 13;
            this.label25.Text = "Пароль:";
            // 
            // tbStationID
            // 
            this.tbStationID.Location = new System.Drawing.Point(116, 20);
            this.tbStationID.Name = "tbStationID";
            this.tbStationID.Size = new System.Drawing.Size(115, 20);
            this.tbStationID.TabIndex = 12;
            this.tbStationID.TextChanged += new System.EventHandler(this.WiFiSettingsTextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(13, 23);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 13);
            this.label26.TabIndex = 5;
            this.label26.Text = "Название:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tbRouterPassword);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.tbRouterID);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Location = new System.Drawing.Point(13, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox4.Size = new System.Drawing.Size(244, 97);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Соединение с роутером";
            // 
            // tbRouterPassword
            // 
            this.tbRouterPassword.Location = new System.Drawing.Point(116, 46);
            this.tbRouterPassword.Name = "tbRouterPassword";
            this.tbRouterPassword.Size = new System.Drawing.Size(115, 20);
            this.tbRouterPassword.TabIndex = 14;
            this.tbRouterPassword.TextChanged += new System.EventHandler(this.WiFiSettingsTextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 49);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 13);
            this.label23.TabIndex = 13;
            this.label23.Text = "Пароль:";
            // 
            // tbRouterID
            // 
            this.tbRouterID.Location = new System.Drawing.Point(116, 20);
            this.tbRouterID.Name = "tbRouterID";
            this.tbRouterID.Size = new System.Drawing.Size(115, 20);
            this.tbRouterID.TabIndex = 12;
            this.tbRouterID.TextChanged += new System.EventHandler(this.WiFiSettingsTextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Имя сети:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GreenHouseConfig.Properties.Resources.wifibig;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(616, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // tpRules
            // 
            this.tpRules.Controls.Add(this.btnDeleteRule);
            this.tpRules.Controls.Add(this.btnAddRule);
            this.tpRules.Controls.Add(this.lblComputeRulesmemory);
            this.tpRules.Controls.Add(this.btnEditRule);
            this.tpRules.Controls.Add(this.groupBox6);
            this.tpRules.Controls.Add(this.btnSaveRules);
            this.tpRules.Controls.Add(this.btnLoadRules);
            this.tpRules.ImageIndex = 8;
            this.tpRules.Location = new System.Drawing.Point(4, 23);
            this.tpRules.Name = "tpRules";
            this.tpRules.Padding = new System.Windows.Forms.Padding(10);
            this.tpRules.Size = new System.Drawing.Size(677, 175);
            this.tpRules.TabIndex = 7;
            this.tpRules.Text = "Правила";
            this.tpRules.UseVisualStyleBackColor = true;
            // 
            // btnDeleteRule
            // 
            this.btnDeleteRule.Enabled = false;
            this.btnDeleteRule.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteRule.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteRule.Location = new System.Drawing.Point(490, 59);
            this.btnDeleteRule.Name = "btnDeleteRule";
            this.btnDeleteRule.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.btnDeleteRule.Size = new System.Drawing.Size(86, 38);
            this.btnDeleteRule.TabIndex = 18;
            this.btnDeleteRule.Text = "Удалить";
            this.btnDeleteRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnDeleteRule, "Удалить выбранное правило");
            this.btnDeleteRule.UseVisualStyleBackColor = true;
            this.btnDeleteRule.Click += new System.EventHandler(this.btnDeleteRule_Click);
            // 
            // btnAddRule
            // 
            this.btnAddRule.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddRule.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddRule.Location = new System.Drawing.Point(581, 17);
            this.btnAddRule.Name = "btnAddRule";
            this.btnAddRule.Size = new System.Drawing.Size(86, 38);
            this.btnAddRule.TabIndex = 17;
            this.btnAddRule.Text = "Добавить";
            this.btnAddRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddRule, "Добавить новое правило");
            this.btnAddRule.UseVisualStyleBackColor = true;
            this.btnAddRule.Click += new System.EventHandler(this.btnAddRule_Click);
            // 
            // lblComputeRulesmemory
            // 
            this.lblComputeRulesmemory.Location = new System.Drawing.Point(490, 101);
            this.lblComputeRulesmemory.Name = "lblComputeRulesmemory";
            this.lblComputeRulesmemory.Size = new System.Drawing.Size(177, 13);
            this.lblComputeRulesmemory.TabIndex = 16;
            this.lblComputeRulesmemory.TabStop = true;
            this.lblComputeRulesmemory.Text = "Расход памяти";
            this.lblComputeRulesmemory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblComputeRulesmemory.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblComputeRulesmemory_LinkClicked);
            // 
            // btnEditRule
            // 
            this.btnEditRule.Enabled = false;
            this.btnEditRule.Image = global::GreenHouseConfig.Properties.Resources.edit_rule;
            this.btnEditRule.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditRule.Location = new System.Drawing.Point(490, 17);
            this.btnEditRule.Name = "btnEditRule";
            this.btnEditRule.Size = new System.Drawing.Size(86, 38);
            this.btnEditRule.TabIndex = 15;
            this.btnEditRule.Text = "Изменить";
            this.btnEditRule.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnEditRule, "Изменить выбранное правило");
            this.btnEditRule.UseVisualStyleBackColor = true;
            this.btnEditRule.Click += new System.EventHandler(this.btnEditRule_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lblRuleStr);
            this.groupBox6.Controls.Add(this.lvRulesList);
            this.groupBox6.Location = new System.Drawing.Point(13, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox6.Size = new System.Drawing.Size(470, 149);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Список правил";
            // 
            // lblRuleStr
            // 
            this.lblRuleStr.AutoSize = true;
            this.lblRuleStr.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblRuleStr.Location = new System.Drawing.Point(10, 126);
            this.lblRuleStr.Name = "lblRuleStr";
            this.lblRuleStr.Size = new System.Drawing.Size(10, 13);
            this.lblRuleStr.TabIndex = 1;
            this.lblRuleStr.Text = " ";
            // 
            // lvRulesList
            // 
            this.lvRulesList.CheckBoxes = true;
            this.lvRulesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader4});
            this.lvRulesList.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvRulesList.FullRowSelect = true;
            this.lvRulesList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvRulesList.HideSelection = false;
            this.lvRulesList.Location = new System.Drawing.Point(10, 23);
            this.lvRulesList.MultiSelect = false;
            this.lvRulesList.Name = "lvRulesList";
            this.lvRulesList.ShowItemToolTips = true;
            this.lvRulesList.Size = new System.Drawing.Size(450, 97);
            this.lvRulesList.TabIndex = 0;
            this.lvRulesList.UseCompatibleStateImageBehavior = false;
            this.lvRulesList.View = System.Windows.Forms.View.Details;
            this.lvRulesList.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.lvRulesList_ItemChecked);
            this.lvRulesList.SelectedIndexChanged += new System.EventHandler(this.lvRulesList_SelectedIndexChanged);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "За чем следим";
            this.columnHeader5.Width = 200;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Что делаем";
            this.columnHeader6.Width = 140;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Служебное?";
            this.columnHeader4.Width = 80;
            // 
            // btnSaveRules
            // 
            this.btnSaveRules.Enabled = false;
            this.btnSaveRules.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveRules.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveRules.Location = new System.Drawing.Point(490, 124);
            this.btnSaveRules.Name = "btnSaveRules";
            this.btnSaveRules.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSaveRules.Size = new System.Drawing.Size(177, 38);
            this.btnSaveRules.TabIndex = 13;
            this.btnSaveRules.Text = "Сохранить в контроллер";
            this.btnSaveRules.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveRules, "Сохранить правила в контроллер");
            this.btnSaveRules.UseVisualStyleBackColor = true;
            this.btnSaveRules.Click += new System.EventHandler(this.btnSaveRules_Click);
            // 
            // btnLoadRules
            // 
            this.btnLoadRules.Enabled = false;
            this.btnLoadRules.Image = global::GreenHouseConfig.Properties.Resources.load_rules;
            this.btnLoadRules.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadRules.Location = new System.Drawing.Point(581, 59);
            this.btnLoadRules.Name = "btnLoadRules";
            this.btnLoadRules.Size = new System.Drawing.Size(86, 38);
            this.btnLoadRules.TabIndex = 8;
            this.btnLoadRules.Text = "Загрузить";
            this.btnLoadRules.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnLoadRules, "Загрузить правила из контроллера");
            this.btnLoadRules.UseVisualStyleBackColor = true;
            this.btnLoadRules.Click += new System.EventHandler(this.btnLoadRules_Click);
            // 
            // tpLog
            // 
            this.tpLog.Controls.Add(this.lblCurrentLogLine);
            this.tpLog.Controls.Add(this.lblCurrentLogFileName);
            this.tpLog.Controls.Add(this.pbLogsProgress);
            this.tpLog.Controls.Add(this.label28);
            this.tpLog.Controls.Add(this.groupBox7);
            this.tpLog.Controls.Add(this.btnLoadLogs);
            this.tpLog.Controls.Add(this.btnSelectFolder);
            this.tpLog.Controls.Add(this.tbLogsDirectory);
            this.tpLog.Controls.Add(this.label27);
            this.tpLog.ImageIndex = 2;
            this.tpLog.Location = new System.Drawing.Point(4, 23);
            this.tpLog.Name = "tpLog";
            this.tpLog.Padding = new System.Windows.Forms.Padding(10);
            this.tpLog.Size = new System.Drawing.Size(677, 175);
            this.tpLog.TabIndex = 8;
            this.tpLog.Text = "Логи";
            this.tpLog.UseVisualStyleBackColor = true;
            // 
            // lblCurrentLogLine
            // 
            this.lblCurrentLogLine.AutoSize = true;
            this.lblCurrentLogLine.Location = new System.Drawing.Point(171, 122);
            this.lblCurrentLogLine.Name = "lblCurrentLogLine";
            this.lblCurrentLogLine.Size = new System.Drawing.Size(34, 13);
            this.lblCurrentLogLine.TabIndex = 14;
            this.lblCurrentLogLine.Text = "         ";
            // 
            // lblCurrentLogFileName
            // 
            this.lblCurrentLogFileName.AutoSize = true;
            this.lblCurrentLogFileName.Location = new System.Drawing.Point(171, 101);
            this.lblCurrentLogFileName.Name = "lblCurrentLogFileName";
            this.lblCurrentLogFileName.Size = new System.Drawing.Size(34, 13);
            this.lblCurrentLogFileName.TabIndex = 13;
            this.lblCurrentLogFileName.Text = "         ";
            // 
            // pbLogsProgress
            // 
            this.pbLogsProgress.Location = new System.Drawing.Point(174, 72);
            this.pbLogsProgress.Name = "pbLogsProgress";
            this.pbLogsProgress.Size = new System.Drawing.Size(493, 23);
            this.pbLogsProgress.Step = 1;
            this.pbLogsProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbLogsProgress.TabIndex = 12;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(171, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 13);
            this.label28.TabIndex = 11;
            this.label28.Text = "Прогресс:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbMonth);
            this.groupBox7.Controls.Add(this.rbWeek);
            this.groupBox7.Controls.Add(this.rbDay);
            this.groupBox7.Location = new System.Drawing.Point(13, 52);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox7.Size = new System.Drawing.Size(152, 110);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Интервал";
            // 
            // rbMonth
            // 
            this.rbMonth.AutoSize = true;
            this.rbMonth.Location = new System.Drawing.Point(13, 70);
            this.rbMonth.Name = "rbMonth";
            this.rbMonth.Size = new System.Drawing.Size(58, 17);
            this.rbMonth.TabIndex = 14;
            this.rbMonth.Text = "Месяц";
            this.rbMonth.UseVisualStyleBackColor = true;
            // 
            // rbWeek
            // 
            this.rbWeek.AutoSize = true;
            this.rbWeek.Location = new System.Drawing.Point(13, 49);
            this.rbWeek.Name = "rbWeek";
            this.rbWeek.Size = new System.Drawing.Size(63, 17);
            this.rbWeek.TabIndex = 13;
            this.rbWeek.Text = "Неделя";
            this.rbWeek.UseVisualStyleBackColor = true;
            // 
            // rbDay
            // 
            this.rbDay.AutoSize = true;
            this.rbDay.Checked = true;
            this.rbDay.Location = new System.Drawing.Point(13, 26);
            this.rbDay.Name = "rbDay";
            this.rbDay.Size = new System.Drawing.Size(52, 17);
            this.rbDay.TabIndex = 12;
            this.rbDay.TabStop = true;
            this.rbDay.Text = "День";
            this.rbDay.UseVisualStyleBackColor = true;
            // 
            // btnLoadLogs
            // 
            this.btnLoadLogs.Enabled = false;
            this.btnLoadLogs.Image = global::GreenHouseConfig.Properties.Resources.load_rules;
            this.btnLoadLogs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadLogs.Location = new System.Drawing.Point(549, 124);
            this.btnLoadLogs.Name = "btnLoadLogs";
            this.btnLoadLogs.Padding = new System.Windows.Forms.Padding(4, 0, 0, 0);
            this.btnLoadLogs.Size = new System.Drawing.Size(118, 38);
            this.btnLoadLogs.TabIndex = 9;
            this.btnLoadLogs.Text = "Загрузить логи";
            this.btnLoadLogs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnLoadLogs, "Загрузить правила из контроллера");
            this.btnLoadLogs.UseVisualStyleBackColor = true;
            this.btnLoadLogs.Click += new System.EventHandler(this.btnLoadLogs_Click);
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.ImageIndex = 9;
            this.btnSelectFolder.ImageList = this.imglTabImages;
            this.btnSelectFolder.Location = new System.Drawing.Point(642, 23);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(25, 23);
            this.btnSelectFolder.TabIndex = 2;
            this.ttDefault.SetToolTip(this.btnSelectFolder, "Выбрать папку для логов");
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.btnSelectFolder_Click);
            // 
            // tbLogsDirectory
            // 
            this.tbLogsDirectory.Location = new System.Drawing.Point(11, 26);
            this.tbLogsDirectory.Name = "tbLogsDirectory";
            this.tbLogsDirectory.ReadOnly = true;
            this.tbLogsDirectory.Size = new System.Drawing.Size(625, 20);
            this.tbLogsDirectory.TabIndex = 1;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(8, 10);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(141, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Текущая папка для логов:";
            // 
            // tpWaterFlow
            // 
            this.tpWaterFlow.Controls.Add(this.btnResetWaterflowData);
            this.tpWaterFlow.Controls.Add(this.btnSaveFlowSettings);
            this.tpWaterFlow.Controls.Add(this.groupBox9);
            this.tpWaterFlow.Controls.Add(this.groupBox8);
            this.tpWaterFlow.ImageIndex = 10;
            this.tpWaterFlow.Location = new System.Drawing.Point(4, 23);
            this.tpWaterFlow.Name = "tpWaterFlow";
            this.tpWaterFlow.Padding = new System.Windows.Forms.Padding(10);
            this.tpWaterFlow.Size = new System.Drawing.Size(677, 175);
            this.tpWaterFlow.TabIndex = 9;
            this.tpWaterFlow.Text = "Расход";
            this.tpWaterFlow.UseVisualStyleBackColor = true;
            // 
            // btnResetWaterflowData
            // 
            this.btnResetWaterflowData.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnResetWaterflowData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResetWaterflowData.Location = new System.Drawing.Point(561, 81);
            this.btnResetWaterflowData.Name = "btnResetWaterflowData";
            this.btnResetWaterflowData.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnResetWaterflowData.Size = new System.Drawing.Size(103, 38);
            this.btnResetWaterflowData.TabIndex = 15;
            this.btnResetWaterflowData.Text = "Сбросить";
            this.btnResetWaterflowData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnResetWaterflowData, "Сбросить общий расход в 0");
            this.btnResetWaterflowData.UseVisualStyleBackColor = true;
            this.btnResetWaterflowData.Click += new System.EventHandler(this.btnResetWaterflowData_Click);
            // 
            // btnSaveFlowSettings
            // 
            this.btnSaveFlowSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveFlowSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveFlowSettings.Location = new System.Drawing.Point(561, 124);
            this.btnSaveFlowSettings.Name = "btnSaveFlowSettings";
            this.btnSaveFlowSettings.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSaveFlowSettings.Size = new System.Drawing.Size(103, 38);
            this.btnSaveFlowSettings.TabIndex = 14;
            this.btnSaveFlowSettings.Text = "Сохранить";
            this.btnSaveFlowSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveFlowSettings, "Сохранить факторы калибровки в контроллер");
            this.btnSaveFlowSettings.UseVisualStyleBackColor = true;
            this.btnSaveFlowSettings.Click += new System.EventHandler(this.btnSaveFlowSettings_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.nudFlowCalibration2);
            this.groupBox9.Controls.Add(this.pictureBox5);
            this.groupBox9.Controls.Add(this.label29);
            this.groupBox9.Controls.Add(this.lblFlowIncremental2);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.lblFlowInstant2);
            this.groupBox9.Location = new System.Drawing.Point(285, 13);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox9.Size = new System.Drawing.Size(260, 149);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Второй расходомер";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(13, 118);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(167, 23);
            this.label36.TabIndex = 9;
            this.label36.Text = "Фактор калибровки:";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // nudFlowCalibration2
            // 
            this.nudFlowCalibration2.Location = new System.Drawing.Point(186, 116);
            this.nudFlowCalibration2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFlowCalibration2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlowCalibration2.Name = "nudFlowCalibration2";
            this.nudFlowCalibration2.Size = new System.Drawing.Size(61, 20);
            this.nudFlowCalibration2.TabIndex = 8;
            this.nudFlowCalibration2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(154, 8);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(96, 96);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(13, 68);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 13);
            this.label29.TabIndex = 5;
            this.label29.Text = "Общий расход:";
            // 
            // lblFlowIncremental2
            // 
            this.lblFlowIncremental2.AutoSize = true;
            this.lblFlowIncremental2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowIncremental2.Location = new System.Drawing.Point(13, 84);
            this.lblFlowIncremental2.Name = "lblFlowIncremental2";
            this.lblFlowIncremental2.Size = new System.Drawing.Size(126, 20);
            this.lblFlowIncremental2.TabIndex = 4;
            this.lblFlowIncremental2.Text = "<нет данных>";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(112, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Мгновенный расход:";
            // 
            // lblFlowInstant2
            // 
            this.lblFlowInstant2.AutoSize = true;
            this.lblFlowInstant2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowInstant2.Location = new System.Drawing.Point(13, 39);
            this.lblFlowInstant2.Name = "lblFlowInstant2";
            this.lblFlowInstant2.Size = new System.Drawing.Size(126, 20);
            this.lblFlowInstant2.TabIndex = 2;
            this.lblFlowInstant2.Text = "<нет данных>";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.nudFlowCalibration1);
            this.groupBox8.Controls.Add(this.pictureBox2);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.lblFlowIncremental1);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.lblFlowInstant1);
            this.groupBox8.Location = new System.Drawing.Point(13, 13);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox8.Size = new System.Drawing.Size(260, 149);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Первый расходомер";
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(13, 118);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(167, 23);
            this.label37.TabIndex = 10;
            this.label37.Text = "Фактор калибровки:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // nudFlowCalibration1
            // 
            this.nudFlowCalibration1.Location = new System.Drawing.Point(186, 116);
            this.nudFlowCalibration1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFlowCalibration1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudFlowCalibration1.Name = "nudFlowCalibration1";
            this.nudFlowCalibration1.Size = new System.Drawing.Size(61, 20);
            this.nudFlowCalibration1.TabIndex = 9;
            this.nudFlowCalibration1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(154, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(96, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(13, 68);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(83, 13);
            this.label31.TabIndex = 5;
            this.label31.Text = "Общий расход:";
            // 
            // lblFlowIncremental1
            // 
            this.lblFlowIncremental1.AutoSize = true;
            this.lblFlowIncremental1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowIncremental1.Location = new System.Drawing.Point(13, 84);
            this.lblFlowIncremental1.Name = "lblFlowIncremental1";
            this.lblFlowIncremental1.Size = new System.Drawing.Size(126, 20);
            this.lblFlowIncremental1.TabIndex = 4;
            this.lblFlowIncremental1.Text = "<нет данных>";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(13, 23);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(112, 13);
            this.label30.TabIndex = 3;
            this.label30.Text = "Мгновенный расход:";
            // 
            // lblFlowInstant1
            // 
            this.lblFlowInstant1.AutoSize = true;
            this.lblFlowInstant1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFlowInstant1.Location = new System.Drawing.Point(13, 39);
            this.lblFlowInstant1.Name = "lblFlowInstant1";
            this.lblFlowInstant1.Size = new System.Drawing.Size(126, 20);
            this.lblFlowInstant1.TabIndex = 2;
            this.lblFlowInstant1.Text = "<нет данных>";
            // 
            // tpMultipleCommands
            // 
            this.tpMultipleCommands.Controls.Add(this.btnClearCCCommands);
            this.tpMultipleCommands.Controls.Add(this.btnDeleteCompositeCommand);
            this.tpMultipleCommands.Controls.Add(this.btnAddCompositeCommand);
            this.tpMultipleCommands.Controls.Add(this.btnEditCompositeCommand);
            this.tpMultipleCommands.Controls.Add(this.groupBox10);
            this.tpMultipleCommands.Controls.Add(this.btnUploadCompositeCommands);
            this.tpMultipleCommands.ImageIndex = 11;
            this.tpMultipleCommands.Location = new System.Drawing.Point(4, 23);
            this.tpMultipleCommands.Name = "tpMultipleCommands";
            this.tpMultipleCommands.Padding = new System.Windows.Forms.Padding(10);
            this.tpMultipleCommands.Size = new System.Drawing.Size(677, 175);
            this.tpMultipleCommands.TabIndex = 10;
            this.tpMultipleCommands.Text = "Составные команды";
            this.tpMultipleCommands.UseVisualStyleBackColor = true;
            // 
            // btnClearCCCommands
            // 
            this.btnClearCCCommands.Enabled = false;
            this.btnClearCCCommands.Image = global::GreenHouseConfig.Properties.Resources.eraser;
            this.btnClearCCCommands.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClearCCCommands.Location = new System.Drawing.Point(581, 59);
            this.btnClearCCCommands.Name = "btnClearCCCommands";
            this.btnClearCCCommands.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.btnClearCCCommands.Size = new System.Drawing.Size(86, 38);
            this.btnClearCCCommands.TabIndex = 25;
            this.btnClearCCCommands.Text = "Очистить";
            this.btnClearCCCommands.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnClearCCCommands, "Очистить список составных команд в контроллере");
            this.btnClearCCCommands.UseVisualStyleBackColor = true;
            this.btnClearCCCommands.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDeleteCompositeCommand
            // 
            this.btnDeleteCompositeCommand.Enabled = false;
            this.btnDeleteCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteCompositeCommand.Location = new System.Drawing.Point(490, 59);
            this.btnDeleteCompositeCommand.Name = "btnDeleteCompositeCommand";
            this.btnDeleteCompositeCommand.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.btnDeleteCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnDeleteCompositeCommand.TabIndex = 24;
            this.btnDeleteCompositeCommand.Text = "Удалить";
            this.btnDeleteCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnDeleteCompositeCommand, "Удалить выбранный список");
            this.btnDeleteCompositeCommand.UseVisualStyleBackColor = true;
            this.btnDeleteCompositeCommand.Click += new System.EventHandler(this.btnDeleteCompositeCommand_Click);
            // 
            // btnAddCompositeCommand
            // 
            this.btnAddCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddCompositeCommand.Location = new System.Drawing.Point(581, 17);
            this.btnAddCompositeCommand.Name = "btnAddCompositeCommand";
            this.btnAddCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnAddCompositeCommand.TabIndex = 23;
            this.btnAddCompositeCommand.Text = "Добавить";
            this.btnAddCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnAddCompositeCommand, "Добавить новый список");
            this.btnAddCompositeCommand.UseVisualStyleBackColor = true;
            this.btnAddCompositeCommand.Click += new System.EventHandler(this.btnAddCompositeCommand_Click);
            // 
            // btnEditCompositeCommand
            // 
            this.btnEditCompositeCommand.Enabled = false;
            this.btnEditCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.edit_rule;
            this.btnEditCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditCompositeCommand.Location = new System.Drawing.Point(490, 17);
            this.btnEditCompositeCommand.Name = "btnEditCompositeCommand";
            this.btnEditCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnEditCompositeCommand.TabIndex = 22;
            this.btnEditCompositeCommand.Text = "Изменить";
            this.btnEditCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnEditCompositeCommand, "Изменить выбранный список");
            this.btnEditCompositeCommand.UseVisualStyleBackColor = true;
            this.btnEditCompositeCommand.Click += new System.EventHandler(this.btnEditCompositeCommand_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lvCompositeCommandsList);
            this.groupBox10.Location = new System.Drawing.Point(13, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox10.Size = new System.Drawing.Size(470, 149);
            this.groupBox10.TabIndex = 21;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Список составных команд";
            // 
            // lvCompositeCommandsList
            // 
            this.lvCompositeCommandsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8});
            this.lvCompositeCommandsList.Dock = System.Windows.Forms.DockStyle.Top;
            this.lvCompositeCommandsList.FullRowSelect = true;
            this.lvCompositeCommandsList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvCompositeCommandsList.HideSelection = false;
            this.lvCompositeCommandsList.Location = new System.Drawing.Point(10, 23);
            this.lvCompositeCommandsList.MultiSelect = false;
            this.lvCompositeCommandsList.Name = "lvCompositeCommandsList";
            this.lvCompositeCommandsList.ShowItemToolTips = true;
            this.lvCompositeCommandsList.Size = new System.Drawing.Size(450, 113);
            this.lvCompositeCommandsList.TabIndex = 0;
            this.lvCompositeCommandsList.UseCompatibleStateImageBehavior = false;
            this.lvCompositeCommandsList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "#";
            this.columnHeader7.Width = 70;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Имя";
            this.columnHeader8.Width = 350;
            // 
            // btnUploadCompositeCommands
            // 
            this.btnUploadCompositeCommands.Enabled = false;
            this.btnUploadCompositeCommands.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnUploadCompositeCommands.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUploadCompositeCommands.Location = new System.Drawing.Point(490, 124);
            this.btnUploadCompositeCommands.Name = "btnUploadCompositeCommands";
            this.btnUploadCompositeCommands.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnUploadCompositeCommands.Size = new System.Drawing.Size(177, 38);
            this.btnUploadCompositeCommands.TabIndex = 20;
            this.btnUploadCompositeCommands.Text = "Сохранить в контроллер";
            this.btnUploadCompositeCommands.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnUploadCompositeCommands, "Сохранить составные команды в контроллер");
            this.btnUploadCompositeCommands.UseVisualStyleBackColor = true;
            this.btnUploadCompositeCommands.Click += new System.EventHandler(this.btnUploadCompositeCommands_Click);
            // 
            // tpDeltas
            // 
            this.tpDeltas.Controls.Add(this.label32);
            this.tpDeltas.Controls.Add(this.groupBox11);
            this.tpDeltas.ImageIndex = 12;
            this.tpDeltas.Location = new System.Drawing.Point(4, 23);
            this.tpDeltas.Name = "tpDeltas";
            this.tpDeltas.Padding = new System.Windows.Forms.Padding(10);
            this.tpDeltas.Size = new System.Drawing.Size(677, 175);
            this.tpDeltas.TabIndex = 11;
            this.tpDeltas.Text = "Дельты";
            this.tpDeltas.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label32.Location = new System.Drawing.Point(367, 22);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(297, 140);
            this.label32.TabIndex = 2;
            this.label32.Text = resources.GetString("label32.Text");
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lvDeltasList);
            this.groupBox11.Location = new System.Drawing.Point(13, 13);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox11.Size = new System.Drawing.Size(348, 149);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Показания дельт";
            // 
            // lvDeltasList
            // 
            this.lvDeltasList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.lvDeltasList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvDeltasList.FullRowSelect = true;
            this.lvDeltasList.GridLines = true;
            this.lvDeltasList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvDeltasList.LabelWrap = false;
            this.lvDeltasList.Location = new System.Drawing.Point(10, 23);
            this.lvDeltasList.MultiSelect = false;
            this.lvDeltasList.Name = "lvDeltasList";
            this.lvDeltasList.Size = new System.Drawing.Size(328, 116);
            this.lvDeltasList.TabIndex = 0;
            this.lvDeltasList.UseCompatibleStateImageBehavior = false;
            this.lvDeltasList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "#";
            this.columnHeader9.Width = 40;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Тип";
            this.columnHeader10.Width = 140;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Показание";
            this.columnHeader11.Width = 120;
            // 
            // tpSoilMoisture
            // 
            this.tpSoilMoisture.Controls.Add(this.label35);
            this.tpSoilMoisture.Controls.Add(this.groupBox12);
            this.tpSoilMoisture.ImageIndex = 13;
            this.tpSoilMoisture.Location = new System.Drawing.Point(4, 23);
            this.tpSoilMoisture.Name = "tpSoilMoisture";
            this.tpSoilMoisture.Padding = new System.Windows.Forms.Padding(10);
            this.tpSoilMoisture.Size = new System.Drawing.Size(677, 175);
            this.tpSoilMoisture.TabIndex = 12;
            this.tpSoilMoisture.Text = "Влажность почвы";
            this.tpSoilMoisture.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label35.Location = new System.Drawing.Point(367, 22);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(297, 140);
            this.label35.TabIndex = 4;
            this.label35.Text = "На данной вкладке отображаются показания с датчиков влажности почвы любых типов, " +
    "поддерживаемых системой.";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.lvSoilMoistureSensorsData);
            this.groupBox12.Location = new System.Drawing.Point(13, 13);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox12.Size = new System.Drawing.Size(348, 149);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Показания датчиков влажности почвы";
            // 
            // lvSoilMoistureSensorsData
            // 
            this.lvSoilMoistureSensorsData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader14});
            this.lvSoilMoistureSensorsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSoilMoistureSensorsData.FullRowSelect = true;
            this.lvSoilMoistureSensorsData.GridLines = true;
            this.lvSoilMoistureSensorsData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvSoilMoistureSensorsData.LabelWrap = false;
            this.lvSoilMoistureSensorsData.Location = new System.Drawing.Point(10, 23);
            this.lvSoilMoistureSensorsData.MultiSelect = false;
            this.lvSoilMoistureSensorsData.Name = "lvSoilMoistureSensorsData";
            this.lvSoilMoistureSensorsData.Size = new System.Drawing.Size(328, 116);
            this.lvSoilMoistureSensorsData.TabIndex = 0;
            this.lvSoilMoistureSensorsData.UseCompatibleStateImageBehavior = false;
            this.lvSoilMoistureSensorsData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "#";
            this.columnHeader12.Width = 40;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Влажность почвы";
            this.columnHeader14.Width = 250;
            // 
            // tpPH
            // 
            this.tpPH.Controls.Add(this.lvPHStatus);
            this.tpPH.Controls.Add(this.btnPHControl);
            this.tpPH.Controls.Add(this.groupBox14);
            this.tpPH.Controls.Add(this.groupBox13);
            this.tpPH.Controls.Add(this.btnSavePHSettings);
            this.tpPH.Controls.Add(this.lvPH);
            this.tpPH.ImageIndex = 14;
            this.tpPH.Location = new System.Drawing.Point(4, 23);
            this.tpPH.Name = "tpPH";
            this.tpPH.Padding = new System.Windows.Forms.Padding(10);
            this.tpPH.Size = new System.Drawing.Size(677, 175);
            this.tpPH.TabIndex = 13;
            this.tpPH.Text = "PH";
            this.tpPH.UseVisualStyleBackColor = true;
            // 
            // lvPHStatus
            // 
            this.lvPHStatus.GridLines = true;
            this.lvPHStatus.HideSelection = false;
            this.lvPHStatus.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4});
            this.lvPHStatus.Location = new System.Drawing.Point(13, 124);
            this.lvPHStatus.MultiSelect = false;
            this.lvPHStatus.Name = "lvPHStatus";
            this.lvPHStatus.Scrollable = false;
            this.lvPHStatus.Size = new System.Drawing.Size(433, 38);
            this.lvPHStatus.TabIndex = 48;
            this.lvPHStatus.UseCompatibleStateImageBehavior = false;
            this.lvPHStatus.View = System.Windows.Forms.View.SmallIcon;
            // 
            // btnPHControl
            // 
            this.btnPHControl.Image = global::GreenHouseConfig.Properties.Resources.applications_systemg;
            this.btnPHControl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPHControl.Location = new System.Drawing.Point(452, 124);
            this.btnPHControl.Name = "btnPHControl";
            this.btnPHControl.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnPHControl.Size = new System.Drawing.Size(103, 38);
            this.btnPHControl.TabIndex = 47;
            this.btnPHControl.Text = "Контроль";
            this.btnPHControl.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnPHControl, "Настроить параметры контроля pH");
            this.btnPHControl.UseVisualStyleBackColor = true;
            this.btnPHControl.Click += new System.EventHandler(this.btnPHControl_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label44);
            this.groupBox14.Controls.Add(this.nudPHCalibrationTemperature);
            this.groupBox14.Controls.Add(this.label42);
            this.groupBox14.Controls.Add(this.nudPHTempSensorIndex);
            this.groupBox14.Controls.Add(this.label41);
            this.groupBox14.Controls.Add(this.nudPHCalibration);
            this.groupBox14.Location = new System.Drawing.Point(464, 17);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(200, 100);
            this.groupBox14.TabIndex = 45;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Настройки";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(103, 13);
            this.label44.TabIndex = 42;
            this.label44.Text = "Темп. калибровки:";
            // 
            // nudPHCalibrationTemperature
            // 
            this.nudPHCalibrationTemperature.DecimalPlaces = 2;
            this.nudPHCalibrationTemperature.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudPHCalibrationTemperature.Location = new System.Drawing.Point(133, 69);
            this.nudPHCalibrationTemperature.Name = "nudPHCalibrationTemperature";
            this.nudPHCalibrationTemperature.Size = new System.Drawing.Size(61, 20);
            this.nudPHCalibrationTemperature.TabIndex = 41;
            this.nudPHCalibrationTemperature.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 47);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(117, 13);
            this.label42.TabIndex = 40;
            this.label42.Text = "Датчик температуры:";
            // 
            // nudPHTempSensorIndex
            // 
            this.nudPHTempSensorIndex.Location = new System.Drawing.Point(133, 45);
            this.nudPHTempSensorIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nudPHTempSensorIndex.Name = "nudPHTempSensorIndex";
            this.nudPHTempSensorIndex.Size = new System.Drawing.Size(61, 20);
            this.nudPHTempSensorIndex.TabIndex = 39;
            this.nudPHTempSensorIndex.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(6, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(109, 13);
            this.label41.TabIndex = 38;
            this.label41.Text = "Поправочное число:";
            // 
            // nudPHCalibration
            // 
            this.nudPHCalibration.Location = new System.Drawing.Point(133, 21);
            this.nudPHCalibration.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudPHCalibration.Name = "nudPHCalibration";
            this.nudPHCalibration.Size = new System.Drawing.Size(61, 20);
            this.nudPHCalibration.TabIndex = 37;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label40);
            this.groupBox13.Controls.Add(this.label39);
            this.groupBox13.Controls.Add(this.label38);
            this.groupBox13.Controls.Add(this.nudPHVoltage10);
            this.groupBox13.Controls.Add(this.nudPHVoltage7);
            this.groupBox13.Controls.Add(this.nudPHVoltage4);
            this.groupBox13.Location = new System.Drawing.Point(259, 17);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(200, 100);
            this.groupBox13.TabIndex = 44;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Калибровочные растворы";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 73);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(106, 13);
            this.label40.TabIndex = 47;
            this.label40.Text = "10 pH, милливольт:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 47);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(100, 13);
            this.label39.TabIndex = 46;
            this.label39.Text = "7 pH, милливольт:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 21);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(100, 13);
            this.label38.TabIndex = 45;
            this.label38.Text = "4 pH, милливольт:";
            // 
            // nudPHVoltage10
            // 
            this.nudPHVoltage10.Location = new System.Drawing.Point(133, 71);
            this.nudPHVoltage10.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage10.Name = "nudPHVoltage10";
            this.nudPHVoltage10.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage10.TabIndex = 44;
            // 
            // nudPHVoltage7
            // 
            this.nudPHVoltage7.Location = new System.Drawing.Point(133, 45);
            this.nudPHVoltage7.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage7.Name = "nudPHVoltage7";
            this.nudPHVoltage7.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage7.TabIndex = 42;
            // 
            // nudPHVoltage4
            // 
            this.nudPHVoltage4.Location = new System.Drawing.Point(133, 19);
            this.nudPHVoltage4.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.nudPHVoltage4.Name = "nudPHVoltage4";
            this.nudPHVoltage4.Size = new System.Drawing.Size(61, 20);
            this.nudPHVoltage4.TabIndex = 40;
            // 
            // btnSavePHSettings
            // 
            this.btnSavePHSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSavePHSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSavePHSettings.Location = new System.Drawing.Point(561, 124);
            this.btnSavePHSettings.Name = "btnSavePHSettings";
            this.btnSavePHSettings.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSavePHSettings.Size = new System.Drawing.Size(103, 38);
            this.btnSavePHSettings.TabIndex = 38;
            this.btnSavePHSettings.Text = "Сохранить";
            this.btnSavePHSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSavePHSettings, "Сохранить настройки pH в контроллер");
            this.btnSavePHSettings.UseVisualStyleBackColor = true;
            this.btnSavePHSettings.Click += new System.EventHandler(this.btnSavePHSettings_Click);
            // 
            // lvPH
            // 
            this.lvPH.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18});
            this.lvPH.FullRowSelect = true;
            this.lvPH.GridLines = true;
            this.lvPH.HideSelection = false;
            this.lvPH.Location = new System.Drawing.Point(13, 17);
            this.lvPH.MultiSelect = false;
            this.lvPH.Name = "lvPH";
            this.lvPH.ShowItemToolTips = true;
            this.lvPH.Size = new System.Drawing.Size(240, 100);
            this.lvPH.TabIndex = 35;
            this.lvPH.UseCompatibleStateImageBehavior = false;
            this.lvPH.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "#";
            this.columnHeader16.Width = 30;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Показания";
            this.columnHeader17.Width = 90;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Вольтаж";
            this.columnHeader18.Width = 90;
            // 
            // tpIOT
            // 
            this.tpIOT.Controls.Add(this.lbIOTSelectedSensors);
            this.tpIOT.Controls.Add(this.lbIOTAllSensors);
            this.tpIOT.Controls.Add(this.label47);
            this.tpIOT.Controls.Add(this.btnSaveIoTSettings);
            this.tpIOT.Controls.Add(this.tbThingSpeakChannelKey);
            this.tpIOT.Controls.Add(this.label46);
            this.tpIOT.Controls.Add(this.label45);
            this.tpIOT.Controls.Add(this.nudIoTInterval);
            this.tpIOT.Controls.Add(this.label43);
            this.tpIOT.Controls.Add(this.cbThingSpeakEnabled);
            this.tpIOT.ImageIndex = 15;
            this.tpIOT.Location = new System.Drawing.Point(4, 23);
            this.tpIOT.Name = "tpIOT";
            this.tpIOT.Padding = new System.Windows.Forms.Padding(3);
            this.tpIOT.Size = new System.Drawing.Size(677, 175);
            this.tpIOT.TabIndex = 14;
            this.tpIOT.Text = "IoT";
            this.tpIOT.UseVisualStyleBackColor = true;
            // 
            // lbIOTSelectedSensors
            // 
            this.lbIOTSelectedSensors.FormattingEnabled = true;
            this.lbIOTSelectedSensors.Location = new System.Drawing.Point(450, 45);
            this.lbIOTSelectedSensors.Name = "lbIOTSelectedSensors";
            this.lbIOTSelectedSensors.Size = new System.Drawing.Size(210, 108);
            this.lbIOTSelectedSensors.TabIndex = 24;
            this.lbIOTSelectedSensors.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragDrop);
            this.lbIOTSelectedSensors.DragOver += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragOver);
            this.lbIOTSelectedSensors.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbIOTSelectedSensors_MouseDown);
            // 
            // lbIOTAllSensors
            // 
            this.lbIOTAllSensors.FormattingEnabled = true;
            this.lbIOTAllSensors.Location = new System.Drawing.Point(224, 45);
            this.lbIOTAllSensors.Name = "lbIOTAllSensors";
            this.lbIOTAllSensors.Size = new System.Drawing.Size(210, 108);
            this.lbIOTAllSensors.TabIndex = 23;
            this.lbIOTAllSensors.DragDrop += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragDrop);
            this.lbIOTAllSensors.DragOver += new System.Windows.Forms.DragEventHandler(this.lbIOTSelectedSensors_DragOver);
            this.lbIOTAllSensors.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lbIOTSelectedSensors_MouseDown);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(447, 18);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(69, 13);
            this.label47.TabIndex = 22;
            this.label47.Text = "Выбранные:";
            // 
            // btnSaveIoTSettings
            // 
            this.btnSaveIoTSettings.Enabled = false;
            this.btnSaveIoTSettings.Image = global::GreenHouseConfig.Properties.Resources.saveSmall;
            this.btnSaveIoTSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaveIoTSettings.Location = new System.Drawing.Point(11, 120);
            this.btnSaveIoTSettings.Name = "btnSaveIoTSettings";
            this.btnSaveIoTSettings.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSaveIoTSettings.Size = new System.Drawing.Size(202, 38);
            this.btnSaveIoTSettings.TabIndex = 21;
            this.btnSaveIoTSettings.Text = "Сохранить в контроллер";
            this.btnSaveIoTSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ttDefault.SetToolTip(this.btnSaveIoTSettings, "Сохранить составные команды в контроллер");
            this.btnSaveIoTSettings.UseVisualStyleBackColor = true;
            this.btnSaveIoTSettings.Click += new System.EventHandler(this.btnSaveIoTSettings_Click);
            // 
            // tbThingSpeakChannelKey
            // 
            this.tbThingSpeakChannelKey.Location = new System.Drawing.Point(11, 94);
            this.tbThingSpeakChannelKey.MaxLength = 19;
            this.tbThingSpeakChannelKey.Name = "tbThingSpeakChannelKey";
            this.tbThingSpeakChannelKey.Size = new System.Drawing.Size(202, 20);
            this.tbThingSpeakChannelKey.TabIndex = 6;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(8, 78);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(136, 13);
            this.label46.TabIndex = 5;
            this.label46.Text = "Ключ канала ThingSpeak:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(221, 18);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(67, 13);
            this.label45.TabIndex = 3;
            this.label45.Text = "Доступные:";
            // 
            // nudIoTInterval
            // 
            this.nudIoTInterval.Location = new System.Drawing.Point(120, 45);
            this.nudIoTInterval.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudIoTInterval.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudIoTInterval.Name = "nudIoTInterval";
            this.nudIoTInterval.Size = new System.Drawing.Size(93, 20);
            this.nudIoTInterval.TabIndex = 2;
            this.nudIoTInterval.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(8, 47);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(71, 13);
            this.label43.TabIndex = 1;
            this.label43.Text = "Интервал, с:";
            // 
            // cbThingSpeakEnabled
            // 
            this.cbThingSpeakEnabled.AutoSize = true;
            this.cbThingSpeakEnabled.Location = new System.Drawing.Point(8, 18);
            this.cbThingSpeakEnabled.Name = "cbThingSpeakEnabled";
            this.cbThingSpeakEnabled.Size = new System.Drawing.Size(199, 17);
            this.cbThingSpeakEnabled.TabIndex = 0;
            this.cbThingSpeakEnabled.Text = "Отсылать данные на ThingSpeak?";
            this.cbThingSpeakEnabled.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ImageList = this.imglTabImages;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(685, 111);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lvLog);
            this.tabPage1.ImageIndex = 2;
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(677, 84);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Лог";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lvLog
            // 
            this.lvLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.logColumn1,
            this.logColumn2});
            this.lvLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvLog.FullRowSelect = true;
            this.lvLog.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lvLog.LabelWrap = false;
            this.lvLog.Location = new System.Drawing.Point(3, 3);
            this.lvLog.MultiSelect = false;
            this.lvLog.Name = "lvLog";
            this.lvLog.ShowGroups = false;
            this.lvLog.Size = new System.Drawing.Size(671, 78);
            this.lvLog.SmallImageList = this.imglTabImages;
            this.lvLog.TabIndex = 0;
            this.lvLog.UseCompatibleStateImageBehavior = false;
            this.lvLog.View = System.Windows.Forms.View.Details;
            // 
            // logColumn1
            // 
            this.logColumn1.Text = "";
            // 
            // logColumn2
            // 
            this.logColumn2.Text = "";
            // 
            // tmrUptime
            // 
            this.tmrUptime.Enabled = true;
            this.tmrUptime.Interval = 1001;
            this.tmrUptime.Tick += new System.EventHandler(this.tmrUptime_Tick);
            // 
            // tmrFreeRam
            // 
            this.tmrFreeRam.Enabled = true;
            this.tmrFreeRam.Interval = 3007;
            this.tmrFreeRam.Tick += new System.EventHandler(this.tmrFreeRam_Tick);
            // 
            // tmProcessCommandsTimer
            // 
            this.tmProcessCommandsTimer.Enabled = true;
            this.tmProcessCommandsTimer.Interval = 103;
            this.tmProcessCommandsTimer.Tick += new System.EventHandler(this.tmProcessCommandsTimer_Tick);
            // 
            // tmrTicks
            // 
            this.tmrTicks.Interval = 1000;
            this.tmrTicks.Tick += new System.EventHandler(this.tmrTicks_Tick);
            // 
            // tmWaitDataTimer
            // 
            this.tmWaitDataTimer.Tick += new System.EventHandler(this.tmWaitDataTimer_Tick);
            // 
            // tmGetAllTempData
            // 
            this.tmGetAllTempData.Interval = 2000;
            this.tmGetAllTempData.Tick += new System.EventHandler(this.tmGetAllTempData_Tick);
            // 
            // ttPhoneNumberHint
            // 
            this.ttPhoneNumberHint.AutoPopDelay = 8000;
            this.ttPhoneNumberHint.InitialDelay = 500;
            this.ttPhoneNumberHint.IsBalloon = true;
            this.ttPhoneNumberHint.ReshowDelay = 100;
            this.ttPhoneNumberHint.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // ttTempRulesHint
            // 
            this.ttTempRulesHint.AutoPopDelay = 8000;
            this.ttTempRulesHint.InitialDelay = 500;
            this.ttTempRulesHint.IsBalloon = true;
            this.ttTempRulesHint.ReshowDelay = 100;
            this.ttTempRulesHint.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.ttTempRulesHint.ToolTipTitle = "Служебные правила";
            // 
            // lblDriveWaterChannels
            // 
            this.lblDriveWaterChannels.AutoSize = true;
            this.lblDriveWaterChannels.Location = new System.Drawing.Point(377, 146);
            this.lblDriveWaterChannels.Name = "lblDriveWaterChannels";
            this.lblDriveWaterChannels.Size = new System.Drawing.Size(122, 13);
            this.lblDriveWaterChannels.TabIndex = 30;
            this.lblDriveWaterChannels.TabStop = true;
            this.lblDriveWaterChannels.Text = "Управление каналами";
            this.ttDefault.SetToolTip(this.lblDriveWaterChannels, "Посмотреть состояние окон по каналам");
            this.lblDriveWaterChannels.Click += new System.EventHandler(this.lblDriveWaterChannels_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(685, 433);
            this.Controls.Add(this.splitCont);
            this.Controls.Add(this.tbToolBar);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Конфигуратор контроллера теплицы Arduino Mega, v.";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tbToolBar.ResumeLayout(false);
            this.tbToolBar.PerformLayout();
            this.splitCont.Panel1.ResumeLayout(false);
            this.splitCont.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitCont)).EndInit();
            this.splitCont.ResumeLayout(false);
            this.tabCMain.ResumeLayout(false);
            this.tcStatPage.ResumeLayout(false);
            this.tcStatPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSetWorkMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWindowPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowWorkMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWindowState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.therm2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.therm1)).EndInit();
            this.tpTemperatureTab.ResumeLayout(false);
            this.tpTemperatureTab.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudInterval)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTOpen)).EndInit();
            this.tpWateringTab.ResumeLayout(false);
            this.tpWateringTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWateringChannels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWateringMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbWatering)).EndInit();
            this.gbWateringSettings.ResumeLayout(false);
            this.gbWateringSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartWateringTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWateringTime)).EndInit();
            this.gbWeekDays.ResumeLayout(false);
            this.tpLuminosity.ResumeLayout(false);
            this.tpLuminosity.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbLuxMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbLux)).EndInit();
            this.gbLuminositySettings.ResumeLayout(false);
            this.gbLuminositySettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxGisteresis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinLux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLuxHourFrom)).EndInit();
            this.tpHumidity.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.tpSMSTab.ResumeLayout(false);
            this.tpSMSTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNumberHelp)).EndInit();
            this.tpWiFi.ResumeLayout(false);
            this.tpWiFi.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tpRules.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tpLog.ResumeLayout(false);
            this.tpLog.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tpWaterFlow.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudFlowCalibration1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tpMultipleCommands.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.tpDeltas.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.tpSoilMoisture.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.tpPH.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibrationTemperature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHTempSensorIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHCalibration)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHVoltage4)).EndInit();
            this.tpIOT.ResumeLayout(false);
            this.tpIOT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIoTInterval)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ImageList imglToolbarImages;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem miFile;
        private System.Windows.Forms.ToolStripMenuItem miExit;
        private System.Windows.Forms.ToolStrip tbToolBar;
        private System.Windows.Forms.SplitContainer splitCont;
        private System.Windows.Forms.TabControl tabCMain;
        private System.Windows.Forms.TabPage tcStatPage;
        private System.Windows.Forms.TabPage tpTemperatureTab;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblUptime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer tmrUptime;
        private System.Windows.Forms.Label lblFreeRam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer tmrFreeRam;
        private System.Windows.Forms.PictureBox therm1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox therm2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Timer tmProcessCommandsTimer;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.Label lblTempOutside;
        private System.Windows.Forms.Label lblTempInside;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton tbbConnectBtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tbbAbout;
        private System.Windows.Forms.ImageList imglTabImages;
        private System.Windows.Forms.Label lblByte;
        private System.Windows.Forms.Label lblCelsius2;
        private System.Windows.Forms.Label lblCelsius1;
        private System.Windows.Forms.Timer tmrTicks;
        private System.Windows.Forms.PictureBox pbWindowState;
        private System.Windows.Forms.Label lblCurrentWindowState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblWindowWorkMode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pbWindowWorkMode;
        private System.Windows.Forms.TrackBar tbWindowPosition;
        private System.Windows.Forms.TrackBar tbSetWorkMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbTempSettings;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nudTClose;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nudTOpen;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnWriteTempSettings;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudInterval;
        private System.Windows.Forms.TabPage tpSMSTab;
        private System.Windows.Forms.TextBox tbPhoneNumber;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnSavePhoneNumber;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pbNumberHelp;
        private System.Windows.Forms.ListView lvLog;
        private System.Windows.Forms.ColumnHeader logColumn1;
        private System.Windows.Forms.ColumnHeader logColumn2;
        private System.Windows.Forms.TabPage tpWateringTab;
        private System.Windows.Forms.ComboBox cbWateringControl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox gbWeekDays;
        private System.Windows.Forms.CheckedListBox clbWeekDays;
        private System.Windows.Forms.GroupBox gbWateringSettings;
        private System.Windows.Forms.Button btnSaveWateringOptions;
        private System.Windows.Forms.NumericUpDown nudWateringTime;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tpLuminosity;
        private System.Windows.Forms.TrackBar tbWatering;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblWateringState;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblWateringMode;
        private System.Windows.Forms.TrackBar tbWateringMode;
        private System.Windows.Forms.NumericUpDown nudStartWateringTime;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ToolStripButton tbPlayPause;
        private System.Windows.Forms.CheckBox chbTurnOnPump;
        private System.Windows.Forms.DataGridView dgvWateringChannels;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.TabPage tpWiFi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tpHumidity;
        private System.Windows.Forms.Timer tmWaitDataTimer;
        private System.Windows.Forms.Button btnSaveLuxSettings;
        private System.Windows.Forms.GroupBox gbLuminositySettings;
        private System.Windows.Forms.NumericUpDown nudMinLux;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nudLuxHourTo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown nudLuxHourFrom;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox cbEnableLuminosityManage;
        private System.Windows.Forms.Timer tmGetAllTempData;
        private System.Windows.Forms.NumericUpDown nudLuxGisteresis;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblLuxMode;
        private System.Windows.Forms.TrackBar tbLuxMode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblLuxState;
        private System.Windows.Forms.TrackBar tbLux;
        private System.Windows.Forms.ToolStripButton btnSetControllerTime;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView lvHumiditySensorsData;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.CheckBox cbConnectToTheRouter;
        private System.Windows.Forms.Button btnSaveWiFiSettings;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox tbStationPassword;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbStationID;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbRouterPassword;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbRouterID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnQueryIP;
        private System.Windows.Forms.CheckBox cbWorkWithoutLightSensor;
        private System.Windows.Forms.TabPage tpRules;
        private System.Windows.Forms.Button btnLoadRules;
        private System.Windows.Forms.Button btnSaveRules;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListView lvRulesList;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnEditRule;
        private System.Windows.Forms.LinkLabel lblComputeRulesmemory;
        private System.Windows.Forms.Button btnAddRule;
        private System.Windows.Forms.Button btnDeleteRule;
        private System.Windows.Forms.ToolTip ttPhoneNumberHint;
        private System.Windows.Forms.ToolTip ttDefault;
        private System.Windows.Forms.Label lblRuleStr;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.TextBox tbLogsDirectory;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.FolderBrowserDialog selectFolder;
        private System.Windows.Forms.Button btnLoadLogs;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbMonth;
        private System.Windows.Forms.RadioButton rbWeek;
        private System.Windows.Forms.RadioButton rbDay;
        private System.Windows.Forms.ProgressBar pbLogsProgress;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblCurrentLogFileName;
        private System.Windows.Forms.Label lblCurrentLogLine;
        private System.Windows.Forms.ToolStripButton tbDelta;
        private System.Windows.Forms.Button btnTempSensorsData;
        private System.Windows.Forms.CheckBox cbCreateTemperatureRules;
        private System.Windows.Forms.ToolTip ttTempRulesHint;
        private System.Windows.Forms.TabPage tpWaterFlow;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblFlowIncremental2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblFlowInstant2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblFlowIncremental1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblFlowInstant1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripButton tbRestartButton;
        private System.Windows.Forms.ToolStripMenuItem tsiCOMConnection;
        private System.Windows.Forms.ToolStripMenuItem miRescanPorts;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.TabPage tpMultipleCommands;
        private System.Windows.Forms.Button btnDeleteCompositeCommand;
        private System.Windows.Forms.Button btnAddCompositeCommand;
        private System.Windows.Forms.Button btnEditCompositeCommand;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ListView lvCompositeCommandsList;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button btnUploadCompositeCommands;
        private System.Windows.Forms.TabPage tpDeltas;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ListView lvDeltasList;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ToolStripMenuItem miConfiguration;
        private System.Windows.Forms.ToolStripMenuItem miDateTime;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem miPlayPause;
        private System.Windows.Forms.ToolStripMenuItem miRestart;
        private System.Windows.Forms.ToolStripMenuItem miDelta;
        private System.Windows.Forms.ToolStripMenuItem miUniversalSensors;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem miFirmwareInfo;
        private System.Windows.Forms.TabPage tpSoilMoisture;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ListView lvSoilMoistureSensorsData;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown nudFlowCalibration2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown nudFlowCalibration1;
        private System.Windows.Forms.Button btnSaveFlowSettings;
        private System.Windows.Forms.Button btnAddSMS;
        private System.Windows.Forms.Button btnSmsList;
        private System.Windows.Forms.ToolStripMenuItem miReservationSettings;
        private System.Windows.Forms.ToolStripMenuItem miTimers;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem miSettings;
        private System.Windows.Forms.ToolStripMenuItem miMonitorScreenSettings;
        private System.Windows.Forms.ListView lvLuminosity;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Button btnClearCCCommands;
        private System.Windows.Forms.LinkLabel lblWindowStates;
        private System.Windows.Forms.Button btnResetWaterflowData;
        private System.Windows.Forms.TabPage tpPH;
        private System.Windows.Forms.ListView lvPH;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.Button btnSavePHSettings;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.NumericUpDown nudPHTempSensorIndex;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.NumericUpDown nudPHCalibration;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.NumericUpDown nudPHVoltage10;
        private System.Windows.Forms.NumericUpDown nudPHVoltage7;
        private System.Windows.Forms.NumericUpDown nudPHVoltage4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown nudPHCalibrationTemperature;
        private System.Windows.Forms.Button btnPHControl;
        private System.Windows.Forms.ListView lvPHStatus;
        private System.Windows.Forms.ToolStripMenuItem miPinsUsed;
        private System.Windows.Forms.TabPage tpIOT;
        private System.Windows.Forms.CheckBox cbThingSpeakEnabled;
        private System.Windows.Forms.NumericUpDown nudIoTInterval;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tbThingSpeakChannelKey;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btnSaveIoTSettings;
        private System.Windows.Forms.ListBox lbIOTSelectedSensors;
        private System.Windows.Forms.ListBox lbIOTAllSensors;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox cbGSMProvider;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.LinkLabel lblDriveWaterChannels;
    }
}

