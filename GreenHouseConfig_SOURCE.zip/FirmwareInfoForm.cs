﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class FirmwareInfoForm : Form
    {
        private MainForm fmMain = null;

        public FirmwareInfoForm(MainForm f)
        {
            InitializeComponent();

            fmMain = f;
        }

        private void FirmwareInfoForm_Load(object sender, EventArgs e)
        {
            AppSettings sett = AppSettings.Instance;

            nudControllerID.Value = sett.ControllerID;

            var enumType = typeof(SensorType);

            foreach (var item in sett.FirmwareSettings)
            {
                var memInfo = enumType.GetMember(item.Key.ToString());
                var atrrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
                string displayName = item.Key.ToString();

                if (atrrs != null && atrrs.Count() > 0)
                {
                    DescriptionAttribute enAttr = (DescriptionAttribute)atrrs[0];
                    displayName = enAttr.ToString();

                }

                ListViewItem li = this.lvHardcodedSensorsList.Items.Add("#" + (this.lvHardcodedSensorsList.Items.Count+1).ToString());
                li.SubItems.Add(displayName);
                li.SubItems.Add(item.Value.ToString());

            } // foreach

            foreach (var item in sett.UniversalModulesSettings)
            {
                var memInfo = enumType.GetMember(item.Key.ToString());
                var atrrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
                string displayName = item.Key.ToString();

                if (atrrs != null && atrrs.Count() > 0)
                {
                    DescriptionAttribute enAttr = (DescriptionAttribute)atrrs[0];
                    displayName = enAttr.ToString();

                }

                ListViewItem li = this.lvUniversalSensorsList.Items.Add("#" + (this.lvUniversalSensorsList.Items.Count + 1).ToString());
                li.SubItems.Add(displayName);
                li.SubItems.Add(item.Value.ToString());

            } // foreach
        }

        private void nudControllerID_ValueChanged(object sender, EventArgs e)
        {
            btnReassignControllerID.Enabled = AppSettings.Instance.ControllerID != Convert.ToInt32(nudControllerID.Value);
        }

        private void btnReassignControllerID_Click(object sender, EventArgs e)
        {
            btnReassignControllerID.Enabled = false;
            AppSettings.Instance.ControllerID = Convert.ToInt32(nudControllerID.Value);
            fmMain.AssignControllerID();
        }
    }
}
