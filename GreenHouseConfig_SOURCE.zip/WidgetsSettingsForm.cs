﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class WidgetsSettingsForm : Form
    {
        public WidgetsSettingsForm()
        {
            InitializeComponent();
        }

        private void WidgetsSettingsForm_Load(object sender, EventArgs e)
        {
            AppSettings settings = AppSettings.Instance;

            this.clbWidgetsList.SetItemChecked(0, settings.WidgetMemoryVisible);
            this.clbWidgetsList.SetItemChecked(1, settings.WidgetWorkTimeVisible);
            this.clbWidgetsList.SetItemChecked(2, settings.WidgetControllerTimeVisible);
            this.clbWidgetsList.SetItemChecked(3, settings.WidgetControllerTemperatureVisible);
            this.clbWidgetsList.SetItemChecked(4, settings.WidgetTemperatureInsideVisible);
            this.clbWidgetsList.SetItemChecked(5, settings.WidgetTemperatureOutsideVisible);
            this.clbWidgetsList.SetItemChecked(6, settings.WidgetWindowsPositionVisible);
            this.clbWidgetsList.SetItemChecked(7, settings.WidgetWindowsWorkModeVisible);
            this.clbWidgetsList.SetItemChecked(8, settings.WidgetWindowsChannelsVisible);
            this.clbWidgetsList.SetItemChecked(9, settings.WidgetTemperatureSensorsVisible);
            this.clbWidgetsList.SetItemChecked(10, settings.WidgetHumiditySensorsVisible);
            this.clbWidgetsList.SetItemChecked(11, settings.WidgetLightSensorsVisible);
            this.clbWidgetsList.SetItemChecked(12, settings.WidgetSoilMoistureVisible);
            this.clbWidgetsList.SetItemChecked(13, settings.WidgetPHVisible);
            this.clbWidgetsList.SetItemChecked(14, settings.WidgetWaterChannelsVisible);
            
        }

        private void WidgetsSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            AppSettings settings = AppSettings.Instance;

            settings.WidgetMemoryVisible = this.clbWidgetsList.GetItemChecked(0);
            settings.WidgetWorkTimeVisible = this.clbWidgetsList.GetItemChecked(1);
            settings.WidgetControllerTimeVisible = this.clbWidgetsList.GetItemChecked(2);
            settings.WidgetControllerTemperatureVisible = this.clbWidgetsList.GetItemChecked(3);
            settings.WidgetTemperatureInsideVisible = this.clbWidgetsList.GetItemChecked(4);
            settings.WidgetTemperatureOutsideVisible = this.clbWidgetsList.GetItemChecked(5);
            settings.WidgetWindowsPositionVisible = this.clbWidgetsList.GetItemChecked(6);
            settings.WidgetWindowsWorkModeVisible = this.clbWidgetsList.GetItemChecked(7);
            settings.WidgetWindowsChannelsVisible = this.clbWidgetsList.GetItemChecked(8);
            settings.WidgetTemperatureSensorsVisible = this.clbWidgetsList.GetItemChecked(9);
            settings.WidgetHumiditySensorsVisible = this.clbWidgetsList.GetItemChecked(10);
            settings.WidgetLightSensorsVisible = this.clbWidgetsList.GetItemChecked(11);
            settings.WidgetSoilMoistureVisible = this.clbWidgetsList.GetItemChecked(12);
            settings.WidgetPHVisible = this.clbWidgetsList.GetItemChecked(13);
            settings.WidgetWaterChannelsVisible = this.clbWidgetsList.GetItemChecked(14);
        }
    }
}
