﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GreenHouseConfig.Properties;


namespace GreenHouseConfig
{
    public partial class AddOneCommandForm : Form
    {
        private CompositeCommand commandToEdit = null;
        private AddEditCompositeCommandForm parentForm = null;

        private void FillCombo()
        {
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.OpenWindows, Settings.Default.OpenWindows, WhichTag.TagOpenWindows));
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.CloseWindows, Settings.Default.CloseWindows, WhichTag.TagCloseWindows));
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.PinsOn, Settings.Default.PinsOn, WhichTag.TagPinOn));
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.PinsOff, Settings.Default.PinsOff, WhichTag.TagPinOff));
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.LightOn, Settings.Default.LightOn, WhichTag.TagLightOn));
            this.cbCommandType.Items.Add(new DescriptionValuePair(Settings.Default.LightOff, Settings.Default.LightOff, WhichTag.TagLightOff));

            this.cbCommandType.SelectedIndex = 0;
           
        }

        private void FillUI()
        {
            FillCombo();

            if (commandToEdit == null)
                return;

            //тут заполняем заполненные параметры для команды
            for (int i = 0; i < cbCommandType.Items.Count; i++)
            {
                DescriptionValuePair dvp = (DescriptionValuePair)cbCommandType.Items[i];
                if (dvp.WhichTag == commandToEdit.Action)
                {
                    cbCommandType.SelectedIndex = i;
                    break;
                }
            }

            tbAdditionalParameter.Text = commandToEdit.AdditionalData.ToString();

        }

        public AddOneCommandForm()
        {
            InitializeComponent();
        }

        public AddOneCommandForm(CompositeCommand cte, AddEditCompositeCommandForm prnt)
        {
            InitializeComponent();

            commandToEdit = cte;
            parentForm = prnt;

            FillUI();
        }

        private void tbAdditionalParameter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            parentForm.DoneEdit(this,commandToEdit);
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
