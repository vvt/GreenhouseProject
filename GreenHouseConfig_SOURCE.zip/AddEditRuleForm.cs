﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GreenHouseConfig.Properties;


namespace GreenHouseConfig
{
    public partial class AddEditRuleForm : Form
    {
        private void FillWhichList()
        {
            this.cbWhich.Items.Add(new DescriptionValuePair("_", Settings.Default.SpyNone, WhichTag.TagNone));
            this.cbWhich.Items.Add(new DescriptionValuePair("TEMP", Settings.Default.SpyTemp,WhichTag.TagTemperature));
            this.cbWhich.Items.Add(new DescriptionValuePair("LIGHT", Settings.Default.SpyLight, WhichTag.TagLight));
            this.cbWhich.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.SpyHumidity, WhichTag.TagHumidity));
            this.cbWhich.Items.Add(new DescriptionValuePair("PIN", "состоянием пина", WhichTag.TagPinState));
            this.cbWhich.Items.Add(new DescriptionValuePair("SOIL", "влажностью почвы", WhichTag.TagSoilMoisture));

            this.cbWhich.SelectedIndex = 0;
        }
        private void FillOperandsList()
        {
            this.cbOperand.Items.Clear();
            this.cbOperand.Items.Add(new DescriptionValuePair(">", Settings.Default.GreaterThan, WhichTag.TagGreaterThan));
            this.cbOperand.Items.Add(new DescriptionValuePair(">=", Settings.Default.GreaterOrEqual, WhichTag.TagGreaterOrEqual));
            this.cbOperand.Items.Add(new DescriptionValuePair("<", Settings.Default.LessThan, WhichTag.TagLessThan));
            this.cbOperand.Items.Add(new DescriptionValuePair("<=", Settings.Default.LessOrEqual, WhichTag.TagLessOrEqual));

            this.cbOperand.SelectedIndex = 0;

        }
        private void FillAvailableActions()
        {
            this.cbAvailableActions.Items.Clear();
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=STATE|WINDOW|{0}|OPEN", Settings.Default.OpenWindows, WhichTag.TagOpenWindows));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=STATE|WINDOW|{0}|CLOSE", Settings.Default.CloseWindows, WhichTag.TagCloseWindows));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=LIGHT|ON", Settings.Default.LightOn, WhichTag.TagLightOn));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=LIGHT|OFF", Settings.Default.LightOff, WhichTag.TagLightOff));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=PIN|{0}|ON", Settings.Default.PinsOn, WhichTag.TagPinOn));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=PIN|{0}|OFF", Settings.Default.PinsOff, WhichTag.TagPinOff));
            this.cbAvailableActions.Items.Add(new DescriptionValuePair("CTSET=CC|EXEC|{0}", "выполнить составную команду", WhichTag.TagExecCompositeCommand));

            this.cbAvailableActions.SelectedIndex = 0;
        }
        private void FillAvailableModulesList(DescriptionValuePair st)
        {
            this.cbLinkedModuleName.Items.Clear();
            bool bEn = true;

            lblSensorIndex.Text = "Индекс датчика:";
            lblSensorData.Text = "Показания датчика:";
            tbSensorData.Visible = true;
            FillOperandsList();

            if (st.WhichTag == WhichTag.TagTemperature)
            {
                this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("STATE", Settings.Default.StateModule, WhichTag.TagNone));
                this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagNone));
                this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("DELTA", Settings.Default.DeltaModule, WhichTag.TagNone));
            }
            else
                if (st.WhichTag == WhichTag.TagLight)
                {
                    this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("LIGHT", Settings.Default.LightModule, WhichTag.TagNone));
                    this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("DELTA", Settings.Default.DeltaModule, WhichTag.TagNone));
                }
                else
                    if (st.WhichTag == WhichTag.TagHumidity)
                    {
                        this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagNone));
                        this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("DELTA", Settings.Default.DeltaModule, WhichTag.TagNone));
                    }
                    else if (st.WhichTag == WhichTag.TagSoilMoisture)
                    {
                        this.cbLinkedModuleName.Items.Add(new DescriptionValuePair("SOIL", "Модуль влажности почвы", WhichTag.TagNone));
                    }
                    else
                        if (st.WhichTag == WhichTag.TagNone)
                        {
                            bEn = false;
                        }

            if (this.cbLinkedModuleName.Items.Count > 0)
                this.cbLinkedModuleName.SelectedIndex = 0;

            cbLinkedModuleName.Enabled = bEn;
            nudSensorIndex.Enabled = bEn;
            cbOperand.Enabled = bEn;
            tbSensorData.Enabled = bEn;

            if (st.WhichTag == WhichTag.TagPinState)
            {
                lblSensorIndex.Text = "Номер пина:";
                cbLinkedModuleName.Enabled = false;
                tbSensorData.Visible = false;
                cbOperand.Items.Clear();

                this.cbOperand.Items.Add(new DescriptionValuePair(">=", "высокий", WhichTag.TagGreaterOrEqual));
                this.cbOperand.Items.Add(new DescriptionValuePair("<", "низкий", WhichTag.TagLessThan));
                cbOperand.SelectedIndex = 0;

                lblSensorData.Text = "Уровень на пине:";
            }


        }
        private void FillLinkedRulesList()
        {
            foreach (AlertRule ar in AppSettings.Instance.AlertRules)
            {
                if (!ar.IsDeleted && ar != workRule)
                {
                    this.clbLinkedRules.Items.Add(new AlertRuleHolder(ar));
                }
            }
        }
        private MainForm mainForm = null;
        private AlertRule workRule = null;
        private byte currentDayMask = 0xFF;
        public AddEditRuleForm(AlertRule ar,MainForm f)
        {
            InitializeComponent();

            mainForm = f;

            FillWhichList();
            FillOperandsList();
            FillAvailableActions();

            workRule = ar;
            

            FillLinkedRulesList();

            if (workRule == null)
                Text = Settings.Default.AddRule;
            else
            {
                currentDayMask = workRule.DayMask;
                Text = Settings.Default.EditRule;
                this.tbRuleName.Enabled = !workRule.IsSpecialRule;

                if(workRule.Name.Length > 5 )
                    workRule.Name = workRule.Name.Substring(0, 5);

                this.tbRuleName.Text = workRule.Name;
                
                if (workRule.SensorIndex > nudSensorIndex.Maximum)
                    workRule.SensorIndex = Convert.ToInt32(nudSensorIndex.Maximum);
                this.nudSensorIndex.Value = workRule.SensorIndex;

                int startHour = Convert.ToInt32(workRule.StartTime / 60);
                if (startHour > nudStartHour.Maximum)
                    startHour = Convert.ToInt32(nudStartHour.Maximum);
                if (startHour < nudStartHour.Minimum)
                    startHour = Convert.ToInt32(nudStartHour.Minimum);
                this.nudStartHour.Value = startHour;

                int startMinute = Convert.ToInt32(workRule.StartTime % 60);
                if (startMinute > nudStartMinute.Maximum)
                    startMinute = Convert.ToInt32(nudStartMinute.Maximum);
                if (startMinute < nudStartMinute.Minimum)
                    startMinute = Convert.ToInt32(nudStartMinute.Minimum);
                this.nudStartMinute.Value = startMinute;

                if (workRule.WorkTime > nudWorkTime.Maximum)
                    workRule.WorkTime = Convert.ToInt32(nudWorkTime.Maximum);
                this.nudWorkTime.Value = workRule.WorkTime;

                this.tbSensorData.Text = workRule.Target;

                this.cbAlarmRule.Checked = workRule.IsAlarm;

                int cnt = cbWhich.Items.Count;
                for (int i=0;i<cnt;i++)
                {
                    DescriptionValuePair dvp = (DescriptionValuePair)cbWhich.Items[i];
                    if (dvp.Value == workRule.SpyTo)
                    {
                        cbWhich.SelectedIndex = i;

                        break;
                    }
                }

                cnt = cbLinkedModuleName.Items.Count;
                for (int i = 0; i < cnt; i++)
                {
                    DescriptionValuePair dvp = (DescriptionValuePair)cbLinkedModuleName.Items[i];
                    if (dvp.Value == workRule.LinkedModuleName)
                    {
                        cbLinkedModuleName.SelectedIndex = i;

                        break;
                    }
                }

                cnt = cbOperand.Items.Count;
                for (int i = 0; i < cnt; i++)
                {
                    DescriptionValuePair dvp = (DescriptionValuePair)cbOperand.Items[i];
                    if (dvp.Value == workRule.Operand)
                    {
                        cbOperand.SelectedIndex = i;

                        break;
                    }
                }

                cnt = cbAvailableActions.Items.Count;
                WhichTag actTag = AppSettings.Instance.GetActionTag(workRule.Command);
                for (int i = 0; i < cnt; i++)
                {
                    DescriptionValuePair dvp = (DescriptionValuePair)cbAvailableActions.Items[i];
                    if (dvp.WhichTag == actTag)
                    {
                        cbAvailableActions.SelectedIndex = i;

                        break;
                    }
                }
                string[] ruleParams = workRule.Command.Split('|');

                switch (actTag)
                {
                    case WhichTag.TagOpenWindows:
                        int interval = 0;
                        bool hasInterval = false;
                        try
                        {
                            interval = Convert.ToInt32(ruleParams[ruleParams.Length-1]);
                            interval /= 1000;
                            hasInterval = true;

                            wndOpenOnterval.Value = interval;
                        }
                        catch { }
                        
                        try
                        {
                            int idx = ruleParams.Length-2;
                            if(hasInterval) --idx;
                            tbAdditional.Text = ruleParams[idx];
                        }
                        catch { }
                    break;

                    case WhichTag.TagCloseWindows:
                    try
                    {
                        tbAdditional.Text = ruleParams[ruleParams.Length - 2];
                    }
                    catch { }
                    break;

                    case WhichTag.TagPinOff:
                    case WhichTag.TagPinOn:
                    try
                    {
                        tbAdditional.Text = ruleParams[ruleParams.Length - 2];
                    }
                    catch { }
                    break;

                    case WhichTag.TagExecCompositeCommand:
                    try
                    {
                        tbAdditional.Text = ruleParams[ruleParams.Length - 1];
                    }
                    catch { }
                    break;
                } // switch

                

                cnt = clbLinkedRules.Items.Count;
                foreach (string s in workRule.LinkedRules)
                {

                    for (int i=0;i<cnt;i++)
                    {
                        AlertRuleHolder arh = (AlertRuleHolder)clbLinkedRules.Items[i];
                        if (arh.Rule.Name == s)
                        {
                            clbLinkedRules.SetItemChecked(i, true);
                            break;
                        }
                    }
                }


            }


            lblAdditional.Text = "";
            lblHint.Text = "";
            lblHint.ForeColor = Color.DarkRed;
        }
        public AddEditRuleForm()
        {
            InitializeComponent();
        }

        private void cbWhich_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillAvailableModulesList(this.cbWhich.Items[this.cbWhich.SelectedIndex] as DescriptionValuePair);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string rulename = tbRuleName.Text.Trim();
            if (rulename.Length < 1)
            {
                MessageBox.Show(Settings.Default.EnterRuleName, Settings.Default.RuleName);
                tbRuleName.Focus();
                return;
            }
            foreach (AlertRule ar in AppSettings.Instance.AlertRules)
            {
                if (!ar.IsDeleted && ar != workRule && ar.Name == rulename)
                {
                    MessageBox.Show(Settings.Default.RuleNameExists, Settings.Default.RuleName);
                    tbRuleName.Focus();
                    return;
                }
            }



            DescriptionValuePair dvp = (DescriptionValuePair)cbWhich.Items[cbWhich.SelectedIndex];
            string lmnm = "";
            int sensidx = 0;
            int startTime = Convert.ToInt32(nudStartHour.Value) * 60 + Convert.ToInt32(nudStartMinute.Value);
            int workTime = Convert.ToInt32(nudWorkTime.Value);

            string sensData = tbSensorData.Text.Trim();
            string command = "";
            string additional = tbAdditional.Text.Trim();
            string which = dvp.Value;

            DescriptionValuePair opPair = (DescriptionValuePair)cbOperand.Items[cbOperand.SelectedIndex];

            if (dvp.WhichTag == WhichTag.TagNone) // выбрано "ни за чем не следим"
            {
                lmnm = "0"; // делаем вид, что следим за модулем 0 - он всегда есть в системе
                sensData = "0";
            }
            else if (dvp.WhichTag == WhichTag.TagPinState)
            {
                lmnm = "0"; // делаем вид, что следим за модулем 0 - он всегда есть в системе
                sensData = "1"; // всегда сравниваем с единицей, поскольку у нас цифровой пин
                sensidx = Convert.ToInt32(nudSensorIndex.Value);
            }
            else
            {
                DescriptionValuePair lmodPair = (DescriptionValuePair)cbLinkedModuleName.Items[cbLinkedModuleName.SelectedIndex];
                lmnm = lmodPair.Value;
                sensidx = Convert.ToInt32(nudSensorIndex.Value);

                if (sensData.Length < 1)
                {
                    MessageBox.Show(Settings.Default.EnterSpyData, Settings.Default.Error);
                    tbSensorData.Focus();
                    return;
                }
            }

            DescriptionValuePair actPair = (DescriptionValuePair)cbAvailableActions.Items[cbAvailableActions.SelectedIndex];
            command = actPair.Value;

            switch (actPair.WhichTag)
            {
                case WhichTag.TagOpenWindows:
                case WhichTag.TagCloseWindows:
                case WhichTag.TagPinOff:
                case WhichTag.TagPinOn:
                case WhichTag.TagExecCompositeCommand:
                    {
                        if (additional.Length < 1)
                        {
                            cbAvailableActions_SelectedIndexChanged(cbAvailableActions, new EventArgs());
                            MessageBox.Show(Settings.Default.EnterAdditionalParams, Settings.Default.Error);
                            tbAdditional.Focus();
                            return;
                        }
                        command = string.Format(actPair.Value, additional);

                        if (actPair.WhichTag == WhichTag.TagOpenWindows)
                        {
                            int interval = Convert.ToInt32(wndOpenOnterval.Value);
                            if (interval > 0)
                            {
                                interval *= 1000;
                                command += "|" + interval.ToString();
                            }

                        }
                    }
                    break;
            } // switch


            bool shouldAdd = false;
            if (workRule == null)
            {
                workRule = new AlertRule();
                shouldAdd = true;
            }

            workRule.DayMask = currentDayMask;
            workRule.Command = command;
            workRule.LinkedModuleName = lmnm;
            workRule.LinkedRules.Clear();
           
            foreach(AlertRuleHolder arh in clbLinkedRules.CheckedItems)
            {
                workRule.LinkedRules.Add(arh.Rule.Name);
            }
            workRule.Name = rulename;
            workRule.Operand = opPair.Value;
            workRule.SensorIndex = sensidx;
            workRule.SpyTo = which;
            workRule.StartTime = startTime;
            workRule.Target = sensData;
            workRule.WorkTime = workTime;

            workRule.IsAlarm = this.cbAlarmRule.Checked;

          //  MessageBox.Show(workRule.ToString()); // тестируем
        //    return;

            if (shouldAdd)
                mainForm.AddRule(workRule);
            else
                mainForm.UpdateRule(workRule);

            DialogResult = DialogResult.OK;

            

        }
         
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void tbSensorData_Enter(object sender, EventArgs e)
        {
            string hint = "";
            
            DescriptionValuePair dvp = (DescriptionValuePair)cbWhich.Items[cbWhich.SelectedIndex];
            switch (dvp.WhichTag)
            {
                case WhichTag.TagTemperature:
                    {
                        hint = Settings.Default.TemperatureHint;
                    }
                    break;

                case WhichTag.TagLight:
                    {
                        hint = Settings.Default.LightHint;
                    }
                    break;
            } // switch
            lblHint.Text = hint;
        }

        private void cbAvailableActions_SelectedIndexChanged(object sender, EventArgs e)
        {
            DescriptionValuePair dvp = (DescriptionValuePair)cbAvailableActions.Items[cbAvailableActions.SelectedIndex];
            switch (dvp.WhichTag)
            {
                case WhichTag.TagOpenWindows:
                case WhichTag.TagCloseWindows:
                    {
                        lblAdditional.Text = Settings.Default.WhichWindows;
                        lblHint.Text = Settings.Default.WindowsHint;
                        if(tbAdditional.Text == "")
                            tbAdditional.Text = "ALL";

                    }
                    break;

                case WhichTag.TagPinOff:
                case WhichTag.TagPinOn:
                    {
                        lblAdditional.Text = Settings.Default.PinNumbers;
                        lblHint.Text = Settings.Default.PinHint;
                        if (tbAdditional.Text == "") 
                            tbAdditional.Text = "13";
                    }
                    break;
                case WhichTag.TagExecCompositeCommand:
                    {
                        lblAdditional.Text = "Индекс команды:";
                        lblHint.Text = "Укажите индекс составной команды из списка составных команд.";
                        if (tbAdditional.Text == "") 
                            tbAdditional.Text = "0";
                    }
                    break;
                default:
                    {
                        lblAdditional.Text = "";
                        lblHint.Text = "";
                        tbAdditional.Text = "";
                    }
                    break;
            }

            lblInterval.Enabled = dvp.WhichTag == WhichTag.TagOpenWindows;
            wndOpenOnterval.Enabled = lblInterval.Enabled;

        }

        private void tbRuleName_Enter(object sender, EventArgs e)
        {
            lblHint.Text = Settings.Default.OnlyLatinLettersHint;
        }

        private void btnDaymask_Click(object sender, EventArgs e)
        {
            

            DayMaskForm dmf = new DayMaskForm();
            dmf.SetDaymask(currentDayMask);
            if (dmf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                currentDayMask = dmf.GetDaymask();
            }
        }

        private void wndOpenOnterval_Enter(object sender, EventArgs e)
        {
            lblHint.Text = "Необязательный интервал работы приводов, с. Если указано \"0\" - будет взят интервал из настроек.";
        }
    }
    public enum WhichTag
    {
        TagNone,
        TagTemperature,
        TagHumidity,
        TagLight,
        TagDelta,
        TagGreaterThan,
        TagGreaterOrEqual,
        TagLessThan,
        TagLessOrEqual,
        TagOpenWindows,
        TagCloseWindows,
        TagLightOn,
        TagLightOff,
        TagPinOn,
        TagPinOff,
        TagPinState,
        TagExecCompositeCommand,
        TagSoilMoisture
    }
    public class AlertRuleHolder
    {
        private AlertRule rule;
        public AlertRule Rule
        {
            get { return rule; }
        }
        public AlertRuleHolder(AlertRule r)
        {
            rule = r;
        }
        public override string ToString()
        {
            return rule.Name + ": " + AppSettings.Instance.GetActionDescription(rule.Command);
        }
    }
    public class DescriptionValuePair
    {
        private WhichTag whichTag = WhichTag.TagNone;
        public WhichTag WhichTag
        {
            get { return this.whichTag; }
        }
        private string val;
        public string Value
        {
            get { return this.val; }
        }
        private string desc;
        public string Description
        {
            get { return this.desc; }
        }
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="v">значение</param>
        /// <param name="d">описание</param>
        /// <param name="t">тег действия</param>
        public DescriptionValuePair(string v, string d,WhichTag t)
        {
            this.val = v;
            this.desc = d;
            this.whichTag = t;
        }

        public override string ToString()
        {
            return this.desc;
        }
    }

}
