﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
  
    public partial class WaterChannelsForm : Form
    {
        
        internal class ChannelHelper
        {
            public bool State;
            public int Index;
        }

        private MainForm mainForm = null;
      
        public WaterChannelsForm(MainForm frm)
        {
            mainForm = frm;
            InitializeComponent();
        }

        private void WaterChannelsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }

        private List<System.Windows.Forms.Button> buttons = new List<Button>();
        private int nameCounter = 0;


        public void UpdateChannelsState(int totalChannels, bool[] stateArray)
        {
            while (buttons.Count > totalChannels)
            {
                Button b = buttons[buttons.Count - 1];
                buttons.Remove(b);
                this.Controls.Remove(b);
            }

            List<Control> controls = new List<Control>();

            while (buttons.Count < totalChannels)
            {
                Button button = new System.Windows.Forms.Button();
                button.UseVisualStyleBackColor = true;
                button.Dock = System.Windows.Forms.DockStyle.Top;
                button.Name = "button" + nameCounter.ToString();
                nameCounter++;

                button.Tag = new ChannelHelper { Index = buttons.Count, State = false };

                Size sz = button.Size;
                sz.Height = 40;

                button.Size = sz;

                button.Location = new System.Drawing.Point(0, button.Size.Height * buttons.Count);

                button.Click += new EventHandler(b_Click);

                buttons.Add(button);

                controls.Add(button);
            } // while

            controls.Reverse();
            this.Controls.AddRange(controls.ToArray());

            for (int i = 0; i < totalChannels; i++)
            {
                Button b = buttons[i];
                string txt = "Канал #" + (i + 1).ToString();
                if (stateArray[i])
                    txt += ": включен. Выключить!";
                else
                    txt += ": выключен. Включить!";

                b.Text = txt;

                ChannelHelper tag = (ChannelHelper)b.Tag;
                tag.Index = i;
                tag.State = stateArray[i];

                b.Tag = tag;
                b.Enabled = true;

                if (tag.State)
                {
                    b.BackColor = Color.LightGreen;
                }
                else
                {
                    b.BackColor = Color.LightSalmon;
                }

            }// for
        }

        private void b_Click(object sender, EventArgs e)
        {
            Button b = sender as Button;
            ChannelHelper tag = (ChannelHelper)b.Tag;

            b.Enabled = false;

            this.mainForm.SwitchWateringChannel(tag.Index, !tag.State);
            /*
            if (tag.State)
            {
                // канал включен, надо выключить
                Console.WriteLine("OFF channel #" + tag.Index.ToString());
            }
            else
            {
                Console.WriteLine("ON channel #" + tag.Index.ToString());
            }
             */
             
        }
    }


}
