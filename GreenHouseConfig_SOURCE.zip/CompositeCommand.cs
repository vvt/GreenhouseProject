﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using GreenHouseConfig.Properties;

namespace GreenHouseConfig
{
    /// <summary>
    /// Класс-держатель команд на выполнение
    /// </summary>
    public class CompositeCommands
    {
        private List<CompositeCommand> commands = new List<CompositeCommand>();

        private string name;

        /// <summary>
        /// Имя составной команды, для отображения в списке.
        /// </summary>
        [XmlAttribute("name")]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        [XmlArray("commands")]
        [XmlArrayItem("command")]
        public List<CompositeCommand> Commands
        {
            get { return this.commands; }
            set { this.commands = value; }
        }

        public CompositeCommands(string nm)
        {
            this.name = nm;
        }

        public CompositeCommands()
        {
        }
    }

    /// <summary>
    /// Класс одной команды в списке составных команд
    /// </summary>
    public class CompositeCommand
    {
        private WhichTag action = WhichTag.TagNone;

        /// <summary>
        /// Действие, которое надо выполнить
        /// </summary>
        [XmlAttribute("action")]
        public WhichTag Action
        {
            get { return this.action; }
            set { this.action = value; }
        }

        private byte additionalData = 0;

        /// <summary>
        /// Дополнительные данные для команды, например, номер пина
        /// </summary>
        [XmlAttribute("data")]
        public byte AdditionalData
        {
            get { return this.additionalData; }
            set { this.additionalData = value; }
        }

        public CompositeCommand()
        {
        }

        public CompositeCommand(WhichTag a, byte addData)
        {
            this.action = a;
            this.additionalData = addData;
        }

        public override string ToString()
        {
            switch (this.action)
            {
                case WhichTag.TagCloseWindows:
                    return Settings.Default.CloseWindows;
                case WhichTag.TagLightOff:
                    return Settings.Default.LightOff;
                case WhichTag.TagLightOn:
                    return Settings.Default.LightOn;
                case WhichTag.TagOpenWindows:
                    return Settings.Default.OpenWindows;
                case WhichTag.TagPinOff:
                    return Settings.Default.PinsOff;
                case WhichTag.TagPinOn:
                    return Settings.Default.PinsOn;
            }

            return base.ToString();
        }
    }


}
