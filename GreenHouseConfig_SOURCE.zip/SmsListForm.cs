﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class SmsListForm : Form
    {
        public SmsListForm()
        {
            InitializeComponent();
        }

        private void SmsListForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < AppSettings.Instance.SMSCommands.Count; i++)
            {
                SmsCommand comm = AppSettings.Instance.SMSCommands[i];
                ListViewItem lvi = lvSMSList.Items.Add(comm.SMSText);
                lvi.SubItems.Add(comm.Command);
                lvi.SubItems.Add(comm.SMSAnswer);
            } // for
        }
    }
}
