﻿namespace GreenHouseConfig
{
    partial class WidgetsSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.clbWidgetsList = new System.Windows.Forms.CheckedListBox();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.SteelBlue;
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.clbWidgetsList);
            this.panel34.Controls.Add(this.panel35);
            this.panel34.Location = new System.Drawing.Point(13, 20);
            this.panel34.Margin = new System.Windows.Forms.Padding(3, 10, 10, 3);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(396, 280);
            this.panel34.TabIndex = 3;
            // 
            // panel35
            // 
            this.panel35.AutoSize = true;
            this.panel35.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel35.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel35.Controls.Add(this.label55);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel35.Location = new System.Drawing.Point(0, 0);
            this.panel35.Name = "panel35";
            this.panel35.Padding = new System.Windows.Forms.Padding(3);
            this.panel35.Size = new System.Drawing.Size(394, 26);
            this.panel35.TabIndex = 0;
            // 
            // label55
            // 
            this.label55.Dock = System.Windows.Forms.DockStyle.Top;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label55.ForeColor = System.Drawing.Color.Beige;
            this.label55.Location = new System.Drawing.Point(3, 3);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(388, 20);
            this.label55.TabIndex = 1;
            this.label55.Text = "Виджеты экрана \"Монитор\"";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.LightGreen;
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOK.ForeColor = System.Drawing.Color.Black;
            this.btnOK.Location = new System.Drawing.Point(283, 319);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(125, 38);
            this.btnOK.TabIndex = 4;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            // 
            // clbWidgetsList
            // 
            this.clbWidgetsList.BackColor = System.Drawing.Color.White;
            this.clbWidgetsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clbWidgetsList.CheckOnClick = true;
            this.clbWidgetsList.ForeColor = System.Drawing.Color.Black;
            this.clbWidgetsList.FormattingEnabled = true;
            this.clbWidgetsList.IntegralHeight = false;
            this.clbWidgetsList.Items.AddRange(new object[] {
            "Свободная память контроллера",
            "Время работы контроллера",
            "Дата и время контроллера",
            "Температура контроллера",
            "Температура внутри(датчик)",
            "Температура снаружи (датчик)",
            "Управление всеми окнами одновременно",
            "Управление режимом работы окон",
            "Управление отдельными окнами",
            "Показания температурных датчиков",
            "Показания датчиков влажности",
            "Показания датчиков освещённости",
            "Показания датчиков влажности почвы",
            "Показания датчиков pH",
            "Управление каналами полива"});
            this.clbWidgetsList.Location = new System.Drawing.Point(1, 29);
            this.clbWidgetsList.Name = "clbWidgetsList";
            this.clbWidgetsList.Size = new System.Drawing.Size(392, 248);
            this.clbWidgetsList.TabIndex = 1;
            // 
            // WidgetsSettingsForm
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(429, 370);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.panel34);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WidgetsSettingsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки виджетов";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WidgetsSettingsForm_FormClosing);
            this.Load += new System.EventHandler(this.WidgetsSettingsForm_Load);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.CheckedListBox clbWidgetsList;
    }
}