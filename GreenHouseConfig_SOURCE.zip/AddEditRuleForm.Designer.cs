﻿namespace GreenHouseConfig
{
    partial class AddEditRuleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.nudSensorIndex = new System.Windows.Forms.NumericUpDown();
            this.lblSensorIndex = new System.Windows.Forms.Label();
            this.cbLinkedModuleName = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbWhich = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbRuleName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbAvailableActions = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbSensorData = new System.Windows.Forms.TextBox();
            this.cbOperand = new System.Windows.Forms.ComboBox();
            this.lblSensorData = new System.Windows.Forms.Label();
            this.btnDaymask = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.nudStartMinute = new System.Windows.Forms.NumericUpDown();
            this.nudWorkTime = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.nudStartHour = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.wndOpenOnterval = new System.Windows.Forms.NumericUpDown();
            this.lblInterval = new System.Windows.Forms.Label();
            this.tbAdditional = new System.Windows.Forms.TextBox();
            this.lblAdditional = new System.Windows.Forms.Label();
            this.clbLinkedRules = new System.Windows.Forms.CheckedListBox();
            this.cbAlarmRule = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartMinute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWorkTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartHour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wndOpenOnterval)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.LightGreen;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.ForeColor = System.Drawing.Color.Black;
            this.btnOk.Location = new System.Drawing.Point(338, 627);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(124, 32);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(468, 627);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(123, 32);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // nudSensorIndex
            // 
            this.nudSensorIndex.BackColor = System.Drawing.Color.White;
            this.nudSensorIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudSensorIndex.ForeColor = System.Drawing.Color.Black;
            this.nudSensorIndex.Location = new System.Drawing.Point(23, 74);
            this.nudSensorIndex.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSensorIndex.Name = "nudSensorIndex";
            this.nudSensorIndex.Size = new System.Drawing.Size(106, 20);
            this.nudSensorIndex.TabIndex = 15;
            // 
            // lblSensorIndex
            // 
            this.lblSensorIndex.AutoSize = true;
            this.lblSensorIndex.ForeColor = System.Drawing.Color.White;
            this.lblSensorIndex.Location = new System.Drawing.Point(20, 58);
            this.lblSensorIndex.Name = "lblSensorIndex";
            this.lblSensorIndex.Size = new System.Drawing.Size(91, 13);
            this.lblSensorIndex.TabIndex = 14;
            this.lblSensorIndex.Text = "Индекс датчика:";
            // 
            // cbLinkedModuleName
            // 
            this.cbLinkedModuleName.BackColor = System.Drawing.Color.White;
            this.cbLinkedModuleName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLinkedModuleName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbLinkedModuleName.ForeColor = System.Drawing.Color.Black;
            this.cbLinkedModuleName.FormattingEnabled = true;
            this.cbLinkedModuleName.Location = new System.Drawing.Point(146, 73);
            this.cbLinkedModuleName.Name = "cbLinkedModuleName";
            this.cbLinkedModuleName.Size = new System.Drawing.Size(198, 21);
            this.cbLinkedModuleName.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(143, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Модуль, который опрашиваем:";
            // 
            // cbWhich
            // 
            this.cbWhich.BackColor = System.Drawing.Color.White;
            this.cbWhich.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWhich.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbWhich.ForeColor = System.Drawing.Color.Black;
            this.cbWhich.FormattingEnabled = true;
            this.cbWhich.Location = new System.Drawing.Point(146, 28);
            this.cbWhich.Name = "cbWhich";
            this.cbWhich.Size = new System.Drawing.Size(198, 21);
            this.cbWhich.TabIndex = 11;
            this.cbWhich.SelectedIndexChanged += new System.EventHandler(this.cbWhich_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(143, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Следим за:";
            // 
            // tbRuleName
            // 
            this.tbRuleName.BackColor = System.Drawing.Color.White;
            this.tbRuleName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbRuleName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbRuleName.ForeColor = System.Drawing.Color.Black;
            this.tbRuleName.Location = new System.Drawing.Point(23, 29);
            this.tbRuleName.MaxLength = 5;
            this.tbRuleName.Name = "tbRuleName";
            this.tbRuleName.Size = new System.Drawing.Size(106, 20);
            this.tbRuleName.TabIndex = 9;
            this.tbRuleName.WordWrap = false;
            this.tbRuleName.Enter += new System.EventHandler(this.tbRuleName_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(20, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Имя правила:";
            // 
            // cbAvailableActions
            // 
            this.cbAvailableActions.BackColor = System.Drawing.Color.White;
            this.cbAvailableActions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAvailableActions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbAvailableActions.ForeColor = System.Drawing.Color.Black;
            this.cbAvailableActions.FormattingEnabled = true;
            this.cbAvailableActions.Location = new System.Drawing.Point(340, 51);
            this.cbAvailableActions.Name = "cbAvailableActions";
            this.cbAvailableActions.Size = new System.Drawing.Size(216, 21);
            this.cbAvailableActions.TabIndex = 21;
            this.cbAvailableActions.SelectedIndexChanged += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            this.cbAvailableActions.Enter += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(337, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Действие:";
            // 
            // tbSensorData
            // 
            this.tbSensorData.BackColor = System.Drawing.Color.White;
            this.tbSensorData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSensorData.ForeColor = System.Drawing.Color.Black;
            this.tbSensorData.Location = new System.Drawing.Point(233, 52);
            this.tbSensorData.MaxLength = 10;
            this.tbSensorData.Name = "tbSensorData";
            this.tbSensorData.Size = new System.Drawing.Size(86, 20);
            this.tbSensorData.TabIndex = 19;
            this.tbSensorData.WordWrap = false;
            this.tbSensorData.Enter += new System.EventHandler(this.tbSensorData_Enter);
            // 
            // cbOperand
            // 
            this.cbOperand.BackColor = System.Drawing.Color.White;
            this.cbOperand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOperand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbOperand.ForeColor = System.Drawing.Color.Black;
            this.cbOperand.FormattingEnabled = true;
            this.cbOperand.Location = new System.Drawing.Point(21, 52);
            this.cbOperand.Name = "cbOperand";
            this.cbOperand.Size = new System.Drawing.Size(194, 21);
            this.cbOperand.TabIndex = 18;
            // 
            // lblSensorData
            // 
            this.lblSensorData.AutoSize = true;
            this.lblSensorData.ForeColor = System.Drawing.Color.White;
            this.lblSensorData.Location = new System.Drawing.Point(18, 37);
            this.lblSensorData.Name = "lblSensorData";
            this.lblSensorData.Size = new System.Drawing.Size(109, 13);
            this.lblSensorData.TabIndex = 17;
            this.lblSensorData.Text = "Показания датчика:";
            // 
            // btnDaymask
            // 
            this.btnDaymask.BackColor = System.Drawing.Color.LightGreen;
            this.btnDaymask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDaymask.ForeColor = System.Drawing.Color.Black;
            this.btnDaymask.Location = new System.Drawing.Point(119, 100);
            this.btnDaymask.Name = "btnDaymask";
            this.btnDaymask.Size = new System.Drawing.Size(51, 23);
            this.btnDaymask.TabIndex = 27;
            this.btnDaymask.Text = "Дни";
            this.btnDaymask.UseVisualStyleBackColor = false;
            this.btnDaymask.Click += new System.EventHandler(this.btnDaymask_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SteelBlue;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(91, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = ":";
            // 
            // nudStartMinute
            // 
            this.nudStartMinute.BackColor = System.Drawing.Color.White;
            this.nudStartMinute.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudStartMinute.ForeColor = System.Drawing.Color.Black;
            this.nudStartMinute.Location = new System.Drawing.Point(107, 55);
            this.nudStartMinute.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nudStartMinute.Name = "nudStartMinute";
            this.nudStartMinute.Size = new System.Drawing.Size(63, 20);
            this.nudStartMinute.TabIndex = 18;
            // 
            // nudWorkTime
            // 
            this.nudWorkTime.BackColor = System.Drawing.Color.White;
            this.nudWorkTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudWorkTime.ForeColor = System.Drawing.Color.Black;
            this.nudWorkTime.Location = new System.Drawing.Point(21, 102);
            this.nudWorkTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudWorkTime.Name = "nudWorkTime";
            this.nudWorkTime.Size = new System.Drawing.Size(92, 20);
            this.nudWorkTime.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SteelBlue;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(18, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Продолжительность, мин:";
            // 
            // nudStartHour
            // 
            this.nudStartHour.BackColor = System.Drawing.Color.White;
            this.nudStartHour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudStartHour.ForeColor = System.Drawing.Color.Black;
            this.nudStartHour.Location = new System.Drawing.Point(21, 55);
            this.nudStartHour.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.nudStartHour.Name = "nudStartHour";
            this.nudStartHour.Size = new System.Drawing.Size(63, 20);
            this.nudStartHour.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.SteelBlue;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(18, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Начало:";
            // 
            // lblHint
            // 
            this.lblHint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(250)))), ((int)(((byte)(156)))));
            this.lblHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHint.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblHint.Location = new System.Drawing.Point(6, 6);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(560, 33);
            this.lblHint.TabIndex = 0;
            this.lblHint.Text = "Здесь текст подсказки, в зависимости от производимых действий.";
            // 
            // wndOpenOnterval
            // 
            this.wndOpenOnterval.BackColor = System.Drawing.Color.White;
            this.wndOpenOnterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wndOpenOnterval.Enabled = false;
            this.wndOpenOnterval.ForeColor = System.Drawing.Color.Black;
            this.wndOpenOnterval.Location = new System.Drawing.Point(192, 53);
            this.wndOpenOnterval.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.wndOpenOnterval.Name = "wndOpenOnterval";
            this.wndOpenOnterval.Size = new System.Drawing.Size(80, 20);
            this.wndOpenOnterval.TabIndex = 17;
            this.wndOpenOnterval.Enter += new System.EventHandler(this.wndOpenOnterval_Enter);
            // 
            // lblInterval
            // 
            this.lblInterval.AutoSize = true;
            this.lblInterval.Enabled = false;
            this.lblInterval.ForeColor = System.Drawing.Color.White;
            this.lblInterval.Location = new System.Drawing.Point(189, 37);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(71, 13);
            this.lblInterval.TabIndex = 16;
            this.lblInterval.Text = "Интервал, c:";
            // 
            // tbAdditional
            // 
            this.tbAdditional.BackColor = System.Drawing.Color.White;
            this.tbAdditional.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAdditional.ForeColor = System.Drawing.Color.Black;
            this.tbAdditional.Location = new System.Drawing.Point(21, 53);
            this.tbAdditional.MaxLength = 50;
            this.tbAdditional.Name = "tbAdditional";
            this.tbAdditional.Size = new System.Drawing.Size(149, 20);
            this.tbAdditional.TabIndex = 15;
            this.tbAdditional.WordWrap = false;
            this.tbAdditional.Enter += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            // 
            // lblAdditional
            // 
            this.lblAdditional.AutoSize = true;
            this.lblAdditional.ForeColor = System.Drawing.Color.White;
            this.lblAdditional.Location = new System.Drawing.Point(18, 37);
            this.lblAdditional.Name = "lblAdditional";
            this.lblAdditional.Size = new System.Drawing.Size(31, 13);
            this.lblAdditional.TabIndex = 14;
            this.lblAdditional.Text = "        ";
            // 
            // clbLinkedRules
            // 
            this.clbLinkedRules.BackColor = System.Drawing.Color.White;
            this.clbLinkedRules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.clbLinkedRules.ForeColor = System.Drawing.Color.Black;
            this.clbLinkedRules.FormattingEnabled = true;
            this.clbLinkedRules.IntegralHeight = false;
            this.clbLinkedRules.Location = new System.Drawing.Point(3, 27);
            this.clbLinkedRules.Name = "clbLinkedRules";
            this.clbLinkedRules.Size = new System.Drawing.Size(563, 127);
            this.clbLinkedRules.TabIndex = 0;
            // 
            // cbAlarmRule
            // 
            this.cbAlarmRule.AutoSize = true;
            this.cbAlarmRule.ForeColor = System.Drawing.Color.White;
            this.cbAlarmRule.Location = new System.Drawing.Point(293, 53);
            this.cbAlarmRule.Name = "cbAlarmRule";
            this.cbAlarmRule.Size = new System.Drawing.Size(263, 17);
            this.cbAlarmRule.TabIndex = 26;
            this.cbAlarmRule.Text = "Тревожное правило? (SMS при срабатывании)";
            this.cbAlarmRule.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(22, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(364, 134);
            this.panel2.TabIndex = 28;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel4.Controls.Add(this.label5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3);
            this.panel4.Size = new System.Drawing.Size(364, 26);
            this.panel4.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Beige;
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(358, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Основные настройки";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.cbLinkedModuleName);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.nudSensorIndex);
            this.panel3.Controls.Add(this.lblSensorIndex);
            this.panel3.Controls.Add(this.tbRuleName);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.cbWhich);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 26);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(364, 108);
            this.panel3.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.btnDaymask);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.nudWorkTime);
            this.panel5.Controls.Add(this.nudStartMinute);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.nudStartHour);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Location = new System.Drawing.Point(405, 22);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(189, 134);
            this.panel5.TabIndex = 29;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel6.Controls.Add(this.label9);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(189, 26);
            this.panel6.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Beige;
            this.label9.Location = new System.Drawing.Point(3, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(183, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Время работы";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SteelBlue;
            this.panel7.Controls.Add(this.cbAvailableActions);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.cbOperand);
            this.panel7.Controls.Add(this.tbSensorData);
            this.panel7.Controls.Add(this.lblSensorData);
            this.panel7.Location = new System.Drawing.Point(22, 168);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(572, 89);
            this.panel7.TabIndex = 30;
            // 
            // panel8
            // 
            this.panel8.AutoSize = true;
            this.panel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel8.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel8.Controls.Add(this.label10);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Padding = new System.Windows.Forms.Padding(3);
            this.panel8.Size = new System.Drawing.Size(572, 26);
            this.panel8.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Beige;
            this.label10.Location = new System.Drawing.Point(3, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(566, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Условие";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.SteelBlue;
            this.panel9.Controls.Add(this.wndOpenOnterval);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.lblInterval);
            this.panel9.Controls.Add(this.tbAdditional);
            this.panel9.Controls.Add(this.cbAlarmRule);
            this.panel9.Controls.Add(this.lblAdditional);
            this.panel9.Location = new System.Drawing.Point(22, 352);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(572, 94);
            this.panel9.TabIndex = 31;
            // 
            // panel10
            // 
            this.panel10.AutoSize = true;
            this.panel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel10.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel10.Controls.Add(this.label11);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Padding = new System.Windows.Forms.Padding(3);
            this.panel10.Size = new System.Drawing.Size(572, 26);
            this.panel10.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.Beige;
            this.label11.Location = new System.Drawing.Point(3, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(566, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Дополнительно, зависит от типа действия";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.SteelBlue;
            this.panel11.Controls.Add(this.clbLinkedRules);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Location = new System.Drawing.Point(22, 458);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(569, 157);
            this.panel11.TabIndex = 32;
            // 
            // panel12
            // 
            this.panel12.AutoSize = true;
            this.panel12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel12.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel12.Controls.Add(this.label12);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Padding = new System.Windows.Forms.Padding(3);
            this.panel12.Size = new System.Drawing.Size(569, 26);
            this.panel12.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.Beige;
            this.label12.Location = new System.Drawing.Point(3, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(563, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Если эти правила сработали - не выполнять текущее";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Location = new System.Drawing.Point(22, 269);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(572, 71);
            this.panel13.TabIndex = 33;
            // 
            // panel14
            // 
            this.panel14.AutoSize = true;
            this.panel14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel14.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel14.Controls.Add(this.label14);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Padding = new System.Windows.Forms.Padding(3);
            this.panel14.Size = new System.Drawing.Size(572, 26);
            this.panel14.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.Beige;
            this.label14.Location = new System.Drawing.Point(3, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(566, 20);
            this.label14.TabIndex = 1;
            this.label14.Text = "Подсказка";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(250)))), ((int)(((byte)(156)))));
            this.panel15.Controls.Add(this.lblHint);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 26);
            this.panel15.Name = "panel15";
            this.panel15.Padding = new System.Windows.Forms.Padding(6);
            this.panel15.Size = new System.Drawing.Size(572, 45);
            this.panel15.TabIndex = 3;
            // 
            // AddEditRuleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(617, 672);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEditRuleForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartMinute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWorkTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartHour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wndOpenOnterval)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.NumericUpDown nudSensorIndex;
        private System.Windows.Forms.Label lblSensorIndex;
        private System.Windows.Forms.ComboBox cbLinkedModuleName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbWhich;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbRuleName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbAvailableActions;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbSensorData;
        private System.Windows.Forms.ComboBox cbOperand;
        private System.Windows.Forms.Label lblSensorData;
        private System.Windows.Forms.NumericUpDown nudWorkTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudStartHour;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Label lblAdditional;
        private System.Windows.Forms.TextBox tbAdditional;
        private System.Windows.Forms.CheckedListBox clbLinkedRules;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudStartMinute;
        private System.Windows.Forms.Button btnDaymask;
        private System.Windows.Forms.NumericUpDown wndOpenOnterval;
        private System.Windows.Forms.Label lblInterval;
        private System.Windows.Forms.CheckBox cbAlarmRule;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label14;
    }
}