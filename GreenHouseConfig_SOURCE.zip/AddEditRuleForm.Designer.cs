﻿namespace GreenHouseConfig
{
    partial class AddEditRuleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nudSensorIndex = new System.Windows.Forms.NumericUpDown();
            this.lblSensorIndex = new System.Windows.Forms.Label();
            this.cbLinkedModuleName = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbWhich = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbRuleName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbAvailableActions = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbSensorData = new System.Windows.Forms.TextBox();
            this.cbOperand = new System.Windows.Forms.ComboBox();
            this.lblSensorData = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnDaymask = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.nudStartMinute = new System.Windows.Forms.NumericUpDown();
            this.nudWorkTime = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.nudStartHour = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblHint = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.wndOpenOnterval = new System.Windows.Forms.NumericUpDown();
            this.lblInterval = new System.Windows.Forms.Label();
            this.tbAdditional = new System.Windows.Forms.TextBox();
            this.lblAdditional = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.clbLinkedRules = new System.Windows.Forms.CheckedListBox();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartMinute)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWorkTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartHour)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wndOpenOnterval)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(507, 350);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(124, 32);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(508, 312);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(123, 32);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nudSensorIndex);
            this.groupBox4.Controls.Add(this.lblSensorIndex);
            this.groupBox4.Controls.Add(this.cbLinkedModuleName);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.cbWhich);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.tbRuleName);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(13, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox4.Size = new System.Drawing.Size(429, 121);
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Основные настройки";
            // 
            // nudSensorIndex
            // 
            this.nudSensorIndex.Location = new System.Drawing.Point(16, 82);
            this.nudSensorIndex.Name = "nudSensorIndex";
            this.nudSensorIndex.Size = new System.Drawing.Size(179, 20);
            this.nudSensorIndex.TabIndex = 15;
            // 
            // lblSensorIndex
            // 
            this.lblSensorIndex.AutoSize = true;
            this.lblSensorIndex.Location = new System.Drawing.Point(13, 65);
            this.lblSensorIndex.Name = "lblSensorIndex";
            this.lblSensorIndex.Size = new System.Drawing.Size(91, 13);
            this.lblSensorIndex.TabIndex = 14;
            this.lblSensorIndex.Text = "Индекс датчика:";
            // 
            // cbLinkedModuleName
            // 
            this.cbLinkedModuleName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLinkedModuleName.FormattingEnabled = true;
            this.cbLinkedModuleName.Location = new System.Drawing.Point(213, 81);
            this.cbLinkedModuleName.Name = "cbLinkedModuleName";
            this.cbLinkedModuleName.Size = new System.Drawing.Size(198, 21);
            this.cbLinkedModuleName.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(210, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(164, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Модуль, который опрашиваем:";
            // 
            // cbWhich
            // 
            this.cbWhich.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWhich.FormattingEnabled = true;
            this.cbWhich.Location = new System.Drawing.Point(213, 38);
            this.cbWhich.Name = "cbWhich";
            this.cbWhich.Size = new System.Drawing.Size(198, 21);
            this.cbWhich.TabIndex = 11;
            this.cbWhich.SelectedIndexChanged += new System.EventHandler(this.cbWhich_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(210, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Следим за:";
            // 
            // tbRuleName
            // 
            this.tbRuleName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbRuleName.Location = new System.Drawing.Point(16, 39);
            this.tbRuleName.MaxLength = 5;
            this.tbRuleName.Name = "tbRuleName";
            this.tbRuleName.Size = new System.Drawing.Size(179, 20);
            this.tbRuleName.TabIndex = 9;
            this.tbRuleName.WordWrap = false;
            this.tbRuleName.Enter += new System.EventHandler(this.tbRuleName_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Имя правила:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbAvailableActions);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.tbSensorData);
            this.groupBox3.Controls.Add(this.cbOperand);
            this.groupBox3.Controls.Add(this.lblSensorData);
            this.groupBox3.Location = new System.Drawing.Point(193, 140);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox3.Size = new System.Drawing.Size(247, 120);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Условия";
            // 
            // cbAvailableActions
            // 
            this.cbAvailableActions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAvailableActions.FormattingEnabled = true;
            this.cbAvailableActions.Location = new System.Drawing.Point(13, 86);
            this.cbAvailableActions.Name = "cbAvailableActions";
            this.cbAvailableActions.Size = new System.Drawing.Size(216, 21);
            this.cbAvailableActions.TabIndex = 21;
            this.cbAvailableActions.SelectedIndexChanged += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            this.cbAvailableActions.Enter += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Действие:";
            // 
            // tbSensorData
            // 
            this.tbSensorData.Location = new System.Drawing.Point(173, 38);
            this.tbSensorData.MaxLength = 10;
            this.tbSensorData.Name = "tbSensorData";
            this.tbSensorData.Size = new System.Drawing.Size(56, 20);
            this.tbSensorData.TabIndex = 19;
            this.tbSensorData.WordWrap = false;
            this.tbSensorData.Enter += new System.EventHandler(this.tbSensorData_Enter);
            // 
            // cbOperand
            // 
            this.cbOperand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbOperand.FormattingEnabled = true;
            this.cbOperand.Location = new System.Drawing.Point(13, 38);
            this.cbOperand.Name = "cbOperand";
            this.cbOperand.Size = new System.Drawing.Size(154, 21);
            this.cbOperand.TabIndex = 18;
            // 
            // lblSensorData
            // 
            this.lblSensorData.AutoSize = true;
            this.lblSensorData.Location = new System.Drawing.Point(10, 23);
            this.lblSensorData.Name = "lblSensorData";
            this.lblSensorData.Size = new System.Drawing.Size(109, 13);
            this.lblSensorData.TabIndex = 17;
            this.lblSensorData.Text = "Показания датчика:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnDaymask);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nudStartMinute);
            this.groupBox2.Controls.Add(this.nudWorkTime);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.nudStartHour);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(13, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox2.Size = new System.Drawing.Size(174, 120);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Время работы";
            // 
            // btnDaymask
            // 
            this.btnDaymask.Location = new System.Drawing.Point(110, 84);
            this.btnDaymask.Name = "btnDaymask";
            this.btnDaymask.Size = new System.Drawing.Size(51, 23);
            this.btnDaymask.TabIndex = 27;
            this.btnDaymask.Text = "Дни";
            this.btnDaymask.UseVisualStyleBackColor = true;
            this.btnDaymask.Click += new System.EventHandler(this.btnDaymask_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = ":";
            // 
            // nudStartMinute
            // 
            this.nudStartMinute.Location = new System.Drawing.Point(98, 39);
            this.nudStartMinute.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nudStartMinute.Name = "nudStartMinute";
            this.nudStartMinute.Size = new System.Drawing.Size(63, 20);
            this.nudStartMinute.TabIndex = 18;
            // 
            // nudWorkTime
            // 
            this.nudWorkTime.Location = new System.Drawing.Point(12, 86);
            this.nudWorkTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudWorkTime.Name = "nudWorkTime";
            this.nudWorkTime.Size = new System.Drawing.Size(92, 20);
            this.nudWorkTime.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Продолжительность, мин:";
            // 
            // nudStartHour
            // 
            this.nudStartHour.Location = new System.Drawing.Point(12, 39);
            this.nudStartHour.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.nudStartHour.Name = "nudStartHour";
            this.nudStartHour.Size = new System.Drawing.Size(63, 20);
            this.nudStartHour.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Начало:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Controls.Add(this.lblHint);
            this.groupBox1.Location = new System.Drawing.Point(448, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.Size = new System.Drawing.Size(180, 121);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Подсказка";
            // 
            // lblHint
            // 
            this.lblHint.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHint.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblHint.Location = new System.Drawing.Point(10, 23);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(160, 88);
            this.lblHint.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.wndOpenOnterval);
            this.groupBox5.Controls.Add(this.lblInterval);
            this.groupBox5.Controls.Add(this.tbAdditional);
            this.groupBox5.Controls.Add(this.lblAdditional);
            this.groupBox5.Location = new System.Drawing.Point(446, 140);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox5.Size = new System.Drawing.Size(180, 120);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Дополнительно";
            // 
            // wndOpenOnterval
            // 
            this.wndOpenOnterval.Enabled = false;
            this.wndOpenOnterval.Location = new System.Drawing.Point(12, 86);
            this.wndOpenOnterval.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.wndOpenOnterval.Name = "wndOpenOnterval";
            this.wndOpenOnterval.Size = new System.Drawing.Size(149, 20);
            this.wndOpenOnterval.TabIndex = 17;
            this.wndOpenOnterval.Enter += new System.EventHandler(this.wndOpenOnterval_Enter);
            // 
            // lblInterval
            // 
            this.lblInterval.AutoSize = true;
            this.lblInterval.Enabled = false;
            this.lblInterval.Location = new System.Drawing.Point(9, 68);
            this.lblInterval.Name = "lblInterval";
            this.lblInterval.Size = new System.Drawing.Size(71, 13);
            this.lblInterval.TabIndex = 16;
            this.lblInterval.Text = "Интервал, c:";
            // 
            // tbAdditional
            // 
            this.tbAdditional.Location = new System.Drawing.Point(12, 39);
            this.tbAdditional.MaxLength = 50;
            this.tbAdditional.Name = "tbAdditional";
            this.tbAdditional.Size = new System.Drawing.Size(149, 20);
            this.tbAdditional.TabIndex = 15;
            this.tbAdditional.WordWrap = false;
            this.tbAdditional.Enter += new System.EventHandler(this.cbAvailableActions_SelectedIndexChanged);
            // 
            // lblAdditional
            // 
            this.lblAdditional.AutoSize = true;
            this.lblAdditional.Location = new System.Drawing.Point(9, 23);
            this.lblAdditional.Name = "lblAdditional";
            this.lblAdditional.Size = new System.Drawing.Size(31, 13);
            this.lblAdditional.TabIndex = 14;
            this.lblAdditional.Text = "        ";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.clbLinkedRules);
            this.groupBox6.Location = new System.Drawing.Point(13, 266);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox6.Size = new System.Drawing.Size(427, 116);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Связанные правила";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Location = new System.Drawing.Point(10, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(350, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Правила, при выполнении которых текущее выполняться не будет:";
            // 
            // clbLinkedRules
            // 
            this.clbLinkedRules.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.clbLinkedRules.FormattingEnabled = true;
            this.clbLinkedRules.Location = new System.Drawing.Point(10, 42);
            this.clbLinkedRules.Name = "clbLinkedRules";
            this.clbLinkedRules.Size = new System.Drawing.Size(407, 64);
            this.clbLinkedRules.TabIndex = 0;
            // 
            // AddEditRuleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(644, 395);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEditRuleForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartMinute)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWorkTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudStartHour)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wndOpenOnterval)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown nudSensorIndex;
        private System.Windows.Forms.Label lblSensorIndex;
        private System.Windows.Forms.ComboBox cbLinkedModuleName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbWhich;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbRuleName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbAvailableActions;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbSensorData;
        private System.Windows.Forms.ComboBox cbOperand;
        private System.Windows.Forms.Label lblSensorData;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown nudWorkTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudStartHour;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblAdditional;
        private System.Windows.Forms.TextBox tbAdditional;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckedListBox clbLinkedRules;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudStartMinute;
        private System.Windows.Forms.Button btnDaymask;
        private System.Windows.Forms.NumericUpDown wndOpenOnterval;
        private System.Windows.Forms.Label lblInterval;
    }
}