﻿namespace GreenHouseConfig
{
    partial class UniversalSensorsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.plRFChannel = new System.Windows.Forms.Panel();
            this.nudRFChannel = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.plExecutionModule = new System.Windows.Forms.Panel();
            this.nudSlot8 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot8 = new System.Windows.Forms.ComboBox();
            this.nudSlot7 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot7 = new System.Windows.Forms.ComboBox();
            this.nudSlot6 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot6 = new System.Windows.Forms.ComboBox();
            this.nudSlot5 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot5 = new System.Windows.Forms.ComboBox();
            this.nudSlot4 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot4 = new System.Windows.Forms.ComboBox();
            this.nudSlot3 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot3 = new System.Windows.Forms.ComboBox();
            this.nudSlot2 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot2 = new System.Windows.Forms.ComboBox();
            this.nudSlot1 = new System.Windows.Forms.NumericUpDown();
            this.cbSlot1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.plModuleWithSensors = new System.Windows.Forms.Panel();
            this.cbRFEnabled = new System.Windows.Forms.CheckBox();
            this.nudQueryInterval = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nudSensor2 = new System.Windows.Forms.NumericUpDown();
            this.lblSensor2 = new System.Windows.Forms.Label();
            this.nudCalibrationFactor2 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nudSensor3 = new System.Windows.Forms.NumericUpDown();
            this.lblSensor3 = new System.Windows.Forms.Label();
            this.nudSensor1 = new System.Windows.Forms.NumericUpDown();
            this.lblSensor1 = new System.Windows.Forms.Label();
            this.nudCalibrationFactor1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.gbInfo = new System.Windows.Forms.GroupBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.plRFChannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRFChannel)).BeginInit();
            this.plExecutionModule.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot1)).BeginInit();
            this.plModuleWithSensors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQueryInterval)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalibrationFactor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalibrationFactor1)).BeginInit();
            this.gbInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(338, 365);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(123, 32);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(208, 365);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(124, 32);
            this.btnOk.TabIndex = 10;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(10, 10);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(455, 338);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.plRFChannel);
            this.tabPage1.Controls.Add(this.plExecutionModule);
            this.tabPage1.Controls.Add(this.plModuleWithSensors);
            this.tabPage1.Controls.Add(this.btnSearch);
            this.tabPage1.Controls.Add(this.btnRegister);
            this.tabPage1.Controls.Add(this.gbInfo);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(10);
            this.tabPage1.Size = new System.Drawing.Size(447, 312);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Регистрация по 1-Wire";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // plRFChannel
            // 
            this.plRFChannel.Controls.Add(this.nudRFChannel);
            this.plRFChannel.Controls.Add(this.label5);
            this.plRFChannel.Location = new System.Drawing.Point(306, 116);
            this.plRFChannel.Name = "plRFChannel";
            this.plRFChannel.Size = new System.Drawing.Size(124, 57);
            this.plRFChannel.TabIndex = 18;
            this.plRFChannel.Visible = false;
            // 
            // nudRFChannel
            // 
            this.nudRFChannel.Location = new System.Drawing.Point(2, 21);
            this.nudRFChannel.Maximum = new decimal(new int[] {
            120,
            0,
            0,
            0});
            this.nudRFChannel.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRFChannel.Name = "nudRFChannel";
            this.nudRFChannel.Size = new System.Drawing.Size(80, 20);
            this.nudRFChannel.TabIndex = 1;
            this.nudRFChannel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-1, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Номер канала RF:";
            // 
            // plExecutionModule
            // 
            this.plExecutionModule.Controls.Add(this.nudSlot8);
            this.plExecutionModule.Controls.Add(this.cbSlot8);
            this.plExecutionModule.Controls.Add(this.nudSlot7);
            this.plExecutionModule.Controls.Add(this.cbSlot7);
            this.plExecutionModule.Controls.Add(this.nudSlot6);
            this.plExecutionModule.Controls.Add(this.cbSlot6);
            this.plExecutionModule.Controls.Add(this.nudSlot5);
            this.plExecutionModule.Controls.Add(this.cbSlot5);
            this.plExecutionModule.Controls.Add(this.nudSlot4);
            this.plExecutionModule.Controls.Add(this.cbSlot4);
            this.plExecutionModule.Controls.Add(this.nudSlot3);
            this.plExecutionModule.Controls.Add(this.cbSlot3);
            this.plExecutionModule.Controls.Add(this.nudSlot2);
            this.plExecutionModule.Controls.Add(this.cbSlot2);
            this.plExecutionModule.Controls.Add(this.nudSlot1);
            this.plExecutionModule.Controls.Add(this.cbSlot1);
            this.plExecutionModule.Controls.Add(this.label3);
            this.plExecutionModule.Controls.Add(this.label2);
            this.plExecutionModule.Location = new System.Drawing.Point(13, 13);
            this.plExecutionModule.Name = "plExecutionModule";
            this.plExecutionModule.Size = new System.Drawing.Size(289, 203);
            this.plExecutionModule.TabIndex = 17;
            this.plExecutionModule.Visible = false;
            // 
            // nudSlot8
            // 
            this.nudSlot8.Location = new System.Drawing.Point(206, 178);
            this.nudSlot8.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot8.Name = "nudSlot8";
            this.nudSlot8.Size = new System.Drawing.Size(65, 20);
            this.nudSlot8.TabIndex = 17;
            // 
            // cbSlot8
            // 
            this.cbSlot8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot8.FormattingEnabled = true;
            this.cbSlot8.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot8.Location = new System.Drawing.Point(13, 177);
            this.cbSlot8.Name = "cbSlot8";
            this.cbSlot8.Size = new System.Drawing.Size(187, 21);
            this.cbSlot8.TabIndex = 16;
            // 
            // nudSlot7
            // 
            this.nudSlot7.Location = new System.Drawing.Point(206, 155);
            this.nudSlot7.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot7.Name = "nudSlot7";
            this.nudSlot7.Size = new System.Drawing.Size(65, 20);
            this.nudSlot7.TabIndex = 15;
            // 
            // cbSlot7
            // 
            this.cbSlot7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot7.FormattingEnabled = true;
            this.cbSlot7.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot7.Location = new System.Drawing.Point(13, 154);
            this.cbSlot7.Name = "cbSlot7";
            this.cbSlot7.Size = new System.Drawing.Size(187, 21);
            this.cbSlot7.TabIndex = 14;
            // 
            // nudSlot6
            // 
            this.nudSlot6.Location = new System.Drawing.Point(206, 132);
            this.nudSlot6.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot6.Name = "nudSlot6";
            this.nudSlot6.Size = new System.Drawing.Size(65, 20);
            this.nudSlot6.TabIndex = 13;
            // 
            // cbSlot6
            // 
            this.cbSlot6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot6.FormattingEnabled = true;
            this.cbSlot6.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot6.Location = new System.Drawing.Point(13, 131);
            this.cbSlot6.Name = "cbSlot6";
            this.cbSlot6.Size = new System.Drawing.Size(187, 21);
            this.cbSlot6.TabIndex = 12;
            // 
            // nudSlot5
            // 
            this.nudSlot5.Location = new System.Drawing.Point(206, 109);
            this.nudSlot5.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot5.Name = "nudSlot5";
            this.nudSlot5.Size = new System.Drawing.Size(65, 20);
            this.nudSlot5.TabIndex = 11;
            // 
            // cbSlot5
            // 
            this.cbSlot5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot5.FormattingEnabled = true;
            this.cbSlot5.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot5.Location = new System.Drawing.Point(13, 108);
            this.cbSlot5.Name = "cbSlot5";
            this.cbSlot5.Size = new System.Drawing.Size(187, 21);
            this.cbSlot5.TabIndex = 10;
            // 
            // nudSlot4
            // 
            this.nudSlot4.Location = new System.Drawing.Point(206, 86);
            this.nudSlot4.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot4.Name = "nudSlot4";
            this.nudSlot4.Size = new System.Drawing.Size(65, 20);
            this.nudSlot4.TabIndex = 9;
            // 
            // cbSlot4
            // 
            this.cbSlot4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot4.FormattingEnabled = true;
            this.cbSlot4.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot4.Location = new System.Drawing.Point(13, 85);
            this.cbSlot4.Name = "cbSlot4";
            this.cbSlot4.Size = new System.Drawing.Size(187, 21);
            this.cbSlot4.TabIndex = 8;
            // 
            // nudSlot3
            // 
            this.nudSlot3.Location = new System.Drawing.Point(206, 63);
            this.nudSlot3.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot3.Name = "nudSlot3";
            this.nudSlot3.Size = new System.Drawing.Size(65, 20);
            this.nudSlot3.TabIndex = 7;
            // 
            // cbSlot3
            // 
            this.cbSlot3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot3.FormattingEnabled = true;
            this.cbSlot3.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot3.Location = new System.Drawing.Point(13, 62);
            this.cbSlot3.Name = "cbSlot3";
            this.cbSlot3.Size = new System.Drawing.Size(187, 21);
            this.cbSlot3.TabIndex = 6;
            // 
            // nudSlot2
            // 
            this.nudSlot2.Location = new System.Drawing.Point(206, 40);
            this.nudSlot2.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot2.Name = "nudSlot2";
            this.nudSlot2.Size = new System.Drawing.Size(65, 20);
            this.nudSlot2.TabIndex = 5;
            // 
            // cbSlot2
            // 
            this.cbSlot2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot2.FormattingEnabled = true;
            this.cbSlot2.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot2.Location = new System.Drawing.Point(13, 39);
            this.cbSlot2.Name = "cbSlot2";
            this.cbSlot2.Size = new System.Drawing.Size(187, 21);
            this.cbSlot2.TabIndex = 4;
            // 
            // nudSlot1
            // 
            this.nudSlot1.Location = new System.Drawing.Point(206, 17);
            this.nudSlot1.Maximum = new decimal(new int[] {
            127,
            0,
            0,
            0});
            this.nudSlot1.Name = "nudSlot1";
            this.nudSlot1.Size = new System.Drawing.Size(65, 20);
            this.nudSlot1.TabIndex = 3;
            // 
            // cbSlot1
            // 
            this.cbSlot1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSlot1.FormattingEnabled = true;
            this.cbSlot1.Items.AddRange(new object[] {
            "Нет привязки",
            "Левый канал окна",
            "Правый канал окна",
            "Канал полива",
            "Канал досветки",
            "Номер пина"});
            this.cbSlot1.Location = new System.Drawing.Point(13, 16);
            this.cbSlot1.Name = "cbSlot1";
            this.cbSlot1.Size = new System.Drawing.Size(187, 21);
            this.cbSlot1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(203, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Индекс";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Тип привязки";
            // 
            // plModuleWithSensors
            // 
            this.plModuleWithSensors.Controls.Add(this.cbRFEnabled);
            this.plModuleWithSensors.Controls.Add(this.nudQueryInterval);
            this.plModuleWithSensors.Controls.Add(this.label4);
            this.plModuleWithSensors.Controls.Add(this.nudSensor2);
            this.plModuleWithSensors.Controls.Add(this.lblSensor2);
            this.plModuleWithSensors.Controls.Add(this.nudCalibrationFactor2);
            this.plModuleWithSensors.Controls.Add(this.label6);
            this.plModuleWithSensors.Controls.Add(this.nudSensor3);
            this.plModuleWithSensors.Controls.Add(this.lblSensor3);
            this.plModuleWithSensors.Controls.Add(this.nudSensor1);
            this.plModuleWithSensors.Controls.Add(this.lblSensor1);
            this.plModuleWithSensors.Controls.Add(this.nudCalibrationFactor1);
            this.plModuleWithSensors.Controls.Add(this.label1);
            this.plModuleWithSensors.Location = new System.Drawing.Point(13, 13);
            this.plModuleWithSensors.Name = "plModuleWithSensors";
            this.plModuleWithSensors.Size = new System.Drawing.Size(289, 194);
            this.plModuleWithSensors.TabIndex = 16;
            this.plModuleWithSensors.Visible = false;
            // 
            // cbRFEnabled
            // 
            this.cbRFEnabled.AutoSize = true;
            this.cbRFEnabled.Enabled = false;
            this.cbRFEnabled.Location = new System.Drawing.Point(13, 162);
            this.cbRFEnabled.Name = "cbRFEnabled";
            this.cbRFEnabled.Size = new System.Drawing.Size(138, 17);
            this.cbRFEnabled.TabIndex = 25;
            this.cbRFEnabled.Text = "Передатчик включён?";
            this.cbRFEnabled.UseVisualStyleBackColor = true;
            // 
            // nudQueryInterval
            // 
            this.nudQueryInterval.Enabled = false;
            this.nudQueryInterval.Location = new System.Drawing.Point(152, 130);
            this.nudQueryInterval.Maximum = new decimal(new int[] {
            915,
            0,
            0,
            0});
            this.nudQueryInterval.Name = "nudQueryInterval";
            this.nudQueryInterval.Size = new System.Drawing.Size(120, 20);
            this.nudQueryInterval.TabIndex = 24;
            this.nudQueryInterval.Enter += new System.EventHandler(this.nudQueryInterval_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(149, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Интервал, с:";
            // 
            // nudSensor2
            // 
            this.nudSensor2.Location = new System.Drawing.Point(151, 79);
            this.nudSensor2.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudSensor2.Name = "nudSensor2";
            this.nudSensor2.Size = new System.Drawing.Size(120, 20);
            this.nudSensor2.TabIndex = 22;
            this.nudSensor2.Enter += new System.EventHandler(this.nudSensor1_Enter);
            // 
            // lblSensor2
            // 
            this.lblSensor2.AutoSize = true;
            this.lblSensor2.Location = new System.Drawing.Point(148, 63);
            this.lblSensor2.Name = "lblSensor2";
            this.lblSensor2.Size = new System.Drawing.Size(56, 13);
            this.lblSensor2.TabIndex = 21;
            this.lblSensor2.Text = "Датчик 2:";
            // 
            // nudCalibrationFactor2
            // 
            this.nudCalibrationFactor2.Enabled = false;
            this.nudCalibrationFactor2.Location = new System.Drawing.Point(151, 29);
            this.nudCalibrationFactor2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudCalibrationFactor2.Name = "nudCalibrationFactor2";
            this.nudCalibrationFactor2.Size = new System.Drawing.Size(120, 20);
            this.nudCalibrationFactor2.TabIndex = 20;
            this.nudCalibrationFactor2.Enter += new System.EventHandler(this.nudCalibrationFactor1_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(148, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Калибровка 2:";
            // 
            // nudSensor3
            // 
            this.nudSensor3.Location = new System.Drawing.Point(14, 130);
            this.nudSensor3.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudSensor3.Name = "nudSensor3";
            this.nudSensor3.Size = new System.Drawing.Size(120, 20);
            this.nudSensor3.TabIndex = 18;
            this.nudSensor3.Enter += new System.EventHandler(this.nudSensor1_Enter);
            // 
            // lblSensor3
            // 
            this.lblSensor3.AutoSize = true;
            this.lblSensor3.Location = new System.Drawing.Point(11, 114);
            this.lblSensor3.Name = "lblSensor3";
            this.lblSensor3.Size = new System.Drawing.Size(56, 13);
            this.lblSensor3.TabIndex = 17;
            this.lblSensor3.Text = "Датчик 3:";
            // 
            // nudSensor1
            // 
            this.nudSensor1.Location = new System.Drawing.Point(13, 79);
            this.nudSensor1.Maximum = new decimal(new int[] {
            254,
            0,
            0,
            0});
            this.nudSensor1.Name = "nudSensor1";
            this.nudSensor1.Size = new System.Drawing.Size(120, 20);
            this.nudSensor1.TabIndex = 16;
            this.nudSensor1.Enter += new System.EventHandler(this.nudSensor1_Enter);
            // 
            // lblSensor1
            // 
            this.lblSensor1.AutoSize = true;
            this.lblSensor1.Location = new System.Drawing.Point(10, 63);
            this.lblSensor1.Name = "lblSensor1";
            this.lblSensor1.Size = new System.Drawing.Size(56, 13);
            this.lblSensor1.TabIndex = 15;
            this.lblSensor1.Text = "Датчик 1:";
            // 
            // nudCalibrationFactor1
            // 
            this.nudCalibrationFactor1.Enabled = false;
            this.nudCalibrationFactor1.Location = new System.Drawing.Point(13, 29);
            this.nudCalibrationFactor1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudCalibrationFactor1.Name = "nudCalibrationFactor1";
            this.nudCalibrationFactor1.Size = new System.Drawing.Size(120, 20);
            this.nudCalibrationFactor1.TabIndex = 14;
            this.nudCalibrationFactor1.Enter += new System.EventHandler(this.nudCalibrationFactor1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Калибровка 1:";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(308, 26);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(124, 32);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Поиск";
            this.toolTip1.SetToolTip(this.btnSearch, "Искать модуль на линии регистрации");
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Enabled = false;
            this.btnRegister.Location = new System.Drawing.Point(308, 66);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(124, 32);
            this.btnRegister.TabIndex = 14;
            this.btnRegister.Text = "Регистрация";
            this.toolTip1.SetToolTip(this.btnRegister, "Зарегистрировать модуль в контроллере");
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // gbInfo
            // 
            this.gbInfo.Controls.Add(this.lblInfo);
            this.gbInfo.Location = new System.Drawing.Point(17, 222);
            this.gbInfo.Name = "gbInfo";
            this.gbInfo.Padding = new System.Windows.Forms.Padding(10);
            this.gbInfo.Size = new System.Drawing.Size(415, 77);
            this.gbInfo.TabIndex = 13;
            this.gbInfo.TabStop = false;
            this.gbInfo.Text = "Информация";
            // 
            // lblInfo
            // 
            this.lblInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblInfo.Location = new System.Drawing.Point(10, 23);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(395, 44);
            this.lblInfo.TabIndex = 4;
            this.lblInfo.Text = "Присоедините модуль к линии регистрации 1-Wire и нажмите кнопку \"Поиск\".";
            // 
            // UniversalSensorsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(475, 410);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UniversalSensorsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Работа с универсальными модулями";
            this.Load += new System.EventHandler(this.UniversalSensorsForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.plRFChannel.ResumeLayout(false);
            this.plRFChannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRFChannel)).EndInit();
            this.plExecutionModule.ResumeLayout(false);
            this.plExecutionModule.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSlot1)).EndInit();
            this.plModuleWithSensors.ResumeLayout(false);
            this.plModuleWithSensors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQueryInterval)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalibrationFactor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCalibrationFactor1)).EndInit();
            this.gbInfo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox gbInfo;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.Button btnSearch;
        public System.Windows.Forms.Button btnRegister;
        public System.Windows.Forms.Label lblInfo;
        public System.Windows.Forms.CheckBox cbRFEnabled;
        public System.Windows.Forms.NumericUpDown nudQueryInterval;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.NumericUpDown nudSensor2;
        private System.Windows.Forms.Label lblSensor2;
        public System.Windows.Forms.NumericUpDown nudCalibrationFactor2;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.NumericUpDown nudSensor3;
        private System.Windows.Forms.Label lblSensor3;
        public System.Windows.Forms.NumericUpDown nudSensor1;
        private System.Windows.Forms.Label lblSensor1;
        public System.Windows.Forms.NumericUpDown nudCalibrationFactor1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel plModuleWithSensors;
        public System.Windows.Forms.Panel plExecutionModule;
        public System.Windows.Forms.NumericUpDown nudSlot8;
        public System.Windows.Forms.ComboBox cbSlot8;
        public System.Windows.Forms.NumericUpDown nudSlot7;
        public System.Windows.Forms.ComboBox cbSlot7;
        public System.Windows.Forms.NumericUpDown nudSlot6;
        public System.Windows.Forms.ComboBox cbSlot6;
        public System.Windows.Forms.NumericUpDown nudSlot5;
        public System.Windows.Forms.ComboBox cbSlot5;
        public System.Windows.Forms.NumericUpDown nudSlot4;
        public System.Windows.Forms.ComboBox cbSlot4;
        public System.Windows.Forms.NumericUpDown nudSlot3;
        public System.Windows.Forms.ComboBox cbSlot3;
        public System.Windows.Forms.NumericUpDown nudSlot2;
        public System.Windows.Forms.ComboBox cbSlot2;
        public System.Windows.Forms.NumericUpDown nudSlot1;
        public System.Windows.Forms.ComboBox cbSlot1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Panel plRFChannel;
        public System.Windows.Forms.NumericUpDown nudRFChannel;
    }
}