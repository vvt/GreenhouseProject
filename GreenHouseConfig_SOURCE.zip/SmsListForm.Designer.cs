﻿namespace GreenHouseConfig
{
    partial class SmsListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvSMSList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lvSMSList
            // 
            this.lvSMSList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvSMSList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvSMSList.FullRowSelect = true;
            this.lvSMSList.GridLines = true;
            this.lvSMSList.HideSelection = false;
            this.lvSMSList.LabelWrap = false;
            this.lvSMSList.Location = new System.Drawing.Point(0, 0);
            this.lvSMSList.MultiSelect = false;
            this.lvSMSList.Name = "lvSMSList";
            this.lvSMSList.ShowItemToolTips = true;
            this.lvSMSList.Size = new System.Drawing.Size(579, 262);
            this.lvSMSList.TabIndex = 0;
            this.lvSMSList.UseCompatibleStateImageBehavior = false;
            this.lvSMSList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Текст СМС";
            this.columnHeader1.Width = 160;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Команда";
            this.columnHeader2.Width = 160;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Ответ";
            this.columnHeader3.Width = 220;
            // 
            // SmsListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 262);
            this.Controls.Add(this.lvSMSList);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SmsListForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Список ранее добавленных СМС";
            this.Load += new System.EventHandler(this.SmsListForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvSMSList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}