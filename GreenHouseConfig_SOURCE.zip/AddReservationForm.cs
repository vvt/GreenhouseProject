﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class AddReservationForm : Form
    {
        public AddReservationForm()
        {
            InitializeComponent();
        }

        private void AddReservationForm_Load(object sender, EventArgs e)
        {
            var enumType = typeof(SensorType);

            foreach (SensorType st in Enum.GetValues(typeof(SensorType)))
            {
                if (st != SensorType.None && st != SensorType.PH)
                {
                    var memInfo = enumType.GetMember(st.ToString());
                    var atrrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
                    string displayName = st.ToString();

                    if (atrrs != null && atrrs.Count() > 0)
                    {
                        DescriptionAttribute enAttr = (DescriptionAttribute)atrrs[0];
                        displayName = enAttr.ToString();

                    }

                    this.cbReservationType.Items.Add(new SensorTypePair(st, displayName));
                }
            } // foreach
            this.cbReservationType.SelectedIndex = 0;
        }

        private void cbReservationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            SensorTypePair stPair = (SensorTypePair)cbReservationType.Items[cbReservationType.SelectedIndex];
            int sensorsCount = AppSettings.Instance.FirmwareSettings[stPair.Type];
           // sensorsCount +=  AppSettings.Instance.UniversalModulesSettings[stPair.Type];
            string moduleName = "";

            if (stPair.Type == SensorType.Temperature)
                moduleName = "STATE";
            else
                if (stPair.Type == SensorType.Luminosity)
                    moduleName = "LIGHT";
                else
                    if (stPair.Type == SensorType.Humidity)
                        moduleName = "HUMIDITY";
                    else
                        if (stPair.Type == SensorType.SoilMoisture)
                            moduleName = "SOIL";


            this.lbSensorsList.Items.Clear();

            // добавляем основную информацию о датчикахх в модуле
            for (var i = 0; i < sensorsCount; i++)
            {
                this.lbSensorsList.Items.Add(new ReservationInfo(moduleName, i));
            } // for

            // температуру резервируем с датчиков влажности так же
            if (stPair.Type == SensorType.Temperature)
            {
                sensorsCount = AppSettings.Instance.FirmwareSettings[SensorType.Humidity];
                moduleName = "HUMIDITY";
                 for (var i = 0; i < sensorsCount; i++)
                     this.lbSensorsList.Items.Add(new ReservationInfo(moduleName, i));
            }


        }

        private void btnOk_Click(object sender, EventArgs e)
        {

            // ищем, сколько выделено датчиков
            if (this.lbSensorsList.CheckedIndices.Count < 2)
            {
                MessageBox.Show("Пожалуйста, укажите по крайней мере два датчика, которые будут резервировать друг друга!");
                return;
            }

            if (this.lbSensorsList.CheckedIndices.Count > 9)
            {
                MessageBox.Show("Максимальное кол-во датчиков в одном списке резервирования - 10!");
                return;
            }

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }

    public class SensorTypePair
    {
        public SensorType Type { get; set; }
        public string DisplayName { get; set; }
        public SensorTypePair(SensorType st, string descr)
        {
            this.Type = st;
            this.DisplayName = descr;
        }
        public override string ToString()
        {
            return this.DisplayName;
        }
    }

}
