﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class TimersForm : Form
    {
        public TimersForm()
        {
            InitializeComponent();
        }

        private void TimersForm_Load(object sender, EventArgs e)
        {
            AppSettings sett = AppSettings.Instance;
            LoadTimerSettings(sett.Timers[0],0);
            LoadTimerSettings(sett.Timers[1], 1);
            LoadTimerSettings(sett.Timers[2], 2);
            LoadTimerSettings(sett.Timers[3], 3);

        }

        private void LoadTimerSettings(TimerSettings ts, int timerNum)
        {
            string prefix = "tmr" + (timerNum+1);
            NumericUpDown timerPin = this.Controls.Find(prefix + "Pin", true)[0] as NumericUpDown;
            NumericUpDown timerOnMin = this.Controls.Find(prefix + "OnMin", true)[0] as NumericUpDown;
            NumericUpDown timerOnSec = this.Controls.Find(prefix + "OnSec", true)[0] as NumericUpDown;
            NumericUpDown timerOffMin = this.Controls.Find(prefix + "OffMin", true)[0] as NumericUpDown;
            NumericUpDown timerOffSec = this.Controls.Find(prefix + "OffSec", true)[0] as NumericUpDown;
            CheckBox timerEnabled = this.Controls.Find(prefix + "Enabled", true)[0] as CheckBox;
            CheckedListBox timerDays = this.Controls.Find(prefix + "Days", true)[0] as CheckedListBox;

            try
            {
                timerPin.Value = ts.Pin;
            }
            catch { }

            try
            {
                timerOnMin.Value = ts.HoldOnTime / 60;
            }
            catch { }
            try
            {
                timerOnSec.Value = ts.HoldOnTime % 60;
            }
            catch { }

            try
            {
                timerOffMin.Value = ts.HoldOffTime / 60;
            }
            catch { }
            try
            {
                timerOffSec.Value = ts.HoldOffTime % 60;
            }
            catch { }

            timerEnabled.Checked = (ts.DayMaskAndEnable & 128) == 128;

            // теперь устанавливаем дни
            for(int i=0;i<timerDays.Items.Count;i++)
                timerDays.SetItemChecked(i,false);

            for (int i = 0; i < 7; i++)
            {
                if((ts.DayMaskAndEnable & (1 << i)) == (1 << i))
                    timerDays.SetItemChecked(i, true);
            }

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            AppSettings sett = AppSettings.Instance;

            for (int i = 0; i < 4; i++)
            {
                TimerSettings ts = sett.Timers[i];

                string prefix = "tmr" + (i + 1);
                NumericUpDown timerPin = this.Controls.Find(prefix + "Pin", true)[0] as NumericUpDown;
                NumericUpDown timerOnMin = this.Controls.Find(prefix + "OnMin", true)[0] as NumericUpDown;
                NumericUpDown timerOnSec = this.Controls.Find(prefix + "OnSec", true)[0] as NumericUpDown;
                NumericUpDown timerOffMin = this.Controls.Find(prefix + "OffMin", true)[0] as NumericUpDown;
                NumericUpDown timerOffSec = this.Controls.Find(prefix + "OffSec", true)[0] as NumericUpDown;
                CheckBox timerEnabled = this.Controls.Find(prefix + "Enabled", true)[0] as CheckBox;
                CheckedListBox timerDays = this.Controls.Find(prefix + "Days", true)[0] as CheckedListBox;

                ts.DayMaskAndEnable = 0;
                if (timerEnabled.Checked)
                    ts.DayMaskAndEnable |= 128;

                ts.Pin = Convert.ToByte(timerPin.Value);
                int onTime = Convert.ToInt32(timerOnMin.Value * 60 + timerOnSec.Value);
                int offTime = Convert.ToInt32(timerOffMin.Value * 60 + timerOffSec.Value);

                ts.HoldOnTime = onTime;
                ts.HoldOffTime = offTime;

                for (int k = 0; k < 7; k++)
                {
                    if (timerDays.GetItemChecked(k))
                    {
                        ts.DayMaskAndEnable |= Convert.ToByte((1 << k));
                    }
                }

            } // for

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
