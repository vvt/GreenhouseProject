﻿namespace GreenHouseConfig
{
    partial class TimersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tmr1Days = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tmr1OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr1OffMin = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tmr1OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr1OnMin = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.tmr1Pin = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.tmr1Enabled = new System.Windows.Forms.CheckBox();
            this.tmr2Days = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tmr2OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr2OffMin = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tmr2OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr2OnMin = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.tmr2Pin = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.tmr2Enabled = new System.Windows.Forms.CheckBox();
            this.tmr3Days = new System.Windows.Forms.CheckedListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tmr3OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr3OffMin = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tmr3OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr3OnMin = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.tmr3Pin = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.tmr3Enabled = new System.Windows.Forms.CheckBox();
            this.tmr4Days = new System.Windows.Forms.CheckedListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tmr4OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr4OffMin = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tmr4OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr4OnMin = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.tmr4Pin = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.tmr4Enabled = new System.Windows.Forms.CheckBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1Pin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2Pin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3Pin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4Pin)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmr1Days
            // 
            this.tmr1Days.BackColor = System.Drawing.Color.White;
            this.tmr1Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1Days.CheckOnClick = true;
            this.tmr1Days.ForeColor = System.Drawing.Color.Black;
            this.tmr1Days.FormattingEnabled = true;
            this.tmr1Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr1Days.Location = new System.Drawing.Point(161, 43);
            this.tmr1Days.Name = "tmr1Days";
            this.tmr1Days.Size = new System.Drawing.Size(120, 137);
            this.tmr1Days.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(86, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = ":";
            // 
            // tmr1OffSec
            // 
            this.tmr1OffSec.BackColor = System.Drawing.Color.White;
            this.tmr1OffSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1OffSec.ForeColor = System.Drawing.Color.Black;
            this.tmr1OffSec.Location = new System.Drawing.Point(98, 131);
            this.tmr1OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1OffSec.Name = "tmr1OffSec";
            this.tmr1OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr1OffSec.TabIndex = 11;
            // 
            // tmr1OffMin
            // 
            this.tmr1OffMin.BackColor = System.Drawing.Color.White;
            this.tmr1OffMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1OffMin.ForeColor = System.Drawing.Color.Black;
            this.tmr1OffMin.Location = new System.Drawing.Point(22, 131);
            this.tmr1OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr1OffMin.Name = "tmr1OffMin";
            this.tmr1OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr1OffMin.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(19, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Выключен (мин, сек):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = ":";
            // 
            // tmr1OnSec
            // 
            this.tmr1OnSec.BackColor = System.Drawing.Color.White;
            this.tmr1OnSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1OnSec.ForeColor = System.Drawing.Color.Black;
            this.tmr1OnSec.Location = new System.Drawing.Point(98, 87);
            this.tmr1OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1OnSec.Name = "tmr1OnSec";
            this.tmr1OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr1OnSec.TabIndex = 7;
            // 
            // tmr1OnMin
            // 
            this.tmr1OnMin.BackColor = System.Drawing.Color.White;
            this.tmr1OnMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1OnMin.ForeColor = System.Drawing.Color.Black;
            this.tmr1OnMin.Location = new System.Drawing.Point(22, 87);
            this.tmr1OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr1OnMin.Name = "tmr1OnMin";
            this.tmr1OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr1OnMin.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(19, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Включён (мин, сек):";
            // 
            // tmr1Pin
            // 
            this.tmr1Pin.BackColor = System.Drawing.Color.White;
            this.tmr1Pin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr1Pin.ForeColor = System.Drawing.Color.Black;
            this.tmr1Pin.Location = new System.Drawing.Point(98, 43);
            this.tmr1Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1Pin.Name = "tmr1Pin";
            this.tmr1Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr1Pin.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(19, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Номер пина:";
            // 
            // tmr1Enabled
            // 
            this.tmr1Enabled.AutoSize = true;
            this.tmr1Enabled.ForeColor = System.Drawing.Color.White;
            this.tmr1Enabled.Location = new System.Drawing.Point(22, 165);
            this.tmr1Enabled.Name = "tmr1Enabled";
            this.tmr1Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr1Enabled.TabIndex = 2;
            this.tmr1Enabled.Text = "Таймер активен?";
            this.tmr1Enabled.UseVisualStyleBackColor = true;
            // 
            // tmr2Days
            // 
            this.tmr2Days.BackColor = System.Drawing.Color.White;
            this.tmr2Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2Days.CheckOnClick = true;
            this.tmr2Days.ForeColor = System.Drawing.Color.Black;
            this.tmr2Days.FormattingEnabled = true;
            this.tmr2Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr2Days.Location = new System.Drawing.Point(161, 43);
            this.tmr2Days.Name = "tmr2Days";
            this.tmr2Days.Size = new System.Drawing.Size(120, 137);
            this.tmr2Days.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(86, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = ":";
            // 
            // tmr2OffSec
            // 
            this.tmr2OffSec.BackColor = System.Drawing.Color.White;
            this.tmr2OffSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2OffSec.ForeColor = System.Drawing.Color.Black;
            this.tmr2OffSec.Location = new System.Drawing.Point(98, 131);
            this.tmr2OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2OffSec.Name = "tmr2OffSec";
            this.tmr2OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr2OffSec.TabIndex = 11;
            // 
            // tmr2OffMin
            // 
            this.tmr2OffMin.BackColor = System.Drawing.Color.White;
            this.tmr2OffMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2OffMin.ForeColor = System.Drawing.Color.Black;
            this.tmr2OffMin.Location = new System.Drawing.Point(22, 131);
            this.tmr2OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr2OffMin.Name = "tmr2OffMin";
            this.tmr2OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr2OffMin.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(19, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Выключен (мин, сек):";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(86, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = ":";
            // 
            // tmr2OnSec
            // 
            this.tmr2OnSec.BackColor = System.Drawing.Color.White;
            this.tmr2OnSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2OnSec.ForeColor = System.Drawing.Color.Black;
            this.tmr2OnSec.Location = new System.Drawing.Point(98, 87);
            this.tmr2OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2OnSec.Name = "tmr2OnSec";
            this.tmr2OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr2OnSec.TabIndex = 7;
            // 
            // tmr2OnMin
            // 
            this.tmr2OnMin.BackColor = System.Drawing.Color.White;
            this.tmr2OnMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2OnMin.ForeColor = System.Drawing.Color.Black;
            this.tmr2OnMin.Location = new System.Drawing.Point(22, 87);
            this.tmr2OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr2OnMin.Name = "tmr2OnMin";
            this.tmr2OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr2OnMin.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(19, 71);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Включён (мин, сек):";
            // 
            // tmr2Pin
            // 
            this.tmr2Pin.BackColor = System.Drawing.Color.White;
            this.tmr2Pin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr2Pin.ForeColor = System.Drawing.Color.Black;
            this.tmr2Pin.Location = new System.Drawing.Point(98, 43);
            this.tmr2Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2Pin.Name = "tmr2Pin";
            this.tmr2Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr2Pin.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(19, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Номер пина:";
            // 
            // tmr2Enabled
            // 
            this.tmr2Enabled.AutoSize = true;
            this.tmr2Enabled.ForeColor = System.Drawing.Color.White;
            this.tmr2Enabled.Location = new System.Drawing.Point(22, 165);
            this.tmr2Enabled.Name = "tmr2Enabled";
            this.tmr2Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr2Enabled.TabIndex = 2;
            this.tmr2Enabled.Text = "Таймер активен?";
            this.tmr2Enabled.UseVisualStyleBackColor = true;
            // 
            // tmr3Days
            // 
            this.tmr3Days.BackColor = System.Drawing.Color.White;
            this.tmr3Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3Days.CheckOnClick = true;
            this.tmr3Days.ForeColor = System.Drawing.Color.Black;
            this.tmr3Days.FormattingEnabled = true;
            this.tmr3Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr3Days.Location = new System.Drawing.Point(161, 43);
            this.tmr3Days.Name = "tmr3Days";
            this.tmr3Days.Size = new System.Drawing.Size(120, 137);
            this.tmr3Days.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(86, 133);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = ":";
            // 
            // tmr3OffSec
            // 
            this.tmr3OffSec.BackColor = System.Drawing.Color.White;
            this.tmr3OffSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3OffSec.ForeColor = System.Drawing.Color.Black;
            this.tmr3OffSec.Location = new System.Drawing.Point(98, 131);
            this.tmr3OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3OffSec.Name = "tmr3OffSec";
            this.tmr3OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr3OffSec.TabIndex = 11;
            // 
            // tmr3OffMin
            // 
            this.tmr3OffMin.BackColor = System.Drawing.Color.White;
            this.tmr3OffMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3OffMin.ForeColor = System.Drawing.Color.Black;
            this.tmr3OffMin.Location = new System.Drawing.Point(22, 131);
            this.tmr3OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr3OffMin.Name = "tmr3OffMin";
            this.tmr3OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr3OffMin.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(19, 115);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Выключен (мин, сек):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(86, 89);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = ":";
            // 
            // tmr3OnSec
            // 
            this.tmr3OnSec.BackColor = System.Drawing.Color.White;
            this.tmr3OnSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3OnSec.ForeColor = System.Drawing.Color.Black;
            this.tmr3OnSec.Location = new System.Drawing.Point(98, 87);
            this.tmr3OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3OnSec.Name = "tmr3OnSec";
            this.tmr3OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr3OnSec.TabIndex = 7;
            // 
            // tmr3OnMin
            // 
            this.tmr3OnMin.BackColor = System.Drawing.Color.White;
            this.tmr3OnMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3OnMin.ForeColor = System.Drawing.Color.Black;
            this.tmr3OnMin.Location = new System.Drawing.Point(22, 87);
            this.tmr3OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr3OnMin.Name = "tmr3OnMin";
            this.tmr3OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr3OnMin.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(19, 71);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Включён (мин, сек):";
            // 
            // tmr3Pin
            // 
            this.tmr3Pin.BackColor = System.Drawing.Color.White;
            this.tmr3Pin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr3Pin.ForeColor = System.Drawing.Color.Black;
            this.tmr3Pin.Location = new System.Drawing.Point(98, 43);
            this.tmr3Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3Pin.Name = "tmr3Pin";
            this.tmr3Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr3Pin.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(19, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Номер пина:";
            // 
            // tmr3Enabled
            // 
            this.tmr3Enabled.AutoSize = true;
            this.tmr3Enabled.ForeColor = System.Drawing.Color.White;
            this.tmr3Enabled.Location = new System.Drawing.Point(22, 165);
            this.tmr3Enabled.Name = "tmr3Enabled";
            this.tmr3Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr3Enabled.TabIndex = 2;
            this.tmr3Enabled.Text = "Таймер активен?";
            this.tmr3Enabled.UseVisualStyleBackColor = true;
            // 
            // tmr4Days
            // 
            this.tmr4Days.BackColor = System.Drawing.Color.White;
            this.tmr4Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4Days.CheckOnClick = true;
            this.tmr4Days.ForeColor = System.Drawing.Color.Black;
            this.tmr4Days.FormattingEnabled = true;
            this.tmr4Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr4Days.Location = new System.Drawing.Point(161, 43);
            this.tmr4Days.Name = "tmr4Days";
            this.tmr4Days.Size = new System.Drawing.Size(120, 137);
            this.tmr4Days.TabIndex = 13;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(86, 133);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(10, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = ":";
            // 
            // tmr4OffSec
            // 
            this.tmr4OffSec.BackColor = System.Drawing.Color.White;
            this.tmr4OffSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4OffSec.ForeColor = System.Drawing.Color.Black;
            this.tmr4OffSec.Location = new System.Drawing.Point(98, 131);
            this.tmr4OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4OffSec.Name = "tmr4OffSec";
            this.tmr4OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr4OffSec.TabIndex = 11;
            // 
            // tmr4OffMin
            // 
            this.tmr4OffMin.BackColor = System.Drawing.Color.White;
            this.tmr4OffMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4OffMin.ForeColor = System.Drawing.Color.Black;
            this.tmr4OffMin.Location = new System.Drawing.Point(22, 131);
            this.tmr4OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr4OffMin.Name = "tmr4OffMin";
            this.tmr4OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr4OffMin.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(19, 115);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Выключен (мин, сек):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(86, 89);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = ":";
            // 
            // tmr4OnSec
            // 
            this.tmr4OnSec.BackColor = System.Drawing.Color.White;
            this.tmr4OnSec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4OnSec.ForeColor = System.Drawing.Color.Black;
            this.tmr4OnSec.Location = new System.Drawing.Point(98, 87);
            this.tmr4OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4OnSec.Name = "tmr4OnSec";
            this.tmr4OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr4OnSec.TabIndex = 7;
            // 
            // tmr4OnMin
            // 
            this.tmr4OnMin.BackColor = System.Drawing.Color.White;
            this.tmr4OnMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4OnMin.ForeColor = System.Drawing.Color.Black;
            this.tmr4OnMin.Location = new System.Drawing.Point(22, 87);
            this.tmr4OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr4OnMin.Name = "tmr4OnMin";
            this.tmr4OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr4OnMin.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(19, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Включён (мин, сек):";
            // 
            // tmr4Pin
            // 
            this.tmr4Pin.BackColor = System.Drawing.Color.White;
            this.tmr4Pin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tmr4Pin.ForeColor = System.Drawing.Color.Black;
            this.tmr4Pin.Location = new System.Drawing.Point(98, 43);
            this.tmr4Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4Pin.Name = "tmr4Pin";
            this.tmr4Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr4Pin.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(19, 45);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Номер пина:";
            // 
            // tmr4Enabled
            // 
            this.tmr4Enabled.AutoSize = true;
            this.tmr4Enabled.ForeColor = System.Drawing.Color.White;
            this.tmr4Enabled.Location = new System.Drawing.Point(22, 165);
            this.tmr4Enabled.Name = "tmr4Enabled";
            this.tmr4Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr4Enabled.TabIndex = 2;
            this.tmr4Enabled.Text = "Таймер активен?";
            this.tmr4Enabled.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(544, 442);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 38);
            this.btnCancel.TabIndex = 26;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.LightGreen;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.ForeColor = System.Drawing.Color.Black;
            this.btnOk.Location = new System.Drawing.Point(452, 442);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(86, 38);
            this.btnOk.TabIndex = 25;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.tmr1Days);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.tmr1OffMin);
            this.panel1.Controls.Add(this.tmr1OffSec);
            this.panel1.Controls.Add(this.tmr1Enabled);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tmr1Pin);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tmr1OnSec);
            this.panel1.Controls.Add(this.tmr1OnMin);
            this.panel1.Location = new System.Drawing.Point(18, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 200);
            this.panel1.TabIndex = 43;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.label21);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(300, 26);
            this.panel2.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.Dock = System.Windows.Forms.DockStyle.Top;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.ForeColor = System.Drawing.Color.Beige;
            this.label21.Location = new System.Drawing.Point(3, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(294, 20);
            this.label21.TabIndex = 1;
            this.label21.Text = "Таймер №1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.tmr3Days);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.tmr3OnMin);
            this.panel3.Controls.Add(this.tmr3OffSec);
            this.panel3.Controls.Add(this.tmr3Enabled);
            this.panel3.Controls.Add(this.tmr3OffMin);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.tmr3Pin);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.tmr3OnSec);
            this.panel3.Location = new System.Drawing.Point(18, 226);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 200);
            this.panel3.TabIndex = 44;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel4.Controls.Add(this.label22);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(3);
            this.panel4.Size = new System.Drawing.Size(300, 26);
            this.panel4.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Top;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.Beige;
            this.label22.Location = new System.Drawing.Point(3, 3);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(294, 20);
            this.label22.TabIndex = 1;
            this.label22.Text = "Таймер №3";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.tmr2Days);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.tmr2OnMin);
            this.panel5.Controls.Add(this.tmr2OffSec);
            this.panel5.Controls.Add(this.tmr2Enabled);
            this.panel5.Controls.Add(this.tmr2OffMin);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.tmr2Pin);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.tmr2OnSec);
            this.panel5.Location = new System.Drawing.Point(330, 13);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(300, 200);
            this.panel5.TabIndex = 45;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel6.Controls.Add(this.label23);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(300, 26);
            this.panel6.TabIndex = 1;
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Top;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.ForeColor = System.Drawing.Color.Beige;
            this.label23.Location = new System.Drawing.Point(3, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(294, 20);
            this.label23.TabIndex = 1;
            this.label23.Text = "Таймер №2";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SteelBlue;
            this.panel7.Controls.Add(this.tmr4Days);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.tmr4OnMin);
            this.panel7.Controls.Add(this.tmr4OffSec);
            this.panel7.Controls.Add(this.tmr4Enabled);
            this.panel7.Controls.Add(this.tmr4OffMin);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Controls.Add(this.label17);
            this.panel7.Controls.Add(this.tmr4Pin);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.tmr4OnSec);
            this.panel7.Location = new System.Drawing.Point(330, 226);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(300, 200);
            this.panel7.TabIndex = 46;
            // 
            // panel8
            // 
            this.panel8.AutoSize = true;
            this.panel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel8.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel8.Controls.Add(this.label24);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Padding = new System.Windows.Forms.Padding(3);
            this.panel8.Size = new System.Drawing.Size(300, 26);
            this.panel8.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.Dock = System.Windows.Forms.DockStyle.Top;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.Color.Beige;
            this.label24.Location = new System.Drawing.Point(3, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(294, 20);
            this.label24.TabIndex = 1;
            this.label24.Text = "Таймер №4";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TimersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(648, 494);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TimersForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки таймеров";
            this.Load += new System.EventHandler(this.TimersForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1Pin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2Pin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3Pin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4Pin)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox tmr1Enabled;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown tmr1OnSec;
        private System.Windows.Forms.NumericUpDown tmr1OnMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown tmr1Pin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown tmr1OffSec;
        private System.Windows.Forms.NumericUpDown tmr1OffMin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox tmr1Days;
        private System.Windows.Forms.CheckedListBox tmr2Days;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown tmr2OffSec;
        private System.Windows.Forms.NumericUpDown tmr2OffMin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown tmr2OnSec;
        private System.Windows.Forms.NumericUpDown tmr2OnMin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown tmr2Pin;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox tmr2Enabled;
        private System.Windows.Forms.CheckedListBox tmr3Days;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown tmr3OffSec;
        private System.Windows.Forms.NumericUpDown tmr3OffMin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown tmr3OnSec;
        private System.Windows.Forms.NumericUpDown tmr3OnMin;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown tmr3Pin;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox tmr3Enabled;
        private System.Windows.Forms.CheckedListBox tmr4Days;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown tmr4OffSec;
        private System.Windows.Forms.NumericUpDown tmr4OffMin;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown tmr4OnSec;
        private System.Windows.Forms.NumericUpDown tmr4OnMin;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown tmr4Pin;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox tmr4Enabled;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label24;
    }
}