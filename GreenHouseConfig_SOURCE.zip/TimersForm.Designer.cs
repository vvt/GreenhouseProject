﻿namespace GreenHouseConfig
{
    partial class TimersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tmr1Days = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tmr1OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr1OffMin = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tmr1OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr1OnMin = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.tmr1Pin = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.tmr1Enabled = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tmr2Days = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tmr2OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr2OffMin = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tmr2OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr2OnMin = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.tmr2Pin = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.tmr2Enabled = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tmr3Days = new System.Windows.Forms.CheckedListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tmr3OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr3OffMin = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tmr3OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr3OnMin = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.tmr3Pin = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.tmr3Enabled = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tmr4Days = new System.Windows.Forms.CheckedListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tmr4OffSec = new System.Windows.Forms.NumericUpDown();
            this.tmr4OffMin = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tmr4OnSec = new System.Windows.Forms.NumericUpDown();
            this.tmr4OnMin = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.tmr4Pin = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.tmr4Enabled = new System.Windows.Forms.CheckBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1Pin)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2Pin)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3Pin)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnSec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4Pin)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tmr1Days);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tmr1OffSec);
            this.groupBox1.Controls.Add(this.tmr1OffMin);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tmr1OnSec);
            this.groupBox1.Controls.Add(this.tmr1OnMin);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tmr1Pin);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tmr1Enabled);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox1.Size = new System.Drawing.Size(284, 176);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Таймер 1";
            // 
            // tmr1Days
            // 
            this.tmr1Days.CheckOnClick = true;
            this.tmr1Days.FormattingEnabled = true;
            this.tmr1Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr1Days.Location = new System.Drawing.Point(153, 19);
            this.tmr1Days.Name = "tmr1Days";
            this.tmr1Days.Size = new System.Drawing.Size(120, 139);
            this.tmr1Days.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = ":";
            // 
            // tmr1OffSec
            // 
            this.tmr1OffSec.Location = new System.Drawing.Point(90, 107);
            this.tmr1OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1OffSec.Name = "tmr1OffSec";
            this.tmr1OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr1OffSec.TabIndex = 11;
            // 
            // tmr1OffMin
            // 
            this.tmr1OffMin.Location = new System.Drawing.Point(14, 107);
            this.tmr1OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr1OffMin.Name = "tmr1OffMin";
            this.tmr1OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr1OffMin.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Выключен (мин, сек):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = ":";
            // 
            // tmr1OnSec
            // 
            this.tmr1OnSec.Location = new System.Drawing.Point(90, 63);
            this.tmr1OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1OnSec.Name = "tmr1OnSec";
            this.tmr1OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr1OnSec.TabIndex = 7;
            // 
            // tmr1OnMin
            // 
            this.tmr1OnMin.Location = new System.Drawing.Point(14, 63);
            this.tmr1OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr1OnMin.Name = "tmr1OnMin";
            this.tmr1OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr1OnMin.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Включён (мин, сек):";
            // 
            // tmr1Pin
            // 
            this.tmr1Pin.Location = new System.Drawing.Point(90, 19);
            this.tmr1Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr1Pin.Name = "tmr1Pin";
            this.tmr1Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr1Pin.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Пин:";
            // 
            // tmr1Enabled
            // 
            this.tmr1Enabled.AutoSize = true;
            this.tmr1Enabled.Location = new System.Drawing.Point(14, 141);
            this.tmr1Enabled.Name = "tmr1Enabled";
            this.tmr1Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr1Enabled.TabIndex = 2;
            this.tmr1Enabled.Text = "Таймер активен?";
            this.tmr1Enabled.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tmr2Days);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tmr2OffSec);
            this.groupBox2.Controls.Add(this.tmr2OffMin);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.tmr2OnSec);
            this.groupBox2.Controls.Add(this.tmr2OnMin);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.tmr2Pin);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tmr2Enabled);
            this.groupBox2.Location = new System.Drawing.Point(303, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox2.Size = new System.Drawing.Size(284, 176);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Таймер 2";
            // 
            // tmr2Days
            // 
            this.tmr2Days.CheckOnClick = true;
            this.tmr2Days.FormattingEnabled = true;
            this.tmr2Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr2Days.Location = new System.Drawing.Point(153, 19);
            this.tmr2Days.Name = "tmr2Days";
            this.tmr2Days.Size = new System.Drawing.Size(120, 139);
            this.tmr2Days.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(78, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = ":";
            // 
            // tmr2OffSec
            // 
            this.tmr2OffSec.Location = new System.Drawing.Point(90, 107);
            this.tmr2OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2OffSec.Name = "tmr2OffSec";
            this.tmr2OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr2OffSec.TabIndex = 11;
            // 
            // tmr2OffMin
            // 
            this.tmr2OffMin.Location = new System.Drawing.Point(14, 107);
            this.tmr2OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr2OffMin.Name = "tmr2OffMin";
            this.tmr2OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr2OffMin.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Выключен (мин, сек):";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(78, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = ":";
            // 
            // tmr2OnSec
            // 
            this.tmr2OnSec.Location = new System.Drawing.Point(90, 63);
            this.tmr2OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2OnSec.Name = "tmr2OnSec";
            this.tmr2OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr2OnSec.TabIndex = 7;
            // 
            // tmr2OnMin
            // 
            this.tmr2OnMin.Location = new System.Drawing.Point(14, 63);
            this.tmr2OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr2OnMin.Name = "tmr2OnMin";
            this.tmr2OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr2OnMin.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Включён (мин, сек):";
            // 
            // tmr2Pin
            // 
            this.tmr2Pin.Location = new System.Drawing.Point(90, 19);
            this.tmr2Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr2Pin.Name = "tmr2Pin";
            this.tmr2Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr2Pin.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Пин:";
            // 
            // tmr2Enabled
            // 
            this.tmr2Enabled.AutoSize = true;
            this.tmr2Enabled.Location = new System.Drawing.Point(14, 141);
            this.tmr2Enabled.Name = "tmr2Enabled";
            this.tmr2Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr2Enabled.TabIndex = 2;
            this.tmr2Enabled.Text = "Таймер активен?";
            this.tmr2Enabled.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tmr3Days);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.tmr3OffSec);
            this.groupBox3.Controls.Add(this.tmr3OffMin);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.tmr3OnSec);
            this.groupBox3.Controls.Add(this.tmr3OnMin);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.tmr3Pin);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.tmr3Enabled);
            this.groupBox3.Location = new System.Drawing.Point(13, 195);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox3.Size = new System.Drawing.Size(284, 176);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Таймер 3";
            // 
            // tmr3Days
            // 
            this.tmr3Days.CheckOnClick = true;
            this.tmr3Days.FormattingEnabled = true;
            this.tmr3Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr3Days.Location = new System.Drawing.Point(153, 19);
            this.tmr3Days.Name = "tmr3Days";
            this.tmr3Days.Size = new System.Drawing.Size(120, 139);
            this.tmr3Days.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(78, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = ":";
            // 
            // tmr3OffSec
            // 
            this.tmr3OffSec.Location = new System.Drawing.Point(90, 107);
            this.tmr3OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3OffSec.Name = "tmr3OffSec";
            this.tmr3OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr3OffSec.TabIndex = 11;
            // 
            // tmr3OffMin
            // 
            this.tmr3OffMin.Location = new System.Drawing.Point(14, 107);
            this.tmr3OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr3OffMin.Name = "tmr3OffMin";
            this.tmr3OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr3OffMin.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Выключен (мин, сек):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(78, 65);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = ":";
            // 
            // tmr3OnSec
            // 
            this.tmr3OnSec.Location = new System.Drawing.Point(90, 63);
            this.tmr3OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3OnSec.Name = "tmr3OnSec";
            this.tmr3OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr3OnSec.TabIndex = 7;
            // 
            // tmr3OnMin
            // 
            this.tmr3OnMin.Location = new System.Drawing.Point(14, 63);
            this.tmr3OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr3OnMin.Name = "tmr3OnMin";
            this.tmr3OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr3OnMin.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Включён (мин, сек):";
            // 
            // tmr3Pin
            // 
            this.tmr3Pin.Location = new System.Drawing.Point(90, 19);
            this.tmr3Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr3Pin.Name = "tmr3Pin";
            this.tmr3Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr3Pin.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(11, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Пин:";
            // 
            // tmr3Enabled
            // 
            this.tmr3Enabled.AutoSize = true;
            this.tmr3Enabled.Location = new System.Drawing.Point(14, 141);
            this.tmr3Enabled.Name = "tmr3Enabled";
            this.tmr3Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr3Enabled.TabIndex = 2;
            this.tmr3Enabled.Text = "Таймер активен?";
            this.tmr3Enabled.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tmr4Days);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.tmr4OffSec);
            this.groupBox4.Controls.Add(this.tmr4OffMin);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.tmr4OnSec);
            this.groupBox4.Controls.Add(this.tmr4OnMin);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.tmr4Pin);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.tmr4Enabled);
            this.groupBox4.Location = new System.Drawing.Point(303, 195);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(8);
            this.groupBox4.Size = new System.Drawing.Size(284, 176);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Таймер 4";
            // 
            // tmr4Days
            // 
            this.tmr4Days.CheckOnClick = true;
            this.tmr4Days.FormattingEnabled = true;
            this.tmr4Days.Items.AddRange(new object[] {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница",
            "Суббота",
            "Воскресенье"});
            this.tmr4Days.Location = new System.Drawing.Point(153, 19);
            this.tmr4Days.Name = "tmr4Days";
            this.tmr4Days.Size = new System.Drawing.Size(120, 139);
            this.tmr4Days.TabIndex = 13;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(78, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(10, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = ":";
            // 
            // tmr4OffSec
            // 
            this.tmr4OffSec.Location = new System.Drawing.Point(90, 107);
            this.tmr4OffSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4OffSec.Name = "tmr4OffSec";
            this.tmr4OffSec.Size = new System.Drawing.Size(46, 20);
            this.tmr4OffSec.TabIndex = 11;
            // 
            // tmr4OffMin
            // 
            this.tmr4OffMin.Location = new System.Drawing.Point(14, 107);
            this.tmr4OffMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr4OffMin.Name = "tmr4OffMin";
            this.tmr4OffMin.Size = new System.Drawing.Size(58, 20);
            this.tmr4OffMin.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(11, 91);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(115, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Выключен (мин, сек):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(78, 65);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(10, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = ":";
            // 
            // tmr4OnSec
            // 
            this.tmr4OnSec.Location = new System.Drawing.Point(90, 63);
            this.tmr4OnSec.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4OnSec.Name = "tmr4OnSec";
            this.tmr4OnSec.Size = new System.Drawing.Size(46, 20);
            this.tmr4OnSec.TabIndex = 7;
            // 
            // tmr4OnMin
            // 
            this.tmr4OnMin.Location = new System.Drawing.Point(14, 63);
            this.tmr4OnMin.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.tmr4OnMin.Name = "tmr4OnMin";
            this.tmr4OnMin.Size = new System.Drawing.Size(58, 20);
            this.tmr4OnMin.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Включён (мин, сек):";
            // 
            // tmr4Pin
            // 
            this.tmr4Pin.Location = new System.Drawing.Point(90, 19);
            this.tmr4Pin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.tmr4Pin.Name = "tmr4Pin";
            this.tmr4Pin.Size = new System.Drawing.Size(44, 20);
            this.tmr4Pin.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Пин:";
            // 
            // tmr4Enabled
            // 
            this.tmr4Enabled.AutoSize = true;
            this.tmr4Enabled.Location = new System.Drawing.Point(14, 141);
            this.tmr4Enabled.Name = "tmr4Enabled";
            this.tmr4Enabled.Size = new System.Drawing.Size(115, 17);
            this.tmr4Enabled.TabIndex = 2;
            this.tmr4Enabled.Text = "Таймер активен?";
            this.tmr4Enabled.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(501, 379);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 38);
            this.btnCancel.TabIndex = 26;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(409, 379);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(86, 38);
            this.btnOk.TabIndex = 25;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // TimersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(602, 430);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TimersForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки таймеров";
            this.Load += new System.EventHandler(this.TimersForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr1Pin)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr2Pin)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr3Pin)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OffMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnSec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4OnMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tmr4Pin)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox tmr1Enabled;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown tmr1OnSec;
        private System.Windows.Forms.NumericUpDown tmr1OnMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown tmr1Pin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown tmr1OffSec;
        private System.Windows.Forms.NumericUpDown tmr1OffMin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox tmr1Days;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckedListBox tmr2Days;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown tmr2OffSec;
        private System.Windows.Forms.NumericUpDown tmr2OffMin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown tmr2OnSec;
        private System.Windows.Forms.NumericUpDown tmr2OnMin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown tmr2Pin;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox tmr2Enabled;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckedListBox tmr3Days;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown tmr3OffSec;
        private System.Windows.Forms.NumericUpDown tmr3OffMin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown tmr3OnSec;
        private System.Windows.Forms.NumericUpDown tmr3OnMin;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown tmr3Pin;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox tmr3Enabled;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckedListBox tmr4Days;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown tmr4OffSec;
        private System.Windows.Forms.NumericUpDown tmr4OffMin;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown tmr4OnSec;
        private System.Windows.Forms.NumericUpDown tmr4OnMin;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown tmr4Pin;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox tmr4Enabled;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
    }
}