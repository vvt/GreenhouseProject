﻿namespace GreenHouseConfig
{
    partial class AddEditCompositeCommandForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbCommandName = new System.Windows.Forms.TextBox();
            this.lvCommandsList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnDeleteCompositeCommand = new System.Windows.Forms.Button();
            this.btnAddCompositeCommand = new System.Windows.Forms.Button();
            this.btnEditCompositeCommand = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblVersion = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbCommandName
            // 
            this.tbCommandName.BackColor = System.Drawing.Color.White;
            this.tbCommandName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbCommandName.ForeColor = System.Drawing.Color.Black;
            this.tbCommandName.Location = new System.Drawing.Point(2, 28);
            this.tbCommandName.Name = "tbCommandName";
            this.tbCommandName.Size = new System.Drawing.Size(479, 20);
            this.tbCommandName.TabIndex = 1;
            // 
            // lvCommandsList
            // 
            this.lvCommandsList.BackColor = System.Drawing.Color.White;
            this.lvCommandsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvCommandsList.ForeColor = System.Drawing.Color.Black;
            this.lvCommandsList.FullRowSelect = true;
            this.lvCommandsList.GridLines = true;
            this.lvCommandsList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvCommandsList.HideSelection = false;
            this.lvCommandsList.Location = new System.Drawing.Point(2, 26);
            this.lvCommandsList.MultiSelect = false;
            this.lvCommandsList.Name = "lvCommandsList";
            this.lvCommandsList.Size = new System.Drawing.Size(480, 163);
            this.lvCommandsList.TabIndex = 3;
            this.lvCommandsList.UseCompatibleStateImageBehavior = false;
            this.lvCommandsList.View = System.Windows.Forms.View.Details;
            this.lvCommandsList.SelectedIndexChanged += new System.EventHandler(this.lvCommandsList_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Действие";
            this.columnHeader2.Width = 210;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Параметр";
            this.columnHeader3.Width = 80;
            // 
            // btnDeleteCompositeCommand
            // 
            this.btnDeleteCompositeCommand.BackColor = System.Drawing.Color.LightSalmon;
            this.btnDeleteCompositeCommand.Enabled = false;
            this.btnDeleteCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteCompositeCommand.Location = new System.Drawing.Point(391, 195);
            this.btnDeleteCompositeCommand.Name = "btnDeleteCompositeCommand";
            this.btnDeleteCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnDeleteCompositeCommand.TabIndex = 27;
            this.btnDeleteCompositeCommand.Text = "Удалить";
            this.btnDeleteCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDeleteCompositeCommand.UseVisualStyleBackColor = false;
            this.btnDeleteCompositeCommand.Click += new System.EventHandler(this.btnDeleteCompositeCommand_Click);
            // 
            // btnAddCompositeCommand
            // 
            this.btnAddCompositeCommand.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnAddCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddCompositeCommand.Location = new System.Drawing.Point(7, 195);
            this.btnAddCompositeCommand.Name = "btnAddCompositeCommand";
            this.btnAddCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnAddCompositeCommand.TabIndex = 26;
            this.btnAddCompositeCommand.Text = "Добавить";
            this.btnAddCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAddCompositeCommand.UseVisualStyleBackColor = false;
            this.btnAddCompositeCommand.Click += new System.EventHandler(this.btnAddCompositeCommand_Click);
            // 
            // btnEditCompositeCommand
            // 
            this.btnEditCompositeCommand.BackColor = System.Drawing.Color.LightSalmon;
            this.btnEditCompositeCommand.Enabled = false;
            this.btnEditCompositeCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditCompositeCommand.ForeColor = System.Drawing.Color.Black;
            this.btnEditCompositeCommand.Image = global::GreenHouseConfig.Properties.Resources.edit_rule;
            this.btnEditCompositeCommand.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditCompositeCommand.Location = new System.Drawing.Point(299, 195);
            this.btnEditCompositeCommand.Name = "btnEditCompositeCommand";
            this.btnEditCompositeCommand.Size = new System.Drawing.Size(86, 38);
            this.btnEditCompositeCommand.TabIndex = 25;
            this.btnEditCompositeCommand.Text = "Изменить";
            this.btnEditCompositeCommand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEditCompositeCommand.UseVisualStyleBackColor = false;
            this.btnEditCompositeCommand.Click += new System.EventHandler(this.btnEditCompositeCommand_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(373, 342);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(123, 32);
            this.btnCancel.TabIndex = 29;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.LightGreen;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.ForeColor = System.Drawing.Color.Black;
            this.btnOk.Location = new System.Drawing.Point(243, 342);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(124, 32);
            this.btnOk.TabIndex = 28;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.tbCommandName);
            this.panel5.Location = new System.Drawing.Point(12, 13);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(484, 50);
            this.panel5.TabIndex = 31;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel6.Controls.Add(this.lblVersion);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(484, 26);
            this.panel6.TabIndex = 1;
            // 
            // lblVersion
            // 
            this.lblVersion.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVersion.ForeColor = System.Drawing.Color.Beige;
            this.lblVersion.Location = new System.Drawing.Point(3, 3);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(478, 20);
            this.lblVersion.TabIndex = 1;
            this.lblVersion.Text = "Имя составной команды";
            this.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lvCommandsList);
            this.panel1.Controls.Add(this.btnAddCompositeCommand);
            this.panel1.Controls.Add(this.btnEditCompositeCommand);
            this.panel1.Controls.Add(this.btnDeleteCompositeCommand);
            this.panel1.Location = new System.Drawing.Point(12, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(484, 239);
            this.panel1.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(484, 26);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Beige;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(478, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Список команд на выполнение";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AddEditCompositeCommandForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(508, 385);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEditCompositeCommandForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавить/изменить составную команду";
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnDeleteCompositeCommand;
        private System.Windows.Forms.Button btnAddCompositeCommand;
        private System.Windows.Forms.Button btnEditCompositeCommand;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        public System.Windows.Forms.TextBox tbCommandName;
        public System.Windows.Forms.ListView lvCommandsList;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
    }
}