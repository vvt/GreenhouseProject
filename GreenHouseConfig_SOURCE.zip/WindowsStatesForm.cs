﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class WindowsStatesForm : Form
    {
        public WindowsStatesForm()
        {
            InitializeComponent();
        }

        public void Init()
        {
            while (lvList.Items.Count < AppSettings.Instance.WindowStates.Count)
            {
                lvList.Items.Add("#" + lvList.Items.Count.ToString());
            }

            for (int i = 0; i < AppSettings.Instance.WindowStates.Count; i++)
            {
                ListViewItem li = lvList.Items[i];
                while (li.SubItems.Count < 2)
                    li.SubItems.Add("");

                GreenHouseConfig.WindowState ws = AppSettings.Instance.WindowStates[i];

                string wsText = ws.ToString();

                var memInfo = typeof(GreenHouseConfig.WindowState).GetMember(ws.ToString());
                var atrrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (atrrs != null && atrrs.Count() > 0)
                {
                    DescriptionAttribute enAttr = (DescriptionAttribute)atrrs[0];
                    wsText = enAttr.ToString();

                }
 
                li.SubItems[1].Text = wsText;
            } // for

            tmTimer.Enabled = true;
        }

        private void WindowsStatesForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            tmTimer.Enabled = false;
            Hide();
        }

        private void tmTimer_Tick(object sender, EventArgs e)
        {
            Init();
        }
    }
}
