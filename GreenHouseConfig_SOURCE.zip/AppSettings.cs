﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Windows.Forms;
using GreenHouseConfig.Properties;
using System.Text.RegularExpressions;


namespace GreenHouseConfig
{

    public class DescriptionAttribute : Attribute
    {
        private string descr;
        public DescriptionAttribute(string d)
        {
            descr = d;
        }
        public override string ToString()
        {
            return descr;
        }
    }

    public class ReservationInfo
    {
        public string ModuleName { get; set; }
        public int SensorIndex {get; set; }

        public ReservationInfo(string mn, int idx)
        {
            this.ModuleName = mn;
            this.SensorIndex = idx;
        }

        public override string ToString()
        {
            string result = "датчик #" + this.SensorIndex.ToString() + " модуля ";
            if (ModuleName == "STATE")
                result += "температур";
            else if (ModuleName == "HUMIDITY")
                result += "влажности";
            else if (ModuleName == "LIGHT")
                result += "освещенности";
            else if (ModuleName == "SOIL")
                result += "влажности почвы";

            return result;
        }
    }

    public class ReservationSetting
    {
        public SensorType Type { get; set; }
        private List<ReservationInfo> list = new List<ReservationInfo>();
        public List<ReservationInfo> List 
        { 
            get { return this.list; }
            set { this.list = value; }
        }
    }


    /// <summary>
    /// Тип датчика
    /// </summary>
    public enum SensorType
    {
        None,
        /// <summary>
        /// Температурный датчик
        /// </summary>
        [Description("Температурный датчик")]
        Temperature,
        /// <summary>
        /// Датчик влажности
        /// </summary>
        [Description("Датчик влажности")]
        Humidity,
        /// <summary>
        /// Датчик освещенности
        /// </summary>
        [Description("Датчик освещенности")]
        Luminosity,
        /// <summary>
        /// Датчик влажности почвы
        /// </summary>
        [Description("Датчик влажности почвы")]
        SoilMoisture,

        /// <summary>
        /// Датчик pH
        /// </summary>
        [Description("Датчик pH")]
        PH

    }

    public class IoTDraggedData
    {
        public ListBox SourceList { get; set; }
        public IoTSensorSettings Sensor { get; set; }
    }

    public class IoTSensorSettings
    {
        private int moduleID;
        public int ModuleID
        {
            get { return moduleID; }
            set { moduleID = value; }
        }
        private int sensorIndex;
        public int SensorIndex
        {
            get { return sensorIndex; }
            set { sensorIndex = value; }
        }
        private int sensorType;
        public int SensorType
        {
            get { return sensorType; }
            set { sensorType = value; }
        }
        public IoTSensorSettings(int st, int mid, int sidx)
        {
            sensorType = st;
            moduleID = mid;
            sensorIndex = sidx;
        }
        public override string ToString()
        {
            string result = "";

            switch (sensorType)
            {
                case 1: // StateTemperature
                    result = "Датчик температуры";
                    if (moduleID == 2)
                    {
                        result = "Датчик влажности, температура";
                    }
                    break;

                case 4: // StateLuminosity
                    result = "Датчик освещённости";
                    break;

                case 8: // StateHumidity
                    result = "Датчик влажности, влажность";
                    break;

                case 64: // StateSoilMoisture
                    result = "Датчик влажности почвы";
                 break;

                case 128: // StatePH
                 result = "Датчик pH";
                 break;
            }

            result += ", #" + sensorIndex.ToString();


            return result;
        }
    };

    public class WateringChannelSettings
    {
        private int wateringDays = 0;
        public int WateringDays
        {
            get { return wateringDays; }
            set { wateringDays = value; }
        }

        private int wateringTime = 0;
        public int WateringTime
        {
            get { return wateringTime; }
            set { wateringTime = value; }
        }

        private int startWateringTime = 0;
        public int StartWateringTime
        {
            get { return startWateringTime; }
            set { startWateringTime = value; }
        }

        public override string ToString()
        {
            return wateringDays.ToString() + "|" + wateringTime.ToString() + "|" + startWateringTime.ToString();
        }
    };
    public class TimerSettings
    {
        public byte DayMaskAndEnable {get; set;}
        public byte Pin {get; set;}
        public int HoldOnTime {get; set;}
        public int HoldOffTime {get; set;}

    };

    /// <summary>
    /// состояние окна
    /// </summary>
    public enum WindowState
    {
        /// <summary>
        /// Неизвестное состояние
        /// </summary>
        [Description("<нет даннных>")]
        Unknown,
        /// <summary>
        /// Открыто
        /// </summary>
        [Description("открыто")]
        Open,
        /// <summary>
        /// Закрыто
        /// </summary>
        [Description("закрыто")]
        Closed,
        /// <summary>
        /// Открывается
        /// </summary>
        [Description("открывается")]
        Opening,
        /// <summary>
        /// Закрывается
        /// </summary>
        [Description("закрывается")]
        Closing
    };

    public class DeltaSettings
    {
        string sensorType;
        public string SensorType
        {
            get { return sensorType; }
            set { sensorType = value; }
        }
        string moduleName1;
        public string ModuleName1
        {
            get { return moduleName1; }
            set { moduleName1 = value; }
        }

        string moduleName2;
        public string ModuleName2
        {
            get { return moduleName2; }
            set { moduleName2 = value; }
        }
        int sensorIndex1;
        public int SensorIndex1
        {
            get { return sensorIndex1; }
            set { sensorIndex1 = value; }
        }
        int sensorIndex2;
        public int SensorIndex2
        {
            get { return sensorIndex2; }
            set { sensorIndex2 = value; }
        }

        public DeltaSettings()
        {
        }

        public DeltaSettings(string stype, string mname1, string mname2, int sidx1, int sidx2)
        {
            this.sensorType = stype;
            this.moduleName1 = mname1;
            this.moduleName2 = mname2;
            this.sensorIndex1 = sidx1;
            this.sensorIndex2 = sidx2;
        }
        public override string ToString()
        {
            string delim = "|";
            return sensorType + delim + moduleName1 + delim + sensorIndex1.ToString() + delim + moduleName2 + delim + sensorIndex2.ToString();
        }
        
        public static bool operator!=(DeltaSettings lhs, DeltaSettings rhs)
        {
            return (lhs.sensorType != rhs.sensorType)
                || (lhs.sensorIndex1 != rhs.sensorIndex1)
                || (lhs.sensorIndex2 != rhs.sensorIndex2)
                || (lhs.moduleName2 != rhs.moduleName2)
                || (lhs.moduleName1 != rhs.moduleName1);
        }
        public static bool operator==(DeltaSettings lhs, DeltaSettings rhs)
        {
            // решаем проблему, когда дельта собирается с двух датчиков, но
            // модули указаны зеркально.

            if ((lhs.sensorType == rhs.sensorType)
                && (lhs.sensorIndex1 == rhs.sensorIndex1)
                && (lhs.sensorIndex2 == rhs.sensorIndex2)
                && (lhs.moduleName2 == rhs.moduleName2)
                && (lhs.moduleName1 == rhs.moduleName1)
            )
                return true;

            if ((lhs.sensorType == rhs.sensorType)
                && (lhs.sensorIndex1 == rhs.sensorIndex2)
                && (lhs.sensorIndex2 == rhs.sensorIndex1)
                && (lhs.moduleName1 == rhs.moduleName2)
                && (lhs.moduleName2 == rhs.moduleName1)
            )
                return true;

            return false;

        }
         

    };
    public class TemperatureSettings
    {
        private string displayName;

        [XmlAttribute("display")]
        public string DisplayName
        {
            get { return this.displayName;  }
            set { this.displayName = value; }
        }

        private int tOpen;
        [XmlAttribute("t_open")]
        public int OpenTemperature
        {
            get { return this.tOpen; }
            set { this.tOpen = value; }
        }

        private int tClose;
        [XmlAttribute("t_close")]
        public int CloseTemperature
        {
            get { return this.tClose; }
            set { this.tClose = value; }
        }

        public override string ToString()
        {
            return this.displayName;
        }
    }

    public class AlertRule
    {
        private bool isAlarm = false;
        public bool IsAlarm
        {
            get { return this.isAlarm; }
            set { this.isAlarm = value; }
        }
        private bool isSpecialRule = false;
        [XmlIgnore]
        public bool IsSpecialRule
        {
            get { return this.isSpecialRule; }
        }

        private bool isDeleted = false;
        [XmlIgnore]
        public bool IsDeleted
        {
            get { return this.isDeleted; }
            set { this.isDeleted = value; }
        }
        private string name;
        [XmlElement("name")]
        public string Name
        {
            get { return this.name; }
            set { 
                this.name = value;
                this.isSpecialRule = this.name == "WOP" ||
                    this.name == "WCL" || this.name == "LON" ||
                    this.name == "LOFF";
            }
        }
        private string linkedModuleName;
        [XmlElement("linked_to")]
        public string LinkedModuleName
        {
            get { return this.linkedModuleName; }
            set { this.linkedModuleName = value; }
        }
        private string spyTo;
        [XmlElement("spy_to")]
        public string SpyTo
        {
            get { return this.spyTo; }
            set { this.spyTo = value; }
        }
        private int sensorIndex = 0;
        [XmlElement("sensor")]
        public int SensorIndex
        {
            get { return this.sensorIndex; }
            set { this.sensorIndex = value; }
        }
        private string operand;
        [XmlElement("operand")]
        public string Operand
        {
            get { return this.operand; }
            set { this.operand = value; }
        }
        private string target;
        [XmlElement("target")]
        public string Target
        {
            get { return this.target; }
            set { this.target = value; }
        }
        private int startTime = 0;
        [XmlElement("start")]
        public int StartTime
        {
            get { return this.startTime; }
            set { this.startTime = value; }
        }
        private int workTime = 0;
        [XmlElement("work")]
        public int WorkTime
        {
            get { return this.workTime; }
            set { this.workTime = value; }
        }
        private byte dayMask = 0xFF;
        [XmlElement("daymask")]
        public byte DayMask
        {
            get { return this.dayMask; }
            set { this.dayMask = value; }
        }
        private List<string> linkedRules = new List<string>();
        [XmlArray("linked_rules")]
        [XmlArrayItem("rule_name")]
        public List<string> LinkedRules
        {
            get { return this.linkedRules; }
            set { this.linkedRules = value; }
        }
        private string command;
        [XmlElement("command")]
        public string Command
        {
            get { return this.command; }
            set { this.command = value; }
        }
        private bool isActive = true;
        [XmlAttribute("active")]
        public bool IsActive
        {
            get { return this.isActive; }
            set { this.isActive = value; }
        }
        public void Clear()
        {
            this.linkedRules.Clear();
            this.command = "";
            this.linkedModuleName = "";
            this.name = "";
            this.operand = "";
            this.sensorIndex = 0;
            this.spyTo = "";
            this.startTime = 0;
            this.target = "";
            this.workTime = 0;
            this.dayMask = 0xFF;
            this.isAlarm = false;
           
        }

        public void Parse(string ruleString)
        {
            string[] splitted = ruleString.Split('|');
            int count = splitted.Length;
            int idx = 0;
            this.Name = splitted[idx++];
            this.linkedModuleName = splitted[idx++];
            this.spyTo = splitted[idx++];
            this.sensorIndex = Convert.ToInt32(splitted[idx++]);
            this.operand = splitted[idx++];
            this.target = splitted[idx++];
            this.startTime = Convert.ToInt32(splitted[idx++]);
            this.workTime = Convert.ToInt32(splitted[idx++]);
            this.dayMask = Convert.ToByte(splitted[idx++]);

            string linkr = splitted[idx++];
            if (linkr.IndexOf(",") != -1)
            {
                string[] lrn = linkr.Split(',');
                foreach (string lr in lrn)
                    this.linkedRules.Add(lr);
            }
            else if (linkr != "_")
                this.linkedRules.Add(linkr);

            // получаем флаг аларма
            string isal = splitted[idx++];
            this.isAlarm = isal == "1";

            while (idx < count)
            {
                if (this.command.Length > 0)
                    this.command += "|";
 
                this.command += splitted[idx++];
            }
                

        }

        public AlertRule()
        {
        }

        public AlertRule(string s)
        {
            this.Clear();
            this.Parse(s);
        }

        public override string ToString()
        {
            string result = "";

            string delim = "|";
            result += this.name;
            result += delim;
            result += this.linkedModuleName;
            result += delim;
            result += this.spyTo;
            result += delim;
            result += this.sensorIndex.ToString();
            result += delim;
            result += this.operand;
            result += delim;
            result += this.target;
            result += delim;
            result += this.startTime.ToString();
            result += delim;
            result += this.workTime.ToString();
            result += delim;
            result += this.dayMask.ToString();
            result += delim;

            if (this.linkedRules.Count < 1)
                result += "_";
            else
            {
                for (int i = 0; i < this.linkedRules.Count; i++)
                {
                    if (i > 0)
                        result += ",";
                    result += this.linkedRules[i];
                }
            }

            result += delim;
            result += this.isAlarm ? "1" : "0";

            result += delim;
            result += this.command;

            return result;
        }
    }

    public class KnownAction
    {
        private string command;
        public string Command
        {
            get { return this.command; }
            set { this.command = value; }
        }

        private string description;
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }
        private WhichTag whichTag = WhichTag.TagNone;
        public WhichTag WhichTag
        {
            get { return whichTag; }
            set { whichTag = value; }
        }

        public KnownAction(string c, string d, WhichTag t)
        {
            this.command = c;
            this.description = d;
            this.whichTag = t;
        }

        public bool IsOurAction(string fullAction)
        {
            Regex re = new Regex(this.command);
            return re.IsMatch(fullAction);
        }
    }

    public class AppSettings
    {

        private List<WindowState> windowsStates = new List<WindowState>();
        [XmlIgnore]
        public List<WindowState> WindowStates
        {
            get { return windowsStates; }
            set { windowsStates = value; }
        }

        private static object lockFlag = new object();
        private static AppSettings instance;

        private List<ReservationSetting> reservationSettings = new List<ReservationSetting>();
        [XmlIgnore]
        public List<ReservationSetting> ReservationSettings
        {
            get { return this.reservationSettings; }
            set { this.reservationSettings = value; }
        }

        private Dictionary<SensorType, int> firmwareSettings = new Dictionary<SensorType, int>();
        [XmlIgnore]
        public Dictionary<SensorType, int> FirmwareSettings
        {
            get { return firmwareSettings; }
            set { firmwareSettings = value; }
        }
        private Dictionary<SensorType, int> universalModulesSettings = new Dictionary<SensorType, int>();
        [XmlIgnore]
        public Dictionary<SensorType, int> UniversalModulesSettings
        {
            get { return universalModulesSettings; }
            set { universalModulesSettings = value; }
        }

        // 

        private int controllerID = 0;
        [XmlIgnore]
        public int ControllerID
        {
            get { return controllerID; }
            set { controllerID = value; }
        }

        /// <summary>
        /// список ранее добавленных SMS-команд
        /// </summary>
        private List<SmsCommand> smsCommands = new List<SmsCommand>();
        [XmlArray("sms_commands")]
        [XmlArrayItem("sms_command")]
        public List<SmsCommand> SMSCommands
        {
            get { return this.smsCommands; }
            set { this.smsCommands = value; }
        }

        public void AddSMSCommand(SmsCommand comm)
        {

            for(int i=0;i<smsCommands.Count;i++)
            {
                SmsCommand c = smsCommands[i];
                if (c.SMSText == comm.SMSText)
                {
                    smsCommands[i] = comm;
                    return;
                }
            }

            smsCommands.Add(comm);
            this.Save();
        }

        /// <summary>
        /// список составных команд
        /// </summary>
        private List<CompositeCommands> compositeCommands = new List<CompositeCommands>();
        [XmlArray("composite_commands")]
        [XmlArrayItem("composite_command")]
        public List<CompositeCommands> CompositeCommands
        {
            get { return this.compositeCommands; }
            set { this.compositeCommands = value; }
        }

        [XmlIgnore]
        public TimerSettings[] Timers = new TimerSettings[4];

        private List<KnownAction> knownActions = new List<KnownAction>();
        [XmlIgnore]
        public List<KnownAction> KnownActions
        {
            get { return this.knownActions; }
            set { this.knownActions = value; }
        }

        private List<DeltaSettings> deltaSettings = new List<DeltaSettings>();
        [XmlIgnore]
        public List<DeltaSettings> DeltaSettings
        {
            get { return this.deltaSettings; }
            set { this.deltaSettings = value; }
        }

        [XmlIgnore]
        public static AppSettings Instance
        {
            get
            {
                lock (lockFlag)
                {
                    if (instance == null)
                    {
                        try
                        {
                            //Пытаемся загрузить файл с диска и десериализовать его
                            using (FileStream fs =
                                new FileStream(Application.StartupPath
                                + "\\config.xml", FileMode.Open))
                            {
                                System.Xml.Serialization.XmlSerializer xs =
                                    new System.Xml.Serialization.XmlSerializer(typeof(AppSettings));
                                instance = (AppSettings)xs.Deserialize(fs);

                                // тут заполняем всё значениями по умолчанию
                                for(int i=0;i<4;i++)
                                    instance.Timers[i] = new TimerSettings();

                                // заполняем карту типов сенсоров
                                foreach (SensorType st in Enum.GetValues(typeof(SensorType)))
                                {
                                    if (st != SensorType.None)
                                    {
                                        instance.firmwareSettings.Add(st, 0);
                                        instance.universalModulesSettings.Add(st, 0);
                                    }
                                }
                            }
                        }
                        catch (Exception)
                        {
                            //Если не удалось десериализовать то просто создаем новый экземпляр
                            instance = new AppSettings();
                        }
                    }
                } // lock
                return instance;
            } // get

        }

        public static void Reload()
        {
            instance = null;
        }

        public void Save()
        {
            HoldActualRulesState(); // удаляем ненужные правила
            using (FileStream fs =
              new FileStream(Application.StartupPath + "\\config.xml", FileMode.Create))
            {
                System.Xml.Serialization.XmlSerializer xs =
                    new System.Xml.Serialization.XmlSerializer(typeof(AppSettings));
                xs.Serialize(fs, instance);
            }
        }

        private byte rfChannel = 19;
        [XmlIgnore]
        public byte RFChannel
        {
            get { return rfChannel; }
            set { rfChannel = value; }
        }

        private bool widgetMemoryVisible = false;
        [XmlElement("widgetMemory")]
        public bool WidgetMemoryVisible
        {
            get { return this.widgetMemoryVisible; }
            set { this.widgetMemoryVisible = value; }
        }

        private bool widgetWorkTimeVisible = false;
        [XmlElement("widgetWorkTime")]
        public bool WidgetWorkTimeVisible
        {
            get { return this.widgetWorkTimeVisible; }
            set { this.widgetWorkTimeVisible = value; }
        }

        private bool widgetControllerTimeVisible = true;
        [XmlElement("widgetControllerTime")]
        public bool WidgetControllerTimeVisible
        {
            get { return this.widgetControllerTimeVisible; }
            set { this.widgetControllerTimeVisible = value; }
        }

        private bool widgetControllerTemperatureVisible = false;
        [XmlElement("widgetControllerTemperature")]
        public bool WidgetControllerTemperatureVisible
        {
            get { return this.widgetControllerTemperatureVisible; }
            set { this.widgetControllerTemperatureVisible = value; }
        }

        private bool widgetTemperatureInsideVisible = true;
        [XmlElement("widgetTemperatureInside")]
        public bool WidgetTemperatureInsideVisible
        {
            get { return this.widgetTemperatureInsideVisible; }
            set { this.widgetTemperatureInsideVisible = value; }
        }

        private bool widgetTemperatureOutsideVisible = true;
        [XmlElement("widgetTemperatureOutside")]
        public bool WidgetTemperatureOutsideVisible
        {
            get { return this.widgetTemperatureOutsideVisible; }
            set { this.widgetTemperatureOutsideVisible = value; }
        }

        private bool widgetWindowsPositionVisible = true;
        [XmlElement("widgetWindowsPosition")]
        public bool WidgetWindowsPositionVisible
        {
            get { return this.widgetWindowsPositionVisible; }
            set { this.widgetWindowsPositionVisible = value; }
        }

        private bool widgetWindowsWorkModeVisible = true;
        [XmlElement("widgetWindowsWorkMode")]
        public bool WidgetWindowsWorkModeVisible
        {
            get { return this.widgetWindowsWorkModeVisible; }
            set { this.widgetWindowsWorkModeVisible = value; }
        }

        private bool widgetWindowsChannelsVisible = true;
        [XmlElement("widgetWindowsChannels")]
        public bool WidgetWindowsChannelsVisible
        {
            get { return this.widgetWindowsChannelsVisible; }
            set { this.widgetWindowsChannelsVisible = value; }
        }

        private bool widgetTemperatureSensorsVisible = true;
        [XmlElement("widgetTemperatureSensors")]
        public bool WidgetTemperatureSensorsVisible
        {
            get { return this.widgetTemperatureSensorsVisible; }
            set { this.widgetTemperatureSensorsVisible = value; }
        }

        private bool widgetHumiditySensorsVisible = true;
        [XmlElement("widgetHumiditySensors")]
        public bool WidgetHumiditySensorsVisible
        {
            get { return this.widgetHumiditySensorsVisible; }
            set { this.widgetHumiditySensorsVisible = value; }
        }

        private bool widgetLightSensorsVisible = true;
        [XmlElement("widgetLightSensors")]
        public bool WidgetLightSensorsVisible
        {
            get { return this.widgetLightSensorsVisible; }
            set { this.widgetLightSensorsVisible = value; }
        }

        private bool widgetSoilMoistureVisible = false;
        [XmlElement("widgetSoilMoisture")]
        public bool WidgetSoilMoistureVisible
        {
            get { return this.widgetSoilMoistureVisible; }
            set { this.widgetSoilMoistureVisible = value; }
        }

        private bool widgetPHVisible = false;
        [XmlElement("widgetPH")]
        public bool WidgetPHVisible
        {
            get { return this.widgetPHVisible; }
            set { this.widgetPHVisible = value; }
        }

        private bool widgetWaterChannelsVisible = false;
        [XmlElement("widgetWaterChannels")]
        public bool WidgetWaterChannelsVisible
        {
            get { return this.widgetWaterChannelsVisible; }
            set { this.widgetWaterChannelsVisible = value; }
        }
        
        

        private bool createTemperatureRules = true;
        [XmlElement("create_t_rules")]
        public bool CreateTemperatureRules
        {
            get
            {
                return this.createTemperatureRules;
            }
            set
            {
                this.createTemperatureRules = value;
            }
        }

        private string logsDir = Application.StartupPath + "\\logs\\";
        [XmlElement("logs_directory")]
        public string LogsDirectory
        {
            get { return logsDir; }
            set { logsDir = value; }
        }

        private int defTOpen = 25;
        [XmlElement("def_t_open")]
        public int TOpen
        {
            get { return this.defTOpen; }
            set { this.defTOpen = value; }
        }

        private int defTClose = 23;
        [XmlElement("def_t_close")]
        public int TClose
        {
            get { return this.defTClose; }
            set { this.defTClose = value; }
        }

        private int selIdx = -1;
        [XmlElement("sel_idx")]
        public int SelectedSetting
        {
            get { return this.selIdx; }
            set { selIdx = value; }
        }

        private int windowInterval = 30000;
        [XmlElement("w_interval")]
        public int Interval
        {
            get { return windowInterval; }
            set { windowInterval = value; }
        }

        private string phoneNumber;
        [XmlElement("phone")]
        public string PhoneNumber
        {
            get { return this.phoneNumber; }
            set { this.phoneNumber = value; }
        }

        private string monitorTempOutsideModule = "STATE";
        [XmlElement("m_t_out_module")]
        public string MonitorTempOutsideModule
        {
            get { return monitorTempOutsideModule; }
            set { monitorTempOutsideModule = value; }
        }

        private string monitorTempInsideModule = "STATE";
        [XmlElement("m_t_in_module")]
        public string MonitorTempInsideModule
        {
            get { return monitorTempInsideModule; }
            set { monitorTempInsideModule = value; }
        }

        private int monitorTempInsideSensor = 0;
        [XmlElement("m_t_in_idx")]
        public int MonitorTempInsideSensor
        {
            get { return monitorTempInsideSensor; }
            set { monitorTempInsideSensor = value; }
        }

        private int monitorTempOutsideSensor = 1;
        [XmlElement("m_t_out_idx")]
        public int MonitorTempOutsideSensor
        {
            get { return monitorTempOutsideSensor; }
            set { monitorTempOutsideSensor = value; }
        }

        private int wateringOption = 0;
        [XmlElement("watering")]
        public int WateringOption
        {
            get { return this.wateringOption; }
            set { this.wateringOption = value; }
        }

        private int wateringDays = 0;
        [XmlElement("watering_days")]
        public int WateringDays
        {
            get { return wateringDays; }
            set { wateringDays = value; }
        }

        private int wateringTime = 60;
        [XmlElement("watering_time")]
        public int WateringTime
        {
            get { return wateringTime; }
            set { wateringTime = value; }
        }

        private int start_watering_time = 12;
        [XmlElement("start_watering_time")]
        public int StartWateringTime
        {
            get { return start_watering_time; }
            set { start_watering_time = value; }
        }

        private int turn_on_pump = 0;
        [XmlElement("turn_on_pump")]
        public int TurpOnPump
        {
            get { return turn_on_pump; }
            set { turn_on_pump = value; }
        }

        private bool luminosity_manage = false;
        [XmlElement("luminosity_manage")]
        public bool LuminosityManage
        {
            get { return luminosity_manage; }
            set { luminosity_manage = value; }
        }
        private int lux_from_hour = 0;
        [XmlElement("lux_from_hour")]
        public int LuxFromHour
        {
            get { return lux_from_hour; }
            set { lux_from_hour = value; }
        }
        private int lux_to_hour = 0;
        [XmlElement("lux_to_hour")]
        public int LuxToHour
        {
            get { return lux_to_hour; }
            set { lux_to_hour = value; }
        }
        private int lux_gisteresis = 0;
        [XmlElement("lux_gisteresis")]
        public int LuxGisteresis
        {
            get { return lux_gisteresis; }
            set { lux_gisteresis = value; }
        }
        private int min_lux_value = 0;
        [XmlElement("min_lux_value")]
        public int MinLuxValue
        {
            get { return min_lux_value; }
            set { min_lux_value = value; }
        }

        private bool connectToRouter = false;
        [XmlElement("connect_to_router")]
        public bool ConnectToRouter
        {
            get { return connectToRouter; }
            set { connectToRouter = value; }
        }

        private string routerID;
        [XmlElement("router_id")]
        public string RouterID
        {
            get { return routerID; }
            set { routerID = value; }
        }

        private string routerPassword;
        [XmlElement("router_password")]
        public string RouterPassword
        {
            get { return routerPassword; }
            set { routerPassword = value; }
        }

        private string stationID;
        [XmlElement("station_id")]
        public string StationID
        {
            get { return stationID; }
            set { stationID = value; }
        }

        private string stationPassword;
        [XmlElement("station_password")]
        public string StationPassword
        {
            get { return stationPassword; }
            set { stationPassword = value; }
        }

        private bool workWithoutLightSensor = false;
        [XmlElement("work_without_ls")]
        public bool WorkWithoutLightSensor
        {
            get { return workWithoutLightSensor; }
            set { workWithoutLightSensor = value; }
        }

        private int waterChannelsCount = 0;
        [XmlIgnore]
        public int WaterChannelsCount
        {
            get { return waterChannelsCount; }
            set { waterChannelsCount = value; }
        }

        private List<WateringChannelSettings> wateringChannels = new List<WateringChannelSettings>();

        [XmlIgnore]
        public List<WateringChannelSettings> WateringChannels
        {
            get { return this.wateringChannels; }
            set { this.wateringChannels = value; }
        }


        private List<string> widgetsOrder = new List<string>();
        [XmlArray("widgets")]
        [XmlArrayItem("widget")]
        public List<string> WidgetsOrder
        {
            get { return this.widgetsOrder; }
            set { this.widgetsOrder = value; }
        }



        private List<TemperatureSettings> tempSettings = new List<TemperatureSettings>();

        [XmlArray("temp")]
        [XmlArrayItem("t_setting")]
        public List<TemperatureSettings> Temperatures
        {
            get { return this.tempSettings; }
            set { this.tempSettings = value; }
        }

        private void HoldActualRulesState()
        {
            // игнорируем удалённые правила
            List<AlertRule> newList = new List<AlertRule>();
            foreach (AlertRule ar in this.alertRules)
            {
                if (!ar.IsDeleted)
                    newList.Add(ar);

            }

            this.alertRules = newList;
        }

        private List<AlertRule> alertRules = new List<AlertRule>();
       // [XmlArray("rules")]
      //  [XmlArrayItem("rule")]
        [XmlIgnore]
        public List<AlertRule> AlertRules
        {
            get { return this.alertRules; }
            set { this.alertRules = value; }
        }

        public AppSettings()
        {
            knownActions.Add(new KnownAction(@".+STATE\|WINDOW\|.*\|OPEN.*$", Settings.Default.OpenWindowsAction, WhichTag.TagOpenWindows));
            knownActions.Add(new KnownAction(@".+STATE\|WINDOW\|.*\|CLOSE$", Settings.Default.CloseWindowsAction, WhichTag.TagCloseWindows));
            knownActions.Add(new KnownAction(@".+LIGHT\|ON$", Settings.Default.LightOnAction, WhichTag.TagLightOn));
            knownActions.Add(new KnownAction(@".+LIGHT\|OFF$", Settings.Default.LightOffAction, WhichTag.TagLightOff));
            knownActions.Add(new KnownAction(@".+PIN\|.*\|OFF$", Settings.Default.PinOffAction, WhichTag.TagPinOff));
            knownActions.Add(new KnownAction(@".+PIN\|.*\|ON$", Settings.Default.PinOnAction, WhichTag.TagPinOn));
            knownActions.Add(new KnownAction(@".+CC\|EXEC\|.*", "выполняем составную команду", WhichTag.TagExecCompositeCommand));

        }
        public WhichTag GetActionTag(string command)
        {
            foreach (KnownAction ka in this.knownActions)
            {
                if (ka.IsOurAction(command))
                    return ka.WhichTag;
            }
            return WhichTag.TagNone;
        }

        public string GetActionDescription(string command)
        {
            foreach (KnownAction ka in this.knownActions)
            {
                if (ka.IsOurAction(command))
                    return ka.Description;
            }
            return Settings.Default.NoData;
        }

    } // AppSettings
}
