﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Collections;
using System.Security.Permissions;
using GreenHouseConfig.Properties;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace GreenHouseConfig
{
    public partial class MainForm : Form
    {
        private ToolStripMenuItem lastSelectedPort = null;
        private AppSettings appSettings;
        private ITransport currentTransport = null;
 
        /// <summary>
        /// Конструктор
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Обработчик выхода из приложения
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void miExit_Click(object sender, EventArgs e)
        {
            DoExit();
        }

        /// <summary>
        /// Выходим из приложения
        /// </summary>
        private void DoExit()
        {
            Application.Exit();
        }
        /// <summary>
        /// Скрываем все вкладки
        /// </summary>
        private void HideTabPages()
        {
            // скрываем все закладки, пока не законнектимся
            ShowTabPage(tpRules, false);
            ShowTabPage(tpTemperatureTab, false);
            ShowTabPage(tpWateringTab, false);
            ShowTabPage(tpLuminosity, false);
            ShowTabPage(tpHumidity, false);
            ShowTabPage(tpSMSTab, false);
            ShowTabPage(tpWiFi, false);
            ShowTabPage(tpLog, false);
            ShowTabPage(tpWaterFlow, false);
            ShowTabPage(tpMultipleCommands, false);
            ShowTabPage(tpDeltas,false);
            ShowTabPage(tpSoilMoisture, false);
            ShowTabPage(tpPH, false);
            ShowTabPage(tpIOT, false);
        }
        /// <summary>
        /// Создаём папку по указанному пути
        /// </summary>
        /// <param name="path"></param>
        private void EnsureDirectoryExists(string path)
        {
            try
            {
                System.IO.Directory.CreateDirectory(path);
            }
            catch { }
        }
        /// <summary>
        /// Обработчик события загрузки формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            appSettings = AppSettings.Instance; // загружаем настройки

            Text += System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            EnsureDirectoryExists(appSettings.LogsDirectory);
            this.tbLogsDirectory.Text = appSettings.LogsDirectory;

            this.lbIOTSelectedSensors.AllowDrop = true;
            this.lbIOTAllSensors.AllowDrop = true;

            cbGSMProvider.SelectedIndex = 0;

            FillCompisiteCommandsList(); // заполняем список составных команд

            HideTabPages();

            cbEnableLuminosityManage.Checked = appSettings.LuminosityManage;
            try
            {
                nudLuxHourFrom.Value = appSettings.LuxFromHour;
                nudLuxHourTo.Value = appSettings.LuxToHour;
                nudMinLux.Value = appSettings.MinLuxValue;
                nudLuxGisteresis.Value = appSettings.LuxGisteresis;
            }
            catch { }

            cbWorkWithoutLightSensor.Checked = appSettings.WorkWithoutLightSensor;
            cbCreateTemperatureRules.Checked = appSettings.CreateTemperatureRules;


            nudLuxHourFrom.ValueChanged += new EventHandler(LuxSettingsValueChanged);
            nudLuxHourTo.ValueChanged += new EventHandler(LuxSettingsValueChanged);
            nudMinLux.ValueChanged += new EventHandler(LuxSettingsValueChanged);
            nudLuxGisteresis.ValueChanged += new EventHandler(LuxSettingsValueChanged);
            cbWorkWithoutLightSensor.CheckedChanged += new EventHandler(LuxSettingsValueChanged);



            ttPhoneNumberHint.ToolTipTitle = Settings.Default.IncomingNumber;
            ttPhoneNumberHint.SetToolTip(pbNumberHelp, Settings.Default.PhoneNumberHint);
            

            this.tbRouterID.Text = appSettings.RouterID;
            this.tbRouterPassword.Text = appSettings.RouterPassword;
            this.tbStationID.Text = appSettings.StationID;
            this.tbStationPassword.Text = appSettings.StationPassword;
            this.cbConnectToTheRouter.Checked = appSettings.ConnectToRouter;



            FillWateringDays();
            FillRulesList();
 
            this.richTextBox1.Rtf = Resources.list;

            this.logColumn1.Width = this.lvLog.ClientRectangle.Width / 2 - SystemInformation.VerticalScrollBarWidth/2 - 2;
            this.logColumn2.Width = this.logColumn1.Width;

            SwitchToPause(false);
 
            Application.Idle += new EventHandler(Application_Idle);
            

            FillComboWithTemperatures();
            FillComboWithWateringOptions();

            try
            {
                this.nudTOpen.Value = this.appSettings.TOpen;
                this.nudTClose.Value = this.appSettings.TClose;
                this.nudInterval.Value = this.appSettings.Interval / 1000;
            }
            catch { }

            this.tbPhoneNumber.Text = this.appSettings.PhoneNumber;

            // проба нашего редактора для ячейки
            CheckListBoxColumn col = new CheckListBoxColumn();
            col.HeaderText = Settings.Default.WeekDaysColumnText;
            col.Width = 180;
            col.DefaultCellStyle.NullValue = Settings.Default.NotSet;
            this.dgvWateringChannels.Columns.Add(col);


            tbToolBar.ImageList = this.imglToolbarImages;
            this.tbbConnectBtn.ImageIndex = 0;

            Color cl = Color.SaddleBrown;
            lblUptime.ForeColor = cl;
            lblFreeRam.ForeColor = cl;
            lblTempInside.ForeColor = cl;
            lblTempOutside.ForeColor = cl;
            lblCurrentWindowState.ForeColor = cl;
            lblWindowWorkMode.ForeColor = cl;
            lblWateringMode.ForeColor = cl;
            lblWateringState.ForeColor = cl;
            lblLuxMode.ForeColor = cl;
            lblLuxState.ForeColor = cl;
            lblFlowIncremental1.ForeColor = cl;
            lblFlowIncremental2.ForeColor = cl;
            lblFlowInstant1.ForeColor = cl;
            lblFlowInstant2.ForeColor = cl;


            lblRuleStr.ForeColor = Color.DarkRed;

            RealignControls();

            EnumSerialPorts();

            currentCommand.ActionToSet = Actions.None;

            // добавляем команды на опрос сразу после коннекта к контроллеру
            PushCommandToQueue(GET_PREFIX + ALL_STAT_COMMAND, Actions.AskAllStat, ParseAskAllStat); // получаем слепок состояния контроллера
            PushCommandToQueue(GET_PREFIX + FREERAM_COMMAND, Actions.AskFreeRam, this.ParseFreeRam); // получаем кол-во свободной памяти
            PushCommandToQueue(GET_PREFIX + UPTIME_COMMAND, Actions.AskUptime, this.ParseUptime); // получаем аптайм

            PushCommandToQueue(GET_PREFIX + GET_WATER_CHANNELS, Actions.AskWaterChannels, this.ParseWaterChannels); // получаем кол-во каналов полива
            PushCommandToQueue(GET_PREFIX + LIST_MODULES_COMMAND, Actions.AskRegisteredModules, this.ParseRegisteredModules); // получаем список зарегистрированных в прошивке модулей

            PushCommandToQueue(GET_PREFIX + INTERVAL_COMMAND, Actions.AskWindowWorkInterval, this.ParseWindowWorkInterval); // получаем интервал работы окон
            PushCommandToQueue(GET_PREFIX + WINDOW_COMMAND, Actions.AskWindowPosition, this.ParseWindowPosition); // получаем позицию окон
            PushCommandToQueue(GET_PREFIX + "STATE|WINDOW|STATEMASK", Actions.AskWindowStatemask, this.ParseWindowStatemask);

            PushCommandToQueue(GET_PREFIX + TEMP_SETTINGS_COMMAND, Actions.AskTemperatureParams, this.ParseTemperatureParams); // получаем настройки температур открытия/закрытия
            PushCommandToQueue(GET_PREFIX + CONTROLLER_DATETIME_COMMAND, Actions.AskControllerDateTime, ParseControllerDateTime); // получаем дату/время из контроллера

        }

        private void ParseWindowStatemask(Answer a)
        {
            // получили состояние окон по отдельности, в виде маски
            if (a.IsOkAnswer)
            {
                // ответ удачен, смотрим, что там
                int totalWindows = Convert.ToInt32(a.Params[3]);
                string byteHolder = a.Params[4];

                // теперь считаем, сколько байт будем читать
                int numBits = totalWindows * 2;
                int numBytes = numBits / 8;
                if (numBits % 8 > 0)
                    numBytes++;

                // добавляем нужное кол-во окон
                while (appSettings.WindowStates.Count < totalWindows)
                {
                    appSettings.WindowStates.Add(GreenHouseConfig.WindowState.Unknown);
                }

                // теперь пробегаемся по всем байтам
                int windowIndex = 0; // текущая позиция записи в массив состояний окон
                for (int i = 0; i < numBytes; i++)
                {
                    string strByte = byteHolder.Substring(0, 2);
                    byteHolder = byteHolder.Substring(2);

                    byte bState = (byte)int.Parse(strByte, System.Globalization.NumberStyles.HexNumber);
                    // сконвертировали строку в байт, теперь смотрим

                    // в одном байте у нас - состояние 4-х окон
                    for (int bitPos = 0; bitPos < 8; bitPos += 2)
                    {
                        // получаем младший бит
                        bool bLow = (bState & (1 << bitPos)) == (1 << bitPos);
                        // получаем старший бит
                        bool bHigh = (bState & (1 << (bitPos+1))) == (1 << (bitPos+1));

                        GreenHouseConfig.WindowState ws = GreenHouseConfig.WindowState.Unknown;
                        // проверяем комбинации
                        if (!bLow && !bHigh)
                        {
                            ws = GreenHouseConfig.WindowState.Closed;
                        }
                        else
                        if (!bHigh && bLow)
                        {
                            ws = GreenHouseConfig.WindowState.Opening;
                        }
                        else
                        if (bHigh && !bLow)
                        {
                            ws = GreenHouseConfig.WindowState.Closing;
                        }
                        else
                            if (bHigh && bLow)
                            {
                                ws = GreenHouseConfig.WindowState.Open;
                            }

                        // сохраняем состояние
                        appSettings.WindowStates[windowIndex] = ws;
                        windowIndex++; // переходим на следующее окно
                    } // for

                } // for
            }
        }

        /// <summary>
        /// Обрабатываем полученную от контроллера дату и время
        /// </summary>
        /// <param name="a"></param>
        private void ParseControllerDateTime(Answer a)
        {
            if (a.IsOkAnswer)
            {
                try
                {
                    string dtStr = a.Params[0];
                    dtStr = dtStr.Substring(dtStr.IndexOf(" ") + 1);

                    this.controllerDateTime = DateTime.ParseExact(dtStr, "dd.MM.yyyy HH:mm:ss", null);
                    dateTimeFromControllerReceived = true;
                }
                catch (FormatException e)
                {
                    dateTimeFromControllerReceived = false;
                }
                catch
                {
                    dateTimeFromControllerReceived = false;
                }

            }
        }
        /// <summary>
        /// Заполняем список дней полива для опции "По дням недели, все каналы одновременно"
        /// </summary>
        private void FillWateringDays()
        {
            int bWateringDays = appSettings.WateringDays;

            for (byte i = 0; i < 8; i++)
            {
                int check = 1 << i;
                if ((bWateringDays & check) == check)
                {
                    this.clbWeekDays.SetItemChecked(i, true);
                }
            }

            try
            {
                nudWateringTime.Value = appSettings.WateringTime;
                nudStartWateringTime.Value = appSettings.StartWateringTime;
            }
            catch { }
            chbTurnOnPump.Checked = appSettings.TurpOnPump == 1;
        }

        /// <summary>
        /// Переключаемся в режим ожидания
        /// </summary>
        /// <param name="paused"></param>
        private void SwitchToPause(bool paused)
        {
            this.bWorkPaused = paused;
            if (this.bWorkPaused)
            {
                tbPlayPause.Image = Resources.play;
                tbPlayPause.Text = Settings.Default.Play;
                miPlayPause.Text = Settings.Default.Play;

                tbPlayPause.ToolTipText = Settings.Default.PlayTooptip;
            }
            else
            {
                tbPlayPause.Image = Resources.pause;
                tbPlayPause.Text = Settings.Default.Pause;
                miPlayPause.Text = Settings.Default.Pause;

                tbPlayPause.ToolTipText = Settings.Default.PauseTooltip;
            }
        }

     
        /// <summary>
        /// Проверяем, соединены ли мы с контроллером
        /// </summary>
        /// <returns></returns>
        private bool IsConnected()
        {
            if (currentTransport != null)
                return currentTransport.Connected();
          
            return false;
        }

        private bool inSaveCompositeCommandsToController = false;
        private bool inRequestPinsUsedFromController = false;

        /// <summary>
        /// Обработчик простоя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Application_Idle(object sender, EventArgs e)
        {

            bool bConnected = IsConnected();

            tbPlayPause.Enabled = bConnected;
            miPlayPause.Enabled = bConnected;

            if (!bConnected)
                inSaveIoTSettings = false;

            btnSaveIoTSettings.Enabled = bConnected && !inSaveIoTSettings;

           

            btnClearCCCommands.Enabled = bConnected;
            btnResetWaterflowData.Enabled = bConnected;

            btnSetControllerTime.Enabled = bConnected;
            miDateTime.Enabled = bConnected;

            this.nudTClose.Enabled = bConnected;
            this.nudTOpen.Enabled = bConnected;
            this.cbTempSettings.Enabled = bConnected;
            this.nudInterval.Enabled = bConnected;
            btnSavePhoneNumber.Enabled = bConnected;// && this.tbPhoneNumber.Text != appSettings.PhoneNumber;
            btnQueryIP.Enabled = bConnected;

            btnLoadRules.Enabled = bConnected && !inGetRulesFromController;
            btnEditRule.Enabled = lvRulesList.SelectedItems.Count > 0;
            btnDeleteRule.Enabled = btnEditRule.Enabled;

            btnEditCompositeCommand.Enabled = lvCompositeCommandsList.SelectedItems.Count > 0;
            btnDeleteCompositeCommand.Enabled = btnEditCompositeCommand.Enabled;
            btnUploadCompositeCommands.Enabled = bConnected && !inSaveCompositeCommandsToController;

            btnSaveRules.Enabled = bConnected && !inSaveRulesToController;
            btnLoadLogs.Enabled = bConnected && !inLoadLogsFromController;

            tbDelta.Enabled = bConnected && deltasLoaded;
            tbDelta.Visible = canWorkWithDeltas;
            miDelta.Enabled = tbDelta.Enabled;
            miDelta.Visible = tbDelta.Visible;

            miPinsUsed.Enabled = bConnected && !inRequestPinsUsedFromController;

            miUniversalSensors.Enabled = bConnected;
            miFirmwareInfo.Enabled = bConnected;
            miReservationSettings.Enabled = bConnected;
            miTimers.Enabled = bConnected;

            tbRestartButton.Enabled = bConnected;
            miRestart.Enabled = bConnected;
 

            cbWateringControl.Enabled = bConnected;
            WateringControlIndexChanged();

            if (!bConnected) // порт закрыт
            {
                if (this.lastSelectedPort != null)
                    this.lastSelectedPort.Checked = false;

                this.tbbConnectBtn.ImageIndex = 0; // коннект оборвался
                this.tbbConnectBtn.Text = Settings.Default.Connect;//"Соединить";

                tmrTicks.Enabled = false; // выключаем внутренний таймер
                tmrUptime.Enabled = true; // включаем таймер запроса аптайма от контроллера

                tbSetWorkMode.Enabled = false;
                tbWindowPosition.Enabled = false;

                HideTabPages();

 
            }
            else
            {

                if (lastSelectedPort != null)
                    if (!lastSelectedPort.Checked)
                        lastSelectedPort.Checked = true;


            }


            int tO = Convert.ToInt32(this.nudTOpen.Value);
            int tC = Convert.ToInt32(this.nudTClose.Value);
            if (tO != this.appSettings.TOpen || tC != this.appSettings.TClose || 
                this.appSettings.Interval != 1000*Convert.ToInt32(nudInterval.Value))
            {
                this.btnWriteTempSettings.Enabled = bConnected;
            }
            else
            {
                this.btnWriteTempSettings.Enabled = false;

            }
        }
        /// <summary>
        /// Класс опций полива
        /// </summary>
        private class WateringOption
        {
            private string text;
            public string Text
            {
                get { return text; }
                set { text = value; }
            }
            private int tag;
            public int Tag
            {
                get { return tag; }
                set { tag = value; }
            }
            public WateringOption(string s, int tag)
            {
                this.text = s;
                this.tag = tag;
            }
            public override string ToString()
            {
                return this.text;
            }
        }

        /// <summary>
        /// Заполняем список возможных опций управления поливом
        /// </summary>
        private void FillComboWithWateringOptions()
        {

            cbWateringControl.Items.Add(new WateringOption(Settings.Default.Off, 0));
            cbWateringControl.Items.Add(new WateringOption(Settings.Default.WeekDays, 1));
            cbWateringControl.Items.Add(new WateringOption(Settings.Default.WeekDaysChannels, 2));
            cbWateringControl.SelectedIndex = appSettings.WateringOption;

        }
        /// <summary>
        /// Заполняем список преднастроенных температур открытия/закрытия
        /// </summary>
        private void FillComboWithTemperatures()
        {
            this.cbTempSettings.Items.Add(Settings.Default.NotSelected);
            this.cbTempSettings.SelectedIndex = 0;
            foreach (TemperatureSettings ts in appSettings.Temperatures)
            {
                this.cbTempSettings.Items.Add(ts);
            }

        }
        /// <summary>
        /// Перечисляем COM-порты
        /// </summary>
        private void EnumSerialPorts()
        {
            
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {

                ToolStripMenuItem ti = new ToolStripMenuItem(port);

                ti.MergeIndex = 1;
                ti.AutoSize = true;
                ti.ImageScaling = ToolStripItemImageScaling.None;
                ti.Tag = port;
                ti.Click += new EventHandler(ti_Click);
                ti.CheckOnClick = false;



                tsiCOMConnection.DropDownItems.Add(ti);
               
                
            }
        }

        /// <summary>
        /// Обработчик события "Пришла строка из транспортного уровня"
        /// </summary>
        /// <param name="a"></param>
        public delegate void DataParseFunction(Answer a);

        /// <summary>
        /// Структура команды на обработку
        /// </summary>
        private struct QueuedCommand
        {
            public string CommandToSend;
            public Actions ActionToSet;
            public DataParseFunction ParseFunction;
        };

        /// <summary>
        /// Помещаем команду в очередь на обработку
        /// </summary>
        /// <param name="cmd">Текстовая команда для контроллера</param>
        /// <param name="act">К какому действию команда привязана</param>
        /// <param name="func">Указатель на функцию-обработчик ответа от контроллера</param>
        public void PushCommandToQueue(string cmd, Actions act, DataParseFunction func)
        {
            QueuedCommand q = new QueuedCommand();
            q.ActionToSet = act;
            q.CommandToSend = cmd;
            q.ParseFunction = func;
            if (!commandsQueue.Contains(q))
                commandsQueue.Enqueue(q);
         

        }

        /// <summary>
        /// Возвращаем команду из очереди
        /// </summary>
        /// <param name="outCmd">Команда, которая получена из очереди</param>
        /// <returns>Возвращаем false, если команд в очереди нет, иначе - true</returns>
        private bool GetCommandFromQeue(ref QueuedCommand outCmd)
        {
            if (commandsQueue.Count < 1)
                return false;

            outCmd = commandsQueue.Dequeue();
            return true;
        }

        /// <summary>
        /// Очередь команд
        /// </summary>
        private Queue<QueuedCommand> commandsQueue = new Queue<QueuedCommand>();


        /// <summary>
        /// Инициализируем необходимое после успешного коннекта
        /// </summary>
        private void InitAfterSuccessfullConnect() 
        {
            this.tbbConnectBtn.ImageIndex = 1;
            this.tbbConnectBtn.Text = Settings.Default.Connected;// "Соединено";
            SwitchToPause(false); // выводим, что мы играем с командами

            // очистим список настроек каналов полива
            appSettings.WateringChannels.Clear();
            appSettings.WaterChannelsCount = 0;

            // добавляем нужные команды для обработки сразу после коннекта
            PushCommandToQueue(GET_PREFIX + "0|ID", Actions.AskControllerID, ParseAskControllerID);
            PushCommandToQueue(GET_PREFIX + "0|RF", Actions.AskRFChannel, ParseAskRFChannel);
            PushCommandToQueue(GET_PREFIX + "0|WIRED", Actions.AskHardCodedSensors, ParseAskHardCodedSensors);
            PushCommandToQueue(GET_PREFIX + "0|UNI", Actions.AskUniversalSensors, ParseAskUniversalSensors);
            PushCommandToQueue(GET_PREFIX + GET_WATER_CHANNELS, Actions.AskWaterChannels, this.ParseWaterChannels);
            PushCommandToQueue(GET_PREFIX + INTERVAL_COMMAND, Actions.AskWindowWorkInterval, this.ParseWindowWorkInterval);
            PushCommandToQueue(GET_PREFIX + LIST_MODULES_COMMAND, Actions.AskRegisteredModules, this.ParseRegisteredModules);

            tmWaitDataTimer.Enabled = true; // ждём данные с порта с таймаутом
        }
   
        private ConnectForm connForm = null;

        private void ParseAskRFChannel(Answer a)
        {
            if (a.IsOkAnswer)
            {
                appSettings.RFChannel = Convert.ToByte(a.Params[1]);
            }
        }

        /// <summary>
        /// Отсоединяемся
        /// </summary>
        private void Disconnect() // отсоединяемся от порта
        {
            if (currentTransport != null)
                currentTransport.Disconnect();

            currentTransport = null;


            HideTabPages(); // скрываем все вкладки до момента коннекта

        }

        /// <summary>
        /// Коннектимся к порту
        /// </summary>
        /// <param name="port">Имя порта</param>
        public void StartConnectToPort(string port)
        {
            System.Diagnostics.Debug.Assert(currentTransport == null);

            // создаём новый транспорт
            currentTransport = new SerialPortTransport(port);
            currentTransport.OnConnect = new ConnectResult(OnCOMConnect);
            currentTransport.OnLineReceived = new TransportLineReceived(OnDataFromCOMPort);

            // коннектимся
            currentTransport.Connect();

        }

        /// <summary>
        /// Обрабатываем строку, пришедшую из транспорта COM-порта
        /// </summary>
        /// <param name="line"></param>
        private void OnDataFromCOMPort(string line)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { OnDataFromCOMPort(line); });
                return;
            }
            EnsureCloseConnectionForm(); // закрываем форму коннекта, если она ещё не закрыта


            // обрабатываем данные, полученные из порта
            ProcessPortAnswer(line.Trim());
        }

        /// <summary>
        /// Обрабатываем результат соединения с портом
        /// </summary>
        /// <param name="succ"></param>
        /// <param name="message"></param>
        private void OnCOMConnect(bool succ, string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { OnCOMConnect(succ, message); });
                return;
            }

            // обнуляем текущее состояние при переконнекте
            this.currentCommand.ActionToSet = Actions.None;

            if (succ)
            {
                InitAfterSuccessfullConnect();

            }
            else
            {
                EnsureCloseConnectionForm();
                this.tbbConnectBtn.ImageIndex = 0;
                this.tbbConnectBtn.Text = Settings.Default.Connect;// "Соединить";
                MessageBox.Show(message, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            if (succ && connForm != null)
            {
                connForm.lblCurrentAction.Text = Settings.Default.WaitPortData;// "Ждём данные из порта...";
            }
        }

       /// <summary>
       /// Начинаем коннектиться к порту
       /// </summary>
       /// <param name="port">имя порта</param>
        private void DoConnect(string port)
        {
            dateTimeFromControllerReceived = false; // не получили ещё текущее время с контроллера
            controllerDateTime = DateTime.MinValue; // устанавливаем минимальное значение даты

            connForm = new ConnectForm();
            connForm.SetMainFormAndPort(this,port);
            connForm.ShowDialog(); 
        }

        /// <summary>
        /// Обработчик события выбора порта в меню
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ti_Click(object sender, EventArgs e)
        {
            // коннектимся к выбранному COM-порту
            Disconnect(); // сначала отсоединяемся

            ToolStripMenuItem mi = (ToolStripMenuItem)sender;
            if (this.lastSelectedPort != null)
                this.lastSelectedPort.Checked = false;

            this.lastSelectedPort = mi;
            mi.Checked = true;

            DoConnect((string)mi.Tag);
        }

        private const string GET_PREFIX = "CTGET=";
        private const string SET_PREFIX = "CTSET=";
        private const char PARAM_DELIMITER = '|';

        private const string FREERAM_COMMAND = "STAT|FREERAM"; // получить данные о свободной памяти
        private const string UPTIME_COMMAND = "STAT|UPTIME"; // получить время работы контроллера
        private const string CONTROLLER_DATETIME_COMMAND = "STAT|DATETIME"; // получить текущее время и дату с контроллера
        private const string TEMP_COMMAND = "STATE|TEMP|"; // получить температуру с датчика
        private const string MODE_COMMAND = "STATE|MODE"; // команда режима работы окон - автоматический или ручной 
        private const string WINDOW_COMMAND = "STATE|WINDOW|ALL"; // команда управления окнами
        private const string INTERVAL_COMMAND = "STATE|INTERVAL"; // сохранить интервал работы моторов
        private const string TEMP_SETTINGS_COMMAND = "STATE|T_SETT"; // сохранить настройки температур открытия/закрытия
        private const string RULE_INTERNAL_ADD_COMMAND = "ALERT|RULE_ADD|{0}|STATE|TEMP|0|{3}|{1}|0|0|255|_|0|CTSET=STATE|WINDOW|ALL|{2}";
        private const string RULE_SAVE_COMMAND = "ALERT|SAVE"; // сохранить правила
        private const string PHONE_NUMBER_COMMAND = "0|PHONE|"; // запомнить номер телефона
        private const string LIST_MODULES_COMMAND = "0|LIST"; // пролистать все зарегистрированные модули
        private const string WATERING_OPTIONS_COMMAND = "WATER|T_SETT";
        private const string LUMINOSITY_COMMAND = "LIGHT";
        private const string WATERING_COMMAND = "WATER";
        private const string WATERING_MODE_COMMAND = "WATER|MODE";
        private const string GET_WATER_CHANNELS = "WATER|CHANNELS";
        private const string GET_WATER_CHANNELS_SETTING = "WATER|CH_SETT|";
        private const string LUX_COMMAND = "LIGHT|STATE";
        private const string LUX_MODE_COMMAND = "LIGHT|MODE";
        private const string RULE_LUX_ADD_COMMAND = "ALERT|RULE_ADD|{0}|LIGHT|LIGHT|0|{1}|{2}|{3}|{4}|255|{5}|0|CTSET=LIGHT|{6}";
        private const string SET_DATETIME_COMMAND = "0|DATETIME|";
        private const string RULE_STATE_COMMAND = "ALERT|RULE_STATE|{0}|{1}";
        private const string ALL_TEMP_DATA_COMMAND = "CTGET=STATE|TEMP|ALL";
        private const string ALL_HUMIDITY_DATA_COMMAND = "CTGET=HUMIDITY|ALL";
        private const string WIFI_SETTINGS_COMMAND = "WIFI|T_SETT|";
        private const string WIFI_IP_COMMAND = "WIFI|IP";
        private const string RULES_CNT_COMMAND = "ALERT|RULES_CNT";
        private const string RULE_VIEW_COMMAND = "ALERT|RULE_VIEW|";
        private const string RULE_DELETE_COMMAND = "ALERT|RULE_DELETE|";
        private const string RULE_ADD_COMMAND = "ALERT|RULE_ADD|";
        private const string LOG_GET_FILE_COMMAND = "LOG|FILE|"; // получить файл лога
        private const string DELTA_COUNT_COMMAND = "DELTA|CNT";
        private const string DELTA_VIEW_COMMAND = "DELTA|VIEW|";
        private const string DELTA_DEL_COMMAND = "DELTA|DEL";
        private const string DELTA_SAVE_COMMAND = "DELTA|SAVE";
        private const string DELTA_ADD_COMMAND = "DELTA|ADD|";
        private const string ALL_STAT_COMMAND = "0|STAT";
        private const string FLOW_SETTINGS_COMMAND = "FLOW|T_SETT";
  
        private const string AUTO = "AUTO";
        private const string MANUAL = "MANUAL";
        private const string OPEN = "OPEN";
        private const string OPENING = "OPENING";
        private const string CLOSING = "CLOSING";
        private const string CLOSED = "CLOSED";
        private const string CLOSE = "CLOSE";
        private const string ON = "ON";
        private const string OFF = "OFF";
        private const string BUSY = "BUSY";

        private const int NO_TEMPERATURE_DATA = -128; // нет данных с датчиков

        /// <summary>
        /// Список доступных действий с контроллером
        /// </summary>
        public enum Actions
        {
            /// <summary>
            /// ничего не делаем
            /// </summary>
            None,
            /// <summary>
            /// перезагружаем контроллер
            /// </summary>
            Reset,
            /// <summary>
            /// спрашиваем о свободной памяти
            /// </summary>
            AskFreeRam,
            /// <summary>
            /// спрашиваем аптайм
            /// </summary>
            AskUptime,
            /// <summary>
            /// спрашиваем температуру на датчиках
            /// </summary>
            AskTemperature,
            /// <summary>
            /// запрашиваем положение окон
            /// </summary>
            AskWindowPosition,
            /// <summary>
            /// запрашиваем интервал работы окон
            /// </summary>
            AskWindowWorkInterval,
            /// <summary>
            /// запрашиваем установки температур открытия/закрытия
            /// </summary>
            AskTemperatureParams,
            /// <summary>
            /// запрашиваем список зарегистрированных в системе модулей
            /// </summary>
            AskRegisteredModules,
            /// <summary>
            /// запрашиваем кол-во поддерживаемых каналов полива
            /// </summary>
            AskWaterChannels,
            /// <summary>
            /// запрашиваем настройки канала полива
            /// </summary>
            AskWaterChannelSetting,
            /// <summary>
            /// запрашиваем текущие дату/время с контроллера
            /// </summary>
            AskControllerDateTime,
            /// <summary>
            /// запрашиваем данные об IP
            /// </summary>
            AskWiFiIP,
            /// <summary>
            /// запрашиваем данные о кол-ве правил
            /// </summary>
            AskRulesCount,
            /// <summary>
            /// запрашиваем данные о правиле
            /// </summary>
            AskRuleView,
            /// <summary>
            /// запрашиваем лог-файл
            /// </summary>
            AskLogFile,
            /// <summary>
            /// запрашиваем кол-во дельт
            /// </summary>
            AskDeltasCount,
            /// <summary>
            /// запрашиваем информацию об одной дельте
            /// </summary>
            AskOneDelta,
            /// <summary>
            /// получаем всю статистику в сжатом виде
            /// </summary>
            AskAllStat,

            AskGSMProvider,
            SetGSMProvider,

            /// <summary>
            /// запрашиваем настройки PH
            /// </summary>
            AskPHSettings,

            /// <summary>
            /// Устанавливаем настройки PH
            /// </summary>
            SetPHSettings,

            /// <summary>
            /// запрашиваем состояние окон по маске
            /// </summary>
            AskWindowStatemask,

            /// <summary>
            /// Получаем ID контроллера
            /// </summary>
            AskControllerID,

            /// <summary>
            /// Получаем жёстко прошитые датчики
            /// </summary>
            AskHardCodedSensors,

            /// <summary>
            /// Запрашиваем кол-во зарегистрированных универсальных модулей
            /// </summary>
            AskUniversalSensors,

            /// <summary>
            /// Запрашиваем настройки калибровки датчиков расхода воды
            /// </summary>
            AskFlowSettings,

            /// <summary>
            /// Добавляем кастомное СМС
            /// </summary>
            AddCustomSMS,

            /// <summary>
            /// Запрашиваем кол-во резервирований
            /// </summary>
            AskReservationsCount,

            /// <summary>
            /// Запрашиваем информацию об одном резервировании
            /// </summary>
            AskOneReservation,

            /// <summary>
            /// запрашиваем настройки таймеров
            /// </summary>
            AskTimersSettings,

            /// <summary>
            /// запрашиваем установку номера канала для nRF
            /// </summary>
            AskRFChannel,

            /// <summary>
            /// запрашиваем настройки IoT
            /// </summary>
            AskIOTSettings,

            /// <summary>
            /// сохраняем настройки IoT
            /// </summary>
            SetIoTSettings,

            /// <summary>
            /// Устанавливаем настройки таймеров
            /// </summary>
            SaveTimersSettings,

            /// <summary>
            /// Удаляем список резервов датчиков
            /// </summary>
            DeleteReservations,

            /// <summary>
            /// Сохраняем список резервов датчиков
            /// </summary>
            SaveReservations,

            /// <summary>
            /// Добавляем один список резервов датчиков
            /// </summary>
            AddReservation,

            /// <summary>
            /// Устанавливаем факторы калибровки
            /// </summary>
            SetFlowSettings,

            /// <summary>
            /// устанавливаем позицию окон
            /// </summary>
            SetWindowPosition,
            /// <summary>
            /// устанавливаем режим работы окон
            /// </summary>
            SetWindowWorkMode,
            /// <summary>
            /// устанавливаем температуры открытия/закрытия
            /// </summary>
            SetTemperatureParams,
            /// <summary>
            /// устанавливаем интервал открытия/закрытия окон
            /// </summary>
            SetWindowInterval,
            /// <summary>
            /// пишем внутреннее правило
            /// </summary>
            SetSpecialRule,
            /// <summary>
            /// сохраняем правила в EEPROM
            /// </summary>
            SetSaveRules,
            /// <summary>
            /// сохраняем номер телефона
            /// </summary>
            SetPhoneNumber,
            /// <summary>
            /// сохраняем настройки полива
            /// </summary>
            SetWateringOptions,
            /// <summary>
            /// включаем/выключаем полив
            /// </summary>
            SetWateringOnOff,
            /// <summary>
            /// устанавливаем режим работы полива
            /// </summary>
            SetWateringMode,
            /// <summary>
            /// устанавливаем настройки канала полива
            /// </summary>
            SetWateringChannelOptions,
            /// <summary>
            /// включаем/выключаем досветку
            /// </summary>
            SetLuxOnOff,
            /// <summary>
            /// устанавливаем режим работы досветки
            /// </summary>
            SetLuxMode,
            /// <summary>
            /// устанавливаем дату/время
            /// </summary>
            SetDatetimeCommand,
            /// <summary>
            /// сохраняем настройки Wi-Fi
            /// </summary>
            SetWiFiSettings,
            /// <summary>
            /// удаляем правила
            /// </summary>
            SetRuleDelete,
            /// <summary>
            /// добавляем правила
            /// </summary>
            SetRuleAdd,
            /// <summary>
            /// сохраняем правила
            /// </summary>
            SetRuleSave,
            /// <summary>
            /// устанавливаем состояние правила
            /// </summary>
            SetRuleState,
            /// <summary>
            /// удаляем дельты
            /// </summary>
            SetDeleteDeltas,
            /// <summary>
            /// сохраняем дельты
            /// </summary>
            SetSaveDeltas,
            /// <summary>
            /// добавляем дельту
            /// </summary>
            SetAddDelta,
            /// <summary>
            /// Удаляем все составные команды
            /// </summary>
            SetDeleteCompositeCommands,
            /// <summary>
            /// Добавляем составную команду
            /// </summary>
            SetAddCompositeCommand,
            /// <summary>
            /// Сохраняем составные команды
            /// </summary>
            SetSaveCompositeCommands,

            /// <summary>
            /// сбрасываем показания с датчиков расхода воды
            /// </summary>
            ResetWaterflowData,

            /// <summary>
            /// Устанавливаем ID контроллера
            /// </summary>
            SetControllerID,
            SearchUniModules,
            UpdateUniModule,
            RegisterUniModule,
            
            /// <summary>
            /// Получаем информацию по используемым пинам
            /// </summary>
            GetPinsUsed

        };

        /// <summary>
        /// в каком режиме работает управление окнами
        /// </summary>
        private enum WindowsWorkMode 
        {
            /// <summary>
            /// пока ничего не знаем о режиме
            /// </summary>
            wmUnknown, 
            /// <summary>
            /// автоматический режим работы форточек
            /// </summary>
            wmAutomatic,
            /// <summary>
            /// ручной режим работы форточек
            /// </summary>
            wmManual
        };

        /// <summary>
        ///  в каком положении находятся окна
        /// </summary>
        private enum WindowsPosition 
        {
            /// <summary>
            /// пока ничего не знаем
            /// </summary>
            wpUnknown, 
            /// <summary>
            /// открыты
            /// </summary>
            wpOpen,
            /// <summary>
            /// закрыты
            /// </summary>
            wpClosed, 
            /// <summary>
            /// открываются
            /// </summary>
            wpOpening,
            /// <summary>
            /// закрываются
            /// </summary>
            wpClosing
        };

        /// <summary>
        /// текущий режим работы по управлению форточками
        /// </summary>
        private WindowsWorkMode WindowWorkMode = WindowsWorkMode.wmUnknown;
        /// <summary>
        /// текущее положение окон
        /// </summary>
        private WindowsPosition CurrentWindowsPosition = WindowsPosition.wpUnknown;
   
        /// <summary>
        /// обработчик события закрытия формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            appSettings.SelectedSetting = this.cbTempSettings.SelectedIndex;
            appSettings.PhoneNumber = this.tbPhoneNumber.Text;

            appSettings.Save();

            Disconnect(); // отсоединяемся
        }
        /// <summary>
        /// закрываем форму ожидания соединения
        /// </summary>
        private void EnsureCloseConnectionForm()
        {
            if (connForm != null)
            {
                connForm.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            connForm = null;
        }

          private TransportLineReceived ContinuousReadingFinction = null; // указатель на функцию продолжающегося чтения

        /// <summary>
        /// обрабатываем ответ от контроллера
        /// </summary>
        /// <param name="dt">строка, которая пришла из порта</param>
        private void ProcessPortAnswer(string dt)
        {
           
            EnsureCloseConnectionForm(); // закрываем форму коннекта, если она ещё не закрыта

            if (this.currentCommand.ActionToSet == Actions.None)
            {
                this.AddToLog(dt);
                return;
            }
            Answer a = new Answer(dt);
            if (ContinuousReadingFinction == null)
            {
                try
                {
                    this.currentCommand.ParseFunction(a);
                }
                catch { }
            }
            a = null;

            if (ContinuousReadingFinction == null) // указатель на функцию продолжающегося чтения не установлен, можно обрабатывать следующую команду
                this.currentCommand.ActionToSet = Actions.None; // сбрасываем текущую операцию в ноль
            else
                ContinuousReadingFinction(dt); // попросили читать, пока не сбросят указатель на функцию
        }

        /// <summary>
        /// Показывает или скрывает вкладку
        /// </summary>
        /// <param name="tp">вкладка</param>
        /// <param name="bShow">флаг - показывать или скрыть</param>
        private void ShowTabPage(TabPage tp, bool bShow)
        {
            if (!bShow)
            {
                tabCMain.TabPages.Remove(tp);
                return;
            }

            if (!tabCMain.Contains(tp))
                tabCMain.TabPages.Add(tp);
        }
        /// <summary>
        /// Обработчик ответа на команду перезагрузки контроллера
        /// </summary>
        /// <param name="a"></param>
        private void ProcessReset(Answer a)
        {
            AddToLog(a.RawData);
        }

        /// <summary>
        /// разбираем настройки канала полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseWaterChannelSetting(Answer a)
        {
            if (a.IsOkAnswer)
            {
                WateringChannelSettings s = new WateringChannelSettings();
                s.WateringDays = Convert.ToInt32(a.Params[3]);
                s.WateringTime = Convert.ToInt32(a.Params[4]);
                s.StartWateringTime = Convert.ToInt32(a.Params[5]);

                appSettings.WateringChannels.Add(s);


                int idx = dgvWateringChannels.Rows.Add(appSettings.WateringChannels.Count.ToString(), "", "",
                    s.WateringDays.ToString()
                    );
                DataGridViewRow row = dgvWateringChannels.Rows[idx];
                row.Tag = s;
              

            }

        }
        /// <summary>
        /// разбираем кол-во прошитых каналов полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseWaterChannels(Answer a)
        {
            if (a.IsOkAnswer)
            {
                appSettings.WaterChannelsCount = Convert.ToInt32(a.Params[2]);

                this.dgvWateringChannels.Rows.Clear(); // очищаем список

                for (int i = 0; i < appSettings.WaterChannelsCount; i++)
                {
                    PushCommandToQueue(GET_PREFIX + GET_WATER_CHANNELS_SETTING + i.ToString(), Actions.AskWaterChannelSetting, this.ParseWaterChannelSetting);
                }
            }

        }

        /// <summary>
        /// можем ли мы запрашивать освещенность?
        /// </summary>
        private bool canQueryLuminosity = false;
        /// <summary>
        /// можем ли мы запрашивать освещенность?
        /// </summary>
        public bool CanQueryLuminosity
        {
            get { return canQueryLuminosity; }
        }
        /// <summary>
        /// можем ли мы запрашивать температуру?
        /// </summary>
        private bool canQueryTemperature = false;
        /// <summary>
        /// можем ли мы запрашивать температуру?
        /// </summary>
        public bool CanQueryTemperature
        {
            get { return canQueryTemperature; }
        }
        /// <summary>
        /// можем ли запрашивать статистику?
        /// </summary>
        private bool canQueryStat = false;
        /// <summary>
        /// можем запрашивать состояние полива?
        /// </summary>
        private bool canQueryWateringState = false;
        /// <summary>
        /// можем ли мы запрашивать влажность?
        /// </summary>
        private bool canQueryHumidity = false;
        /// <summary>
        /// можем ли мы запрашивать влажность?
        /// </summary>
        public bool CanQueryHumidity
        {
            get { return canQueryHumidity; }
        }
        /// <summary>
        /// доступна ли вкладка настройки Wi-Fi?
        /// </summary>
        private bool canDriveWiFi = false;
        /// <summary>
        /// доступна ли вкладка управления по SMS?
        /// </summary>
        private bool canDriveSMS = false;
        /// <summary>
        /// доступна ли вкладка работы с лог-файлами
        /// </summary>
        private bool canDriveLog = false;
        /// <summary>
        /// можем ли работать с дельтами?
        /// </summary>
        private bool canWorkWithDeltas = false;
        /// <summary>
        /// флаг загрузки дельт
        /// </summary>
        private bool deltasLoaded = false;
        private int deltasToQuery = 0;

        /// <summary>
        /// Можем ли мы работать с датчиками влажности почвы?
        /// </summary>
        private bool canQuerySoilMoisture = false;

        /// <summary>
        /// Доступна ли нам вкладка "Составные команды"
        /// </summary>
        private bool canDriveCompositeCommands = false;

        /// <summary>
        /// Доступна ли вкладка расхода воды
        /// </summary>
        private bool canWorkWithFlow = false;

        private bool canWorkWithPH = false;

        private bool canWorkWithIoT = false;

        /// <summary>
        /// обновляем дельты в контроллере
        /// </summary>
        private void UpdateDeltas()
        {
            deltasLoaded = false;
            PushCommandToQueue(SET_PREFIX + DELTA_DEL_COMMAND, Actions.SetDeleteDeltas, ParseDeleteDeltas);

            foreach (DeltaSettings ds in appSettings.DeltaSettings)
            {
                PushCommandToQueue(SET_PREFIX + DELTA_ADD_COMMAND + ds.ToString(), Actions.SetAddDelta, ParseAddDelta);
            }

            PushCommandToQueue(SET_PREFIX + DELTA_SAVE_COMMAND, Actions.SetSaveDeltas, ParseSaveDeltas);
        }

        private void ParseAskReservationsCount(Answer a)
        {
            if (a.IsOkAnswer) //OK=RSRV|CNT|Num
            {
                // можем запрашивать список резервирования
                int cnt = Convert.ToInt32(a.Params[2]);
                for (int i = 0; i < cnt; i++)
                {
                    PushCommandToQueue(GET_PREFIX + "RSRV|VIEW|" + i.ToString(), Actions.AskOneReservation, ParseAskOneReservation);
                } // for
            }
        }

        private void ParseAskOneReservation(Answer a)
        {
            if (a.IsOkAnswer) // OK=RSRV|VIEW|Num|Type|Module1|Idx1|Module2|Idx2|ModuleN|IdxN
            {
                string type = a.Params[3];
                SensorType st = SensorType.None;
                if (type == "TEMP")
                    st = SensorType.Temperature;
                else if (type == "LIGHT")
                    st = SensorType.Luminosity;
                else if (type == "HUMIDITY")
                    st = SensorType.Humidity;
                else if (type == "SOIL")
                    st = SensorType.SoilMoisture;

                ReservationSetting rs = new ReservationSetting();
                rs.Type = st;
                for (int i = 4; i < a.Params.Count(); i+=2)
                {
                    string moduleName = a.Params[i];
                    int sensorIndex = Convert.ToInt32(a.Params[i+1]);
                    rs.List.Add(new ReservationInfo(moduleName,sensorIndex));
                }

                AppSettings.Instance.ReservationSettings.Add(rs);
            }
        } 

        /// <summary>
        /// функция, вызывающаяся после добавления дельты в контроллер
        /// </summary>
        /// <param name="a"></param>
        private void ParseAddDelta(Answer a)
        {
            if (a.IsOkAnswer)
            {
            }
        }
        /// <summary>
        /// Функция, вызывающаяся после удаления дельт в контродллере
        /// </summary>
        /// <param name="a"></param>
        private void ParseDeleteDeltas(Answer a)
        {
            if (a.IsOkAnswer)
            {
            }
        }
        /// <summary>
        /// обработчик ответа на команду сохранения дельт
        /// </summary>
        /// <param name="a"></param>
        private void ParseSaveDeltas(Answer a)
        {
            deltasLoaded = true;
        }

        private void ParseAskTimersSettings(Answer a)
        {
            if (a.IsOkAnswer)
            {
                int tmrNum = 0;
                for (int i = 1; i < 17; i+=4)
                {
                    appSettings.Timers[tmrNum].DayMaskAndEnable = Convert.ToByte(a.Params[i]);
                    appSettings.Timers[tmrNum].Pin = Convert.ToByte(a.Params[i + 1]);
                    appSettings.Timers[tmrNum].HoldOnTime = Convert.ToInt32(a.Params[i + 2]);
                    appSettings.Timers[tmrNum].HoldOffTime = Convert.ToInt32(a.Params[i + 3]);
                    tmrNum++;
                }

                miTimers.Visible = true;
            }
        }

        private int phCalibrationFactor = 0;
        private int phVoltage4 = 0;
        private int phVoltage7 = 0;
        private int phVoltage10 = 0;
        private int phTemperatureSensor = 0;
        private decimal phCalibrationTemperature = 0;
        private decimal phTarget = 7.0M;
        private decimal phHisteresis = 0.5M;
        private int phMixPumpTime = 60;
        private int phReagentPumpTime = 60;


        void ParseAskPHSettings(Answer a)
        {
            if (a.IsOkAnswer)
            {
                try
                {
                    phCalibrationFactor = Convert.ToInt32(a.Params[2]);

                    if (phCalibrationFactor < nudPHCalibration.Minimum)
                        phCalibrationFactor = Convert.ToInt32(nudPHCalibration.Minimum);

                    if (phCalibrationFactor > nudPHCalibration.Maximum)
                        phCalibrationFactor = Convert.ToInt32(nudPHCalibration.Maximum);

                    nudPHCalibration.Value = phCalibrationFactor;

                    phVoltage4 = Convert.ToInt32(a.Params[3]);

                    if (phVoltage4 < nudPHVoltage4.Minimum)
                        phVoltage4 = Convert.ToInt32(nudPHVoltage4.Minimum);

                    if (phVoltage4 > nudPHVoltage4.Maximum)
                        phVoltage4 = Convert.ToInt32(nudPHVoltage4.Maximum);
                    
                    nudPHVoltage4.Value = phVoltage4;

                    phVoltage7 = Convert.ToInt32(a.Params[4]);

                    if (phVoltage7 < nudPHVoltage7.Minimum)
                        phVoltage7 = Convert.ToInt32(nudPHVoltage7.Minimum);

                    if (phVoltage7 > nudPHVoltage7.Maximum)
                        phVoltage7 = Convert.ToInt32(nudPHVoltage7.Maximum);
                    
                    nudPHVoltage7.Value = phVoltage7;

                    phVoltage10 = Convert.ToInt32(a.Params[5]);

                    if (phVoltage10 < nudPHVoltage10.Minimum)
                        phVoltage10 = Convert.ToInt32(nudPHVoltage10.Minimum);

                    if (phVoltage10 > nudPHVoltage10.Maximum)
                        phVoltage10 = Convert.ToInt32(nudPHVoltage10.Maximum);
                    
                    nudPHVoltage10.Value = phVoltage10;

                    phTemperatureSensor = Convert.ToInt32(a.Params[6]);

                    if (phTemperatureSensor < nudPHTempSensorIndex.Minimum)
                        phTemperatureSensor = Convert.ToInt32(nudPHTempSensorIndex.Minimum);

                    if (phTemperatureSensor > nudPHTempSensorIndex.Maximum)
                        phTemperatureSensor = Convert.ToInt32(nudPHTempSensorIndex.Maximum);

                    nudPHTempSensorIndex.Value = phTemperatureSensor;

                    phCalibrationTemperature = Convert.ToDecimal(a.Params[7], new System.Globalization.NumberFormatInfo() { NumberDecimalSeparator = "," });

                    if (phCalibrationTemperature < nudPHCalibrationTemperature.Minimum)
                        phCalibrationTemperature = nudPHCalibrationTemperature.Minimum;

                    if (phCalibrationTemperature > nudPHCalibrationTemperature.Maximum)
                        phCalibrationTemperature = nudPHCalibrationTemperature.Maximum;
                    
                    nudPHCalibrationTemperature.Value = phCalibrationTemperature;

                    this.phTarget = Convert.ToDecimal(a.Params[8]) / 100;
                    this.phHisteresis = Convert.ToDecimal(a.Params[9]) / 100;
                    this.phMixPumpTime = Convert.ToInt32(a.Params[10]);
                    this.phReagentPumpTime = Convert.ToInt32(a.Params[11]);

                }
                catch { }
            }
        }

        /// <summary>
        /// разбираем список пришедших зарегистрированных модулей
        /// </summary>
        /// <param name="a"></param>
        private void ParseRegisteredModules(Answer a)
        {
            if (a.IsOkAnswer)
            {
                ShowTabPage(tpRules, true);
                LoadRules(true);

                // если есть модуль резервирования - показываем работу с резервированием
                bool reservationEnabled = a.Params.Contains("RSRV");
                this.miReservationSettings.Visible = reservationEnabled;
                if (reservationEnabled)
                {
                    // получаем список резервирования
                    AppSettings.Instance.ReservationSettings.Clear();
                    PushCommandToQueue(GET_PREFIX + "RSRV|CNT", Actions.AskReservationsCount, ParseAskReservationsCount);

                }

                if (a.Params.Contains("TMR"))
                {
                    // есть работа с таймерами
                    PushCommandToQueue(GET_PREFIX + "TMR", Actions.AskTimersSettings, ParseAskTimersSettings);
                }


                canQueryStat = a.Params.Contains("STAT"); // будем запрашивать статистику или нет?

                canWorkWithDeltas = a.Params.Contains("DELTA"); // есть модуль дельт в прошивке или нет?

                canDriveCompositeCommands = a.Params.Contains("CC"); // есть ли модуль составных команд в прошивке?
                ShowTabPage(tpMultipleCommands, canDriveCompositeCommands);

                canQueryTemperature = a.Params.Contains("STATE"); // будем запрашивать температуру или нет?
                ShowTabPage(tpTemperatureTab, canQueryTemperature);// если не нашли модуль управления фрамугами - скрываем работу с ним

                canQueryWateringState = a.Params.Contains("WATER");
                ShowTabPage(tpWateringTab, canQueryWateringState);// если не нашли модуль управления поливом, скрываем работу с ним


                canQueryLuminosity = a.Params.Contains("LIGHT"); // есть ли модуль освещенности в контроллере?
                ShowTabPage(tpLuminosity, canQueryLuminosity); // если не нашли модуль освещенности - скрываем работу с ним

                canQueryHumidity = a.Params.Contains("HUMIDITY"); // есть ли модуль влажности в контроллере?
                ShowTabPage(tpHumidity, canQueryHumidity); // если не нашли модуль влажности - скрываем работу с ним

                canQuerySoilMoisture = a.Params.Contains("SOIL"); // есть ли модуль датчиков влажности почвы в прошивке?
                ShowTabPage(tpSoilMoisture, canQuerySoilMoisture); // показываем или скрываем закладку датчиков влажности почвы

                ShowTabPage(tpDeltas, canWorkWithDeltas); // показываем вкладку дельт

                /*
                if (this.canQueryHumidity) // можем запрашивать данные со всех датчиков влажности
                {
                    PushCommandToQueue(ALL_HUMIDITY_DATA_COMMAND, Actions.AskAllHumidityData, ParseAllHumidityData);
                }
                 */

                canDriveSMS = a.Params.Contains("SMS");
                ShowTabPage(tpSMSTab, canDriveSMS);// если не нашли SMS-модуль, скрываем работу с ним

                if (canDriveSMS)
                {
                    PushCommandToQueue(GET_PREFIX + "SMS|PROV", Actions.AskGSMProvider, ParseAskGSMProvider);
                }

                canDriveWiFi = a.Params.Contains("WIFI");
                ShowTabPage(tpWiFi, canDriveWiFi);// если не нашли WIFI-модуль, скрываем работу с ним

                canDriveLog = a.Params.Contains("LOG");
                ShowTabPage(tpLog, canDriveLog);

                canWorkWithFlow = a.Params.Contains("FLOW");
                ShowTabPage(tpWaterFlow, canWorkWithFlow);

                if (canWorkWithFlow)
                {
                    PushCommandToQueue(GET_PREFIX + FLOW_SETTINGS_COMMAND, Actions.AskFlowSettings, ParseAskFlowSettings);
                }

                canWorkWithPH = a.Params.Contains("PH");
                ShowTabPage(tpPH, canWorkWithPH);
                if (canWorkWithPH)
                {
                    PushCommandToQueue(GET_PREFIX + "PH|T_SETT", Actions.AskPHSettings, ParseAskPHSettings);
                }

                if (canWorkWithDeltas)
                {
                    // можем запрашивать список дельт
                    appSettings.DeltaSettings.Clear();
                   
                    PushCommandToQueue(GET_PREFIX + DELTA_COUNT_COMMAND, Actions.AskDeltasCount, ParseAskDeltasCount);
                }

                canWorkWithIoT = a.Params.Contains("IOT") && (canDriveSMS || canDriveWiFi);
                ShowTabPage(tpIOT, canWorkWithIoT);
                if (canWorkWithIoT) // IoT у нас через GSM или Wi-Fi
                {
                    PushCommandToQueue(GET_PREFIX + "IOT|T_SETT", Actions.AskIOTSettings, ParseAskIOTSettings);
                }
            }
        }

        private void ParseAskGSMProvider(Answer a)
        {
            if (a.IsOkAnswer)
            {
                try
                {
                    int idx = Convert.ToInt32(a.Params[2]);
                    cbGSMProvider.SelectedIndex = idx;
                }
                catch { }
            }
        }

        private void ParseAskIOTSettings(Answer a)
        {
            if (a.IsOkAnswer)
            {
                // тут пришли настройки IoT
                byte flags = Convert.ToByte(a.Params[1]);
                bool thingSpeakEnabled = (flags & 1) == 1;
                int iotUpdateInterval = Convert.ToInt32(a.Params[2]);

                cbThingSpeakEnabled.Checked = thingSpeakEnabled;
                try
                {
                    nudIoTInterval.Value = iotUpdateInterval/1000;
                }
                catch { }

                // тут заполняем список датчиков
                lbIOTAllSensors.Items.Clear();

                int tempSensorsCount = appSettings.FirmwareSettings[SensorType.Temperature] + appSettings.UniversalModulesSettings[SensorType.Temperature];

                for (int i = 0; i < tempSensorsCount; i++)
                {
                    IoTSensorSettings ioss = new IoTSensorSettings(1,1,i);
                    lbIOTAllSensors.Items.Add(ioss);
                }

                int humiditySensorsCount = appSettings.FirmwareSettings[SensorType.Humidity] + appSettings.UniversalModulesSettings[SensorType.Humidity];

                for (int i = 0; i < humiditySensorsCount; i++)
                {
                    IoTSensorSettings ioss = new IoTSensorSettings(8, 2, i);
                    lbIOTAllSensors.Items.Add(ioss);

                    ioss = new IoTSensorSettings(1, 2, i);
                    lbIOTAllSensors.Items.Add(ioss);
                }

                int luminositySensorsCount = appSettings.FirmwareSettings[SensorType.Luminosity] + appSettings.UniversalModulesSettings[SensorType.Luminosity];
                for (int i = 0; i < luminositySensorsCount; i++)
                {
                    IoTSensorSettings ioss = new IoTSensorSettings(4, 3, i);
                    lbIOTAllSensors.Items.Add(ioss);
                }

                int soilMoistureCount = appSettings.FirmwareSettings[SensorType.SoilMoisture] + appSettings.UniversalModulesSettings[SensorType.SoilMoisture];
                for (int i = 0; i < soilMoistureCount; i++)
                {
                    IoTSensorSettings ioss = new IoTSensorSettings(64, 4, i);
                    lbIOTAllSensors.Items.Add(ioss);
                }

                int phCount = appSettings.FirmwareSettings[SensorType.PH] + appSettings.UniversalModulesSettings[SensorType.PH];
                for (int i = 0; i < phCount; i++)
                {
                    IoTSensorSettings ioss = new IoTSensorSettings(128, 5, i);
                    lbIOTAllSensors.Items.Add(ioss);
                }

                // теперь разбираем, чего там сохранено
                int paramIdx = 3;
                for (int i = 0; i < 8; i++)
                {
                    int moduleId = Convert.ToInt32(a.Params[paramIdx++]);
                    int sensorType = Convert.ToInt32(a.Params[paramIdx++]);
                    int sensorIndex = Convert.ToInt32(a.Params[paramIdx++]);

                    // тут ищем такой же датчик в списке и чекаем его
                    for (int k = 0; k < lbIOTAllSensors.Items.Count; k++)
                    {
                        IoTSensorSettings ioss = (IoTSensorSettings)lbIOTAllSensors.Items[k];
                        if (ioss.ModuleID == moduleId && ioss.SensorType == sensorType && ioss.SensorIndex == sensorIndex)
                        {
                            //lbIOTAllSensors.SetItemChecked(k, true);
                            lbIOTAllSensors.Items.RemoveAt(k);
                            lbIOTSelectedSensors.Items.Add(ioss);
                            break;
                        }
                    }
                }

                // теперь получаем ключ канала ThingSpeak
                string thingSpeakChannelKey = a.Params[paramIdx++];
                tbThingSpeakChannelKey.Text = thingSpeakChannelKey;
            } // if (a.IsOkAnswer)
        }

        /// <summary>
        /// разбираем пришедшие данные одной дельты
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskOneDelta(Answer a)
        {
            if (a.IsOkAnswer)
            {
                // пришли данные дельты
                string stype = a.Params[3];
                string mname1 = a.Params[4];
                int sidx1 = Convert.ToInt32(a.Params[5]);
                string mname2 = a.Params[6];
                int sidx2 = Convert.ToInt32(a.Params[7]);

                DeltaSettings ds = new DeltaSettings(stype, mname1, mname2, sidx1, sidx2);
                appSettings.DeltaSettings.Add(ds);

            }
            deltasToQuery--;
            if (deltasToQuery < 1)
                deltasLoaded = true;
        }

        /// <summary>
        /// разбираем настройки калибровки датчиков расхода воды
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskFlowSettings(Answer a)
        {
            if (a.IsOkAnswer)
            {
                int calFactor1 = Convert.ToInt32(a.Params[2]);
                int calFactor2 = Convert.ToInt32(a.Params[3]);

                try
                {

                    nudFlowCalibration1.Value = calFactor1;
                    nudFlowCalibration2.Value = calFactor2;
                }
                catch { }
            }
        }

        /// <summary>
        /// разбираем данные по кол-ву дельт в контроллере
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskDeltasCount(Answer a)
        {
            if (a.IsOkAnswer)
            {
                deltasToQuery = Convert.ToInt32(a.Params[2]);
                for (int i = 0; i < deltasToQuery; i++)
                    PushCommandToQueue(GET_PREFIX + DELTA_VIEW_COMMAND + i.ToString(), Actions.AskOneDelta, ParseAskOneDelta);

                if (deltasToQuery < 1)
                    deltasLoaded = true; // нечего запрашивать, активируем кнопку
            }
            else
                deltasLoaded = true; // что-то пошло не так - активируем кнопку
        }
        /// <summary>
        /// проверяем, установлен ли бит
        /// </summary>
        /// <param name="val">байт, в котором проверяется бит</param>
        /// <param name="pos">номер бита</param>
        /// <returns></returns>
        private bool BitIsSet(byte val, int pos)
        {
            return (val & (1 << pos)) != 0;
        }
        /// <summary>
        /// обрабатываем слепок состояния контроллера
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskAllStat(Answer a)
        {
            // запрещаем к обновлению все списки
            lvHumiditySensorsData.BeginUpdate();
            lvDeltasList.BeginUpdate();

            try
            {
                // ничего не будем добавлять в лог
                //AddToLog(a.RawData);

                if (a.IsOkAnswer)
                {
                    // пришла статистика в сжатом виде, разбираем её по косточкам
                    string line = a.Params[0];

                    // выщемляем первые два байта - это состояние всех модулей
                    string firstByte = line.Substring(0, 2);
                    string secondByte = line.Substring(2, 2);
                    line = line.Substring(4);
                    // переводим это в номер всё
                    byte num = (byte)int.Parse(firstByte, System.Globalization.NumberStyles.HexNumber);
                    // теперь смотрим, чего там в состояниях
                    bool windowOpen = BitIsSet(num, 0); // первый бит выставлен - окна открыты
                    bool windowAutoMode = BitIsSet(num, 1); // второй бит выставлен - автоматический режим работы окон
                    bool waterOn = BitIsSet(num, 2); // третий бит выставлен - полив включен
                    bool waterAutoMode = BitIsSet(num, 3); // четвертый бит выставлен - автоматический режим работы полива
                    bool lightOn = BitIsSet(num, 4); // пятый бит выставлен - включена досветка
                    bool lightAutoMode = BitIsSet(num, 5); // шестой бит выставлен - автоматический режим работы досветки

                    bool phFlowAddOn = BitIsSet(num, 7);
                    num = (byte)int.Parse(secondByte, System.Globalization.NumberStyles.HexNumber);
                    bool phMixPumpOn = BitIsSet(num, 0);
                    bool phPlusPumpOn = BitIsSet(num, 1);
                    bool phMinusPumpOn = BitIsSet(num, 2);

                    this.lvPHStatus.Items[0].BackColor = phFlowAddOn ? Color.Green : Color.LightGray;
                    this.lvPHStatus.Items[0].ForeColor = phFlowAddOn ? Color.White : Color.Black;

                    this.lvPHStatus.Items[1].BackColor = phMixPumpOn ? Color.Green : Color.LightGray;
                    this.lvPHStatus.Items[1].ForeColor = phMixPumpOn ? Color.White : Color.Black;

                    this.lvPHStatus.Items[2].BackColor = phPlusPumpOn ? Color.Green : Color.LightGray;
                    this.lvPHStatus.Items[2].ForeColor = phPlusPumpOn ? Color.White : Color.Black;

                    this.lvPHStatus.Items[3].BackColor = phMinusPumpOn ? Color.Green : Color.LightGray;
                    this.lvPHStatus.Items[3].ForeColor = phMinusPumpOn ? Color.White : Color.Black;


                    // обновляем состояние досветки
                    UpdateLuxState(lightOn, lightAutoMode);
                    // обновляем состояние полива
                    UpdateWateringState(waterOn, waterAutoMode);
                    // обновляем состояние окон
                    UpdateWindowState(windowOpen, windowAutoMode);

                    // дальше идут данные от модулей
                    while (line.Length > 0)
                    {
                        // читаем байт флагов модуля
                        string f = line.Substring(0, 2);
                        line = line.Substring(2);

                        // смотрим, чего там во флагах модуля задано
                        int flags = int.Parse(f, System.Globalization.NumberStyles.HexNumber);
                        bool tempPresent = (flags & 1) == 1;
                        bool luminosityPresent = (flags & 4) == 4;
                        bool humidityPresent = (flags & 8) == 8;
                        bool waterFlowInstantPresent = (flags & 16) == 16;
                        bool waterFlowIncrementalPresent = (flags & 32) == 32;
                        bool soilMoisturePresent = (flags & 64) == 64;
                        bool phPresent = (flags & 128) == 128;

                        // читаем байт имени модуля
                        string s = line.Substring(0, 2);
                        int namelen = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                        // дальше идёт имя модуля, читаем его
                        string moduleName = line.Substring(2, namelen);

                        line = line.Substring(2 + namelen);

                        int cnt = 0;

                        // прочитали имя модуля, можем работать с датчиками
                        // сперва идут температурные, первый байт - их количество
                        if (tempPresent)
                        {
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // теперь читаем данные с датчиков
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                                // затем два байта - его показания
                                string val = line.Substring(2, 2);
                                string fract = line.Substring(4, 2);
                                line = line.Substring(6);

                                // теперь смотрим, есть ли показания с датчика
                                bool haveSensorData = !(val == "FF" && fract == "FF");
                                string temp = "";
                                if (haveSensorData)
                                {
                                    // имеем показания, надо сконвертировать
                                    temp = sbyte.Parse(val, System.Globalization.NumberStyles.HexNumber).ToString() + ",";
                                    int fractVal = byte.Parse(fract, System.Globalization.NumberStyles.HexNumber);
                                    if (fractVal < 10)
                                        temp += "0";
                                    temp += fractVal.ToString();
                                }

                                // получили показания с датчика, надо их вывести в UI
                                SaveTemperatureSensorData(moduleName, sensorIdx, temp, haveSensorData);
                            } // for
                        } // if(tempPresent)
                        // опрос температурных датчиков окончен, переходим на датчики влажности

                        if (humidityPresent)
                        {
                            // переходим на чтение данных с датчиков влажности
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // обрабатываем их
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                                // затем два байта - его показания
                                string val = line.Substring(2, 2);
                                string fract = line.Substring(4, 2);
                                line = line.Substring(6);

                                // теперь смотрим, есть ли показания с датчика
                                bool haveSensorData = !(val == "FF" && fract == "FF");
                                string humidity = "";
                                if (haveSensorData)
                                {
                                    // имеем показания, надо сконвертировать
                                    humidity = int.Parse(val, System.Globalization.NumberStyles.HexNumber).ToString() + ",";
                                    int fractVal = int.Parse(fract, System.Globalization.NumberStyles.HexNumber);
                                    if (fractVal < 10)
                                        humidity += "0";
                                    humidity += fractVal.ToString();
                                }

                                // получили показания с датчика, надо их вывести в UI
                                SaveHumiditySensorData(moduleName, sensorIdx, humidity, haveSensorData);

                            } // for
                        } // if(humidityPresent)

                        if (luminosityPresent)
                        {
                            // далее идут показания датчиков освещенности
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // обрабатываем их
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                                // затем два байта - его показания
                                string val = line.Substring(2, 2);
                                string fract = line.Substring(4, 2);
                                line = line.Substring(6);

                                // теперь смотрим, есть ли показания с датчика
                                bool haveSensorData = !(val == "FF" && fract == "FF");
                                int luminosity = 0;
                                if (haveSensorData)
                                {
                                    // имеем показания, надо сконвертировать
                                    luminosity = int.Parse((val + fract), System.Globalization.NumberStyles.HexNumber);

                                }

                                // получили показания с датчика, надо их вывести в UI
                                SaveLuminositySensorData(moduleName, sensorIdx, luminosity, haveSensorData);

                            } // for
                        } // luminosityPresent

                        if (waterFlowInstantPresent)
                        {
                            // далее идут показания датчиков мгновенного расхода воды
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // обрабатываем их
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);

                                // затем 4 байта - его показания
                                string dt = line.Substring(2, 8);
                                line = line.Substring(10);
                                long flow = int.Parse(dt, System.Globalization.NumberStyles.HexNumber);


                                // получили показания с датчика, надо их вывести в UI
                                //сохраняем показания с датчика мгновенного расхода воды
                                SaveInstantFlowData(sensorIdx, flow);

                            } // for
                        } // waterFlowInstantPresent

                        if (waterFlowIncrementalPresent)
                        {
                            // далее идут показания датчиков накопительного расхода воды
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // обрабатываем их
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);

                                // затем 4 байта - его показания
                                string dt = line.Substring(2, 8);
                                line = line.Substring(10);
                                long flow = int.Parse(dt, System.Globalization.NumberStyles.HexNumber);


                                // получили показания с датчика, надо их вывести в UI
                                //сохраняем показания с датчика накопительного расхода воды
                                SaveIncrementalFlowData(sensorIdx, flow);

                            } // for
                        } // waterFlowIncrementalPresent

                        // разбираем показания с датчиков влажности почвы
                        if (soilMoisturePresent)
                        {
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // теперь читаем данные с датчиков
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                                // затем два байта - его показания
                                string val = line.Substring(2, 2);
                                string fract = line.Substring(4, 2);
                                line = line.Substring(6);

                                // теперь смотрим, есть ли показания с датчика
                                bool haveSensorData = !(val == "FF" && fract == "FF");
                                string temp = "";
                                if (haveSensorData)
                                {
                                    // имеем показания, надо сконвертировать
                                    temp = int.Parse(val, System.Globalization.NumberStyles.HexNumber).ToString() + ",";
                                    int fractVal = int.Parse(fract, System.Globalization.NumberStyles.HexNumber);
                                    if (fractVal < 10)
                                        temp += "0";
                                    temp += fractVal.ToString();
                                }

                                // получили показания с датчика, надо их вывести в UI
                                SaveHumiditySensorData(moduleName, sensorIdx, temp, haveSensorData);
                            } // for
                        } // if(soilMoisturePresent)


                        // разбираем показания с датчиков pH
                        if (phPresent)
                        {
                            s = line.Substring(0, 2);
                            cnt = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                            line = line.Substring(2);

                            // теперь читаем данные с датчиков
                            for (int i = 0; i < cnt; i++)
                            {
                                // первым байтом идёт индекс датчика
                                s = line.Substring(0, 2);
                                int sensorIdx = int.Parse(s, System.Globalization.NumberStyles.HexNumber);
                                // затем два байта - его показания
                                string val = line.Substring(2, 2);
                                string fract = line.Substring(4, 2);
                                line = line.Substring(6);

                                // теперь смотрим, есть ли показания с датчика
                                bool haveSensorData = !(val == "FF" && fract == "FF");
                                string temp = "";
                                if (haveSensorData)
                                {
                                    // имеем показания, надо сконвертировать
                                    temp = int.Parse(val, System.Globalization.NumberStyles.HexNumber).ToString() + ",";
                                    int fractVal = int.Parse(fract, System.Globalization.NumberStyles.HexNumber);
                                    if (fractVal < 10)
                                        temp += "0";
                                    temp += fractVal.ToString();
                                }

                                // получили показания с датчика, надо их вывести в UI
                                SavePHSensorData(moduleName, sensorIdx, temp, haveSensorData);
                            } // for
                        } // if(phPresent)
                        
                        
                        // все датчики обработали, переходим к следующему модулю

                    } // while

                }
            }
            catch { }

            // обновляем все списки
            lvHumiditySensorsData.EndUpdate();
            lvDeltasList.EndUpdate();

        }
        /// <summary>
        /// сохраняем данные о постоянном расходе воды
        /// </summary>
        /// <param name="sensorIdx"></param>
        /// <param name="flow"></param>
        private void SaveIncrementalFlowData(int sensorIdx, long flow)
        {
            string txt;
            if (flow < 1000)
            {
                // до кубометра
                txt = flow.ToString() + " л";
            }
            else
            {
                // уже кубометры
                long m3 = flow / 1000;
                long litres = flow % 1000;
                txt = String.Format("{0} м3 {1} л", m3, litres);
            }

            if (sensorIdx == 0)
                lblFlowIncremental1.Text = txt;
            else
                lblFlowIncremental2.Text = txt;


        }
        /// <summary>
        /// сохраняем данные о мгновенном расходе воды
        /// </summary>
        /// <param name="sensorIdx"></param>
        /// <param name="flow"></param>
        private void SaveInstantFlowData(int sensorIdx, long flow)
        {
            string txt;
            if (flow < 1000)
            {
                // до литра
                txt = flow.ToString() + " мл";
            }
            else
            {
                //больше литра
                long litres = flow / 1000;
                long ml = flow % 1000;
                txt = String.Format("{0},{1,0:D2} л", litres, ml);

            }

            if (sensorIdx == 0)
                lblFlowInstant1.Text = txt;
            else
                lblFlowInstant2.Text = txt;

        }

        /// <summary>
        /// Сохраняем данные с датчиков pH
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="sensorIdx"></param>
        /// <param name="luminosity"></param>
        /// <param name="haveSensorData"></param>
        private void SavePHSensorData(string moduleName, int sensorIdx, string ph, bool haveSensorData)
        {
            if (moduleName == "PH") // показания для модуля pH
            {
                while (this.lvPH.Items.Count < (sensorIdx + 1))
                    lvPH.Items.Add("");

                ListViewItem lvi = lvPH.Items[sensorIdx];
                while (lvi.SubItems.Count < 3)
                    lvi.SubItems.Add("");

                lvi.Text = "#" + sensorIdx.ToString();

                // преобразуем значение pH в милливольты
                float mv = 0;
                int phMV = 0;
                try
                {
                    if (haveSensorData)
                    {
                        mv = Convert.ToSingle(ph, new System.Globalization.NumberFormatInfo() { NumberDecimalSeparator = "," });
                        mv = (mv*10000)/35;
                        phMV = Convert.ToInt32(mv);
                    }
                }
                catch { }

                lvi.SubItems[1].Text = haveSensorData ? ph + " pH" : Settings.Default.NoData;
                lvi.SubItems[2].Text = haveSensorData ? phMV + " mV" : Settings.Default.NoData;


            } // LIGHT
            else
                if (moduleName == "DELTA")
                {
                    while (this.lvDeltasList.Items.Count < (sensorIdx + 1))
                        lvDeltasList.Items.Add("");

                    ListViewItem lvi = lvDeltasList.Items[sensorIdx];

                    while (lvi.SubItems.Count < 3)
                        lvi.SubItems.Add("");

                    lvi.Text = "#" + sensorIdx.ToString();
                    lvi.SubItems[1].Text = "pH";
                    lvi.SubItems[2].Text = haveSensorData ? ph + " pH" : Settings.Default.NoData;
                } // DELTA
        }

        /// <summary>
        /// сохраняем данные с датчика освещенности
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="sensorIdx"></param>
        /// <param name="luminosity"></param>
        /// <param name="haveSensorData"></param>
        private void SaveLuminositySensorData(string moduleName, int sensorIdx, int luminosity, bool haveSensorData)
        {
            if (moduleName == "LIGHT") // показания для модуля досветки
            {
                while (this.lvLuminosity.Items.Count < (sensorIdx + 1))
                    lvLuminosity.Items.Add("");

                ListViewItem lvi = lvLuminosity.Items[sensorIdx];
                while (lvi.SubItems.Count < 2)
                    lvi.SubItems.Add("");

                lvi.Text = "#" + sensorIdx.ToString();
                lvi.SubItems[1].Text = haveSensorData ? luminosity + " люкс" : Settings.Default.NoData;

              
            } // LIGHT
            else
                if (moduleName == "DELTA")
                {
                    while (this.lvDeltasList.Items.Count < (sensorIdx + 1))
                        lvDeltasList.Items.Add("");

                    ListViewItem lvi = lvDeltasList.Items[sensorIdx];

                    while (lvi.SubItems.Count < 3)
                        lvi.SubItems.Add("");

                    lvi.Text = "#" + sensorIdx.ToString();
                    lvi.SubItems[1].Text = "освещенность";
                    lvi.SubItems[2].Text = haveSensorData ? luminosity + " люкс" : Settings.Default.NoData;
                } // DELTA
        }
        /// <summary>
        /// сохраняем данные с датчика влажности
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="sensorIdx"></param>
        /// <param name="humidity"></param>
        /// <param name="haveSensorData"></param>
        private void SaveHumiditySensorData(string moduleName, int sensorIdx, string humidity, bool haveSensorData)
        {
            if (moduleName == "HUMIDITY") // показания для закладки "влажность"
            {

                // добавляем все нужные строки сразу
                while (this.lvHumiditySensorsData.Items.Count < (sensorIdx+1))
                    lvHumiditySensorsData.Items.Add("");

                ListViewItem lvi = lvHumiditySensorsData.Items[sensorIdx];

                while (lvi.SubItems.Count < 3)
                    lvi.SubItems.Add("");

                lvi.Text = "#" + sensorIdx.ToString();
                lvi.SubItems[1].Text = haveSensorData ? humidity + "%" : Settings.Default.NoData;

            } // HUMIDITY
            else
                if (moduleName == "DELTA")
                {
                    while (this.lvDeltasList.Items.Count < (sensorIdx + 1))
                        lvDeltasList.Items.Add("");

                    ListViewItem lvi = lvDeltasList.Items[sensorIdx];

                    while (lvi.SubItems.Count < 3)
                        lvi.SubItems.Add("");

                    lvi.Text = "#" + sensorIdx.ToString();
                    lvi.SubItems[1].Text = "влажность";
                    lvi.SubItems[2].Text = haveSensorData ? humidity + "%" : Settings.Default.NoData;
                } // DELTA
                else
                    if (moduleName == "SOIL") // показания датчика влажности почвы
                    {
                        // добавляем все нужные строки сразу
                        while (this.lvSoilMoistureSensorsData.Items.Count < (sensorIdx + 1))
                            lvSoilMoistureSensorsData.Items.Add("");

                        ListViewItem lvi = lvSoilMoistureSensorsData.Items[sensorIdx];

                        while (lvi.SubItems.Count < 2)
                            lvi.SubItems.Add("");

                        lvi.Text = "#" + sensorIdx.ToString();
                        lvi.SubItems[1].Text = haveSensorData ? humidity + "%" : Settings.Default.NoData;
                    } // SOIL

        }

        /// <summary>
        /// Устанавливаем температуры на экране монитора
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="sensorIdx"></param>
        /// <param name="temp"></param>
        /// <param name="haveSensorData"></param>
        private void SetMonitorTemperature(string moduleName, int sensorIdx, string temp, bool haveSensorData)
        {
            if (!(moduleName == appSettings.MonitorTempInsideModule || moduleName == appSettings.MonitorTempOutsideModule))
                return; // неизвестный модуль, не устанавливаем ничего

            float fTemp = 0.0F;
            if (haveSensorData)
                fTemp = Convert.ToSingle(temp, new System.Globalization.NumberFormatInfo() { NumberDecimalSeparator = "," });

            String txt = temp;
            if (!haveSensorData)
                txt = Settings.Default.NoData;


            if (moduleName == appSettings.MonitorTempInsideModule)
            {
                if (sensorIdx == appSettings.MonitorTempInsideSensor)
                {

                    lblCelsius1.Visible = haveSensorData;
                    lblTempInside.Text = txt;

                    if (fTemp < 12)
                        therm1.Image = Resources.bluetherm;
                    else if (fTemp >= 12 && fTemp <= 23)
                        therm1.Image = Resources.yellowterm;
                    else
                        therm1.Image = Resources.redtherm;

                    RealignControls();
                }
            }
            
            if (moduleName == appSettings.MonitorTempOutsideModule)
            {
                if (sensorIdx == appSettings.MonitorTempOutsideSensor)
                {
                    lblCelsius2.Visible = haveSensorData;
                    lblTempOutside.Text = txt;

                    if (fTemp < 12)
                        therm2.Image = Resources.bluetherm;
                    else if (fTemp >= 12 && fTemp <= 23)
                        therm2.Image = Resources.yellowterm;
                    else
                        therm2.Image = Resources.redtherm;

                    RealignControls();

                }
            }

        }

        /// <summary>
        /// температура ядра
        /// </summary>
        private string coreTemperature = Settings.Default.NoData;

        /// <summary>
        /// сохраняем данные с датчика температуры
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="sensorIdx"></param>
        /// <param name="temp"></param>
        /// <param name="haveSensorData"></param>
        private void SaveTemperatureSensorData(string moduleName, int sensorIdx, string temp, bool haveSensorData)
        {
            SetMonitorTemperature(moduleName, sensorIdx, temp, haveSensorData);

            // разбираем, чего пришло
            if (moduleName == "STATE") // для модуля управления фрамугами
            {
              
            } // STATE
            else
                if (moduleName == "HUMIDITY")
                {
                    // данные для вкладки "влажность"
                    // добавляем все нужные строки сразу
                    while (this.lvHumiditySensorsData.Items.Count < (sensorIdx + 1))
                        lvHumiditySensorsData.Items.Add("");

                    ListViewItem lvi = lvHumiditySensorsData.Items[sensorIdx];

                    while (lvi.SubItems.Count < 3)
                        lvi.SubItems.Add("");

                    lvi.Text = "#" + sensorIdx.ToString();
                    lvi.SubItems[2].Text = haveSensorData ? temp + " °С" : Settings.Default.NoData;

                } // HUMIDITY
                else 
                    if (moduleName == "DELTA")
                {
                        // показания датчиков дельт
                    while (this.lvDeltasList.Items.Count < (sensorIdx + 1))
                        lvDeltasList.Items.Add("");

                    ListViewItem lvi = lvDeltasList.Items[sensorIdx];
                    while (lvi.SubItems.Count < 3)
                        lvi.SubItems.Add("");

                    lvi.Text = "#" + sensorIdx.ToString();
                    lvi.SubItems[1].Text = "температура";
                    lvi.SubItems[2].Text = haveSensorData ? temp + " °С" : Settings.Default.NoData;
                } // DELTA
                    else if (moduleName == "0")
                    {
                        coreTemperature = haveSensorData ? temp + " °С" : Settings.Default.NoData;
                    }

        }
        /// <summary>
        /// обновляем состояние окон
        /// </summary>
        /// <param name="windowOpen">флаг открытия</param>
        /// <param name="windowAutoMode">флаг автоматического режима работы</param>
        private void UpdateWindowState(bool windowOpen, bool windowAutoMode)
        {

            if (windowAutoMode)
                this.WindowWorkMode = WindowsWorkMode.wmAutomatic;
            else
                this.WindowWorkMode = WindowsWorkMode.wmManual;

            UpdateWindowsWorkMode();      

  
            RealignControls();
        }
        /// <summary>
        /// обновляем состояние полива
        /// </summary>
        /// <param name="waterOn">флаг включенного полива</param>
        /// <param name="waterAutoMode">флаг автоматического режима работы</param>
        private void UpdateWateringState(bool waterOn, bool waterAutoMode)
        {
                if (!setWateringStateRequested) // только если юзер не запостил в очередь команду включения/выключения полива
                {
                    if (waterOn)
                    {
                        this.tbWatering.Value = 1;
                        this.lblWateringState.Text = Settings.Default.StateOn;
                    }
                    else
                    {
                        this.tbWatering.Value = 0;
                        this.lblWateringState.Text = Settings.Default.StateOff;
                    }
                }
                setWateringStateRequested = false;

                if (!setWateringModeRequested) // только если юзер не запостил в очередь команду переключения режима полива
                {
                    if (waterAutoMode)
                    {
                        this.tbWateringMode.Value = 1;
                        this.lblWateringMode.Text = Settings.Default.Automatic;
                    }
                    else
                    {
                        this.tbWateringMode.Value = 0;
                        this.lblWateringMode.Text = Settings.Default.Manual;
                    }
                }
                setWateringModeRequested = false;


            tbWatering.Enabled = IsConnected();
            tbWateringMode.Enabled = tbWatering.Enabled;

        }
        /// <summary>
        /// обновляем состояние модуля управления досветкой
        /// </summary>
        /// <param name="lightOn">флаг включенной досветки</param>
        /// <param name="lightAutoMode">флаг автоматического режима работы</param>
        private void UpdateLuxState(bool lightOn, bool lightAutoMode)
        {
                if (!setLuxStateRequested) // только если юзер не запостил в очередь команду включения/выключения досветки
                {
                    if (lightOn)
                    {
                        this.tbLux.Value = 1;
                        this.lblLuxState.Text = Settings.Default.StateOn;
                    }
                    else
                    {
                        this.tbLux.Value = 0;
                        this.lblLuxState.Text = Settings.Default.StateOff;
                    }
                }
                setLuxStateRequested = false;

                if (!setLuxModeRequested) // только если юзер не запостил в очередь команду переключения режима досветки
                {
                    if (lightAutoMode)
                    {
                        this.tbLuxMode.Value = 1;
                        this.lblLuxMode.Text = Settings.Default.Automatic;
                    }
                    else
                    {
                        this.tbLuxMode.Value = 0;
                        this.lblLuxMode.Text = Settings.Default.Manual;
                    }
                }

                setLuxModeRequested = false;

            
            tbLux.Enabled = IsConnected();
            tbLuxMode.Enabled = IsConnected();

        }

        /// <summary>
        /// Обновляем положение элементов интерфейса
        /// </summary>
        private void RealignControls()
        {
            this.lblByte.Left = this.lblFreeRam.Left + this.lblFreeRam.Width;
            this.lblCelsius1.Left = this.lblTempInside.Left + this.lblTempInside.Width;
            this.lblCelsius2.Left = this.lblTempOutside.Left + this.lblTempOutside.Width;
            
        }
        /// <summary>
        /// обновляем состояние элементов интерфейса для окон
        /// </summary>
        private void UpdateWindowsPosition()
        {
            switch (this.CurrentWindowsPosition)
            {
                case WindowsPosition.wpUnknown:
                    this.lblCurrentWindowState.Text = Settings.Default.NoData;
                    this.pbWindowState.Image = Resources.windowStateUnknown;
                    tbWindowPosition.Enabled = false;
                    break;

                case WindowsPosition.wpOpening:
                    this.lblCurrentWindowState.Text = Settings.Default.WindowOpening;
                    this.pbWindowState.Image = Resources.windowInAction;
                    tbWindowPosition.Enabled = false;
                    break;

                case WindowsPosition.wpOpen:
                    this.lblCurrentWindowState.Text = Settings.Default.WindowOpen;
                    this.pbWindowState.Image = Resources.windowOpen;
                    tbWindowPosition.Enabled = true;
                    tbWindowPosition.Value = 1;
                    break;

                case WindowsPosition.wpClosing:
                    this.lblCurrentWindowState.Text = Settings.Default.WindowClosing;
                    this.pbWindowState.Image = Resources.windowInAction;
                    break;

                case WindowsPosition.wpClosed:
                    this.lblCurrentWindowState.Text = Settings.Default.WindowClosed;
                    this.pbWindowState.Image = Resources.windowClosed;
                    tbWindowPosition.Enabled = true;
                    tbWindowPosition.Value = 0;
                    break;
            }


        }

        /// <summary>
        /// кол-во ошибок, накопленных при записи в контроллер
        /// </summary>
        private int anylWriteError = 0;
        /// <summary>
        /// Обработчик установки интервала открытия/закрытия для окон
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWindowInterval(Answer a)
        {
            AddToLog(a.RawData);
            if (a.IsOkAnswer)
            {
           }
            else
            {
                anylWriteError++;
            }
        }
        /// <summary>
        /// Обработчик установки спецправила
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetSpecialRule(Answer a)
        {
            if (a.IsOkAnswer)
            {
            }
            else
            {
                anylWriteError++;
            }
        }

        /// <summary>
        /// обработчик команды сохранения правил
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetSaveRules(Answer a)
        {
             if (a.IsOkAnswer)
            {
            }
            else
            {
                anylWriteError++;
            }
        }
        private void ParseSetPHSettings(Answer a)
        {
            btnSavePHSettings.Enabled = true;
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if (a.IsOkAnswer)
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }


        private void ParseSetFlowSettings(Answer a)
        {
            btnSaveFlowSettings.Enabled = true;
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if(a.IsOkAnswer)
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        /// <summary>
        /// Показываем результаты сохранения настроек
        /// </summary>
        private void ShowWriteResultMessage()
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if(anylWriteError == 0)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                appSettings.Interval = oldInterval;
                appSettings.TOpen = oldTOpen;
                appSettings.TClose = oldTClose;
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
           }
        }
        /// <summary>
        /// обработчик ответа на установку настроек канала полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseWateringChannelOptions(Answer a)
        {
        }
        /// <summary>
        /// обработчик ответа на установку настроек полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseWateringOptions(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            AddToLog(a.RawData);
            if (a.IsOkAnswer)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// обработчик ответа на запрос IP Wi-Fi модуля
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskWiFiIP(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                string staip = a.Params[2];
                string apip = a.Params[3];
                string mess = string.Format(Settings.Default.WiFiIPFormat, staip, apip);
                MessageBox.Show(mess, Settings.Default.AskWIFIIPCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if(a.ParamsCount > 1 && a.Params[1] == BUSY) // заняты
                    MessageBox.Show(Settings.Default.WiFiBusy, Settings.Default.AskWIFIIPCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show(Settings.Default.ErrorWiFiIP, Settings.Default.AskWIFIIPCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// обработчик ответа на установку настроек Wi-Fi
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWiFiSettings(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnSaveWiFiSettings.Enabled = false;
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// кол-во правил всего
        /// </summary>
        private int totalRulesCount = 0;
        /// <summary>
        /// сколько правил отработано
        /// </summary>
        private int rulesProcessed = 0;
        /// <summary>
        /// флаг, что мы в состоянии загрузки правил из контроллера
        /// </summary>
        private bool inGetRulesFromController = false;

        /// <summary>
        /// обработчик получения кол-ва правил в контроллере
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskRulesCount(Answer a)
        {
            if (a.IsOkAnswer)
            {
                rulesProcessed = 0;
                totalRulesCount = Convert.ToInt32(a.Params[2]);

                if (totalRulesCount < 1)
                {
                    // завершили опрос

                    FillRulesList();

                    inGetRulesFromController = false;

                    if (!loadRulesSilentMode)
                    {

                        Cursor.Current = Cursors.Default;
                        Application.UseWaitCursor = false;
                        Application.DoEvents();

                        MessageBox.Show(Settings.Default.RulesGetOk, Settings.Default.Info, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    for (int i = 0; i < totalRulesCount; i++)
                        PushCommandToQueue(GET_PREFIX + RULE_VIEW_COMMAND + i.ToString(), Actions.AskRuleView, ParseAskRuleView);
                }
            }
            else
            {
                inGetRulesFromController = false;
                if (!loadRulesSilentMode)
                {
                    Cursor.Current = Cursors.Default;
                    Application.UseWaitCursor = false;
                    Application.DoEvents();
                    MessageBox.Show(Settings.Default.ErrorGetRules, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        /// <summary>
        /// обработчик получения настроек одного правила
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskRuleView(Answer a)
        {
            if (a.IsOkAnswer)
            {
                // парсим правило
                int startIdx = 3;
                string s = "";
                while (startIdx < a.ParamsCount)
                {
                    if (s.Length > 0)
                        s += PARAM_DELIMITER;

                    s += a.Params[startIdx++];
                }

                AlertRule ar = new AlertRule(s);
                appSettings.AlertRules.Add(ar);


                rulesProcessed++;
                if (rulesProcessed == totalRulesCount)
                {
                    // завершили опрос
                    inGetRulesFromController = false;
                    FillRulesList();

                    if (!loadRulesSilentMode)
                    {
                        Cursor.Current = Cursors.Default;
                        Application.UseWaitCursor = false;
                        Application.DoEvents();

                        MessageBox.Show(Settings.Default.RulesGetOk, Settings.Default.Info, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                inGetRulesFromController = false;
                appSettings.AlertRules.Clear();

                if (!loadRulesSilentMode)
                {
                    Cursor.Current = Cursors.Default;
                    Application.UseWaitCursor = false;
                    Application.DoEvents();
                    MessageBox.Show(Settings.Default.ErrorGetRules, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        /// <summary>
        /// возвращаем строку для правила
        /// </summary>
        /// <param name="ar">правило, для которого надо показать строку</param>
        /// <returns></returns>
        private string GetRuleDisplayString(AlertRule ar)
        {
            string result = "";

            // получаем строку с более понятным описанием, за чем следит правило
            string templ = Settings.Default.RuleSpyTemplate;
            string spytemp = Settings.Default.SpyTemp;
            string spylight = Settings.Default.SpyLight;
            string spyhum = Settings.Default.SpyHumidity;

            string sub0 = "";
            string sub1 = ar.LinkedModuleName;
            if (ar.SpyTo == "TEMP")
                sub0 = spytemp;
            else if (ar.SpyTo == "LIGHT")
                sub0 = spylight;
            else if (ar.SpyTo == "HUMIDITY")
                sub0 = spyhum;
            else if (ar.SpyTo == "SOIL")
                sub0 = "влажностью почвы";

            result = string.Format(templ, sub0, sub1);

            if (ar.LinkedModuleName == "0") // ни за чем не следим
            {
                if (ar.SpyTo == "PIN") // следим за состоянием пина
                    return string.Format("За уровнем пина {0}", ar.SensorIndex);

                return Settings.Default.SpyNone;
            }


            return result;
        }
        /// <summary>
        /// обновляем правило в интерфейсе
        /// </summary>
        /// <param name="ar">правило, по которому будет обновлён список</param>
        public void UpdateRule(AlertRule ar)
        {
            ListViewItem selItem = null;
            foreach (ListViewItem lvi in this.lvRulesList.SelectedItems)
            {
                AlertRule lviRule = (AlertRule)lvi.Tag;
                if (lviRule == ar)
                {
                    selItem = lvi;

                    break;
                }
            }

            if (selItem != null)
            {
                selItem.SubItems.Clear();
                selItem.Text = GetRuleDisplayString(ar);
                selItem.SubItems.Add(appSettings.GetActionDescription(ar.Command));
                selItem.SubItems.Add(ar.IsSpecialRule ? Settings.Default.YES : Settings.Default.NO);
            }

        }
        /// <summary>
        /// добавляем правило в список
        /// </summary>
        /// <param name="ar">Правило, которое надо добавить в список</param>
        public void AddRule(AlertRule ar)
        {
            ListViewItem lvi = lvRulesList.Items.Add(GetRuleDisplayString(ar));
            lvi.SubItems.Add(appSettings.GetActionDescription(ar.Command));
            lvi.SubItems.Add(ar.IsSpecialRule ? Settings.Default.YES : Settings.Default.NO);
            lvi.Tag = ar;
            lvi.Checked = ar.IsActive;

            appSettings.AlertRules.Add(ar);
        }
        /// <summary>
        /// заполняем список правил
        /// </summary>
        private void FillRulesList()
        {
            // заполняем список с правилами
            lvRulesList.BeginUpdate();
            lvRulesList.Items.Clear();

            // начинаем заполнять
            int idx = 0;
            foreach (AlertRule ar in appSettings.AlertRules)
            {
                if (!ar.IsDeleted) // только если правило не удалено
                {
                    ListViewItem lvi = lvRulesList.Items.Add(GetRuleDisplayString(ar));
                    lvi.SubItems.Add(appSettings.GetActionDescription(ar.Command));
                    lvi.SubItems.Add(ar.IsSpecialRule ? Settings.Default.YES : Settings.Default.NO);
                    lvi.Tag = ar;
                    lvi.Checked = ar.IsActive;
                }
            }

            lvRulesList.EndUpdate();
        }
        /// <summary>
        /// очищаем список правил
        /// </summary>
        private void ClearRulesList()
        {
            // очищаем список правил
            lvRulesList.BeginUpdate();
            lvRulesList.Items.Clear();
            lvRulesList.EndUpdate();

            lblRuleStr.Text = "";
        }

        private void ParseSetGSMProvider(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();


           // AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// обработчик сохранения номера телефона в контроллере
        /// </summary>
        /// <param name="a"></param>
        private void ParseSavePhoneNumber(Answer a)
        {


        }
        /// <summary>
        /// Обработчик сохранения температур открытия/закрытия
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetTemperatureParams(Answer a)
        {
             AddToLog(a.RawData);
 
            if (a.IsOkAnswer)
            {
            }
            else
            {
                anylWriteError++;
             }

            ShowWriteResultMessage(); // показываем результаты записи
        }

        private bool setWateringStateRequested = false;
        private bool setWateringModeRequested = false;
        private bool setLuxStateRequested = false;
        private bool setLuxModeRequested = false;

        /// <summary>
        /// обработчик установки режима работы полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWateringMode(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {

                string s = a.Params[2];
                if (s == AUTO)
                {
                    this.tbWateringMode.Value = 1;
                    this.lblWateringMode.Text = Settings.Default.Automatic;
                }
                else
                {
                    this.tbWateringMode.Value = 0;
                    this.lblWateringMode.Text = Settings.Default.Manual;
                }

            }
        }

        /// <summary>
        /// Обработчик получения ID контроллера
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskControllerID(Answer a)
        {
            if (a.IsOkAnswer && a.Params.Count() > 1)
            {
                appSettings.ControllerID = Convert.ToInt32(a.Params[1]);
            }
        }

        /// <summary>
        /// Разбираем кол-во зарегистрированных универсальных модулей
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskUniversalSensors(Answer a)
        {
            if (a.IsOkAnswer && a.Params.Count() > 4)
            {
                // первым у нас идёт ко-во температурных датчиков
                appSettings.UniversalModulesSettings[SensorType.Temperature] = Convert.ToInt32(a.Params[1]);
                // затем - влажность
                appSettings.UniversalModulesSettings[SensorType.Humidity] = Convert.ToInt32(a.Params[2]);
                // затем - освещённость
                appSettings.UniversalModulesSettings[SensorType.Luminosity] = Convert.ToInt32(a.Params[3]);
                // затем - влажность почвы
                appSettings.UniversalModulesSettings[SensorType.SoilMoisture] = Convert.ToInt32(a.Params[4]);
                // затем - pH
                appSettings.UniversalModulesSettings[SensorType.PH] = Convert.ToInt32(a.Params[5]);

            }
        }

        /// <summary>
        /// Разбираем кол-во жёстко прошитых в контроллере датчиков того или иного типа
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskHardCodedSensors(Answer a)
        {
            if (a.IsOkAnswer && a.Params.Count() > 4)
            {
                // первым у нас идёт ко-во температурных датчиков
                appSettings.FirmwareSettings[SensorType.Temperature] = Convert.ToInt32(a.Params[1]);
                // затем - влажность
                appSettings.FirmwareSettings[SensorType.Humidity] = Convert.ToInt32(a.Params[2]);
                // затем - освещённость
                appSettings.FirmwareSettings[SensorType.Luminosity] = Convert.ToInt32(a.Params[3]);
                // затем - влажность почвы
                appSettings.FirmwareSettings[SensorType.SoilMoisture] = Convert.ToInt32(a.Params[4]);
                // затем - pH
                appSettings.FirmwareSettings[SensorType.PH] = Convert.ToInt32(a.Params[5]);

            }
        }

        /// <summary>
        /// обработчик установки режима работы досветки
        /// </summary>
        /// <param name="a"></param>
       private void ParseSetLuxMode(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {

                string s = a.Params[2];
                if (s == AUTO)
                {
                    this.tbLuxMode.Value = 1;
                    this.lblLuxMode.Text = Settings.Default.Automatic;
                }
                else
                {
                    this.tbLuxMode.Value = 0;
                    this.lblLuxMode.Text = Settings.Default.Manual;
                }

            }

        }

        /// <summary>
       /// разбираем пришедший ответ на запрос установки положения окон
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWindowPosition(Answer a)
        {
            AddToLog(a.RawData);
 
            if (a.IsOkAnswer)
            {
                string s = a.Params[1];

                if (s == CLOSED)
                    this.CurrentWindowsPosition = WindowsPosition.wpClosed;
                else
                    if (s == CLOSING)
                        this.CurrentWindowsPosition = WindowsPosition.wpClosing;
                    else
                        if (s == OPEN)
                            this.CurrentWindowsPosition = WindowsPosition.wpOpen;
                        else
                            if (s == OPENING)
                                this.CurrentWindowsPosition = WindowsPosition.wpOpening;
                            else
                                this.CurrentWindowsPosition = WindowsPosition.wpUnknown;

                UpdateWindowsPosition();

                RealignControls();

            } // if   

        }
        /// <summary>
        /// обработчик ответа на команду включения/выключения полива
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWateringOnOff(Answer a)
        {
            AddToLog(a.RawData);
 
            if (a.IsOkAnswer)
            {
                
                string s = a.Params[1];
                if (s == ON)
                    this.lblWateringState.Text = Settings.Default.StateOn;
                else
                    this.lblWateringState.Text = Settings.Default.StateOff;
                 
            }

        }
        /// <summary>
        /// обработчик ответа на команду включения/выключения досветки
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetLuxOnOff(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {

                string s = a.Params[1];
                if (s == ON)
                {
                    this.lblLuxState.Text = Settings.Default.StateOn;
                    this.tbLux.Value = 1;
                }
                else
                {
                    this.lblLuxState.Text = Settings.Default.StateOff;
                    this.tbLux.Value = 0;
                }

            }

        }
       
        /// <summary>
        /// разбираем пришедшее положение окон
        /// </summary>
        /// <param name="a"></param>
        private void ParseWindowPosition(Answer a)
        {
          //  AddToLog(a.RawData);
 
            if (a.IsOkAnswer)
            {
                string s = a.Params[3];

                if (s == CLOSED)
                    this.CurrentWindowsPosition = WindowsPosition.wpClosed;
                else
                    if (s == CLOSING)
                        this.CurrentWindowsPosition = WindowsPosition.wpClosing;
                    else 
                        if (s == OPEN)
                        this.CurrentWindowsPosition = WindowsPosition.wpOpen;
                    else 
                            if (s == OPENING)
                        this.CurrentWindowsPosition = WindowsPosition.wpOpening;
                    else
                        this.CurrentWindowsPosition = WindowsPosition.wpUnknown;

                UpdateWindowsPosition();

                RealignControls();

            } // if   

        }
        /// <summary>
        /// разбираем пришедшие настройки температуры
        /// </summary>
        /// <param name="a"></param>
        private void ParseTemperatureParams(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                int tO = Convert.ToInt32(a.Params[2]);
                int tC = Convert.ToInt32(a.Params[3]);

                this.appSettings.TOpen = tO;
                this.appSettings.TClose = tC;
   
                //Тут выставляем информацию в текстбоксы
                try
                {
                    this.nudTOpen.Value = tO;
                    this.nudTClose.Value = tC;
                }
                catch { }

            } // if   

        }
        /// <summary>
        /// разбираем пришедший интервал работы окон
        /// </summary>
        /// <param name="a"></param>
        private void ParseWindowWorkInterval(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                string s = a.Params[2];
                appSettings.Interval = Convert.ToInt32(s);

                try
                {
                    this.nudInterval.Value = appSettings.Interval / 1000;
                }
                catch { }


            } // if   

        }
        /// <summary>
        /// разбираем ответ на запрос установки режима работы
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetWindowWorkMode(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                string s = a.Params[2];

                if (s == AUTO)
                    this.WindowWorkMode = WindowsWorkMode.wmAutomatic;
                else
                    if (s == MANUAL)
                        this.WindowWorkMode = WindowsWorkMode.wmManual;
                    else
                        this.WindowWorkMode = WindowsWorkMode.wmUnknown;

                UpdateWindowsWorkMode();

                RealignControls();

            } // if   

        }
        /// <summary>
        /// обновляем интерфейс режима работы окон
        /// </summary>
        private void UpdateWindowsWorkMode()
        {
            switch (this.WindowWorkMode)
            {
                case WindowsWorkMode.wmUnknown:
                    this.lblWindowWorkMode.Text = Settings.Default.NoData;
                    this.pbWindowWorkMode.Image = Resources.windowStateUnknown;
                    tbSetWorkMode.Enabled = false;
                    break;

                case WindowsWorkMode.wmAutomatic:
                    this.lblWindowWorkMode.Text = Settings.Default.Automatic;
                    this.pbWindowWorkMode.Image = Resources.automaticMode;
                    tbSetWorkMode.Value = 1;
                    tbSetWorkMode.Enabled = true;
                    break;

                case WindowsWorkMode.wmManual:
                    this.lblWindowWorkMode.Text = Settings.Default.Manual;
                    this.pbWindowWorkMode.Image = Resources.manualMode;
                    tbSetWorkMode.Value = 0;
                    tbSetWorkMode.Enabled = true;
                    break;
            }
        }

        /// <summary>
        /// разбираем пришедшее кол-во свободной памяти
        /// </summary>
        /// <param name="a"></param>
        private void ParseFreeRam(Answer a)
        {
           AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                string s = a.Params[1];
                int ut = Convert.ToInt32(s);
                this.lblFreeRam.Text = Convert.ToString(ut);
                lblByte.Visible = true;
                RealignControls();
                
            } // if   
        }
        /// <summary>
        /// Класс ответа от контроллера
        /// </summary>
        public class Answer
        {
            /// <summary>
            /// флаг, что ответ положительный
            /// </summary>
            public bool IsOkAnswer;
            /// <summary>
            /// список параметров
            /// </summary>
            public string[] Params;
            /// <summary>
            /// сырые данные, полученные от контроллера
            /// </summary>
            public string RawData;

            /// <summary>
            /// очищает все переменные
            /// </summary>
            private void Clear()
            {
                IsOkAnswer = false;
                Params = null;
                RawData = "";
            }

            /// <summary>
            /// конструирует параметры из строки
            /// </summary>
            /// <param name="dt"></param>
            public void Parse(string dt)
            {
                Clear();
                RawData = dt;

                int idx = dt.IndexOf("OK=");
                if (idx != -1)
                {
                    this.IsOkAnswer = true;
                    dt = dt.Substring(3).Trim();
                    this.Params = dt.Split(PARAM_DELIMITER);
                }
                idx = dt.IndexOf("ER=");
                if (idx != -1)
                {
                    this.IsOkAnswer = false;
                    dt = dt.Substring(3).Trim();
                    this.Params = dt.Split(PARAM_DELIMITER);
                }
                
            }
            /// <summary>
            /// кол-во параметров
            /// </summary>
            public int ParamsCount
            {
                get { return this.Params == null ? 0 : this.Params.Length; }
            }
            /// <summary>
            /// конструктор
            /// </summary>
            /// <param name="dt">строка для разбора</param>
            public Answer(string dt)
            {
                this.Clear();
                this.Parse(dt);
                
            }
        };

        private Color currentLogItemColor = SystemColors.ControlLight;
        /// <summary>
        /// добавляем строку в лог
        /// </summary>
        /// <param name="line">строка для добавления в лог</param>
        private void AddToLog(string line)
        {
            line = line.Trim();
            if (line.Length < 1)
                return;

            lvLog.BeginUpdate();

            int cnt = this.lvLog.Items.Count;
            if (cnt > 100)
            {
                this.lvLog.Items.RemoveAt(0);
             }

            ListViewItem li = this.lvLog.Items.Add(currentCommand.CommandToSend);
            li.ImageIndex = 2;
            if(currentLogItemColor == SystemColors.Window)
                currentLogItemColor = SystemColors.ControlLight;
            else
                currentLogItemColor = SystemColors.Window;

            li.BackColor = currentLogItemColor;
            li.SubItems.Add("=> " + line);
            li.EnsureVisible();

            lvLog.EndUpdate();

        }
        /// <summary>
        /// показываем аптайм
        /// </summary>
        /// <param name="ut">аптайм, в секундах</param>
        private void ShowUptime(int ut)
        {

            int min = ut / 60;
            int sec = ut % 60;

            int hr = 0;
            if (min > 60)
            {
                hr = min / 60;
                min = min % 60;
            }

            String formattedOut = string.Format("{0,0:D2}:{1,0:D2}:{2,0:D2}", hr, min, sec);

            this.lblUptime.Text = formattedOut;
            RealignControls();
        }

        /// <summary>
        /// разбираем пришедшее значение аптайма
        /// </summary>
        /// <param name="a"></param>
        private void ParseUptime(Answer a)
        {
            AddToLog(a.RawData);

            if (a.IsOkAnswer)
            {
                tmrUptime.Enabled = false; // отключаем таймер запроса аптайма

                string s = a.Params[1];
                int ut = Convert.ToInt32(s);

                tmrTicks.Tag = ut;
                tmrTicks.Enabled = true; // включаем таймер для обновления аптайма без работы

                ShowUptime(ut);
               
            } // if
 
        }


        /// <summary>
        /// флаг паузы работы
        /// </summary>
        private bool bWorkPaused = false;

        /// <summary>
        /// Проверяем, можем ли мы работать
        /// </summary>
        /// <returns>возвращаем true, если работать можем</returns>
        private bool GrantToProcess()
        {


            if (!this.IsConnected()) // нет коннекта
            {

                return false;
            }
            if (this.currentCommand.ActionToSet != Actions.None) // чем-то заняты
                return false;

            if (bWorkPaused) // запросы поставлены на паузу
                return false; 

            return true;
        }
  
        /// <summary>
        /// обработчик таймера аптайма
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmrUptime_Tick(object sender, EventArgs e)
        {
            if (GrantToProcess())
            {
                if(this.canQueryStat) // можем запрашивать статистику
                     PushCommandToQueue(GET_PREFIX + UPTIME_COMMAND, Actions.AskUptime, this.ParseUptime);
            }
        }
        /// <summary>
        /// обработчик таймера запроса свободной памяти
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmrFreeRam_Tick(object sender, EventArgs e)
        {
            if (GrantToProcess())
            {
                if (this.canQueryStat) // можем запрашивать статистику
                {
                    if (tmrFreeRam.Tag == null)
                        tmrFreeRam.Tag = 1;

                    tmrFreeRam.Tag = 1 + (int) tmrFreeRam.Tag;
                    if( ((int) tmrFreeRam.Tag) % 5 == 0) // пореже запрашиваем данные по памяти
                        PushCommandToQueue(GET_PREFIX + FREERAM_COMMAND, Actions.AskFreeRam, this.ParseFreeRam);

                    if(!dateTimeFromControllerReceived)
                    {
                        PushCommandToQueue(GET_PREFIX + CONTROLLER_DATETIME_COMMAND, Actions.AskControllerDateTime, ParseControllerDateTime);
                    }
                } // canQueryStat

                if (this.canQueryTemperature) // можем запрашивать температуру и состояние окон
                {
                    PushCommandToQueue(GET_PREFIX + WINDOW_COMMAND, Actions.AskWindowPosition, this.ParseWindowPosition);
                    PushCommandToQueue(GET_PREFIX + "STATE|WINDOW|STATEMASK", Actions.AskWindowStatemask, this.ParseWindowStatemask);
                }

                PushCommandToQueue(GET_PREFIX + ALL_STAT_COMMAND, Actions.AskAllStat, ParseAskAllStat);
            }
        }

        /// <summary>
        /// текущая команда на обработку
        /// </summary>
        private QueuedCommand currentCommand = new QueuedCommand();

        /// <summary>
        /// обрабатываем следующую команду
        /// </summary>
        private void ProcessNextCommand()
        {
            if (!GrantToProcess())
                return;

            if (!this.GetCommandFromQeue(ref this.currentCommand))
                return;

            System.Diagnostics.Debug.Assert(this.currentTransport != null);

            this.currentTransport.WriteLine(currentCommand.CommandToSend);

        }

        /// <summary>
        /// обработчик таймера очереди команд
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmProcessCommandsTimer_Tick(object sender, EventArgs e)
        {
            ProcessNextCommand();
        }


        /// <summary>
        /// обработчик сканирования COM-портов
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void miRescanPorts_Click(object sender, EventArgs e)
        {
            int cnt = tsiCOMConnection.DropDownItems.Count;
            for (int i = cnt - 1; i >= 0; i--)
            {
                ToolStripItem ti = tsiCOMConnection.DropDownItems[i];
                if ("1" != (string)ti.Tag)
                    tsiCOMConnection.DropDownItems.RemoveAt(i);
                
            } // for
            string s = "";
            if (this.lastSelectedPort != null)
                s = (string)this.lastSelectedPort.Tag;

            EnumSerialPorts();

            foreach (ToolStripItem it in tsiCOMConnection.DropDownItems)
            {
                if (it is ToolStripMenuItem && s == (string)it.Tag)
                {
                    (it as ToolStripMenuItem).Checked = true;
                    this.lastSelectedPort = it as ToolStripMenuItem;
                    break;
                }
            }

            tbbConnectBtn.ShowDropDown();
            tsiCOMConnection.ShowDropDown();
        }

        /// <summary>
        /// перезагружаем контроллер
        /// </summary>
        private void ResetController()
        {
            tmrTicks.Enabled = false;
            dateTimeFromControllerReceived = false;
            while (commandsQueue.Count > 0)
                commandsQueue.Dequeue();

            PushCommandToQueue("CTSET=0|RST", Actions.Reset, ProcessReset);
            PushCommandToQueue(GET_PREFIX + UPTIME_COMMAND, Actions.AskUptime, this.ParseUptime);
        }

        /// <summary>
        /// показываем диалог "о программе"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {

            AboutForm ab = new AboutForm();
            ab.ShowDialog();

        }

        /// <summary>
        /// показываем внутренний аптайм
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmrTicks_Tick(object sender, EventArgs e)
        {
            // показываем внутренний аптайм
            int ut = (int)tmrTicks.Tag;
            ut += tmrTicks.Interval/1000;
            tmrTicks.Tag = ut;

           // if (this.controllerDateTime != DateTime.MinValue)
            if(dateTimeFromControllerReceived)
            {
                this.controllerDateTime = this.controllerDateTime.AddMilliseconds(tmrTicks.Interval);
                this.tbToolBar.Invalidate();
            }
            ShowUptime(ut);
        }

        private void tbWindowPosition_Scroll(object sender, EventArgs e)
        {
            string s = CLOSE;
            if (tbWindowPosition.Value == 1)
            {
                s = OPEN;
            }

            tbWindowPosition.Enabled = false;
            PushCommandToQueue(SET_PREFIX + WINDOW_COMMAND + PARAM_DELIMITER + s, Actions.SetWindowPosition, ParseSetWindowPosition);
        }

        private void tbSetWorkMode_Scroll(object sender, EventArgs e)
        {
            string s = MANUAL;
            if (tbSetWorkMode.Value == 1)
                s = AUTO;

            tbSetWorkMode.Enabled = false;
            PushCommandToQueue(SET_PREFIX + MODE_COMMAND + PARAM_DELIMITER + s, Actions.SetWindowWorkMode, ParseSetWindowWorkMode);

        }

        private void cbTempSettings_SelectedIndexChanged(object sender, EventArgs e)
        {
            object o = this.cbTempSettings.Items[this.cbTempSettings.SelectedIndex];
            if (o is TemperatureSettings)
            {
                TemperatureSettings ts = o as TemperatureSettings;
                try
                {
                    this.nudTOpen.Value = ts.OpenTemperature;
                    this.nudTClose.Value = ts.CloseTemperature;
                }
                catch { }

            }
            else
            {
                try
                {
                    this.nudTOpen.Value = this.appSettings.TOpen;
                    this.nudTClose.Value = this.appSettings.TClose;
                }
                catch { }

            }
        }

        /// <summary>
        /// помещаем команды на запись специальных правил в очередь
        /// </summary>
        private void PushWriteRulesCommands()
        {
            String cmd = string.Format(RULE_INTERNAL_ADD_COMMAND, "WOP", "%TO%", "OPEN", ">");
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);

            cmd = string.Format(RULE_INTERNAL_ADD_COMMAND, "WCL", "%TC%", "CLOSE", "<");
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);
            PushCommandToQueue(SET_PREFIX + RULE_SAVE_COMMAND, Actions.SetSaveRules, ParseSetSaveRules);

        }

        private int oldTOpen, oldTClose, oldInterval;
        private void btnWriteTempSettings_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            oldTOpen = appSettings.TOpen;
            oldTClose = appSettings.TClose;
            oldInterval = appSettings.Interval;

            appSettings.TOpen = Convert.ToInt32(this.nudTOpen.Value);
            appSettings.TClose = Convert.ToInt32(this.nudTClose.Value);

            int iT = Convert.ToInt32(this.nudInterval.Value * 1000);
            appSettings.Interval = iT;

            String s = this.nudTOpen.Value.ToString() + PARAM_DELIMITER + this.nudTClose.Value.ToString();
            anylWriteError = 0; // обнуляем счетчик ошибок записи
            PushCommandToQueue(SET_PREFIX + INTERVAL_COMMAND + PARAM_DELIMITER + iT.ToString(), Actions.SetWindowInterval, ParseSetWindowInterval);

            // посылаем команды на запись правил
            if(cbCreateTemperatureRules.Checked)
                PushWriteRulesCommands();
     
            PushCommandToQueue(SET_PREFIX + TEMP_SETTINGS_COMMAND + PARAM_DELIMITER + s, Actions.SetTemperatureParams, ParseSetTemperatureParams);
        }

        private void btnSavePhoneNumber_Click(object sender, EventArgs e)
        {
            appSettings.PhoneNumber = this.tbPhoneNumber.Text.Trim();
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            PushCommandToQueue(SET_PREFIX + PHONE_NUMBER_COMMAND + this.tbPhoneNumber.Text.Trim(), Actions.SetPhoneNumber, ParseSavePhoneNumber);
            PushCommandToQueue(SET_PREFIX + "SMS|PROV|" + cbGSMProvider.SelectedIndex.ToString(), Actions.SetGSMProvider, ParseSetGSMProvider);

        }

        private void WateringControlIndexChanged()
        {
            appSettings.WateringOption = cbWateringControl.SelectedIndex;

            WateringOption opt = cbWateringControl.Items[cbWateringControl.SelectedIndex] as WateringOption;
            bool bConnected = IsConnected();

            

            switch (opt.Tag)
            {
                case 0: // выключено управление поливом
                    gbWeekDays.Visible = false;
                    gbWateringSettings.Visible = false;
                    dgvWateringChannels.Visible = false;
                    break;

                case 1: // управление поливом по дням недели (все каналы одновременно)
                    gbWeekDays.Visible = true;
                    gbWateringSettings.Visible = true;
                    dgvWateringChannels.Visible = false;
                    break;

                case 2:
                    gbWeekDays.Visible = false;
                    gbWateringSettings.Visible = false;
                    dgvWateringChannels.Visible = true;
                    break;
            }

        }

        private void cbWateringControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            WateringControlIndexChanged();
            btnSaveWateringOptions.Enabled = IsConnected();
        }

        private void clbWeekDays_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            bool isChecked = e.NewValue == CheckState.Checked;
            int idx = e.Index;

            int mask = 1 << idx;
            if (isChecked)
                appSettings.WateringDays = appSettings.WateringDays | mask;
            else
                appSettings.WateringDays = appSettings.WateringDays & ~mask;

            btnSaveWateringOptions.Enabled = IsConnected();
        }

        private void nudWateringTime_ValueChanged(object sender, EventArgs e)
        {
            appSettings.WateringTime = Convert.ToInt32(nudWateringTime.Value);
            btnSaveWateringOptions.Enabled = IsConnected();
        }

        private void btnSaveWateringOptions_Click(object sender, EventArgs e)
        {
            btnSaveWateringOptions.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            string command = SET_PREFIX + WATERING_OPTIONS_COMMAND + PARAM_DELIMITER;

            command += appSettings.WateringOption.ToString() + PARAM_DELIMITER;
            command += appSettings.WateringDays.ToString() + PARAM_DELIMITER;
            command += appSettings.WateringTime.ToString() + PARAM_DELIMITER;
            command += appSettings.StartWateringTime.ToString() + PARAM_DELIMITER;
            string add = "0";
            if (chbTurnOnPump.Checked)
                add = "1";

            command += add;

            for (int i = 0; i < appSettings.WaterChannelsCount; i++)
            {
                string s = SET_PREFIX + GET_WATER_CHANNELS_SETTING + i.ToString() + PARAM_DELIMITER +
                    appSettings.WateringChannels[i].ToString();

                PushCommandToQueue(s, Actions.SetWateringChannelOptions, ParseWateringChannelOptions);

            }

            PushCommandToQueue(command, Actions.SetWateringOptions, ParseWateringOptions);

        }

        private void tbWatering_Scroll(object sender, EventArgs e)
        {
            string s = OFF;
            if (tbWatering.Value == 1)
            {
                s = ON;
            }
            //this.cbWateringControl.SelectedIndex = 0; // сбрасываем на выключение автоматического управления поливом

            tbWatering.Enabled = false;
            tbWateringMode.Value = 0; // сбрасываем на ручной режим принудительно
            lblWateringMode.Text = Settings.Default.Manual;
            setWateringStateRequested = true;
            setWateringModeRequested = true;
            PushCommandToQueue(SET_PREFIX + WATERING_COMMAND + PARAM_DELIMITER + s, Actions.SetWateringOnOff, ParseSetWateringOnOff);

        }

        private void tbWateringMode_Scroll(object sender, EventArgs e)
        {
            tbWateringMode.Enabled = false;
            string s = AUTO;
            if (tbWateringMode.Value == 0)
                s = MANUAL;

            setWateringModeRequested = true;
            PushCommandToQueue(SET_PREFIX + WATERING_MODE_COMMAND + PARAM_DELIMITER + s, Actions.SetWateringMode, ParseSetWateringMode);
        }

        private void nudStartWateringTime_ValueChanged(object sender, EventArgs e)
        {
            appSettings.StartWateringTime = Convert.ToInt32(nudStartWateringTime.Value);
            btnSaveWateringOptions.Enabled = IsConnected();
 
        }

        private void tbPlayPause_Click(object sender, EventArgs e)
        {
            this.bWorkPaused = !this.bWorkPaused;
            SwitchToPause(bWorkPaused);
        }

        private void chbTurnOnPump_CheckedChanged(object sender, EventArgs e)
        {
            if (chbTurnOnPump.Checked)
                appSettings.TurpOnPump = 1;
            else
                appSettings.TurpOnPump = 0;

            btnSaveWateringOptions.Enabled = IsConnected();
        }

        private void dgvWateringChannels_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            
            
            if (e.ColumnIndex > 2) // не будем форматировать строку с днями недели, она сама это сделает
                return;

            WateringChannelSettings s = (WateringChannelSettings) dgvWateringChannels.Rows[e.RowIndex].Tag;

            if (e.ColumnIndex == 0)
            {
                e.Value = "#" + (e.RowIndex + 1).ToString();
            }
            else if (e.ColumnIndex == 1)
            {
                e.Value = s.StartWateringTime.ToString() + " ч";
            }
            else if (e.ColumnIndex == 2)
            {
                e.Value = s.WateringTime.ToString() + " мин";
            }
            e.FormattingApplied = true;


        }

        string textForEditingControl = "";
        TextBox editBox = null;
        private void dgvWateringChannels_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is TextBox)
            {
                editBox = e.Control as TextBox;
                editBox.Text = textForEditingControl;
            }
            else
                editBox = null;

        }

        private void dgvWateringChannels_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            textForEditingControl = "";

            if (e.ColumnIndex > 2)
                return;

                WateringChannelSettings s = (WateringChannelSettings)dgvWateringChannels.Rows[e.RowIndex].Tag;

                if (e.ColumnIndex == 1)
                {
                    textForEditingControl = s.StartWateringTime.ToString();
                }
                else if (e.ColumnIndex == 2)
                {
                    textForEditingControl = s.WateringTime.ToString();
                }

        }

        private void dgvWateringChannels_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (editBox != null)
            {
                WateringChannelSettings s = (WateringChannelSettings)dgvWateringChannels.Rows[e.RowIndex].Tag;
                switch (e.ColumnIndex)
                {
                    case 1:
                        try
                        {
                            s.StartWateringTime = Convert.ToInt32(editBox.Text);
                            btnSaveWateringOptions.Enabled = IsConnected();
                        }
                        catch
                        {
                        }
                        break;

                    case 2:
                        try
                        {
                            s.WateringTime = Convert.ToInt32(editBox.Text);
                            btnSaveWateringOptions.Enabled = IsConnected();
                        }
                        catch
                        {
                        }
                        break;
                }
            } // if (editBox != null)

            if(e.ColumnIndex > 2) // редактировали ячейку дней недели
                btnSaveWateringOptions.Enabled = IsConnected();

            
            
            
        }

        private void dgvWateringChannels_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }

        private void tmWaitDataTimer_Tick(object sender, EventArgs e)
        {
            // делаем так, чтобы не висло на форме подключения
            int t = 0;
            if(tmWaitDataTimer.Tag == null)
                tmWaitDataTimer.Tag = 0;

            t = (int) tmWaitDataTimer.Tag;
            t++;

            tmWaitDataTimer.Tag = t;

            if(t > 50)
            {
                tmWaitDataTimer.Enabled = false;
                tmWaitDataTimer.Tag = 0;
                EnsureCloseConnectionForm();

            }
        }

        private void cbEnableLuminosityManage_CheckedChanged(object sender, EventArgs e)
        {
            gbLuminositySettings.Enabled = cbEnableLuminosityManage.Checked;
            appSettings.LuminosityManage = cbEnableLuminosityManage.Checked;
            btnSaveLuxSettings.Enabled = IsConnected();
        }
        /// <summary>
        /// запрашиваем данные со всех датчиков температуры
        /// </summary>
        private void QueryForAllTempData()
        {
            PushCommandToQueue(ALL_TEMP_DATA_COMMAND, Actions.AskTemperature, ParseAskAllTemperature);
        }
        private void tmGetAllTempData_Tick(object sender, EventArgs e)
        {
            if(GrantToProcess())
                QueryForAllTempData();
        }
        /// <summary>
        /// обрабатываем результат запроса данных со всех датчиков температуры
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskAllTemperature(Answer a)
        {
            if (a.IsOkAnswer && tempDataForm != null)
            {
                for (int i = 2; i < a.ParamsCount; i++)
                {
                    string temp = a.Params[i];
                    float fTemp = Convert.ToSingle(temp, new System.Globalization.NumberFormatInfo() { NumberDecimalSeparator = "," });
                    int iTemp = Convert.ToInt32(fTemp);

                    String txt = temp + " °C";
                    if (iTemp == NO_TEMPERATURE_DATA)
                        txt = Settings.Default.NoData;

                    tempDataForm.AddTemperature(i - 2, txt);

                }

            }
        }

        private void tbLux_Scroll(object sender, EventArgs e)
        {
            string s = OFF;
            if (tbLux.Value == 1)
            {
                s = ON;
            }

            tbLux.Enabled = false;
            tbLuxMode.Value = 0; // сбрасываем на ручной режим принудительно
            lblLuxMode.Text = Settings.Default.Manual;
            setLuxStateRequested = true;
            setLuxModeRequested = true;
            PushCommandToQueue(SET_PREFIX + LUMINOSITY_COMMAND + PARAM_DELIMITER + s, Actions.SetLuxOnOff, ParseSetLuxOnOff);

        }

        private void tbLuxMode_Scroll(object sender, EventArgs e)
        {
            tbLuxMode.Enabled = false;
            string s = AUTO;
            if (tbLuxMode.Value == 0)
                s = MANUAL;

            setLuxModeRequested = true;
            PushCommandToQueue(SET_PREFIX + LUX_MODE_COMMAND + PARAM_DELIMITER + s, Actions.SetLuxMode, ParseSetLuxMode);

        }

        private void LuxSettingsValueChanged(object sender, EventArgs e)
        {
            try
            {
                appSettings.LuxFromHour = Convert.ToInt32(nudLuxHourFrom.Value);
                appSettings.LuxToHour = Convert.ToInt32(nudLuxHourTo.Value);
                appSettings.MinLuxValue = Convert.ToInt32(nudMinLux.Value);
                appSettings.LuxGisteresis = Convert.ToInt32(nudLuxGisteresis.Value);
                appSettings.WorkWithoutLightSensor = cbWorkWithoutLightSensor.Checked;
            }
            catch { }


            btnSaveLuxSettings.Enabled = IsConnected();
        }
        private void btnSaveLuxSettings_Click(object sender, EventArgs e)
        {
            btnSaveLuxSettings.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            anylWriteError = 0;

            PushWriteLuxRulesCommands();
        }
        /// <summary>
        /// добавляем запись специальных правил управления досветкой в очередь
        /// </summary>
        private void PushWriteLuxRulesCommands()
        {
            // вычисляем все необходимые интервалы
            int gisteresis = Convert.ToInt32(nudLuxGisteresis.Value);
            int minlux = Convert.ToInt32(nudMinLux.Value);
            int luxhourto = Convert.ToInt32(nudLuxHourTo.Value);
            int luxhourfrom = Convert.ToInt32(nudLuxHourFrom.Value);

            int lux_off_value = minlux +  gisteresis;
            if(lux_off_value < 0)
                  lux_off_value = 0; // когда выключать досветку, с учётом гистерезиса

            // вычисляем продолжительность работы правила
            int lux_worktime = 0;
            if(luxhourto >= luxhourfrom) // например, 7 - 10
            {
                lux_worktime = (luxhourto - luxhourfrom)*60;
                if(luxhourto == luxhourfrom && luxhourto > 0)
                     lux_worktime = 60; // когда час начала равен часу конца, и не нули введены
            }
            else // например, 22 - 4
            {
                lux_worktime = ((24 - luxhourfrom) + luxhourto)*60; // оборачиваем через день
            }

            string minluxForOffRule = "0";

            if (appSettings.WorkWithoutLightSensor) // работаем без датчика освещенности
            {
                minlux = -2; // делаем вид, что у нас нет датчика освещенности, специальное значение -2
                minluxForOffRule = minlux.ToString();
            }


            string ruleCmd = RULE_STATE_COMMAND;

            luxhourfrom *= 60; // У НАС В МИНУТАХ ТЕПЕРЬ НАЧАЛО РАБОТЫ!!!

            String cmd = string.Format(RULE_LUX_ADD_COMMAND, "LON", "<=", minlux.ToString(), luxhourfrom.ToString(), lux_worktime.ToString(), "_", ON);
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);

            cmd = string.Format(RULE_LUX_ADD_COMMAND, "LOFF", ">=", minluxForOffRule, "0", "0", "LON", OFF);
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);

            cmd = string.Format(ruleCmd, "LON", cbEnableLuminosityManage.Checked ? ON : OFF);
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);

            cmd = string.Format(ruleCmd, "LOFF", cbEnableLuminosityManage.Checked ? ON : OFF);
            PushCommandToQueue(SET_PREFIX + cmd, Actions.SetSpecialRule, ParseSetSpecialRule);

            
            if(!cbEnableLuminosityManage.Checked) // принудительно выключаем свет, если нет управления досветкой
                  PushCommandToQueue(SET_PREFIX + LUMINOSITY_COMMAND + PARAM_DELIMITER + OFF, Actions.SetLuxOnOff, ParseSetLuxOnOff);

            // переводим в автоматический режим работы
            PushCommandToQueue(SET_PREFIX + LUX_MODE_COMMAND + PARAM_DELIMITER + AUTO, Actions.SetLuxMode, ParseSetLuxMode);

            PushCommandToQueue(SET_PREFIX + RULE_SAVE_COMMAND, Actions.SetSaveRules, ParseSetSaveLuxRules);

        }
        /// <summary>
        /// обрабатываем результат запроса на сохранение правил
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetSaveLuxRules(Answer a)
        {
            if (a.IsOkAnswer)
            {
            }
            else
            {
                anylWriteError++;
            }

            ShowWriteLuxResultMessage();
        }
        /// <summary>
        /// обрабатываем результат запроса на установку даты/времени в контроллере
        /// </summary>
        /// <param name="a"></param>
        private void ParseSetDatetime(Answer a)
        {
            if (a.IsOkAnswer)
            {
                PushCommandToQueue(GET_PREFIX + CONTROLLER_DATETIME_COMMAND, Actions.AskControllerDateTime, ParseControllerDateTime);
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            setDateTimeInProgress = false;
        }
        /// <summary>
        /// Показываем результат записи настроек досветки
        /// </summary>
        private void ShowWriteLuxResultMessage()
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            btnSaveLuxSettings.Enabled = false;

            if (anylWriteError == 0)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool setDateTimeInProgress = false;
        private void btnSetControllerTime_Click(object sender, EventArgs e)
        {
            if (setDateTimeInProgress)
                return;

            DialogResult dr = MessageBox.Show(Settings.Default.SetControllerTime, Settings.Default.Question, MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr != System.Windows.Forms.DialogResult.OK)
                return;

            setDateTimeInProgress = true;

            DateTime dt = DateTime.Now;

            String s = string.Format("{0,0:D2}.{1,0:D2}.{2} {3,0:D2}:{4,0:D2}:{5,0:D2}",dt.Day,dt.Month,dt.Year,dt.Hour,dt.Minute,dt.Second);
            PushCommandToQueue(SET_PREFIX + SET_DATETIME_COMMAND + s, Actions.SetDatetimeCommand, ParseSetDatetime);


        }

        private DateTime controllerDateTime = DateTime.MinValue;
        private bool dateTimeFromControllerReceived = false;

        private void tbToolBar_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;


            FontStyle fs = FontStyle.Bold;

            Font myFont = new System.Drawing.Font(this.Font.Name, 10, fs);
            Brush myBrush = new SolidBrush(Color.SaddleBrown);

            string strToDraw = controllerDateTime.ToString();

            if (!dateTimeFromControllerReceived)
                strToDraw = Settings.Default.NoData;

            Size sz = g.MeasureString(strToDraw, myFont).ToSize();

            float left = tbToolBar.Left + tbToolBar.Width - sz.Width - 10;
            float top = (tbToolBar.Height) / 2 - sz.Height - 5;

            g.DrawString(strToDraw, myFont, myBrush, left, top);


            strToDraw = "Т прибора: " + coreTemperature;
            sz = g.MeasureString(strToDraw, myFont).ToSize();
            top += sz.Height + 5;
            left = tbToolBar.Left + tbToolBar.Width - sz.Width - 10;

            g.DrawString(strToDraw, myFont, myBrush, left, top);

            myFont.Dispose();
            myBrush.Dispose();

        }

        private void cbConnectToTheRouter_CheckedChanged(object sender, EventArgs e)
        {
            btnSaveWiFiSettings.Enabled = IsConnected();
        }

        private void WiFiSettingsTextChanged(object sender, EventArgs e)
        {
            btnSaveWiFiSettings.Enabled = IsConnected();
        }

        private void btnSaveWiFiSettings_Click(object sender, EventArgs e)
        {
            if (this.tbStationPassword.Text.Trim().Length < 8)
            {
                MessageBox.Show(Settings.Default.PasswordTooShort, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            appSettings.RouterID = this.tbRouterID.Text;
            appSettings.RouterPassword = this.tbRouterPassword.Text;
            appSettings.StationID = this.tbStationID.Text;
            appSettings.StationPassword = this.tbStationPassword.Text;
            appSettings.ConnectToRouter = this.cbConnectToTheRouter.Checked;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            string s = appSettings.ConnectToRouter ? "1" : "0";
            string command = SET_PREFIX + WIFI_SETTINGS_COMMAND + s;
            command += PARAM_DELIMITER + appSettings.RouterID;
            command += PARAM_DELIMITER + appSettings.RouterPassword;
            command += PARAM_DELIMITER + appSettings.StationID;
            command += PARAM_DELIMITER + appSettings.StationPassword;

            PushCommandToQueue(command, Actions.SetWiFiSettings, ParseSetWiFiSettings);

        }

        private void btnQueryIP_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            PushCommandToQueue(GET_PREFIX + WIFI_IP_COMMAND, Actions.AskWiFiIP, ParseAskWiFiIP);
        }

        private bool loadRulesSilentMode = false;
        private void LoadRules(bool silent)
        {
            loadRulesSilentMode = silent;

            if (!loadRulesSilentMode)
            {
                Cursor.Current = Cursors.WaitCursor;
                Application.UseWaitCursor = true;
                Application.DoEvents();
            }

            ClearRulesList();

            // очищаем правила
            appSettings.AlertRules.Clear();

            // начинаем работать с правилами
            inGetRulesFromController = true;
            PushCommandToQueue(GET_PREFIX + RULES_CNT_COMMAND, Actions.AskRulesCount, ParseAskRulesCount);
        }


        private void btnLoadRules_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(Settings.Default.ConfirmLoadRules, Settings.Default.Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            LoadRules(false);
        }

        private void lvRulesList_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            AlertRule ar = (AlertRule) e.Item.Tag;
            if(ar != null)
                ar.IsActive = e.Item.Checked;
        }

        private void lblComputeRulesmemory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int eepromMemory = 0;
            int ramMemory = 0;
            foreach (ListViewItem lvi in this.lvRulesList.Items)
            {
                AlertRule ar = (AlertRule)lvi.Tag;
                if (!ar.IsDeleted)
                {
                    eepromMemory += 16 + ar.Name.Length+1 + ar.LinkedRules.Count+1 + 5;
                    ramMemory += 25 + ar.LinkedRules.Count+1 + 5;
                   
                }
            } // foreach

            string tpl = Settings.Default.RulesMemoryTemplate;
            string mess = string.Format(tpl, eepromMemory, ramMemory);
            MessageBox.Show(mess, Settings.Default.Info, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDeleteRule_Click(object sender, EventArgs e)
        {
           
            foreach (ListViewItem lvi in lvRulesList.SelectedItems)
            {
                AlertRule ar = (AlertRule)lvi.Tag;
                if (ar.IsSpecialRule)
                {
                    if (MessageBox.Show(Settings.Default.DeleteSpecialRuleConfirmation, Settings.Default.Confirmation, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                        return;

                }
                ar.IsDeleted = true;
            }

            lvRulesList.BeginUpdate();

            foreach (ListViewItem lvi in lvRulesList.SelectedItems)
                lvRulesList.Items.Remove(lvi);

            lvRulesList.EndUpdate();

            lblRuleStr.Text = "";
        }

        private void btnAddRule_Click(object sender, EventArgs e)
        {
            if (appSettings.AlertRules.Count > 29)
            {
                // не можем добавлять больше 30 правил!
                MessageBox.Show(Settings.Default.RulesLimitReached, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddEditRuleForm ae = new AddEditRuleForm(null,this);
            if (ae.ShowDialog() == DialogResult.OK)
            {
               // добавлено
            }
        }

        private void lvRulesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach(ListViewItem lvi in lvRulesList.SelectedItems)
            {
                AlertRule ar = (AlertRule)lvi.Tag;
                if (ar != null)
                {
                    lblRuleStr.Text = ar.ToString();
                    break;
                }
            }
        }
        /// <summary>
        /// пустой обработчик ответа от контроллера
        /// </summary>
        /// <param name="a"></param>
        private void DummyAnswerReceiver(Answer a)
        {
            if (!a.IsOkAnswer)
            {
               
            }
        }
        /// <summary>
        /// обработчик результата сохранения правил
        /// </summary>
        /// <param name="a"></param>
        private void ParseSaveRules(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if (a.IsOkAnswer)
            {
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.Info, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            inSaveRulesToController = false;
        }
        private bool inSaveRulesToController = false;
        private void btnSaveRules_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            inSaveRulesToController = true;
            foreach (AlertRule ar in appSettings.AlertRules)
            {
                if (ar.IsDeleted)
                {
                    PushCommandToQueue(SET_PREFIX + RULE_DELETE_COMMAND + ar.Name, Actions.SetRuleDelete, DummyAnswerReceiver);
                }
                else
                {
                    PushCommandToQueue(SET_PREFIX + RULE_ADD_COMMAND + ar.ToString(), Actions.SetRuleAdd, DummyAnswerReceiver);
                    string command = string.Format(RULE_STATE_COMMAND, ar.Name, ar.IsActive ? ON : OFF);
                    PushCommandToQueue(SET_PREFIX + command, Actions.SetRuleState, DummyAnswerReceiver);

                      
                }
            } // foreach

            PushCommandToQueue(SET_PREFIX + RULE_SAVE_COMMAND, Actions.SetSaveRules, ParseSaveRules);

        }

        private void btnEditRule_Click(object sender, EventArgs e)
        {
            // получаем выбранное правило
            AlertRule selRule = null;
            foreach (ListViewItem lvi in this.lvRulesList.SelectedItems)
            {
                selRule = (AlertRule) lvi.Tag;
                break;
            }
            if (appSettings.AlertRules.Count > 29)
            {
                // не можем добавлять больше 30 правил!
                MessageBox.Show(Settings.Default.RulesLimitReached, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddEditRuleForm ae = new AddEditRuleForm(selRule, this);
            if (ae.ShowDialog() == DialogResult.OK)
            {
                // добавлено
                lvRulesList_SelectedIndexChanged(lvRulesList, new EventArgs());
            }
  
        }

        private void btnSelectFolder_Click(object sender, EventArgs e)
        {
            selectFolder.SelectedPath = appSettings.LogsDirectory;
            if (selectFolder.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                appSettings.LogsDirectory = selectFolder.SelectedPath;
                if (appSettings.LogsDirectory[appSettings.LogsDirectory.Length - 1] != '\\')
                    appSettings.LogsDirectory = appSettings.LogsDirectory + "\\";

                EnsureDirectoryExists(appSettings.LogsDirectory);
                tbLogsDirectory.Text = appSettings.LogsDirectory;
            }
        }
        /// <summary>
        /// генерируем имена лог-файлов для указанного интервала времени
        /// </summary>
        /// <param name="interval"></param>
        private void GenerateFilesNames(int interval)
        {
            DateTime dt = DateTime.Now;
            while (interval > 0)
            {
                string name = string.Format("{0,0:D4}{1,0:D2}{2,0:D2}.LOG", dt.Year, dt.Month, dt.Day);
                logFileNames.Add(name);

                interval--;
                dt = dt.AddDays(-1);
            }
        }
        /// <summary>
        /// список имён файлов к опросу
        /// </summary>
        private List<string> logFileNames = new List<string>();

        /// <summary>
        /// подготавливаем имена файлов
        /// </summary>
        void PrepareLogFileNames()
        {
            logFileNames.Clear();
            int interval = 0;
            if (rbDay.Checked)
                interval = 1;
            else if (rbWeek.Checked)
                interval = 7;
            else if (rbMonth.Checked)
                interval = 31;

            GenerateFilesNames(interval);
            pbLogsProgress.Value = 0; // сбрасываем прогресс
            receivedLogFiles = 0; // обнуляем счетчик полученных файлов
            ContinuousReadingFinction = null;
            pbLogsProgress.Maximum = logFileNames.Count + 1;

            QueryLogFiles(); // запрашиваем файлы
        }
        /// <summary>
        /// разбираем ответ на команду запроса лог-файла
        /// </summary>
        /// <param name="a"></param>
        private void ParseAskLogFile(Answer a)
        {

            if (ContinuousReadingFinction != null) // читаем из файла уже
            {
                System.Diagnostics.Debug.WriteLine("Waiting END_OF_FILE: " + a.RawData);
                return;
            }

            if (!IsConnected()) // связь оборвалась
            {
                logFileNames.Clear();
                pbLogsProgress.Value = 0;
                ContinuousReadingFinction = null; // сбрасываем функцию продолжающегося чтения
                return;
            }
  
                if (a.IsOkAnswer) // файл найден контроллером, продолжаем
                {
                    // создаём файл
                    EnsureDirectoryExists(appSettings.LogsDirectory);
                    string fullPath = appSettings.LogsDirectory + currentLogFileName;

                    try
                    {
                        if (fileWriter != null)
                            fileWriter.Close();
                    }
                    catch { }

                    fileWriter = null;

                    try
                    {
                        if (currentLogFile != null)
                            currentLogFile.Close();
                    }
                    catch { }

                    currentLogFile = null;
                    

                    try
                    {
                        currentLogFile = System.IO.File.Create(fullPath, 128, System.IO.FileOptions.None);
                        fileWriter = new StreamWriter(currentLogFile);
                        ContinuousReadingFinction = ReceiveLogFileLine;
                    }
                    catch
                    {
                        ContinuousReadingFinction = null; // сбрасываем указатель на функцию продолжающегося чтения
                        QueryNextLogFile();
                    }

                }
                else
                {
                    // чего-то не срослось, переходим к следующему файлу
                    System.Diagnostics.Debug.WriteLine("Receive log file ERROR: " + a.RawData);
                    ContinuousReadingFinction = null; // сбрасываем указатель на функцию продолжающегося чтения
                    QueryNextLogFile();
                } // else

        }
        private string currentLogFileName;
        System.IO.FileStream currentLogFile = null;
        StreamWriter fileWriter = null;

        /// <summary>
        /// обработчик события получения строки лог-файла в порт
        /// </summary>
        /// <param name="line"></param>
        void ReceiveLogFileLine(string line)
        {
            if (line == "OK=FOLLOW")
                return;

            // наша функция чтения данных из файла
            if (line.EndsWith("END_OF_FILE"))
            {
                // файл закончен
                try
                {
                    fileWriter.Close();
                }
                catch { }
                fileWriter = null;
                try
                {
                    currentLogFile.Close();
                }
                catch { }
                currentLogFile = null;
                ContinuousReadingFinction = null;// сбрасываем указатель на функцию продолжающегося чтения
                receivedLogFiles++;
                System.Diagnostics.Debug.WriteLine("FILE RECEIVED, SWITCH TO NEXT FILE...");
                QueryNextLogFile(); // переходим на следующий лог-файл
                return;
            }
            // уже идут данные, пишем их в файл
            lblCurrentLogLine.Text = line;
            fileWriter.WriteLine(line);
        }
        /// <summary>
        /// запрашиваем следующий лог-файл
        /// </summary>
        private void QueryNextLogFile()
        {
            if (logFileNames.Count > 0)
            {
                currentLogFileName = logFileNames[0];
                lblCurrentLogFileName.Text = "Вычитываем файл " + currentLogFileName + "...";
                logFileNames.RemoveAt(0);
                ContinuousReadingFinction = null;// сбрасываем указатель на функцию продолжающегося чтения
                pbLogsProgress.Value++;

                PushCommandToQueue(GET_PREFIX + LOG_GET_FILE_COMMAND + currentLogFileName, Actions.AskLogFile, ParseAskLogFile);
                this.currentCommand.ActionToSet = Actions.None; // разрешаем обработку следующей команды

                Application.DoEvents();

            }
            else
            {
                // конец, все файлы получили
                inLoadLogsFromController = false;
                pbLogsProgress.Value = pbLogsProgress.Maximum;

                try
                {
                    if (fileWriter != null)
                        fileWriter.Close();
                }
                catch { }
                fileWriter = null;

                try
                {
                    if (currentLogFile != null)
                        currentLogFile.Close();
                }
                catch { }

                currentLogFile = null;

                ContinuousReadingFinction = null;// сбрасываем указатель на функцию продолжающегося чтения
                this.currentCommand.ActionToSet = Actions.None; // разрешаем обработку следующей команды

                Cursor.Current = Cursors.Default;
                Application.UseWaitCursor = false;
                Application.DoEvents();

                lblCurrentLogFileName.Text = "";
                lblCurrentLogLine.Text = "";

                MessageBox.Show("Получено файлов: " + receivedLogFiles.ToString(), Settings.Default.Info);
            }
        }
        /// <summary>
        /// запрашиваем лог-файлы из контроллера
        /// </summary>
        private void QueryLogFiles()
        {
            QueryNextLogFile();
        }

        private bool inLoadLogsFromController = false;
        private int receivedLogFiles = 0;
        private void btnLoadLogs_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            lblCurrentLogFileName.Text = "";
            lblCurrentLogLine.Text = "";

            inLoadLogsFromController = true;
            PrepareLogFileNames();
        }

        private void tbDelta_Click(object sender, EventArgs e)
        {
            DeltaListForm ds = new DeltaListForm();
            if (ds.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                UpdateDeltas();
        }

        private TempDataForm tempDataForm = null;
        private void btnTempSensorsData_Click(object sender, EventArgs e)
        {
            tempDataForm = new TempDataForm();
            QueryForAllTempData();
            tmGetAllTempData.Enabled = true;
            tempDataForm.ShowDialog();
            tmGetAllTempData.Enabled = false;
            tempDataForm = null;
        }

        private void tbRestartButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите перезагрузить контроллер?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Yes)
                return;

            this.ResetController();
        }

        private void btnAddCompositeCommand_Click(object sender, EventArgs e)
        {
            AddEditCompositeCommandForm aec = new AddEditCompositeCommandForm(null, this);
            aec.ShowDialog();
        }

        public void DoneCompositeCommandEdit(AddEditCompositeCommandForm frm, CompositeCommands cc)
        {
            // завершено редактирование или добавление составной команды
            if (cc == null)
            {
                // запросили добавить новую
                cc = new CompositeCommands(frm.tbCommandName.Text.Trim());

                // добавляем этой команде весь список команд
                for (int i = 0; i < frm.lvCommandsList.Items.Count; i++)
                {
                    CompositeCommand comC = (CompositeCommand)frm.lvCommandsList.Items[i].Tag;
                    System.Diagnostics.Debug.Assert(comC != null);
                    cc.Commands.Add(comC);                       
                } // for

                appSettings.CompositeCommands.Add(cc);
                appSettings.Save();

                // добавляем команду в список
                ListViewItem lvi = lvCompositeCommandsList.Items.Add("#" + lvCompositeCommandsList.Items.Count);
                lvi.Tag = cc;
                lvi.SubItems.Add(cc.Name);

            }
            else
            {
                // запросили отредактировать существующую
                System.Diagnostics.Debug.Assert(lvCompositeCommandsList.SelectedItems.Count > 0);
                CompositeCommands old = (CompositeCommands)lvCompositeCommandsList.SelectedItems[0].Tag;
                System.Diagnostics.Debug.Assert(old == cc);
                cc.Commands.Clear();
                cc.Name = frm.tbCommandName.Text.Trim();

                // добавляем этой команде весь список команд
                for (int i = 0; i < frm.lvCommandsList.Items.Count; i++)
                {
                    CompositeCommand comC = (CompositeCommand)frm.lvCommandsList.Items[i].Tag;
                    System.Diagnostics.Debug.Assert(comC != null);
                    cc.Commands.Add(comC);
                } // for

                appSettings.Save();

                lvCompositeCommandsList.SelectedItems[0].SubItems[1].Text = cc.Name;

            }
        }

        private void btnEditCompositeCommand_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.Assert(lvCompositeCommandsList.SelectedItems.Count > 0);
            AddEditCompositeCommandForm aec = new AddEditCompositeCommandForm((CompositeCommands)lvCompositeCommandsList.SelectedItems[0].Tag, this);
            aec.ShowDialog();
        }

        private void btnDeleteCompositeCommand_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.Assert(lvCompositeCommandsList.SelectedItems.Count > 0);
            CompositeCommands cc = (CompositeCommands)lvCompositeCommandsList.SelectedItems[0].Tag;
            lvCompositeCommandsList.SelectedItems[0].Remove();

            for (int i = 0; i < lvCompositeCommandsList.Items.Count; i++)
            {
                lvCompositeCommandsList.Items[i].Text = "#" + i.ToString();
            }

            appSettings.CompositeCommands.Remove(cc);
            appSettings.Save();
 
        }

        private void FillCompisiteCommandsList()
        {
            for (int i = 0; i < appSettings.CompositeCommands.Count; i++)
            {
                CompositeCommands cc = appSettings.CompositeCommands[i];
                ListViewItem lvi = lvCompositeCommandsList.Items.Add("#" + i.ToString());
                lvi.Tag = cc;
                lvi.SubItems.Add(cc.Name);
            }
        }

        private void ParseDeleteCompositeCommands(Answer a)
        {
            /*
            AddToLog(a.RawData);
            if (a.IsOkAnswer)
            {
            }
             */
        }

        private void ParseSaveCompositeCommands(Answer a)
        {
            this.inSaveCompositeCommandsToController = false;
                Cursor.Current = Cursors.Default;
                Application.UseWaitCursor = false;
                Application.DoEvents();
                MessageBox.Show("Составные команды успешно сохранены в контроллер!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnUploadCompositeCommands_Click(object sender, EventArgs e)
        {
            // добавляем составные команды в контроллер
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            // сперва удаляем все составные команды из контроллера
            this.inSaveCompositeCommandsToController = true;
            PushCommandToQueue(SET_PREFIX + "CC|DEL", Actions.SetDeleteCompositeCommands, ParseDeleteCompositeCommands);

            // теперь добавляем для каждой составной команды её список в контроллер
            int cmdCntr = 0;
            foreach (CompositeCommands ccs in appSettings.CompositeCommands)
            {
                foreach (CompositeCommand cc in ccs.Commands)
                {
                    string cmd = SET_PREFIX + "CC|ADD|" + cmdCntr.ToString() + "|";

                    // переводим в понятную для контроллера форму
                    switch (cc.Action)
                    {
                        case WhichTag.TagCloseWindows:
                            cmd += "0";
                            break;
                        case WhichTag.TagOpenWindows:
                            cmd += "1";
                            break;
                        case WhichTag.TagLightOff:
                            cmd += "2";
                            break;
                        case WhichTag.TagLightOn:
                            cmd += "3";
                            break;
                        case WhichTag.TagPinOff:
                            cmd += "4";
                            break;
                        case WhichTag.TagPinOn:
                            cmd += "5";
                            break;
                        default:
                            System.Diagnostics.Debug.Assert(false, "UNKNOWN COMMAND!");
                            break;
                    } // switch

                    cmd += PARAM_DELIMITER;
                    cmd += cc.AdditionalData.ToString();
              
                    PushCommandToQueue(cmd, Actions.SetAddCompositeCommand, this.DummyAnswerReceiver);
                }

                cmdCntr++;
            } // foreach

            PushCommandToQueue(SET_PREFIX + "CC|SAVE", Actions.SetSaveCompositeCommands, ParseSaveCompositeCommands);
        }

        private void miFirmwareInfo_Click(object sender, EventArgs e)
        {
            FirmwareInfoForm fi = new FirmwareInfoForm(this);
            fi.ShowDialog();
            fi.Dispose();
        }


        public void AssignControllerID()
        {
            PushCommandToQueue(SET_PREFIX + "0|ID|" + appSettings.ControllerID.ToString(), Actions.SetControllerID, DummyAnswerReceiver);
        }

        private UniversalSensorsForm uniForm = null;
        bool uniCalibrationAvailable = false;
        bool uniCalibrationFactor1Available = false;
        bool uniCalibrationFactor2Available = false;
        bool uniSensor1Available = false;
        bool uniSensor2Available = false;
        bool uniSensor3Available = false;
        bool isUniModuleRegistered = false;
        private byte[] uniScratch = null;

        /*
        private void ParseRegisterUniModule(Answer a)
        {
            // обновляем информацию по зарегистрированным универсальным модулям
            PushCommandToQueue(GET_PREFIX + "0|UNI", Actions.AskUniversalSensors, ParseAskUniversalSensors);

            if (uniForm == null)
                return;

            if (a.IsOkAnswer)
            {
                uniForm.btnSearch.Enabled = true;
                uniForm.btnRegister.Enabled = true;
                uniForm.lblInfo.Text = "Модуль успешно обновлён!";
            }
            else
            {
                if (a.Params[0] == "U_NONE")
                    uniForm.lblInfo.Text = "Модуль на линии регистрации 1-Wire не найден!";
                else
                    uniForm.lblInfo.Text = "Линия регистрации универсальных модулей не поддерживается прошивкой!";

                DisableUniFormControls();

                uniForm.btnSearch.Enabled = true;
            }
        }
        */
        private void ParseUpdateUniModule(Answer a)
        {
            // обновляем информацию по зарегистрированным универсальным модулям
            PushCommandToQueue(GET_PREFIX + "0|UNI", Actions.AskUniversalSensors, ParseAskUniversalSensors);

            if (uniForm == null)
                return;

            if (a.IsOkAnswer)
            {
                uniForm.btnSearch.Enabled = true;
                uniForm.btnRegister.Enabled = true;
                uniForm.lblInfo.Text = "Модуль успешно обновлён!";

                MessageBox.Show(uniForm.lblInfo.Text);
            }
            else
            {
                if (a.Params[0] == "U_NONE")
                    uniForm.lblInfo.Text = "Модуль на линии регистрации 1-Wire не найден!";
                else
                    if (a.Params[0] == "SCRATCH_TYPE_ERROR")
                        uniForm.lblInfo.Text = "Несоответствие типов скратчпадов при обновлении модуля!";
                    else
                        uniForm.lblInfo.Text = "Линия регистрации универсальных модулей не поддерживается прошивкой!";// +a.RawData;

                MessageBox.Show(uniForm.lblInfo.Text);

                DisableUniFormControls();

                uniForm.btnSearch.Enabled = true;
            }

        }
        
        private void ParseSearchUniModulesResult(Answer a)
        {
            if (uniForm == null)
                return;

            if (a.IsOkAnswer)
            {
                // нашли модуль, парсим
                // OK=SCRATCH_DATA

                string data = a.Params[0];
                System.Diagnostics.Debug.Assert((data.Length / 2) == 30);
                uniScratch = new byte[30];

                int cntr = 0;
                for (int i = 0; i < data.Length; i += 2)
                {
                    string hexStr = data.Substring(i, 2);
                    uniScratch[cntr] = byte.Parse(hexStr, System.Globalization.NumberStyles.HexNumber);
                    cntr++;

                } // for

                byte moduleType = uniScratch[0];
                if (moduleType == 1) // модуль с датчиками
                {
                    uniForm.plModuleWithSensors.Visible = true;
                    uniForm.plRFChannel.Visible = true;

                    byte controllerID = uniScratch[3];

                    isUniModuleRegistered = controllerID == appSettings.ControllerID;
                    //isUniModuleRegistered = false;

                    //byte addIndex = 0;
                    //if (!isUniModuleRegistered)
                    //    addIndex = 1;


                    Dictionary<SensorType, int> currentSensorSettings = new Dictionary<SensorType, int>();
                    foreach(var ss in appSettings.UniversalModulesSettings)
                    {
                        currentSensorSettings[ss.Key] = ss.Value + 1;// +addIndex;
                    }

                    byte config = uniScratch[2];// Convert.ToByte(a.Params[2]);
                    byte cFactor1 = uniScratch[6];//Convert.ToByte(a.Params[3]);
                    byte cFactor2 = uniScratch[7];// Convert.ToByte(a.Params[4]);
                    byte queryIntervalMin = uniScratch[8];//Convert.ToByte(a.Params[5]);
                    byte queryIntervalSec = uniScratch[9];//Convert.ToByte(a.Params[5]);

                    byte sensor1Type = uniScratch[12];//Convert.ToByte(a.Params[6]);
                    byte sensor1Index = uniScratch[11];// Convert.ToByte(a.Params[7]);

                    byte sensor2Type = uniScratch[18];//Convert.ToByte(a.Params[8]);
                    byte sensor2Index = uniScratch[17];//Convert.ToByte(a.Params[9]);

                    byte sensor3Type = uniScratch[24];// Convert.ToByte(a.Params[10]);
                    byte sensor3Index = uniScratch[23];//Convert.ToByte(a.Params[11]);

                    bool rfEnabled = (config & 1) == 1;
                    uniCalibrationAvailable = (config & 2) == 2;
                    uniCalibrationFactor1Available = (config & 4) == 4;
                    uniCalibrationFactor2Available = (config & 8) == 8;

                    int queryIntervalSeconds = queryIntervalMin * 60 + queryIntervalSec;

                    uniForm.btnRegister.Enabled = true;

                    // разобрали, теперь можем работать с UI
                    uniForm.cbRFEnabled.Enabled = true;
                    uniForm.cbRFEnabled.Checked = rfEnabled;



                    if (uniCalibrationAvailable)
                    {
                        uniForm.nudCalibrationFactor1.Enabled = uniCalibrationFactor1Available;
                        uniForm.nudCalibrationFactor2.Enabled = uniCalibrationFactor2Available;

                        try
                        {
                            uniForm.nudCalibrationFactor1.Value = cFactor1;
                            uniForm.nudCalibrationFactor2.Value = cFactor2;
                        }
                        catch { }
                    }

                    if (queryIntervalSeconds > uniForm.nudQueryInterval.Maximum)
                        queryIntervalSeconds = Convert.ToInt32(uniForm.nudQueryInterval.Maximum);

                    try
                    {
                        uniForm.nudQueryInterval.Value = queryIntervalSeconds;
                    }
                    catch { }
                    uniForm.nudQueryInterval.Enabled = true;

                    uniSensor1Available = sensor1Type != 0 && sensor1Type != 0xFF;
                    uniForm.nudSensor1.Enabled = uniSensor1Available;
                    uniForm.nudSensor1.Tag = null;

                    if (uniSensor1Available)
                    {
                        SensorType st = (SensorType)sensor1Type;
                        uniForm.nudSensor1.Tag = st;
                        int idx = /*appSettings.UniversalModulesSettings*/currentSensorSettings[st] - 1;// +addIndex;
                        currentSensorSettings[st]++;

                        if (idx < 0)
                        {
                            
                            uniForm.nudSensor1.Maximum = uniForm.nudSensor1.Minimum;
                        }
                        else
                        {
                            uniForm.nudSensor1.Maximum = idx;
                            try
                            {
                                uniForm.nudSensor1.Value = sensor1Index;
                            }
                            catch { }

//                            uniForm.nudSensor1.Enabled = (uniForm.nudSensor1.Maximum > uniForm.nudSensor1.Minimum);
                        }
                    }

                    uniSensor2Available = sensor2Type != 0 && sensor2Type != 0xFF;
                    uniForm.nudSensor2.Enabled = uniSensor2Available;
                    uniForm.nudSensor2.Tag = null;

                    if (uniSensor2Available)
                    {
                        SensorType st = (SensorType)sensor2Type;
                        uniForm.nudSensor2.Tag = st;
                        int idx = /*appSettings.UniversalModulesSettings*/currentSensorSettings[st] - 1;// +addIndex;
                        currentSensorSettings[st]++;

                        if (idx < 0)
                        {
                            uniForm.nudSensor2.Maximum = uniForm.nudSensor2.Minimum;
                        }
                        else
                        {
                            uniForm.nudSensor2.Maximum = idx;
                            try
                            {
                                uniForm.nudSensor2.Value = sensor2Index;
                            }
                            catch { }

                           // uniForm.nudSensor2.Enabled = (uniForm.nudSensor2.Maximum > uniForm.nudSensor2.Minimum);
                        }
                    }

                    uniSensor3Available = sensor3Type != 0 && sensor3Type != 0xFF;
                    uniForm.nudSensor3.Enabled = uniSensor3Available;
                    uniForm.nudSensor3.Tag = null;

                    if (uniSensor3Available)
                    {
                        SensorType st = (SensorType)sensor3Type;
                        uniForm.nudSensor3.Tag = st;
                        int idx = /*appSettings.UniversalModulesSettings*/currentSensorSettings[st] - 1;// +addIndex;
                        currentSensorSettings[st]++;

                        if (idx < 0)
                        {
                            uniForm.nudSensor3.Maximum = uniForm.nudSensor3.Minimum;
                        }
                        else
                        {
                            uniForm.nudSensor3.Maximum = idx;
                            try
                            {
                                uniForm.nudSensor3.Value = sensor3Index;
                            }
                            catch { }

                            //  uniForm.nudSensor3.Enabled = (uniForm.nudSensor3.Maximum > uniForm.nudSensor3.Minimum);
                        }
                    }


                    if (!isUniModuleRegistered)
                    {
                        // модуль не зарегистрирован у нас.
                        uniForm.lblInfo.Text = "Найденный модуль не зарегистрирован в контроллере. Вы можете как зарегистрировать его как с настройками по умолчанию, так и со своими.";
                        uniForm.btnRegister.Text = "Зарегистрировать";
                        MessageBox.Show(uniForm.lblInfo.Text);
                    }
                    else
                    {
                        // модуль зарегистрирован у нас.
                        uniForm.lblInfo.Text = "Найденный модуль уже зарегистрирован в контроллере. Вы можете поменять доступные настройки модуля.";
                        uniForm.btnRegister.Text = "Сохранить";
                        MessageBox.Show(uniForm.lblInfo.Text);

                    }

                } // moduleType == 1
                else if (moduleType == 2) // дисплей Nextion
                {
                    MessageBox.Show("Дисплей Nextion не нуждается в регистрации в системе.");
                }
                else if (moduleType == 3) // исполнительный модуль
                {
                    uniForm.InitSlots();

                    uniForm.plExecutionModule.Visible = true;
                    uniForm.plRFChannel.Visible = true;
                    uniForm.btnRegister.Enabled = true;

                    byte controllerID = uniScratch[3];
                    isUniModuleRegistered = controllerID == appSettings.ControllerID;

                    // теперь заполняем слоты
                    int read_addr = 5;
                    for (int i = 0; i < 8; i++)
                    {
                        byte slotType = uniScratch[read_addr];
                        byte slotIndex = uniScratch[read_addr + 1];                           

                        read_addr += 3;

                        if (slotType == 0 || slotType == 0xFF) // пустой слот
                            continue;

                        try
                        {
                            ComboBox cb = uniForm.plExecutionModule.Controls.Find("cbSlot" + (i + 1).ToString(), false)[0] as ComboBox;
                            NumericUpDown nud = uniForm.plExecutionModule.Controls.Find("nudSlot" + (i + 1).ToString(), false)[0] as NumericUpDown;

                            if (slotType < cb.Items.Count)
                                cb.SelectedIndex = slotType;

                            if (slotIndex < nud.Maximum)
                            {
                               nud.Value = slotIndex;
                            }
                        }
                        catch { }
                        


                    } // for

                    if (!isUniModuleRegistered)
                    {
                        // модуль не зарегистрирован у нас.
                        uniForm.lblInfo.Text = "Найденный модуль не зарегистрирован в контроллере. Вы можете назначить ему нужные настройки.";
                        uniForm.btnRegister.Text = "Зарегистрировать";
                        MessageBox.Show(uniForm.lblInfo.Text);
                    }
                    else
                    {
                        // модуль зарегистрирован у нас.
                        uniForm.lblInfo.Text = "Найденный модуль уже зарегистрирован в контроллере. Вы можете поменять доступные настройки модуля.";
                        uniForm.btnRegister.Text = "Сохранить";
                        MessageBox.Show(uniForm.lblInfo.Text);

                    }
                } // type == 3
                else
                {
                    MessageBox.Show("Найден неподдерживаемый системой тип модуля!");
                }

            }
            else
            {
                if (a.Params[0] == "U_NONE")
                {
                    uniForm.lblInfo.Text = "Модуль на линии регистрации 1-Wire не найден!";
                    MessageBox.Show(uniForm.lblInfo.Text);
                }
                else
                {
                    uniForm.lblInfo.Text = "Линия регистрации универсальных модулей не поддерживается прошивкой!";// +a.RawData;
                    MessageBox.Show(uniForm.lblInfo.Text);
                }

                DisableUniFormControls();

                
            }

            uniForm.btnSearch.Enabled = true;

        }

        private void DisableUniFormControls()
        {
            if (uniForm == null)
                return;

            uniForm.plModuleWithSensors.Visible = false;
            uniForm.plExecutionModule.Visible = false;
            uniForm.plRFChannel.Visible = false;

            uniForm.nudCalibrationFactor1.Enabled = false;
            uniForm.nudCalibrationFactor2.Enabled = false;
            uniForm.nudQueryInterval.Enabled = false;


            uniForm.nudSensor1.Enabled = false;
            uniForm.nudSensor2.Enabled = false;
            uniForm.nudSensor3.Enabled = false;

            uniForm.cbRFEnabled.Enabled = false;
            uniForm.btnRegister.Enabled = false;
        }

        private void miUniversalSensors_Click(object sender, EventArgs e)
        {
            uniForm = new UniversalSensorsForm(this);
            uniForm.ShowDialog();
            uniForm = null;
        }

        public void SearchUniModules()
        {
            uniForm.plModuleWithSensors.Visible = false;
            uniForm.plExecutionModule.Visible = false;
            uniForm.plRFChannel.Visible = false;
            uniForm.btnSearch.Enabled = false;
            uniSensor1Available = false;
            uniSensor2Available = false;
            uniSensor3Available = false;
            uniCalibrationAvailable = false;

            PushCommandToQueue(GET_PREFIX + "0|U_SEARCH", Actions.SearchUniModules, ParseSearchUniModulesResult);
        }

        public void UpdateUniModule()
        {
            byte rfChannel = Convert.ToByte(uniForm.nudRFChannel.Value);
            if (appSettings.RFChannel != rfChannel)
            {
                appSettings.RFChannel = rfChannel;
                PushCommandToQueue(SET_PREFIX + "0|RF|" + rfChannel.ToString(), Actions.AskRFChannel, DummyAnswerReceiver);
            }

            if (uniScratch[0] == 1) // модуль с датчиками
            {

                uniForm.btnSearch.Enabled = false;
                uniForm.btnRegister.Enabled = false;

                byte config = 0;
                if (uniCalibrationAvailable)
                    config |= 2;

                if (uniForm.cbRFEnabled.Checked)
                    config |= 1;

                if (uniCalibrationFactor1Available)
                    config |= 4;

                if (uniCalibrationFactor2Available)
                    config |= 8;

                uniScratch[2] = config;
                uniScratch[4] = rfChannel; // запоминаем номер канала для nRF
                uniScratch[6] = Convert.ToByte(uniForm.nudCalibrationFactor1.Value);
                uniScratch[7] = Convert.ToByte(uniForm.nudCalibrationFactor2.Value);

                int queryInterval = Convert.ToInt32(uniForm.nudQueryInterval.Value);
                byte minutes = Convert.ToByte(queryInterval / 60);
                byte seconds = Convert.ToByte(queryInterval % 60);

                uniScratch[8] = minutes;
                uniScratch[9] = seconds;

                byte sIdx = Convert.ToByte(uniForm.nudSensor1.Value);
                if (!uniSensor1Available)
                    sIdx = 0xFF;

                uniScratch[11] = sIdx;

                sIdx = Convert.ToByte(uniForm.nudSensor2.Value);
                if (!uniSensor2Available)
                    sIdx = 0xFF;

                uniScratch[17] = sIdx;

                sIdx = Convert.ToByte(uniForm.nudSensor3.Value);
                if (!uniSensor3Available)
                    sIdx = 0xFF;

                uniScratch[23] = sIdx;

                string txtScratch = BitConverter.ToString(uniScratch);
                txtScratch = txtScratch.Replace("-", "");
           

                string command = SET_PREFIX + "0|U_REG|" + txtScratch;
                PushCommandToQueue(command, Actions.UpdateUniModule, ParseUpdateUniModule);

            } // uniScratch[0] == 1
            else if (uniScratch[0] == 3) // исполнительный модуль
            {
                uniForm.btnSearch.Enabled = false;
                uniForm.btnRegister.Enabled = false;

                uniScratch[4] = rfChannel; // запоминаем номер канала для nRF
                byte write_addr = 5;

                for (int i = 0; i < 8; i++)
                {

                    try
                    {
                        ComboBox cb = uniForm.plExecutionModule.Controls.Find("cbSlot" + (i + 1).ToString(), false)[0] as ComboBox;
                        NumericUpDown nud = uniForm.plExecutionModule.Controls.Find("nudSlot" + (i + 1).ToString(), false)[0] as NumericUpDown;

                        byte slotType = Convert.ToByte(cb.SelectedIndex);
                        byte slotIndex = Convert.ToByte(nud.Value);

                        uniScratch[write_addr] = slotType;
                        uniScratch[write_addr + 1] = slotIndex;

                        write_addr += 3;

                    }
                    catch { }
                } // for

                string txtScratch = BitConverter.ToString(uniScratch);
                txtScratch = txtScratch.Replace("-", "");

                string command = SET_PREFIX + "0|U_REG|" + txtScratch;
                PushCommandToQueue(command, Actions.UpdateUniModule, ParseUpdateUniModule);

            } // type == 3

        }

        private void btnSaveFlowSettings_Click(object sender, EventArgs e)
        {
            if (!IsConnected())
                return;

            btnSaveFlowSettings.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            string comm = SET_PREFIX + FLOW_SETTINGS_COMMAND + PARAM_DELIMITER + nudFlowCalibration1.Value.ToString() +
                PARAM_DELIMITER + nudFlowCalibration2.Value.ToString();

            PushCommandToQueue(comm, Actions.SetFlowSettings, ParseSetFlowSettings);

        }

        private void ParseAddCustomSMS(Answer a)
        {
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if (a.IsOkAnswer)
            {
                MessageBox.Show("Новое СМС успешно добавлено!");
            }
            else
            {
                MessageBox.Show("Ошибка добавления СМС! Возможно, модуль SD-карты не указан в настройках прошивки.");
            }

            if (customSMSForm != null)
            {
                customSMSForm.CanClose();
                customSMSForm.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            }
            customSMSForm = null;
        }

        private CustomSMSForm customSMSForm = null;
        public void AddCustomSMS(string sms)
        {
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();
            PushCommandToQueue(sms, Actions.AddCustomSMS, ParseAddCustomSMS);
        }
        public void CloseCustomSMSForm()
        {
            customSMSForm = null;
        }

        private void btnAddSMS_Click(object sender, EventArgs e)
        {
            customSMSForm = new CustomSMSForm(this);
            customSMSForm.ShowDialog();
        }

        private void btnSmsList_Click(object sender, EventArgs e)
        {
            SmsListForm lst = new SmsListForm();
            lst.ShowDialog();
        }

        private void miReservationSettings_Click(object sender, EventArgs e)
        {
            ReservationSettingsForm rsForm = new ReservationSettingsForm();
            if (rsForm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                PushCommandToQueue(SET_PREFIX + "RSRV|DEL", Actions.DeleteReservations, this.DummyAnswerReceiver);

                for (int i = 0; i < appSettings.ReservationSettings.Count; i++)
                {
                    ReservationSetting rs = appSettings.ReservationSettings[i];
                    string cmd = SET_PREFIX + "RSRV|ADD|";
                    switch (rs.Type)
                    {
                        case SensorType.Humidity:
                            cmd += "HUMIDITY";
                            break;
                        case SensorType.Luminosity:
                            cmd += "LIGHT";
                            break;
                        case SensorType.SoilMoisture:
                            cmd += "SOIL";
                            break;
                        case SensorType.Temperature:
                            cmd += "TEMP";
                            break;
                    } // switch

                   

                    for (int j = 0; j < rs.List.Count; j++)
                    {
                        cmd += "|";
                        ReservationInfo ri = rs.List[j];
                        cmd += ri.ModuleName + "|";
                        cmd += ri.SensorIndex.ToString();
                    } // for

                    PushCommandToQueue(cmd, Actions.AddReservation, this.DummyAnswerReceiver);
                } // for

                PushCommandToQueue(SET_PREFIX + "RSRV|SAVE", Actions.SaveReservations, this.DummyAnswerReceiver);
            }
        }

        private void miTimers_Click(object sender, EventArgs e)
        {
            TimersForm tf = new TimersForm();
            if (tf.ShowDialog() == DialogResult.OK)
            {
                string cmd = SET_PREFIX + "TMR";
                for (int i = 0; i < 4; i++)
                {
                    TimerSettings ts = appSettings.Timers[i];
                    cmd += PARAM_DELIMITER;
                    cmd += ts.DayMaskAndEnable.ToString();

                    cmd += PARAM_DELIMITER;
                    cmd += ts.Pin.ToString();

                    cmd += PARAM_DELIMITER;
                    cmd += ts.HoldOnTime.ToString();

                    cmd += PARAM_DELIMITER;
                    cmd += ts.HoldOffTime.ToString();

                } // for

                PushCommandToQueue(cmd, Actions.SaveTimersSettings, this.DummyAnswerReceiver);
            }
        }

        private void miMonitorScreenSettings_Click(object sender, EventArgs e)
        {
            MonitorSettingsForm ms = new MonitorSettingsForm();
            ms.ShowDialog();
        }

        private void ParseClearCCCommands(Answer a)
        {
            if (a.IsOkAnswer)
            {
                PushCommandToQueue(SET_PREFIX + "CC|SAVE", Actions.SetSaveCompositeCommands, DummyAnswerReceiver);
                MessageBox.Show("Составные команды успешно очищены!");
            }
            else
            {
                MessageBox.Show("Ошибка очистки составных команд.");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите очистить все составные команды в контроллере?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Yes)
                return;

            PushCommandToQueue(SET_PREFIX + "CC|DEL", Actions.SetDeleteCompositeCommands, ParseClearCCCommands);
        }

        private WindowsStatesForm wStatesForm = null;

        private void lblWindowStates_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(wStatesForm == null)
                wStatesForm = new WindowsStatesForm();

            wStatesForm.Init();
            wStatesForm.Show();
        }

        private void ParseResetWaterflowData(Answer a)
        {
            MessageBox.Show("Данные по расходу воды успешно сброшены!");
        }

        private void btnResetWaterflowData_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите сбросить показания счётчиков?", "Подтверждение", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Yes)
                return;

            PushCommandToQueue(SET_PREFIX + "FLOW|RST", Actions.ResetWaterflowData, ParseResetWaterflowData);
        }

        private void cbCreateTemperatureRules_CheckedChanged(object sender, EventArgs e)
        {
            appSettings.CreateTemperatureRules = cbCreateTemperatureRules.Checked;
        }

        private void btnSavePHSettings_Click(object sender, EventArgs e)
        {
            if (!IsConnected())
                return;

            btnSavePHSettings.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            this.phCalibrationFactor = Convert.ToInt32(nudPHCalibration.Value);
            this.phVoltage4 = Convert.ToInt32(nudPHVoltage4.Value);
            this.phVoltage7 = Convert.ToInt32(nudPHVoltage7.Value);
            this.phVoltage10 = Convert.ToInt32(nudPHVoltage10.Value);
            this.phTemperatureSensor = Convert.ToInt32(nudPHTempSensorIndex.Value);
            this.phCalibrationTemperature = nudPHCalibrationTemperature.Value;

            int phCalTemp = Convert.ToInt32(phCalibrationTemperature * 100);

            int iPHTarget = Convert.ToInt32(this.phTarget * 100);
            int iPHHisteresis =  Convert.ToInt32(this.phHisteresis * 100);


            string comm = SET_PREFIX + "PH|T_SETT|" + phCalibrationFactor.ToString() + "|" +
                phVoltage4.ToString() + "|" + phVoltage7.ToString() + "|" + phVoltage10.ToString() + "|" + phTemperatureSensor.ToString()
                + "|" + phCalTemp.ToString() + "|" + iPHTarget.ToString() + "|" + iPHHisteresis.ToString() +
                "|" + this.phMixPumpTime.ToString() + "|" + this.phReagentPumpTime.ToString();

            PushCommandToQueue(comm, Actions.SetPHSettings, ParseSetPHSettings);

        }


        private decimal Constrain(decimal val, NumericUpDown nud)
        {
            if (val < nud.Minimum)
                return nud.Minimum;
            if (val > nud.Maximum)
                return nud.Maximum;
            return val;
        }

        private int Constrain(int val, NumericUpDown nud)
        {
            if (val < nud.Minimum)
                return Convert.ToInt32(nud.Minimum);
            if (val > nud.Maximum)
                return Convert.ToInt32(nud.Maximum);

            return val;
        }


        private void btnPHControl_Click(object sender, EventArgs e)
        {
            PHControlForm pc = new PHControlForm();

            this.phTarget = Constrain(this.phTarget, pc.nudTargetPH);
            pc.nudTargetPH.Value = this.phTarget;

            this.phHisteresis = Constrain(this.phHisteresis, pc.nudPHHisteresis);
            pc.nudPHHisteresis.Value = this.phHisteresis;

            this.phMixPumpTime = Constrain(this.phMixPumpTime, pc.nudPHMixPumpTime);
            pc.nudPHMixPumpTime.Value = this.phMixPumpTime;

            this.phReagentPumpTime = Constrain(this.phReagentPumpTime, pc.nudPHReagentPumpTime);
            pc.nudPHReagentPumpTime.Value = this.phReagentPumpTime;

            DialogResult dr = pc.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                // TODO: Тут сохранение настроек !!!
                this.phTarget = pc.nudTargetPH.Value;
                this.phHisteresis = pc.nudPHHisteresis.Value;
                this.phMixPumpTime = Convert.ToInt32(pc.nudPHMixPumpTime.Value);
                this.phReagentPumpTime = Convert.ToInt32(pc.nudPHReagentPumpTime.Value);

                btnSavePHSettings_Click(btnSavePHSettings, new EventArgs());
            }
        }

        private void miPinsUsed_Click(object sender, EventArgs e)
        {
            inRequestPinsUsedFromController = true;
            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            PushCommandToQueue(GET_PREFIX + "0|PINS", Actions.GetPinsUsed, ParseSetPinsUsed);
        }

        private UsedPinsForm usedPinsForm = null;

        private string getPinDescription(int pinNumber)
        {
            string desc = "";

            switch (pinNumber)
            {
                case 0:
                    desc = "RX0";
                    break;

                case 1:
                    desc = "TX0";
                    break;

                case 17:
                    desc = "RX2";
                    break;

                case 16:
                    desc = "TX2";
                    break;

                case 53:
                    desc = "SS";
                    break;

                case 52:
                    desc = "SCK";
                    break;

                case 51:
                    desc = "MOSI";
                    break;

                case 50:
                    desc = "MISO";
                    break;

                case 21:
                    desc = "SCL";
                    break;

                case 20:
                    desc = "SDA";
                    break;

                case 19:
                    desc = "RX1";
                    break;

                case 18:
                    desc = "TX1";
                    break;

                case 15:
                    desc = "RX3";
                    break;

                case 14:
                    desc = "TX3";
                    break;

            }

            if (pinNumber >= 54 && pinNumber <= 69)
            {
                // analog pins
                desc = "A" + (pinNumber - 54).ToString();
            }

            if (desc != "")
                desc = " (" + desc + ")";

            return desc;
        }

        private void ParseSetPinsUsed(Answer a)
        {
            inRequestPinsUsedFromController = false;
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if (a.IsOkAnswer)
            {
              
                if(usedPinsForm == null)
                    usedPinsForm = new UsedPinsForm();

                usedPinsForm.lvPins.Items.Clear();

                // пришла информация об используемых пинах
                int numBytes = Convert.ToInt32(a.Params[2]);
                string pinsUsed = a.Params[3];
                string pinsMode = a.Params[4];

                for (int i = 0; i < numBytes; i++)
                {
                    string currentPinsUsed = pinsUsed.Substring(0, 2);
                    byte bCurrentPins = (byte)int.Parse(currentPinsUsed, System.Globalization.NumberStyles.HexNumber);
                    pinsUsed = pinsUsed.Substring(2);

                    string currentPinsMode = pinsMode.Substring(0, 2);
                    byte bCurrentPinsMode = (byte)int.Parse(currentPinsMode, System.Globalization.NumberStyles.HexNumber);
                    pinsMode = pinsMode.Substring(2);

                    int startPinNumber = 8 * i;

                    for (int k = 0; k < 8; k++)
                    {
                        bool isPinUsed = BitIsSet(bCurrentPins, k);
                        if (isPinUsed)
                        {
                            bool isPinOutput = BitIsSet(bCurrentPinsMode, k);
                            int usedPinNumber = startPinNumber + k;

                            string caption = usedPinNumber.ToString() + getPinDescription(usedPinNumber);

                            ListViewItem li = usedPinsForm.lvPins.Items.Add("#" + caption);
                            li.SubItems.Add((isPinOutput ? "выход" : "вход"));
                            li.Tag = isPinOutput;
                            li.BackColor = isPinOutput ? Color.LightGreen : Color.LightSalmon;
                           // System.Diagnostics.Debug.Print("Found used pin: " + usedPinNumber.ToString() + "; is output : " + (isPinOutput ? "true" : "false"));
                        }
                    } // for
                } // for

                // тут показываем форму
                usedPinsForm.Show();
            } // ok answer
        }

        private void ParseSetIoTSettings(Answer a)
        {
            inSaveIoTSettings = false;
            Cursor.Current = Cursors.Default;
            Application.UseWaitCursor = false;
            Application.DoEvents();

            if (a.IsOkAnswer)
                MessageBox.Show(Settings.Default.SettingsSaved, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(Settings.Default.ErrorSaveSettings, Settings.Default.SaveSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private bool inSaveIoTSettings = false;
        private void btnSaveIoTSettings_Click(object sender, EventArgs e)
        {
            if (inSaveIoTSettings)
                return;

            // сперва проверяем, сколько всего итемов выбрано
            int countChecked = lbIOTSelectedSensors.Items.Count;

            if (countChecked < 1 || tbThingSpeakChannelKey.Text.Length < 1)
            {
                MessageBox.Show("Пожалуйста, выберите хотя бы один датчик, и не забудьте указать ключ канала!", "Выбор датчиков", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (countChecked > 8)
            {
                // выбрано больше 8 датчиков, надо вывести предупреждение
                DialogResult dr = MessageBox.Show("Выбрано больше 8 датчиков! При нажатии ОК будут сохранены настройки для первых 8 выбранных датчиков. Продолжить?", "Выбор датчиков", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dr != System.Windows.Forms.DialogResult.OK)
                    return;
            }

            int iterations = Math.Min(8, countChecked);

            string command = "IOT|T_SETT|";

            byte flags = 0;
            if(cbThingSpeakEnabled.Checked)
                flags |= 1;

            command += flags.ToString();
            command += PARAM_DELIMITER;
            int interval = Convert.ToInt32(nudIoTInterval.Value) * 1000;
            command += interval.ToString();

            for (int i = 0; i < iterations; i++)
            {
                IoTSensorSettings ioss = (IoTSensorSettings)lbIOTSelectedSensors.Items[i];
                command += PARAM_DELIMITER;
                command += ioss.ModuleID.ToString();

                command += PARAM_DELIMITER;
                command += ioss.SensorType.ToString();

                command += PARAM_DELIMITER;
                command += ioss.SensorIndex.ToString();

            }

            // дополняем до восьми
            for (int i = iterations; i < 8; i++)
            {
                command += "|0|0|0";
            }

            command += PARAM_DELIMITER;
            command += tbThingSpeakChannelKey.Text;


            Cursor.Current = Cursors.WaitCursor;
            Application.UseWaitCursor = true;
            Application.DoEvents();

            this.inSaveIoTSettings = true;
            PushCommandToQueue(SET_PREFIX + command, Actions.SetIoTSettings, ParseSetIoTSettings);
        }

        private void lbIOTSelectedSensors_MouseDown(object sender, MouseEventArgs e)
        {
            ListBox list = sender as ListBox;
            if (list.SelectedItem == null) 
                return;
            //object dragObject = new {list = list, item = list.SelectedItem};
            IoTDraggedData draggedData = new IoTDraggedData();
            draggedData.SourceList = list;
            draggedData.Sensor = list.SelectedItem as IoTSensorSettings;

            list.DoDragDrop(draggedData, DragDropEffects.Move);
        }

        private void lbIOTSelectedSensors_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void lbIOTSelectedSensors_DragDrop(object sender, DragEventArgs e)
        {
            ListBox targetList = sender as ListBox;


            Point point = targetList.PointToClient(new Point(e.X, e.Y));
            int index = targetList.IndexFromPoint(point);
            bool isInsert = true;
            if (index < 0)
                isInsert = false;//index = targetList.Items.Count -1;

            IoTDraggedData draggedData = (IoTDraggedData) e.Data.GetData(typeof(IoTDraggedData));

            // если таскают внутри одного списка и он у нас - список со всеми датчиками - не даём этого делать
            if (draggedData.SourceList == targetList && targetList == this.lbIOTAllSensors)
                return;

            // проверяем, не больше ли 8 датчиков?
            if (targetList == this.lbIOTSelectedSensors && targetList.Items.Count > 7)
                return;

            draggedData.SourceList.Items.Remove(draggedData.Sensor);
            if (isInsert)
                targetList.Items.Insert(index, draggedData.Sensor);
            else
                targetList.Items.Add(draggedData.Sensor);

        }

    }
}
