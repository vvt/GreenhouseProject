﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class UniversalSensorsForm : Form
    {
        private MainForm mainForm = null;
        public UniversalSensorsForm(MainForm fm)
        {
            InitializeComponent();

            mainForm = fm;
        }

        private void nudCalibrationFactor1_Enter(object sender, EventArgs e)
        {
            lblInfo.Text = "Фактор калибровки датчика, зависит от его типа.";
        }

        private void nudQueryInterval_Enter(object sender, EventArgs e)
        {
            lblInfo.Text = "Интервал обновления показаний датчиков универсального модуля.";
        }

        private void cbRFEnabled_Enter(object sender, EventArgs e)
        {
            lblInfo.Text = "Включить/выключить радиопередатчик универсального модуля.";
        }

        private void nudSensor1_Enter(object sender, EventArgs e)
        {
            NumericUpDown nud = (NumericUpDown)sender;
            lblInfo.Text = "";

            if (nud.Tag != null)
            {
                SensorType st = (SensorType)nud.Tag;
                string addHint = " Значение индекса меняется только в пределах интервала индексов ранее зарегистрированных универсальных модулей.";
                switch (st)
                {
                    case SensorType.Humidity:
                        lblInfo.Text = "Индекс датчика влажности универсального модуля." + addHint;
                        break;
                    case SensorType.Luminosity:
                        lblInfo.Text = "Индекс датчик освещённости универсального модуля." + addHint;
                        break;
                    case SensorType.SoilMoisture:
                        lblInfo.Text = "Индекс датчика влажности почвы универсального модуля." + addHint;
                        break;
                    case SensorType.Temperature:
                        lblInfo.Text = "Индекс датчика температуры универсального модуля." + addHint;
                        break;
                    case SensorType.PH:
                        lblInfo.Text = "Индекс датчика pH универсального модуля." + addHint;
                        break;
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            mainForm.SearchUniModules();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            mainForm.UpdateUniModule();
        }

        private void UniversalSensorsForm_Load(object sender, EventArgs e)
        {
            InitSlots();
            try
            {
                nudRFChannel.Value = AppSettings.Instance.RFChannel;
            }
            catch
            {
            }
        }

        public void InitSlots()
        {
            for (int i = 0; i < plExecutionModule.Controls.Count; i++)
            {
                Control c = plExecutionModule.Controls[i];
                if (c is ComboBox)
                {
                    (c as ComboBox).SelectedIndex = 0;
                }
                else
                    if (c is NumericUpDown)
                    {
                        try
                        {
                            (c as NumericUpDown).Value = 0;
                        }
                        catch { }
                    }
            } // for
        }
    }
}
