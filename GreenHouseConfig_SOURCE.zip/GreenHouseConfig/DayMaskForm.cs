﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class DayMaskForm : Form
    {
        public DayMaskForm()
        {
            InitializeComponent();
        }

        public void SetDaymask(byte mask)
        {          
            for (int i = 0; i < clbDaymask.Items.Count; i++)
            {
                clbDaymask.SetItemChecked(i, (mask & (1 << i)) != 0);
            }
        }

        public byte GetDaymask()
        {
            byte mask = 0;

            for (int i = 0; i < clbDaymask.Items.Count; i++)
            {
                byte sel = 0;
                if(clbDaymask.GetItemChecked(i))
                    sel = 1;
                byte pos = Convert.ToByte(i);
                mask |= Convert.ToByte(sel << pos);
            }

            return mask;
        }

        private void DayMaskForm_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
