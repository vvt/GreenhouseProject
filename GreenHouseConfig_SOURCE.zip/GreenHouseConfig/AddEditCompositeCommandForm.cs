﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class AddEditCompositeCommandForm : Form
    {
        private CompositeCommands commandToEdit = null;
        private MainForm mainForm = null;

        public AddEditCompositeCommandForm()
        {
            InitializeComponent();
        }

        private void FillUI()
        {
            if (commandToEdit == null)
                return;

            tbCommandName.Text = commandToEdit.Name;
            for (int i = 0; i < commandToEdit.Commands.Count; i++)
            {
                CompositeCommand cp = commandToEdit.Commands[i];
                ListViewItem lvi = lvCommandsList.Items.Add("#" + i.ToString());
                lvi.Tag = cp;
                lvi.SubItems.Add(cp.ToString());
                lvi.SubItems.Add(cp.AdditionalData.ToString());
            } // for
        }

        public AddEditCompositeCommandForm(CompositeCommands cte, MainForm mf)
        {
            InitializeComponent();

            commandToEdit = cte;
            mainForm = mf;


            FillUI();

        }

        private void lvCommandsList_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool anySelected = lvCommandsList.SelectedItems.Count > 0;
            btnDeleteCompositeCommand.Enabled = anySelected;
            btnEditCompositeCommand.Enabled = anySelected;
        }

        public void DoneEdit(AddOneCommandForm frm, CompositeCommand cmd)
        {
            if (cmd == null)
            {
                // запросили добавить новую
                DescriptionValuePair dvp = (DescriptionValuePair) frm.cbCommandType.Items[frm.cbCommandType.SelectedIndex];
                byte addData = 0;
                if (frm.tbAdditionalParameter.Text != "")
                {
                    try
                    {
                        addData = byte.Parse(frm.tbAdditionalParameter.Text);
                    }
                    catch { }
                }
                cmd = new CompositeCommand(dvp.WhichTag, addData);

                ListViewItem lvi = lvCommandsList.Items.Add("#" + lvCommandsList.Items.Count);
                lvi.Tag = cmd;
                lvi.SubItems.Add(cmd.ToString());
                lvi.SubItems.Add(cmd.AdditionalData.ToString());

            }
            else
            {
                // запросили обновить существующую
                System.Diagnostics.Debug.Assert(lvCommandsList.SelectedItems.Count > 0);
                ListViewItem lvi = lvCommandsList.SelectedItems[0];
                CompositeCommand cc = (CompositeCommand) lvi.Tag;

                System.Diagnostics.Debug.Assert(cc == cmd);

                DescriptionValuePair dvp = (DescriptionValuePair) frm.cbCommandType.Items[frm.cbCommandType.SelectedIndex];
                cc.Action = dvp.WhichTag;

                byte addData = 0;
                if (frm.tbAdditionalParameter.Text != "")
                {
                    try
                    {
                        addData = byte.Parse(frm.tbAdditionalParameter.Text);
                    }
                    catch { }
                }

                cc.AdditionalData = addData;
                lvi.SubItems[1].Text = cc.ToString();
                lvi.SubItems[2].Text = cc.AdditionalData.ToString();

            } // else
        }

        private void btnAddCompositeCommand_Click(object sender, EventArgs e)
        {
            AddOneCommandForm aoc = new AddOneCommandForm(null, this);
            aoc.ShowDialog();
        }

        private void btnEditCompositeCommand_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.Assert(lvCommandsList.SelectedItems.Count > 0);
            ListViewItem lvi = lvCommandsList.SelectedItems[0];
            CompositeCommand cc = (CompositeCommand)lvi.Tag;
            AddOneCommandForm aoc = new AddOneCommandForm(cc, this);
            aoc.ShowDialog();
        }

        private void btnDeleteCompositeCommand_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.Assert(lvCommandsList.SelectedItems.Count > 0);
            ListViewItem lvi = lvCommandsList.SelectedItems[0];
            lvi.Remove();

            for (int i = 0; i < lvCommandsList.Items.Count; i++)
            {
                lvCommandsList.Items[i].Text = "#" + i.ToString();
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (this.tbCommandName.Text.Trim() == "")
            {
                MessageBox.Show("Пожалуйста, укажите имя команды!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (this.lvCommandsList.Items.Count < 1)
            {
                MessageBox.Show("Пожалуйста, укажите хотя бы одно действие на выполнение!", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.mainForm.DoneCompositeCommandEdit(this, this.commandToEdit);
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
