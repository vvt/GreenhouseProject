﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace GreenHouseConfig
{
    public partial class CustomSMSForm : Form
    {
        private MainForm mainForm = null;
        private bool canClose = false;
        public CustomSMSForm(MainForm f)
        {
            InitializeComponent();

            mainForm = f;
        }

        private void CustomSMSForm_Load(object sender, EventArgs e)
        {

            cbCustomSMSCommandType.Items.Add(new SmsCommand("Открыть окна","CTSET=STATE|WINDOW|ALL|OPEN"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Закрыть окна", "CTSET=STATE|WINDOW|ALL|CLOSE"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выставить на пинах высокий уровень", "CTSET=PIN|{0}|ON",true,"Введите номера пинов, через запятую!"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выставить на пинах низкий уровень", "CTSET=PIN|{0}|OFF", true, "Введите номера пинов, через запятую!"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выполнить составную команду", "CTSET=CC|EXEC|{0}", true, "Введите индекс составной команды!"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Включить полив", "CTSET=WATER|ON"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выключить полив", "CTSET=WATER|OFF"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Включить досветку", "CTSET=LIGHT|ON"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выключить досветку", "CTSET=LIGHT|OFF"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Включить все правила", "CTSET=ALERT|RULE_STATE|ALL|ON"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Выключить все правила", "CTSET=ALERT|RULE_STATE|ALL|OFF"));
            cbCustomSMSCommandType.Items.Add(new SmsCommand("Перевести контроллер в автоматический режим работы", "CTSET=0|AUTO"));

            cbCustomSMSCommandType.SelectedIndex = 0;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            SmsCommand sms = (SmsCommand)cbCustomSMSCommandType.Items[cbCustomSMSCommandType.SelectedIndex];
            if (sms.HasAdditionalParam && tbAdditionalParam.Text.Trim().Length < 1)
            {
                string mess = "Укажите дополнительный параметр!";
                if (sms.Hint.Length > 0)
                    mess = sms.Hint;
                MessageBox.Show(mess);
                return;
            }

            if (tbSMSText.Text.Trim().Length < 1)
            {
                MessageBox.Show("Укажите текст СМС!");
                return;
            }

            string completeCommand = "CTSET=SMS|ADD|";
            string pattern = sms.Command;
            if(sms.HasAdditionalParam)
            {
                pattern = string.Format(sms.Command, tbAdditionalParam.Text.Trim());
            }

            string message = "", answer = "";
            UTF8Encoding enc = new UTF8Encoding();
            try
            {
                byte[] bytes = enc.GetBytes(tbSMSText.Text.Trim());

                message = BitConverter.ToString(bytes);
                message = message.Replace("-", "");

                bytes = enc.GetBytes(tbSMSAnswer.Text.Trim());

                answer = BitConverter.ToString(bytes);
                answer = answer.Replace("-", "");
            }
            catch { }

            completeCommand += message;
            completeCommand += "|";
            completeCommand += answer;
            completeCommand += "|";
            completeCommand += pattern;

            btnCancel.Enabled = false;
            btnOK.Enabled = false;

            SmsCommand comm = (SmsCommand) sms.Clone();
            comm.Command = pattern;
            comm.SMSText = tbSMSText.Text.Trim();
            comm.SMSAnswer = tbSMSAnswer.Text.Trim();
            AppSettings.Instance.AddSMSCommand(comm);

            mainForm.AddCustomSMS(completeCommand);

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            canClose = true;
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void CustomSMSForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            mainForm.CloseCustomSMSForm();
        }
        public void CanClose()
        {
            canClose = true;
        }

        private void CustomSMSForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = !canClose;
        }

        private void cbCustomSMSCommandType_SelectedIndexChanged(object sender, EventArgs e)
        {
            SmsCommand sms = (SmsCommand)cbCustomSMSCommandType.Items[cbCustomSMSCommandType.SelectedIndex];
            tbAdditionalParam.Enabled = sms.HasAdditionalParam;
        }
    }

    public class SmsCommand : ICloneable
    {
        [XmlElement("caption")]
        public string Caption { get; set; }
        [XmlElement("command")]
        public string Command { get; set; }
        [XmlAttribute("has_param")]
        public bool HasAdditionalParam { get; set; }
        [XmlAttribute("param")]
        public string AdditionalParam { get; set; }
        [XmlIgnore]
        public string Hint { get; set; }
        [XmlElement("sms_text")]
        public string SMSText { get; set; }
        [XmlElement("sms_answer")]
        public string SMSAnswer { get; set; }

        public SmsCommand()
        {
        }
        public SmsCommand(string caption, string command, bool hasParam = false, string hint="")
        {
            this.Caption = caption;
            this.Command = command;
            this.HasAdditionalParam = hasParam;
            this.Hint = hint;
        }

        public override string ToString()
        {
            return this.Caption;
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
         
    }
}
