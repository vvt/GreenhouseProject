﻿namespace GreenHouseConfig
{
    partial class PHControlForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.nudPHMixPumpTime = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.nudTargetPH = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.nudPHHisteresis = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nudPHReagentPumpTime = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHMixPumpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTargetPH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHHisteresis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHReagentPumpTime)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(260, 148);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 38);
            this.btnCancel.TabIndex = 26;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(168, 148);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(86, 38);
            this.btnOk.TabIndex = 25;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(13, 74);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(219, 13);
            this.label41.TabIndex = 40;
            this.label41.Text = "Время работы насоса перемешивания, с:";
            // 
            // nudPHMixPumpTime
            // 
            this.nudPHMixPumpTime.Location = new System.Drawing.Point(285, 72);
            this.nudPHMixPumpTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudPHMixPumpTime.Name = "nudPHMixPumpTime";
            this.nudPHMixPumpTime.Size = new System.Drawing.Size(61, 20);
            this.nudPHMixPumpTime.TabIndex = 39;
            this.nudPHMixPumpTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(13, 22);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(167, 13);
            this.label44.TabIndex = 44;
            this.label44.Text = "Поддерживаемое значение pH:";
            // 
            // nudTargetPH
            // 
            this.nudTargetPH.DecimalPlaces = 2;
            this.nudTargetPH.Increment = new decimal(new int[] {
            25,
            0,
            0,
            131072});
            this.nudTargetPH.Location = new System.Drawing.Point(285, 20);
            this.nudTargetPH.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.nudTargetPH.Name = "nudTargetPH";
            this.nudTargetPH.Size = new System.Drawing.Size(61, 20);
            this.nudTargetPH.TabIndex = 43;
            this.nudTargetPH.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 46;
            this.label1.Text = "Гистерезис:";
            // 
            // nudPHHisteresis
            // 
            this.nudPHHisteresis.DecimalPlaces = 2;
            this.nudPHHisteresis.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.nudPHHisteresis.Location = new System.Drawing.Point(285, 46);
            this.nudPHHisteresis.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.nudPHHisteresis.Name = "nudPHHisteresis";
            this.nudPHHisteresis.Size = new System.Drawing.Size(61, 20);
            this.nudPHHisteresis.TabIndex = 45;
            this.nudPHHisteresis.Value = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(13, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(241, 32);
            this.label2.TabIndex = 48;
            this.label2.Text = "Время работы насоса подачи реагента, для изменения pH на 0.1, с:";
            // 
            // nudPHReagentPumpTime
            // 
            this.nudPHReagentPumpTime.Location = new System.Drawing.Point(285, 98);
            this.nudPHReagentPumpTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudPHReagentPumpTime.Name = "nudPHReagentPumpTime";
            this.nudPHReagentPumpTime.Size = new System.Drawing.Size(61, 20);
            this.nudPHReagentPumpTime.TabIndex = 47;
            this.nudPHReagentPumpTime.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // PHControlForm
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(359, 199);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nudPHReagentPumpTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudPHHisteresis);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.nudTargetPH);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.nudPHMixPumpTime);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PHControlForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки контроля pH";
            ((System.ComponentModel.ISupportInitialize)(this.nudPHMixPumpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTargetPH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHHisteresis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPHReagentPumpTime)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.NumericUpDown nudPHMixPumpTime;
        public System.Windows.Forms.NumericUpDown nudTargetPH;
        public System.Windows.Forms.NumericUpDown nudPHHisteresis;
        public System.Windows.Forms.NumericUpDown nudPHReagentPumpTime;
    }
}