﻿namespace GreenHouseConfig
{
    partial class MonitorSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbTOut = new System.Windows.Forms.ComboBox();
            this.nudTOut = new System.Windows.Forms.NumericUpDown();
            this.nudTIn = new System.Windows.Forms.NumericUpDown();
            this.cbTIn = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudTOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTIn)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(144, 111);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(90, 32);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(240, 111);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 32);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Т снаружи (модуль/датчик):";
            // 
            // cbTOut
            // 
            this.cbTOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTOut.FormattingEnabled = true;
            this.cbTOut.Items.AddRange(new object[] {
            "Модуль температур",
            "Модуль влажности"});
            this.cbTOut.Location = new System.Drawing.Point(16, 26);
            this.cbTOut.Name = "cbTOut";
            this.cbTOut.Size = new System.Drawing.Size(246, 21);
            this.cbTOut.TabIndex = 5;
            // 
            // nudTOut
            // 
            this.nudTOut.Location = new System.Drawing.Point(268, 27);
            this.nudTOut.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudTOut.Name = "nudTOut";
            this.nudTOut.Size = new System.Drawing.Size(62, 20);
            this.nudTOut.TabIndex = 6;
            // 
            // nudTIn
            // 
            this.nudTIn.Location = new System.Drawing.Point(268, 73);
            this.nudTIn.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudTIn.Name = "nudTIn";
            this.nudTIn.Size = new System.Drawing.Size(62, 20);
            this.nudTIn.TabIndex = 9;
            // 
            // cbTIn
            // 
            this.cbTIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTIn.FormattingEnabled = true;
            this.cbTIn.Items.AddRange(new object[] {
            "Модуль температур",
            "Модуль влажности"});
            this.cbTIn.Location = new System.Drawing.Point(16, 72);
            this.cbTIn.Name = "cbTIn";
            this.cbTIn.Size = new System.Drawing.Size(246, 21);
            this.cbTIn.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Т внутри (модуль/датчик):";
            // 
            // MonitorSettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(343, 156);
            this.Controls.Add(this.nudTIn);
            this.Controls.Add(this.cbTIn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nudTOut);
            this.Controls.Add(this.cbTOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MonitorSettingsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки экрана ожидания";
            this.Load += new System.EventHandler(this.MonitorSettingsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudTOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTIn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbTOut;
        private System.Windows.Forms.NumericUpDown nudTOut;
        private System.Windows.Forms.NumericUpDown nudTIn;
        private System.Windows.Forms.ComboBox cbTIn;
        private System.Windows.Forms.Label label2;
    }
}