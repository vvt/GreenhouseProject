﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using GreenHouseConfig.Properties;

namespace GreenHouseConfig
{
    public partial class DeltaListForm : Form
    {
        public DeltaListForm()
        {
            InitializeComponent();
        }
        private List<DescriptionValuePair> modules = new List<DescriptionValuePair>();

        private string GetDescription(string moduleName)
        {
            foreach (DescriptionValuePair dvp in modules)
            {
                if (dvp.Value == moduleName)
                    return dvp.Description;
            }
            return moduleName;
        }

        private List<DeltaSettings> thisDeltaSettings = new List<DeltaSettings>();

        private void DeltaListForm_Load(object sender, EventArgs e)
        {
            modules.Add(new DescriptionValuePair("STATE", Settings.Default.StateModule, WhichTag.TagTemperature));
            modules.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagHumidity));
            modules.Add(new DescriptionValuePair("LIGHT", Settings.Default.LightModule, WhichTag.TagLight));
            modules.Add(new DescriptionValuePair("SOIL", "Модуль влажности почвы", WhichTag.TagSoilMoisture));

            this.cbWhich.Items.Add(new DescriptionValuePair("TEMP", Settings.Default.SpyTemp2, WhichTag.TagTemperature));
            this.cbWhich.Items.Add(new DescriptionValuePair("LIGHT", Settings.Default.SpyLight2, WhichTag.TagLight));
            this.cbWhich.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.SpyHumidity2, WhichTag.TagHumidity));
            this.cbWhich.Items.Add(new DescriptionValuePair("SOIL", "влажности почвы", WhichTag.TagSoilMoisture));
            

            this.cbWhich.SelectedIndex = 0;


            int cntr = 0;
            foreach (DeltaSettings ds in AppSettings.Instance.DeltaSettings)
            {
                AddDeltaToList(ds, cntr);
                cntr++;
            }

            

           
        }

        private void AddDeltaToList(DeltaSettings ds, int cntr)
        {
            ListViewItem lvi = new ListViewItem();
            lvi.Tag = ds;
            lvi.Text = cntr.ToString();
            lvi.SubItems.Add(GetDescription(ds.ModuleName1));
            lvi.SubItems.Add(ds.SensorIndex1.ToString());
            lvi.SubItems.Add(GetDescription(ds.ModuleName2));
            lvi.SubItems.Add(ds.SensorIndex2.ToString());
            lvDeltasList.Items.Add(lvi);
            

            thisDeltaSettings.Add(ds);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void lvDeltasList_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool anySelection = lvDeltasList.SelectedItems.Count > 0;
            btnDeleteDelta.Enabled = anySelection;
        }

        private void btnDeleteDelta_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvi in lvDeltasList.SelectedItems)
            {
                DeltaSettings ds = (DeltaSettings)lvi.Tag;
                thisDeltaSettings.Remove(ds);
                lvi.Remove();
                break;
            }
        }

        private void btnAddDelta_Click(object sender, EventArgs e)
        {
            if (thisDeltaSettings.Count > 19)
            {
                MessageBox.Show(Settings.Default.DeltaLimitReached, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            int selIdx1 = cbModuleName1.SelectedIndex;
            int selIdx2 = cbModuleName2.SelectedIndex;

            int sensorIdx1 = Convert.ToInt32(nudSensorIndex1.Value);
            int sensorIdx2 = Convert.ToInt32(nudSensorIndex2.Value);

            if (selIdx1 == -1 || selIdx2 == -1)
            {
                MessageBox.Show(Settings.Default.DeltaSelectModules, Settings.Default.Info, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            /*
            if (selIdx1 == selIdx2 && sensorIdx1 == sensorIdx2)
            {
                MessageBox.Show(Settings.Default.DeltaSameSensor, Settings.Default.Error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
             */

            DescriptionValuePair dvp1 = (DescriptionValuePair)cbModuleName1.Items[selIdx1];
            DescriptionValuePair dvp2 = (DescriptionValuePair)cbModuleName2.Items[selIdx2];

            // проверяем, чтобы два тэга были одинаковы
            System.Diagnostics.Debug.Assert(dvp1.WhichTag == dvp2.WhichTag);

            // добавляем новую дельту
            DescriptionValuePair whichP = (DescriptionValuePair)cbWhich.Items[cbWhich.SelectedIndex];
            string sensorType = whichP.Value;
    

            DeltaSettings ds = new DeltaSettings(sensorType,dvp1.Value,dvp2.Value,sensorIdx1,sensorIdx2);

            foreach (DeltaSettings s in this.thisDeltaSettings)
            {
                if (s == ds)
                {
                    MessageBox.Show(Settings.Default.SameDeltaExists,Settings.Default.Error,MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
            }

            //MessageBox.Show(ds.ToString());
            //return;
            AddDeltaToList(ds, lvDeltasList.Items.Count);

        }

        private void cbWhich_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillAvailableModulesList(this.cbWhich.Items[this.cbWhich.SelectedIndex] as DescriptionValuePair);
        }
        private void FillAvailableModulesList(DescriptionValuePair st)
        {
            cbModuleName1.Items.Clear();
            cbModuleName2.Items.Clear();


            if (st.WhichTag == WhichTag.TagTemperature)
            {
                this.cbModuleName1.Items.Add(new DescriptionValuePair("STATE", Settings.Default.StateModule, WhichTag.TagTemperature));
                this.cbModuleName1.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagTemperature));
                this.cbModuleName2.Items.Add(new DescriptionValuePair("STATE", Settings.Default.StateModule, WhichTag.TagTemperature));
                this.cbModuleName2.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagTemperature));
            }
            else
                if (st.WhichTag == WhichTag.TagLight)
                {
                    this.cbModuleName1.Items.Add(new DescriptionValuePair("LIGHT", Settings.Default.LightModule, WhichTag.TagLight));
                    this.cbModuleName2.Items.Add(new DescriptionValuePair("LIGHT", Settings.Default.LightModule, WhichTag.TagLight));
                }
                else
                    if (st.WhichTag == WhichTag.TagHumidity)
                    {
                        this.cbModuleName1.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagHumidity));
                        this.cbModuleName2.Items.Add(new DescriptionValuePair("HUMIDITY", Settings.Default.HumidityModule, WhichTag.TagHumidity));
                    }
                    else
                        if (st.WhichTag == WhichTag.TagSoilMoisture)
                        {
                            this.cbModuleName1.Items.Add(new DescriptionValuePair("SOIL", "Модуль влажности почвы", WhichTag.TagSoilMoisture));
                            this.cbModuleName2.Items.Add(new DescriptionValuePair("SOIL", "Модуль влажности почвы", WhichTag.TagSoilMoisture));
                        }

            if (this.cbModuleName1.Items.Count > 0)
                this.cbModuleName1.SelectedIndex = 0;

            if (this.cbModuleName2.Items.Count > 0)
                this.cbModuleName2.SelectedIndex = 0;

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            AppSettings.Instance.DeltaSettings.Clear();
            AppSettings.Instance.DeltaSettings = thisDeltaSettings;
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

    }
}
