﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class MonitorSettingsForm : Form
    {
        public MonitorSettingsForm()
        {
            InitializeComponent();
        }

        private void MonitorSettingsForm_Load(object sender, EventArgs e)
        {
            cbTIn.SelectedIndex = 0;
            cbTOut.SelectedIndex = 0;

            AppSettings appS = AppSettings.Instance;
            try
            {
                nudTIn.Value = appS.MonitorTempInsideSensor;
            } 
            catch { }

            try
            {
                nudTOut.Value = appS.MonitorTempOutsideSensor;
            }
            catch { }

            if (appS.MonitorTempInsideModule == "HUMIDITY")
                cbTIn.SelectedIndex = 1;

            if (appS.MonitorTempOutsideModule == "HUMIDITY")
                cbTOut.SelectedIndex = 1;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            AppSettings appS = AppSettings.Instance;

            appS.MonitorTempInsideSensor = Convert.ToInt32(nudTIn.Value);
            appS.MonitorTempOutsideSensor = Convert.ToInt32(nudTOut.Value);

            appS.MonitorTempInsideModule = "STATE";
            appS.MonitorTempOutsideModule = "STATE";
            if (cbTIn.SelectedIndex == 1)
                appS.MonitorTempInsideModule = "HUMIDITY";

            if (cbTOut.SelectedIndex == 1)
                appS.MonitorTempOutsideModule = "HUMIDITY";

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
