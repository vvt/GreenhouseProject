﻿namespace GreenHouseConfig
{
    partial class FirmwareInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lvHardcodedSensorsList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnReassignControllerID = new System.Windows.Forms.Button();
            this.nudControllerID = new System.Windows.Forms.NumericUpDown();
            this.lvUniversalSensorsList = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudControllerID)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Жёстко указанные в прошивке датчики:";
            // 
            // lvHardcodedSensorsList
            // 
            this.lvHardcodedSensorsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvHardcodedSensorsList.FullRowSelect = true;
            this.lvHardcodedSensorsList.GridLines = true;
            this.lvHardcodedSensorsList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvHardcodedSensorsList.HideSelection = false;
            this.lvHardcodedSensorsList.LabelWrap = false;
            this.lvHardcodedSensorsList.Location = new System.Drawing.Point(13, 30);
            this.lvHardcodedSensorsList.MultiSelect = false;
            this.lvHardcodedSensorsList.Name = "lvHardcodedSensorsList";
            this.lvHardcodedSensorsList.Size = new System.Drawing.Size(355, 111);
            this.lvHardcodedSensorsList.TabIndex = 1;
            this.lvHardcodedSensorsList.UseCompatibleStateImageBehavior = false;
            this.lvHardcodedSensorsList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Тип датчика";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Кол-во";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnReassignControllerID);
            this.groupBox1.Controls.Add(this.nudControllerID);
            this.groupBox1.Location = new System.Drawing.Point(385, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.Size = new System.Drawing.Size(141, 89);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ID контроллера";
            // 
            // btnReassignControllerID
            // 
            this.btnReassignControllerID.Enabled = false;
            this.btnReassignControllerID.Location = new System.Drawing.Point(13, 52);
            this.btnReassignControllerID.Name = "btnReassignControllerID";
            this.btnReassignControllerID.Size = new System.Drawing.Size(111, 23);
            this.btnReassignControllerID.TabIndex = 6;
            this.btnReassignControllerID.Text = "Переназначить";
            this.btnReassignControllerID.UseVisualStyleBackColor = true;
            this.btnReassignControllerID.Click += new System.EventHandler(this.btnReassignControllerID_Click);
            // 
            // nudControllerID
            // 
            this.nudControllerID.Location = new System.Drawing.Point(13, 26);
            this.nudControllerID.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudControllerID.Name = "nudControllerID";
            this.nudControllerID.Size = new System.Drawing.Size(111, 20);
            this.nudControllerID.TabIndex = 5;
            this.nudControllerID.ValueChanged += new System.EventHandler(this.nudControllerID_ValueChanged);
            // 
            // lvUniversalSensorsList
            // 
            this.lvUniversalSensorsList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lvUniversalSensorsList.FullRowSelect = true;
            this.lvUniversalSensorsList.GridLines = true;
            this.lvUniversalSensorsList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvUniversalSensorsList.HideSelection = false;
            this.lvUniversalSensorsList.LabelWrap = false;
            this.lvUniversalSensorsList.Location = new System.Drawing.Point(13, 173);
            this.lvUniversalSensorsList.MultiSelect = false;
            this.lvUniversalSensorsList.Name = "lvUniversalSensorsList";
            this.lvUniversalSensorsList.Size = new System.Drawing.Size(355, 111);
            this.lvUniversalSensorsList.TabIndex = 7;
            this.lvUniversalSensorsList.UseCompatibleStateImageBehavior = false;
            this.lvUniversalSensorsList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "#";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Тип датчика";
            this.columnHeader5.Width = 200;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Кол-во";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Датчики универсальных модулей:";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(398, 214);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(123, 32);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOk.Location = new System.Drawing.Point(397, 252);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(124, 32);
            this.btnOk.TabIndex = 8;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // FirmwareInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(539, 310);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.lvUniversalSensorsList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lvHardcodedSensorsList);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FirmwareInfoForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки прошивки";
            this.Load += new System.EventHandler(this.FirmwareInfoForm_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudControllerID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lvHardcodedSensorsList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnReassignControllerID;
        private System.Windows.Forms.NumericUpDown nudControllerID;
        private System.Windows.Forms.ListView lvUniversalSensorsList;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
    }
}