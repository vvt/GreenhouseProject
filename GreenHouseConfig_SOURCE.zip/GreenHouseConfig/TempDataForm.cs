﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class TempDataForm : Form
    {
        public TempDataForm()
        {
            InitializeComponent();
        }

        public void AddTemperature(int idx, string temp)
        {
            int cnt = this.lvTempData.Items.Count;
            if (idx >= cnt)
            {
                lvTempData.Items.Add("#" + cnt.ToString());
            }
            //  + " °C"
            ListViewItem li = lvTempData.Items[idx];
            if (li.SubItems.Count < 2)
                li.SubItems.Add(temp);
            else
                li.SubItems[1].Text = temp;
           
        }
    }
}
