﻿namespace GreenHouseConfig
{
    partial class DeltaListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.lvDeltasList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.btnDeleteDelta = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nudSensorIndex1 = new System.Windows.Forms.NumericUpDown();
            this.cbModuleName1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nudSensorIndex2 = new System.Windows.Forms.NumericUpDown();
            this.cbModuleName2 = new System.Windows.Forms.ComboBox();
            this.btnAddDelta = new System.Windows.Forms.Button();
            this.cbWhich = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(393, 344);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 32);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(301, 344);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(86, 32);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lvDeltasList
            // 
            this.lvDeltasList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvDeltasList.FullRowSelect = true;
            this.lvDeltasList.GridLines = true;
            this.lvDeltasList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvDeltasList.HideSelection = false;
            this.lvDeltasList.Location = new System.Drawing.Point(13, 26);
            this.lvDeltasList.MultiSelect = false;
            this.lvDeltasList.Name = "lvDeltasList";
            this.lvDeltasList.ShowItemToolTips = true;
            this.lvDeltasList.Size = new System.Drawing.Size(466, 107);
            this.lvDeltasList.TabIndex = 2;
            this.lvDeltasList.UseCompatibleStateImageBehavior = false;
            this.lvDeltasList.View = System.Windows.Forms.View.Details;
            this.lvDeltasList.SelectedIndexChanged += new System.EventHandler(this.lvDeltasList_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "#";
            this.columnHeader1.Width = 30;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Модуль 1";
            this.columnHeader2.Width = 130;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Датчик №";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Модуль 2";
            this.columnHeader4.Width = 130;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Датчик №";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 70;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Список текущих дельт:";
            // 
            // btnDeleteDelta
            // 
            this.btnDeleteDelta.Enabled = false;
            this.btnDeleteDelta.Image = global::GreenHouseConfig.Properties.Resources.delete_rule;
            this.btnDeleteDelta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteDelta.Location = new System.Drawing.Point(393, 139);
            this.btnDeleteDelta.Name = "btnDeleteDelta";
            this.btnDeleteDelta.Size = new System.Drawing.Size(86, 32);
            this.btnDeleteDelta.TabIndex = 19;
            this.btnDeleteDelta.Text = "Удалить";
            this.btnDeleteDelta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnDeleteDelta, "Удалить выбранную дельту");
            this.btnDeleteDelta.UseVisualStyleBackColor = true;
            this.btnDeleteDelta.Click += new System.EventHandler(this.btnDeleteDelta_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbWhich);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnAddDelta);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nudSensorIndex2);
            this.groupBox1.Controls.Add(this.cbModuleName2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.nudSensorIndex1);
            this.groupBox1.Controls.Add(this.cbModuleName1);
            this.groupBox1.Location = new System.Drawing.Point(13, 173);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.Size = new System.Drawing.Size(466, 161);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Новая дельта";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Модуль и датчик 1:";
            // 
            // nudSensorIndex1
            // 
            this.nudSensorIndex1.Location = new System.Drawing.Point(170, 81);
            this.nudSensorIndex1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudSensorIndex1.Name = "nudSensorIndex1";
            this.nudSensorIndex1.Size = new System.Drawing.Size(45, 20);
            this.nudSensorIndex1.TabIndex = 28;
            // 
            // cbModuleName1
            // 
            this.cbModuleName1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbModuleName1.DropDownWidth = 250;
            this.cbModuleName1.FormattingEnabled = true;
            this.cbModuleName1.Location = new System.Drawing.Point(10, 81);
            this.cbModuleName1.Name = "cbModuleName1";
            this.cbModuleName1.Size = new System.Drawing.Size(154, 21);
            this.cbModuleName1.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(238, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Модуль и датчик 2:";
            // 
            // nudSensorIndex2
            // 
            this.nudSensorIndex2.Location = new System.Drawing.Point(401, 81);
            this.nudSensorIndex2.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudSensorIndex2.Name = "nudSensorIndex2";
            this.nudSensorIndex2.Size = new System.Drawing.Size(45, 20);
            this.nudSensorIndex2.TabIndex = 31;
            // 
            // cbModuleName2
            // 
            this.cbModuleName2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbModuleName2.DropDownWidth = 250;
            this.cbModuleName2.FormattingEnabled = true;
            this.cbModuleName2.Location = new System.Drawing.Point(241, 81);
            this.cbModuleName2.Name = "cbModuleName2";
            this.cbModuleName2.Size = new System.Drawing.Size(154, 21);
            this.cbModuleName2.TabIndex = 30;
            // 
            // btnAddDelta
            // 
            this.btnAddDelta.Image = global::GreenHouseConfig.Properties.Resources.add_rule;
            this.btnAddDelta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddDelta.Location = new System.Drawing.Point(360, 118);
            this.btnAddDelta.Name = "btnAddDelta";
            this.btnAddDelta.Size = new System.Drawing.Size(86, 32);
            this.btnAddDelta.TabIndex = 33;
            this.btnAddDelta.Text = "Добавить";
            this.btnAddDelta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnAddDelta, "Добавить новую дельту");
            this.btnAddDelta.UseVisualStyleBackColor = true;
            this.btnAddDelta.Click += new System.EventHandler(this.btnAddDelta_Click);
            // 
            // cbWhich
            // 
            this.cbWhich.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbWhich.FormattingEnabled = true;
            this.cbWhich.Location = new System.Drawing.Point(13, 36);
            this.cbWhich.Name = "cbWhich";
            this.cbWhich.Size = new System.Drawing.Size(433, 21);
            this.cbWhich.TabIndex = 35;
            this.cbWhich.SelectedIndexChanged += new System.EventHandler(this.cbWhich_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Получаем дельту:";
            // 
            // DeltaListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(496, 391);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDeleteDelta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lvDeltasList);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DeltaListForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Список виртуальных датчиков дельт";
            this.Load += new System.EventHandler(this.DeltaListForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSensorIndex2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.ListView lvDeltasList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btnDeleteDelta;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbWhich;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddDelta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudSensorIndex2;
        private System.Windows.Forms.ComboBox cbModuleName2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudSensorIndex1;
        private System.Windows.Forms.ComboBox cbModuleName1;
    }
}