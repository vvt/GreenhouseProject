﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GreenHouseConfig
{
    public partial class ReservationSettingsForm : Form
    {
        public ReservationSettingsForm()
        {
            InitializeComponent();
        }

        private void lvReservations_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDeleteReservation.Enabled = lvReservations.SelectedItems.Count > 0;
        }

        private void AddReservationToList(ReservationSetting item)
        {
            var enumType = typeof(SensorType);

            var memInfo = enumType.GetMember(item.Type.ToString());
            var atrrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
            string displayName = item.Type.ToString();

            if (atrrs != null && atrrs.Count() > 0)
            {
                DescriptionAttribute enAttr = (DescriptionAttribute)atrrs[0];
                displayName = enAttr.ToString();

            }

            ListViewItem li = this.lvReservations.Items.Add("#" + this.lvReservations.Items.Count);
            li.Tag = item;
            li.SubItems.Add(displayName);

            // теперь проходим по всем индексам датчиков
            string indicies = "";
            foreach (var idx in item.List)
            {
                if (indicies.Length > 0)
                    indicies += ", ";

                indicies += idx.ToString();
            }

            li.SubItems.Add(indicies);
        }

        private void ReservationSettingsForm_Load(object sender, EventArgs e)
        {
           
            foreach (var item in AppSettings.Instance.ReservationSettings)
            {
                AddReservationToList(item);

            } // foreach
        }

        private void btnDeleteReservation_Click(object sender, EventArgs e)
        {
            if (lvReservations.SelectedItems.Count < 1)
                return;

            ListViewItem li = lvReservations.SelectedItems[0];
            AppSettings.Instance.ReservationSettings.Remove((ReservationSetting)li.Tag);
            li.Remove();

            for (int i = 0; i < lvReservations.Items.Count; i++)
            {
                li = lvReservations.Items[i];
                li.Text = "#" + i.ToString();
            } // for
        }

        private void btnAddReservation_Click(object sender, EventArgs e)
        {
            if (this.lvReservations.Items.Count > 9)
            {
                MessageBox.Show("Максимальное кол-во записей резервирования - 10!");
                return;
            }
            AddReservationForm ar = new AddReservationForm();
            if (ar.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // добавляем список резервирования
                SensorTypePair stPair = (SensorTypePair)ar.cbReservationType.Items[ar.cbReservationType.SelectedIndex];
                ReservationSetting rs = new ReservationSetting();
                rs.Type = stPair.Type;
                foreach (int idx in ar.lbSensorsList.CheckedIndices)
                {
                    ReservationInfo ri = (ReservationInfo)ar.lbSensorsList.Items[idx];
                    rs.List.Add(ri);
                }
                AppSettings.Instance.ReservationSettings.Add(rs);
                AddReservationToList(rs);
            } // if
        }
    }
}
