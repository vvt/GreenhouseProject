﻿namespace GreenHouseConfig
{
    partial class CustomSMSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbCustomSMSCommandType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAdditionalParam = new System.Windows.Forms.TextBox();
            this.tbSMSText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSMSAnswer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblHint = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(331, 340);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(124, 38);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.LightGreen;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOK.ForeColor = System.Drawing.Color.Black;
            this.btnOK.Location = new System.Drawing.Point(201, 340);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(124, 38);
            this.btnOK.TabIndex = 17;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Тип команды:";
            // 
            // cbCustomSMSCommandType
            // 
            this.cbCustomSMSCommandType.BackColor = System.Drawing.Color.White;
            this.cbCustomSMSCommandType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCustomSMSCommandType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbCustomSMSCommandType.ForeColor = System.Drawing.Color.Black;
            this.cbCustomSMSCommandType.FormattingEnabled = true;
            this.cbCustomSMSCommandType.Location = new System.Drawing.Point(14, 52);
            this.cbCustomSMSCommandType.Name = "cbCustomSMSCommandType";
            this.cbCustomSMSCommandType.Size = new System.Drawing.Size(413, 21);
            this.cbCustomSMSCommandType.TabIndex = 19;
            this.cbCustomSMSCommandType.SelectedIndexChanged += new System.EventHandler(this.cbCustomSMSCommandType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Дополнительный параметр:";
            // 
            // tbAdditionalParam
            // 
            this.tbAdditionalParam.BackColor = System.Drawing.Color.White;
            this.tbAdditionalParam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAdditionalParam.Enabled = false;
            this.tbAdditionalParam.ForeColor = System.Drawing.Color.Black;
            this.tbAdditionalParam.Location = new System.Drawing.Point(14, 100);
            this.tbAdditionalParam.Name = "tbAdditionalParam";
            this.tbAdditionalParam.Size = new System.Drawing.Size(413, 20);
            this.tbAdditionalParam.TabIndex = 21;
            // 
            // tbSMSText
            // 
            this.tbSMSText.BackColor = System.Drawing.Color.White;
            this.tbSMSText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSMSText.ForeColor = System.Drawing.Color.Black;
            this.tbSMSText.Location = new System.Drawing.Point(14, 147);
            this.tbSMSText.MaxLength = 50;
            this.tbSMSText.Name = "tbSMSText";
            this.tbSMSText.Size = new System.Drawing.Size(413, 20);
            this.tbSMSText.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(11, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Текст СМС:";
            // 
            // tbSMSAnswer
            // 
            this.tbSMSAnswer.BackColor = System.Drawing.Color.White;
            this.tbSMSAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSMSAnswer.ForeColor = System.Drawing.Color.Black;
            this.tbSMSAnswer.Location = new System.Drawing.Point(14, 194);
            this.tbSMSAnswer.MaxLength = 50;
            this.tbSMSAnswer.Name = "tbSMSAnswer";
            this.tbSMSAnswer.Size = new System.Drawing.Size(413, 20);
            this.tbSMSAnswer.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(11, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Что послать в ответ:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.tbSMSAnswer);
            this.panel1.Controls.Add(this.cbCustomSMSCommandType);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tbSMSText);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tbAdditionalParam);
            this.panel1.Location = new System.Drawing.Point(17, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(438, 228);
            this.panel1.TabIndex = 34;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(438, 26);
            this.panel2.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Beige;
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(432, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Настройки СМС";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Location = new System.Drawing.Point(17, 253);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(438, 71);
            this.panel13.TabIndex = 35;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(250)))), ((int)(((byte)(156)))));
            this.panel15.Controls.Add(this.lblHint);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 26);
            this.panel15.Name = "panel15";
            this.panel15.Padding = new System.Windows.Forms.Padding(6);
            this.panel15.Size = new System.Drawing.Size(438, 45);
            this.panel15.TabIndex = 3;
            // 
            // lblHint
            // 
            this.lblHint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(250)))), ((int)(((byte)(156)))));
            this.lblHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHint.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblHint.Location = new System.Drawing.Point(6, 6);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(426, 33);
            this.lblHint.TabIndex = 0;
            this.lblHint.Text = "Дополнительный параметр может содержать номер пина для включения или выключения, " +
    "или номер составной команды.";
            // 
            // panel14
            // 
            this.panel14.AutoSize = true;
            this.panel14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel14.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel14.Controls.Add(this.label14);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Padding = new System.Windows.Forms.Padding(3);
            this.panel14.Size = new System.Drawing.Size(438, 26);
            this.panel14.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.Beige;
            this.label14.Location = new System.Drawing.Point(3, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(432, 20);
            this.label14.TabIndex = 1;
            this.label14.Text = "Подсказка";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CustomSMSForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(472, 394);
            this.ControlBox = false;
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomSMSForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавить команду по СМС";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomSMSForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CustomSMSForm_FormClosed);
            this.Load += new System.EventHandler(this.CustomSMSForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button btnCancel;
        public System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCustomSMSCommandType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAdditionalParam;
        private System.Windows.Forms.TextBox tbSMSText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSMSAnswer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label14;
    }
}