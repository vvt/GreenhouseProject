﻿namespace GreenHouseConfig
{
    partial class CustomSMSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbCustomSMSCommandType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAdditionalParam = new System.Windows.Forms.TextBox();
            this.tbSMSText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSMSAnswer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(305, 217);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(124, 32);
            this.btnCancel.TabIndex = 16;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(175, 217);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(124, 32);
            this.btnOK.TabIndex = 17;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Тип команды:";
            // 
            // cbCustomSMSCommandType
            // 
            this.cbCustomSMSCommandType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCustomSMSCommandType.FormattingEnabled = true;
            this.cbCustomSMSCommandType.Location = new System.Drawing.Point(16, 26);
            this.cbCustomSMSCommandType.Name = "cbCustomSMSCommandType";
            this.cbCustomSMSCommandType.Size = new System.Drawing.Size(413, 21);
            this.cbCustomSMSCommandType.TabIndex = 19;
            this.cbCustomSMSCommandType.SelectedIndexChanged += new System.EventHandler(this.cbCustomSMSCommandType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Дополнительный параметр:";
            // 
            // tbAdditionalParam
            // 
            this.tbAdditionalParam.Enabled = false;
            this.tbAdditionalParam.Location = new System.Drawing.Point(16, 75);
            this.tbAdditionalParam.Name = "tbAdditionalParam";
            this.tbAdditionalParam.Size = new System.Drawing.Size(413, 20);
            this.tbAdditionalParam.TabIndex = 21;
            // 
            // tbSMSText
            // 
            this.tbSMSText.Location = new System.Drawing.Point(16, 114);
            this.tbSMSText.MaxLength = 50;
            this.tbSMSText.Name = "tbSMSText";
            this.tbSMSText.Size = new System.Drawing.Size(413, 20);
            this.tbSMSText.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Текст СМС:";
            // 
            // tbSMSAnswer
            // 
            this.tbSMSAnswer.Location = new System.Drawing.Point(16, 153);
            this.tbSMSAnswer.MaxLength = 50;
            this.tbSMSAnswer.Name = "tbSMSAnswer";
            this.tbSMSAnswer.Size = new System.Drawing.Size(413, 20);
            this.tbSMSAnswer.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Что послать в ответ:";
            // 
            // CustomSMSForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 262);
            this.ControlBox = false;
            this.Controls.Add(this.tbSMSAnswer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbSMSText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbAdditionalParam);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbCustomSMSCommandType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomSMSForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавить команду по СМС";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomSMSForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CustomSMSForm_FormClosed);
            this.Load += new System.EventHandler(this.CustomSMSForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnCancel;
        public System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCustomSMSCommandType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAdditionalParam;
        private System.Windows.Forms.TextBox tbSMSText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSMSAnswer;
        private System.Windows.Forms.Label label4;
    }
}