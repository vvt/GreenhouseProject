﻿namespace GreenHouseConfig
{
    partial class MonitorSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.cbTOut = new System.Windows.Forms.ComboBox();
            this.nudTOut = new System.Windows.Forms.NumericUpDown();
            this.nudTIn = new System.Windows.Forms.NumericUpDown();
            this.cbTIn = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudTOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTIn)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.LightGreen;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.ForeColor = System.Drawing.Color.Black;
            this.btnOk.Location = new System.Drawing.Point(158, 161);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(90, 38);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(254, 161);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // cbTOut
            // 
            this.cbTOut.BackColor = System.Drawing.Color.White;
            this.cbTOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbTOut.ForeColor = System.Drawing.Color.Black;
            this.cbTOut.FormattingEnabled = true;
            this.cbTOut.Items.AddRange(new object[] {
            "Модуль температур",
            "Модуль влажности"});
            this.cbTOut.Location = new System.Drawing.Point(9, 32);
            this.cbTOut.Name = "cbTOut";
            this.cbTOut.Size = new System.Drawing.Size(246, 21);
            this.cbTOut.TabIndex = 5;
            // 
            // nudTOut
            // 
            this.nudTOut.BackColor = System.Drawing.Color.White;
            this.nudTOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudTOut.ForeColor = System.Drawing.Color.Black;
            this.nudTOut.Location = new System.Drawing.Point(261, 33);
            this.nudTOut.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudTOut.Name = "nudTOut";
            this.nudTOut.Size = new System.Drawing.Size(62, 20);
            this.nudTOut.TabIndex = 6;
            // 
            // nudTIn
            // 
            this.nudTIn.Location = new System.Drawing.Point(261, 33);
            this.nudTIn.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudTIn.Name = "nudTIn";
            this.nudTIn.Size = new System.Drawing.Size(62, 20);
            this.nudTIn.TabIndex = 9;
            // 
            // cbTIn
            // 
            this.cbTIn.BackColor = System.Drawing.Color.White;
            this.cbTIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbTIn.ForeColor = System.Drawing.Color.Black;
            this.cbTIn.FormattingEnabled = true;
            this.cbTIn.Items.AddRange(new object[] {
            "Модуль температур",
            "Модуль влажности"});
            this.cbTIn.Location = new System.Drawing.Point(9, 32);
            this.cbTIn.Name = "cbTIn";
            this.cbTIn.Size = new System.Drawing.Size(246, 21);
            this.cbTIn.TabIndex = 8;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.cbTOut);
            this.panel5.Controls.Add(this.nudTOut);
            this.panel5.Location = new System.Drawing.Point(12, 13);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(332, 60);
            this.panel5.TabIndex = 40;
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(3);
            this.panel6.Size = new System.Drawing.Size(332, 26);
            this.panel6.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Beige;
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(326, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Т снаружи (модуль/датчик)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.cbTIn);
            this.panel1.Controls.Add(this.nudTIn);
            this.panel1.Location = new System.Drawing.Point(12, 85);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(332, 60);
            this.panel1.TabIndex = 41;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(3);
            this.panel2.Size = new System.Drawing.Size(332, 26);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Beige;
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(326, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Т внутри (модуль/датчик)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MonitorSettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(357, 214);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MonitorSettingsForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Настройки экрана \"Монитор\"";
            this.Load += new System.EventHandler(this.MonitorSettingsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudTOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTIn)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cbTOut;
        private System.Windows.Forms.NumericUpDown nudTOut;
        private System.Windows.Forms.NumericUpDown nudTIn;
        private System.Windows.Forms.ComboBox cbTIn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
    }
}